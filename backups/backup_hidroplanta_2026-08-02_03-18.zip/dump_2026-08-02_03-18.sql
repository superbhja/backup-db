--
-- PostgreSQL database dump
--

\restrict VZhSrn4I2mReAABgHbsvLfw7glc2P1q9umfRYo2cuMqDeGIvndlVp7lphbDnaNu

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- Name: supabase_migrations; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA supabase_migrations;


ALTER SCHEMA supabase_migrations OWNER TO postgres;

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE auth.oauth_authorization_status OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE auth.oauth_client_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE auth.oauth_registration_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


ALTER TYPE auth.oauth_response_type OWNER TO supabase_auth_admin;

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_realtime_admin;

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_realtime_admin;

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text,
	negate boolean
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_realtime_admin;

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_realtime_admin;

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_realtime_admin;

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE storage.buckettype OWNER TO supabase_storage_admin;

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: supabase_admin
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


ALTER FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) OWNER TO supabase_admin;

--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO supabase_admin;

--
-- Name: block_email_update_on_mvp_users(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.block_email_update_on_mvp_users() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.email IS DISTINCT FROM OLD.email THEN
    RAISE EXCEPTION 'No se puede modificar el email desde la aplicación. Para cambiar el email del usuario, usá el panel de Supabase (Auth → Users) y luego sincronizá manualmente mvp_users.email vía SQL.';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.block_email_update_on_mvp_users() OWNER TO postgres;

--
-- Name: calcular_saldo_caja(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calcular_saldo_caja(p_caja_id uuid) RETURNS numeric
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT COALESCE(SUM(monto), 0) FROM mvp_movimientos_caja WHERE caja_id = p_caja_id; $$;


ALTER FUNCTION public.calcular_saldo_caja(p_caja_id uuid) OWNER TO postgres;

--
-- Name: es_tesorero(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.es_tesorero() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
    SELECT COALESCE(
        (SELECT rol_tesorero FROM public.mvp_users WHERE id = auth.uid() LIMIT 1),
        false
    );
$$;


ALTER FUNCTION public.es_tesorero() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mvp_periodo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_periodo (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    codigo character varying NOT NULL,
    fecha_inicio date NOT NULL,
    fecha_fin date NOT NULL,
    estado character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mvp_periodo_estado_check CHECK (((estado)::text = ANY ((ARRAY['ABIERTO'::character varying, 'EN_CIERRE'::character varying, 'CERRADO'::character varying])::text[])))
);


ALTER TABLE public.mvp_periodo OWNER TO postgres;

--
-- Name: fn_abrir_periodo(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_abrir_periodo(p_codigo character varying) RETURNS public.mvp_periodo
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $_$
DECLARE
  v_rol varchar;
  v_inicio date;
  v_fin date;
  v_row mvp_periodo;
BEGIN
  v_rol := get_user_rol();
  IF v_rol NOT IN ('tesorero', 'admin') AND NOT public.es_tesorero() THEN
    RAISE EXCEPTION 'Operacion no autorizada para rol: %', v_rol;
  END IF;

  IF p_codigo !~ '^\d{4}-\d{2}$' THEN
    RAISE EXCEPTION 'Codigo de periodo invalido (esperado YYYY-MM): %', p_codigo;
  END IF;

  IF EXISTS (SELECT 1 FROM mvp_periodo WHERE estado <> 'CERRADO') THEN
    RAISE EXCEPTION 'Ya existe un periodo activo (ABIERTO o EN_CIERRE); cerralo antes de abrir otro';
  END IF;

  IF EXISTS (SELECT 1 FROM mvp_periodo WHERE codigo = p_codigo) THEN
    RAISE EXCEPTION 'El periodo % ya existe', p_codigo;
  END IF;

  v_inicio := to_date(p_codigo || '-01', 'YYYY-MM-DD');
  v_fin := (date_trunc('month', v_inicio) + interval '1 month' - interval '1 day')::date;

  INSERT INTO mvp_periodo (codigo, fecha_inicio, fecha_fin, estado)
  VALUES (p_codigo, v_inicio, v_fin, 'ABIERTO')
  RETURNING * INTO v_row;

  RETURN v_row;
END;
$_$;


ALTER FUNCTION public.fn_abrir_periodo(p_codigo character varying) OWNER TO postgres;

--
-- Name: fn_actualizar_mi_telefono(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_actualizar_mi_telefono(p_telefono text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  UPDATE mvp_users
  SET telefono = p_telefono,
      updated_at = now()
  WHERE id = auth.uid();
END;
$$;


ALTER FUNCTION public.fn_actualizar_mi_telefono(p_telefono text) OWNER TO postgres;

--
-- Name: fn_actualizar_usuario(uuid, text, uuid, numeric, numeric, boolean, boolean, text, boolean, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_actualizar_usuario(p_user_id uuid, p_nombre text DEFAULT NULL::text, p_cliente_id uuid DEFAULT NULL::uuid, p_porc_ganancia numeric DEFAULT NULL::numeric, p_porc_venta numeric DEFAULT NULL::numeric, p_activo boolean DEFAULT NULL::boolean, p_es_repartidor boolean DEFAULT NULL::boolean, p_telefono text DEFAULT NULL::text, p_rol_tesorero boolean DEFAULT NULL::boolean, p_es_tester boolean DEFAULT NULL::boolean) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth', 'pg_temp'
    AS $$
DECLARE
  v_rol_ejecutor       text;
  v_user_id_ejecutor   uuid;
  v_rol_afectado       text;
  v_cliente_id_actual  uuid;
  v_activo_actual      boolean;
  v_caja_repartidor_id uuid;
  v_saldo_repartidor   numeric;
  v_entregas_pendientes integer;
  v_tiene_capacidad_rep boolean;
BEGIN
  -- ===========================================================
  -- FASE 1: Validación del ejecutor.
  -- ===========================================================
  v_rol_ejecutor := get_user_rol();
  v_user_id_ejecutor := auth.uid();

  IF v_rol_ejecutor IS NULL OR v_rol_ejecutor NOT IN ('admin', 'socio') THEN
    RAISE EXCEPTION 'Solo admin o socio pueden actualizar usuarios. Rol del ejecutor: %.', COALESCE(v_rol_ejecutor, 'sin sesión');
  END IF;

  -- ===========================================================
  -- FASE 2: Validación de inputs básicos.
  -- ===========================================================
  IF p_user_id IS NULL THEN
    RAISE EXCEPTION 'p_user_id es obligatorio.';
  END IF;

  IF p_nombre IS NOT NULL AND length(trim(p_nombre)) = 0 THEN
    RAISE EXCEPTION 'El nombre no puede ser cadena vacía. Para no cambiarlo, pasar NULL.';
  END IF;

  IF p_porc_ganancia IS NOT NULL AND (p_porc_ganancia < 0 OR p_porc_ganancia > 100) THEN
    RAISE EXCEPTION 'porc_ganancia debe estar entre 0 y 100. Valor recibido: %.', p_porc_ganancia;
  END IF;

  IF p_porc_venta IS NOT NULL AND (p_porc_venta < 0 OR p_porc_venta > 100) THEN
    RAISE EXCEPTION 'porc_venta debe estar entre 0 y 100. Valor recibido: %.', p_porc_venta;
  END IF;

  -- Si todos los parámetros opcionales son NULL, no hay nada que actualizar.
  IF p_nombre IS NULL 
     AND p_cliente_id IS NULL 
     AND p_porc_ganancia IS NULL 
     AND p_porc_venta IS NULL 
     AND p_activo IS NULL 
     AND p_es_repartidor IS NULL 
     AND p_telefono IS NULL                   -- RN-U08
     AND p_rol_tesorero IS NULL
     AND p_es_tester IS NULL
  THEN
    RAISE EXCEPTION 'No se especificó ningún campo a actualizar.';
  END IF;

  -- ===========================================================
  -- FASE 3: Validación de existencia y obtención de estado actual.
  -- ===========================================================
  SELECT rol, cliente_id, activo
  INTO v_rol_afectado, v_cliente_id_actual, v_activo_actual
  FROM public.mvp_users
  WHERE id = p_user_id;

  IF v_rol_afectado IS NULL THEN
    RAISE EXCEPTION 'No existe usuario con id %.', p_user_id;
  END IF;

  -- Verificar si el usuario tiene capacidad repartidor activa actualmente.
  SELECT EXISTS (
    SELECT 1 FROM public.mvp_repartidores
    WHERE user_id = p_user_id AND activo = true
  ) INTO v_tiene_capacidad_rep;

  -- ===========================================================
  -- FASE 4: Validación de permisos por rol del ejecutor.
  -- ===========================================================
  -- 4.1) Si ejecutor es socio: solo puede actualizar operadores.
  IF v_rol_ejecutor = 'socio' AND v_rol_afectado IS DISTINCT FROM 'operador' THEN
    RAISE EXCEPTION 'Los socios solo pueden actualizar usuarios con rol operador. Rol del afectado: %.', v_rol_afectado;
  END IF;

  -- 4.2) Si se quiere togglear capacidad repartidor: solo admin (Decisión 6 sesión anterior).
  IF p_es_repartidor IS NOT NULL AND v_rol_ejecutor != 'admin' THEN
    RAISE EXCEPTION 'Solo el administrador puede activar o desactivar capacidad repartidor. Rol del ejecutor: %.', v_rol_ejecutor;
  END IF;

  -- 4.3) Si se quiere togglear activo: solo admin.
  IF p_activo IS NOT NULL AND v_rol_ejecutor != 'admin' THEN
    RAISE EXCEPTION 'Solo el administrador puede activar o desactivar usuarios. Rol del ejecutor: %.', v_rol_ejecutor;
  END IF;

  -- 4.3 bis) Togglear capacidad Tesorero: solo admin (RN-U09, B-3).
  IF p_rol_tesorero IS NOT NULL AND v_rol_ejecutor != 'admin' THEN
    RAISE EXCEPTION 'Solo el administrador puede activar o desactivar la capacidad de Tesorero (RN-U09).';
  END IF;

  -- 4.3 ter) Togglear capacidad Tester: solo admin (RN-U10).
  IF p_es_tester IS NOT NULL AND v_rol_ejecutor != 'admin' THEN
    RAISE EXCEPTION 'Solo el administrador puede activar o desactivar la capacidad TESTER (RN-U10).';
  END IF;

  -- 4.4) Si se quieren actualizar porcentajes: solo si rol del afectado es socio.
  IF (p_porc_ganancia IS NOT NULL OR p_porc_venta IS NOT NULL) AND v_rol_afectado != 'socio' THEN
    RAISE EXCEPTION 'Los porcentajes solo aplican a usuarios con rol socio. Rol del afectado: %.', v_rol_afectado;
  END IF;

  -- 4.5) Si se quiere actualizar cliente_id: solo si rol del afectado es operador.
  IF p_cliente_id IS NOT NULL AND v_rol_afectado != 'operador' THEN
    RAISE EXCEPTION 'cliente_id solo aplica a usuarios con rol operador. Rol del afectado: %.', v_rol_afectado;
  END IF;

  -- ===========================================================
  -- FASE 4 BIS: Validaciones de lógica de negocio.
  -- ===========================================================

  -- 4.6) Validar nuevo cliente_id si se provee (existe y activo + unicidad 1:1).
  IF p_cliente_id IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.mvp_clientes
      WHERE id = p_cliente_id AND activo = true
    ) THEN
      RAISE EXCEPTION 'El cliente_id % no existe o no está activo.', p_cliente_id;
    END IF;

    -- Unicidad 1:1: ningún OTRO operador activo apunta al mismo cliente.
    IF EXISTS (
      SELECT 1 FROM public.mvp_users
      WHERE rol = 'operador'
        AND cliente_id = p_cliente_id
        AND activo = true
        AND id != p_user_id
    ) THEN
      RAISE EXCEPTION 'Ya existe un operador activo para el cliente %. Desactivá el actual antes de reasignar.', p_cliente_id;
    END IF;
  END IF;

  -- 4.7) Si se quiere activar capacidad repartidor: validar que rol no sea operador.
  IF p_es_repartidor = true AND v_rol_afectado = 'operador' THEN
    RAISE EXCEPTION 'Un usuario con rol operador no puede tener capacidad repartidor (RN-U05.1).';
  END IF;

  -- 4.8) Si se quiere desactivar capacidad repartidor (RN-U06):
  --      validar caja Repartidor en cero + sin entregas pendientes.
  IF p_es_repartidor = false AND v_tiene_capacidad_rep = true THEN
    -- Localizar caja Repartidor del usuario.
    SELECT id INTO v_caja_repartidor_id
    FROM public.mvp_cajas
    WHERE user_id = p_user_id AND tipo = 'REPARTIDOR'
    LIMIT 1;

    IF v_caja_repartidor_id IS NOT NULL THEN
      v_saldo_repartidor := public.calcular_saldo_caja(v_caja_repartidor_id);
      IF v_saldo_repartidor != 0 THEN
        RAISE EXCEPTION 'No se puede desactivar capacidad repartidor: la caja Repartidor tiene saldo % distinto de cero. Rendir antes de desactivar.', v_saldo_repartidor;
      END IF;
    END IF;

    -- Verificar entregas pendientes (ASIGNADO o ENTREGADA).
    SELECT COUNT(*) INTO v_entregas_pendientes
    FROM public.mvp_ventas
    WHERE repartidor_id = p_user_id
      AND estado IN ('ASIGNADO', 'ENTREGADA');

    IF v_entregas_pendientes > 0 THEN
      RAISE EXCEPTION 'No se puede desactivar capacidad repartidor: tiene % ventas en estado ASIGNADO o ENTREGADA. Completar entregas antes de desactivar.', v_entregas_pendientes;
    END IF;
  END IF;

  -- 4.9) Si se quiere desactivar usuario (p_activo=false) Y tiene capacidad repartidor activa:
  --      rechazar (Decisión 6).
  IF p_activo = false AND v_activo_actual = true AND v_tiene_capacidad_rep = true THEN
    RAISE EXCEPTION 'El usuario tiene capacidad repartidor activa. Desactivá la capacidad repartidor primero (caja en cero + sin entregas pendientes).';
  END IF;

  -- 4.10) Activar capacidad Tesorero: afectado debe ser Socio + unicidad (RN-U09, B-3).
  IF p_rol_tesorero = true THEN
    IF v_rol_afectado != 'socio' THEN
      RAISE EXCEPTION 'La capacidad de Tesorero solo puede asignarse a un Socio. Rol del afectado: %.', v_rol_afectado;
    END IF;
    IF EXISTS (SELECT 1 FROM public.mvp_users WHERE rol_tesorero = true AND id != p_user_id) THEN
      RAISE EXCEPTION 'Ya existe un Tesorero. Desactiva el actual antes de asignar uno nuevo.';
    END IF;
  END IF;

  -- 4.11) Activar capacidad Tester: afectado debe ser Socio + unicidad (RN-U10).
  IF p_es_tester = true THEN
    IF v_rol_afectado != 'socio' THEN
      RAISE EXCEPTION 'La capacidad TESTER solo puede asignarse a un Socio. Rol del afectado: %.', v_rol_afectado;
    END IF;
    IF EXISTS (SELECT 1 FROM public.mvp_users WHERE es_tester = true AND id != p_user_id) THEN
      RAISE EXCEPTION 'Ya existe un TESTER. Desactivá el actual antes de asignar uno nuevo (RN-U10).';
    END IF;
  END IF;

  -- ===========================================================
  -- FASE 5: Aplicación de cambios (validaciones pasadas).
  -- ===========================================================

  -- 5.1) Actualizar mvp_users (nombre, cliente_id, telefono, activo, rol_tesorero, es_tester).
  UPDATE public.mvp_users
  SET
    nombre     = COALESCE(trim(p_nombre), nombre),
    cliente_id = CASE 
                   WHEN p_cliente_id IS NOT NULL THEN p_cliente_id
                   ELSE cliente_id
                 END,
    telefono   = COALESCE(p_telefono, telefono),   -- RN-U08
    activo     = COALESCE(p_activo, activo),
    rol_tesorero = COALESCE(p_rol_tesorero, rol_tesorero),
    es_tester    = COALESCE(p_es_tester, es_tester),
    updated_at = now()
  WHERE id = p_user_id;

  -- 5.2) Actualizar mvp_socios (porcentajes), solo si afectado es socio.
  IF v_rol_afectado = 'socio' AND (p_porc_ganancia IS NOT NULL OR p_porc_venta IS NOT NULL) THEN
    UPDATE public.mvp_socios
    SET
      porc_ganancia = COALESCE(p_porc_ganancia, porc_ganancia),
      porc_venta    = COALESCE(p_porc_venta, porc_venta),
      updated_at    = now()
    WHERE user_id = p_user_id;
  END IF;

  -- 5.3) Activar capacidad repartidor.
  IF p_es_repartidor = true AND v_tiene_capacidad_rep = false THEN
    -- Insertar fila en mvp_repartidores.
    INSERT INTO public.mvp_repartidores (user_id, activo)
    VALUES (p_user_id, true);

    -- Crear caja Repartidor con nombre estándar.
    INSERT INTO public.mvp_cajas (nombre, tipo, user_id)
    VALUES (
      'Caja Repartidor — ' || trim((SELECT nombre FROM public.mvp_users WHERE id = p_user_id)),
      'REPARTIDOR',
      p_user_id
    );
  END IF;

  -- 5.4) Desactivar capacidad repartidor (baja lógica, validaciones ya pasadas).
  IF p_es_repartidor = false AND v_tiene_capacidad_rep = true THEN
    UPDATE public.mvp_repartidores
    SET activo = false,
        updated_at = now()
    WHERE user_id = p_user_id;
    -- Nota: la caja Repartidor NO se borra ni desactiva. Queda inerte (saldo cero).
  END IF;

  RETURN p_user_id;
END;
$$;


ALTER FUNCTION public.fn_actualizar_usuario(p_user_id uuid, p_nombre text, p_cliente_id uuid, p_porc_ganancia numeric, p_porc_venta numeric, p_activo boolean, p_es_repartidor boolean, p_telefono text, p_rol_tesorero boolean, p_es_tester boolean) OWNER TO postgres;

--
-- Name: fn_anular_venta(uuid, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_anular_venta(p_venta_id uuid, p_motivo character varying) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  v_rol varchar;
  v_estado varchar;
BEGIN
  SELECT rol INTO v_rol FROM mvp_users WHERE id = auth.uid();
  IF v_rol IS NULL OR v_rol NOT IN ('admin', 'socio', 'tesorero') THEN
    RAISE EXCEPTION 'No autorizado para anular pedidos';
  END IF;
  SELECT estado INTO v_estado FROM mvp_ventas WHERE id = p_venta_id FOR UPDATE;
  IF v_estado IS NULL THEN
    RAISE EXCEPTION 'La venta no existe';
  END IF;
  IF v_estado <> 'PEDIDO' THEN
    RAISE EXCEPTION 'Solo se puede anular un pedido en estado PEDIDO (estado actual: %)', v_estado;
  END IF;
  IF p_motivo NOT IN ('DESISTIMIENTO_CLIENTE', 'FALTA_STOCK') THEN
    RAISE EXCEPTION 'Motivo de anulacion invalido: %', p_motivo;
  END IF;
  UPDATE mvp_ventas
     SET estado = 'ANULADA',
         motivo_anulacion = p_motivo,
         fecha_anulacion = (now() AT TIME ZONE 'America/Argentina/Buenos_Aires')::date,
         updated_at = now()
   WHERE id = p_venta_id;
END;
$$;


ALTER FUNCTION public.fn_anular_venta(p_venta_id uuid, p_motivo character varying) OWNER TO postgres;

--
-- Name: fn_asignar_reparto(uuid, uuid, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_asignar_reparto(p_venta_id uuid, p_repartidor_id uuid, p_nro_factura character varying) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol      varchar;
    v_user_id  uuid;
    v_venta    mvp_ventas%ROWTYPE;
    v_cap_ok   boolean;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'No autenticado' USING ERRCODE = '28000';
    END IF;
    v_rol := public.get_user_rol();
    IF v_rol NOT IN ('socio', 'admin', 'tesorero') THEN
        RAISE EXCEPTION 'Rol % no autorizado para asignar reparto', v_rol USING ERRCODE = '42501';
    END IF;
    IF p_nro_factura IS NULL OR btrim(p_nro_factura) = '' THEN
        RAISE EXCEPTION 'El número de factura es obligatorio para asignar reparto' USING ERRCODE = '22023';
    END IF;
    SELECT * INTO v_venta FROM mvp_ventas WHERE id = p_venta_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Venta % no existe', p_venta_id USING ERRCODE = 'P0002';
    END IF;
    IF v_venta.estado NOT IN ('PEDIDO', 'ASIGNADO') THEN
        RAISE EXCEPTION 'La venta % está en estado % y no admite (re)asignación', p_venta_id, v_venta.estado USING ERRCODE = '22023';
    END IF;
    SELECT true INTO v_cap_ok
    FROM mvp_repartidores r
    WHERE r.user_id = p_repartidor_id AND r.activo = true;
    IF v_cap_ok IS NOT TRUE THEN
        RAISE EXCEPTION 'El usuario % no tiene capacidad de repartidor activa', p_repartidor_id USING ERRCODE = '22023';
    END IF;
    UPDATE mvp_ventas
    SET estado = 'ASIGNADO',
        repartidor_id = p_repartidor_id,
        nro_factura = p_nro_factura,
        fecha_asignacion = COALESCE(v_venta.fecha_asignacion, (now() AT TIME ZONE 'America/Argentina/Buenos_Aires')::date),
        updated_at = now()
    WHERE id = p_venta_id;
    RETURN json_build_object(
        'ok', true, 'venta_id', p_venta_id,
        'estado', 'ASIGNADO', 'repartidor_id', p_repartidor_id, 'nro_factura', p_nro_factura
    );
END;
$$;


ALTER FUNCTION public.fn_asignar_reparto(p_venta_id uuid, p_repartidor_id uuid, p_nro_factura character varying) OWNER TO postgres;

--
-- Name: fn_baja_venta(uuid, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_baja_venta(p_venta_id uuid, p_clave text, p_motivo text DEFAULT NULL::text) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_uid         uuid := auth.uid();
    v_rol         varchar;
    v_hash        text;
    v_venta       mvp_ventas%ROWTYPE;
    v_periodo     mvp_periodo%ROWTYPE;
    v_op_id       uuid;
    v_op_periodo  uuid;
    v_op_count    integer;
    v_mov         record;
    v_caja_tipo   varchar;
    v_caja_nombre varchar;
    v_n_items     integer;
    v_n_mov       integer := 0;
    v_snapshot    jsonb;
    v_caja_id     uuid;
    v_caja_nom    varchar;
    v_del_mov     integer := 0;
    v_del_op      integer := 0;
    v_del_venta   integer := 0;
    v_rend        record;        -- D-L.1: par TRANSFERENCIA de una venta rendida
    v_caja_deleg  uuid;          -- D-L.1: caja SOCIO destino de la rendición
    v_caja_deleg_nom varchar;
    v_del_transf  integer := 0;  -- D-L.1: movimientos TRANSFERENCIA borrados (0 o 2)
BEGIN
    -- 1. Autenticación y rol
    IF v_uid IS NULL THEN
        RAISE EXCEPTION 'No autenticado' USING ERRCODE = '28000';
    END IF;
    v_rol := public.get_user_rol();
    IF v_rol IS NULL OR v_rol <> 'admin' THEN
        RAISE EXCEPTION 'Operación reservada al Administrador' USING ERRCODE = '42501';
    END IF;

    -- 2. Segunda credencial
    SELECT clave_baja_venta_hash INTO v_hash FROM mvp_config_seguridad WHERE id = 1;
    IF v_hash IS NULL THEN
        RAISE EXCEPTION 'Credencial de confirmación no configurada' USING ERRCODE = 'P0002';
    END IF;
    IF p_clave IS NULL OR extensions.crypt(p_clave, v_hash) <> v_hash THEN
        RAISE EXCEPTION 'Clave de confirmación inválida' USING ERRCODE = '28000';
    END IF;

    -- 3. Venta y lock
    SELECT * INTO v_venta FROM mvp_ventas WHERE id = p_venta_id FOR UPDATE;
    IF v_venta.id IS NULL THEN
        RAISE EXCEPTION 'La venta no existe' USING ERRCODE = 'P0002';
    END IF;
    IF v_venta.estado NOT IN ('ASIGNADO', 'ENTREGADA', 'COBRADO') THEN
        RAISE EXCEPTION 'No se puede dar de baja una venta en estado % (habilitados: ASIGNADO, ENTREGADA, COBRADO)',
            v_venta.estado USING ERRCODE = '22023';
    END IF;

    -- 4. Período vigente
    SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'No hay período ABIERTO (cierre en curso o cerrado)' USING ERRCODE = 'P0001';
    END IF;
    IF v_venta.fecha_entrega < v_periodo.fecha_inicio OR v_venta.fecha_entrega > v_periodo.fecha_fin THEN
        RAISE EXCEPTION 'La venta (% ) está fuera del período abierto (% a %)',
            v_venta.fecha_entrega, v_periodo.fecha_inicio, v_periodo.fecha_fin USING ERRCODE = '22023';
    END IF;

    -- 5. Operación de caja asociada (0 o 1)
    SELECT count(*) INTO v_op_count
      FROM mvp_operacion_caja
     WHERE documento_tipo = 'VENTA' AND documento_id = p_venta_id;
    IF v_op_count > 1 THEN
        RAISE EXCEPTION 'La venta tiene % operaciones de caja asociadas; requiere revisión manual', v_op_count
            USING ERRCODE = 'P0001';
    END IF;

    IF v_op_count = 1 THEN
        SELECT id, periodo_id INTO v_op_id, v_op_periodo
          FROM mvp_operacion_caja
         WHERE documento_tipo = 'VENTA' AND documento_id = p_venta_id
           FOR UPDATE;

        IF v_op_periodo <> v_periodo.id THEN
            RAISE EXCEPTION 'La operación de caja pertenece a un período distinto del vigente'
                USING ERRCODE = '22023';
        END IF;

        IF EXISTS (SELECT 1 FROM mvp_ctacte WHERE operacion_id = v_op_id) THEN
            RAISE EXCEPTION 'La operación tiene asientos de cuenta corriente; no se puede dar de baja'
                USING ERRCODE = 'P0001';
        END IF;

        -- 6. Guarda "Caja No Rendida" (dos ramas) + saldo no negativo
        FOR v_mov IN
            SELECT m.id, m.caja_id, m.monto, m.fecha
              FROM mvp_movimientos_caja m
             WHERE m.operacion_id = v_op_id
        LOOP
            v_n_mov := v_n_mov + 1;

            SELECT c.tipo, c.nombre INTO v_caja_tipo, v_caja_nombre
              FROM mvp_cajas c WHERE c.id = v_mov.caja_id;

            IF v_caja_tipo = 'SOCIO' THEN
                IF EXISTS (
                    SELECT 1 FROM mvp_rendiciones r
                     WHERE r.caja_id = v_mov.caja_id
                       AND r.periodo_id = v_periodo.id
                       AND r.fecha >= v_mov.fecha
                ) THEN
                    RAISE EXCEPTION 'La caja "%" ya fue rendida después de este movimiento; la baja rompería la rendición',
                        v_caja_nombre USING ERRCODE = 'P0001';
                END IF;

            ELSIF v_caja_tipo = 'REPARTIDOR' THEN
                -- D-L.1: con A-bis la rendición ya no barre en agregado; deja un par
                -- TRANSFERENCIA por venta (referencia_id = venta_id). Si la venta fue
                -- rendida, su plata está en la Caja Delegada destino. Localizamos ese
                -- movimiento y le aplicamos la MISMA guarda que a SOCIO: si la delegada
                -- ya tuvo su rendición mensual posterior, la baja rompería el arqueo.
                SELECT m2.caja_id, c2.nombre
                  INTO v_caja_deleg, v_caja_deleg_nom
                  FROM mvp_movimientos_caja m2
                  JOIN mvp_cajas c2 ON c2.id = m2.caja_id
                 WHERE m2.tipo_referencia = 'TRANSFERENCIA'
                   AND m2.referencia_id = p_venta_id::text
                   AND m2.monto > 0
                 LIMIT 1;

                IF v_caja_deleg IS NOT NULL THEN
                    IF EXISTS (
                        SELECT 1 FROM mvp_rendiciones r
                         WHERE r.caja_id = v_caja_deleg
                           AND r.periodo_id = v_periodo.id
                    ) THEN
                        RAISE EXCEPTION 'La Caja Delegada "%" ya fue rendida en el período; la baja rompería el arqueo',
                            v_caja_deleg_nom USING ERRCODE = 'P0001';
                    END IF;

                    IF (public.calcular_saldo_caja(v_caja_deleg)
                        - (SELECT m3.monto FROM mvp_movimientos_caja m3
                            WHERE m3.caja_id = v_caja_deleg
                              AND m3.tipo_referencia = 'TRANSFERENCIA'
                              AND m3.referencia_id = p_venta_id::text
                            LIMIT 1)) < 0 THEN
                        RAISE EXCEPTION 'La baja dejaría la Caja Delegada "%" con saldo negativo', v_caja_deleg_nom
                            USING ERRCODE = 'P0001';
                    END IF;
                END IF;
            END IF;

            -- D-L.1: la validación de saldo sobre el movimiento VENTA solo aplica si
            -- la venta NO fue rendida. Si tiene par TRANSFERENCIA (v_caja_deleg NOT NULL),
            -- el movimiento VENTA se borra junto con su par que lo compensa: el neto en
            -- la caja REPARTIDOR es cero y el saldo de la delegada ya se validó arriba.
            IF v_caja_deleg IS NULL THEN
                IF (public.calcular_saldo_caja(v_mov.caja_id) - v_mov.monto) < 0 THEN
                    RAISE EXCEPTION 'La baja dejaría la caja "%" con saldo negativo', v_caja_nombre
                        USING ERRCODE = 'P0001';
                END IF;
            END IF;

            IF v_caja_id IS NULL THEN
                v_caja_id  := v_mov.caja_id;
                v_caja_nom := v_caja_nombre;
            END IF;
        END LOOP;
    END IF;

    -- 7. Snapshot
    SELECT count(*) INTO v_n_items FROM mvp_ventas_detalle WHERE venta_id = p_venta_id;

    SELECT jsonb_build_object(
        'venta',       to_jsonb(v),
        'detalle',     COALESCE((SELECT jsonb_agg(to_jsonb(d))
                                   FROM mvp_ventas_detalle d WHERE d.venta_id = v.id), '[]'::jsonb),
        'operacion',   (SELECT to_jsonb(o) FROM mvp_operacion_caja o WHERE o.id = v_op_id),
        'movimientos', COALESCE((SELECT jsonb_agg(to_jsonb(m))
                                   FROM mvp_movimientos_caja m WHERE m.operacion_id = v_op_id), '[]'::jsonb),
        'movimientos_rendicion', COALESCE((SELECT jsonb_agg(to_jsonb(m))
                                   FROM mvp_movimientos_caja m
                                  WHERE m.tipo_referencia = 'TRANSFERENCIA'
                                    AND m.referencia_id = v.id::text), '[]'::jsonb)
    ) INTO v_snapshot
      FROM mvp_ventas v WHERE v.id = p_venta_id;

    -- 8. Bitácora
    INSERT INTO mvp_ventas_bajas (
        venta_id, periodo_id, usuario_baja_id, estado_previo, nro_factura, fecha_entrega,
        cliente_id, cliente_razon_social, socio_id, socio_nombre, repartidor_nombre,
        total, caja_afectada_id, caja_afectada_nombre, motivo, snapshot
    )
    VALUES (
        p_venta_id, v_periodo.id, v_uid, v_venta.estado, v_venta.nro_factura, v_venta.fecha_entrega,
        v_venta.cliente_id,
        (SELECT razon_social FROM mvp_clientes WHERE id = v_venta.cliente_id),
        v_venta.socio_id,
        public.fn_nombre_socio(v_venta.socio_id),
        (SELECT nombre FROM mvp_users WHERE id = v_venta.repartidor_id),
        v_venta.total, v_caja_id, v_caja_nom, NULLIF(btrim(COALESCE(p_motivo, '')), ''), v_snapshot
    );

    -- 9. Borrado en orden FK-safe
    -- D-L.1: primero, el par TRANSFERENCIA de la venta rendida (si existe).
    -- Se borran los movimientos por referencia_id, SIN tocar la operación de
    -- rendición: ésta puede agrupar otras ventas que siguen rendidas.
    DELETE FROM mvp_movimientos_caja
     WHERE tipo_referencia = 'TRANSFERENCIA'
       AND referencia_id = p_venta_id::text;
    GET DIAGNOSTICS v_del_transf = ROW_COUNT;
    IF v_del_transf NOT IN (0, 2) THEN
        RAISE EXCEPTION 'Inconsistencia: se esperaban 0 o 2 movimientos de rendición y se borraron %', v_del_transf
            USING ERRCODE = 'P0001';
    END IF;

    IF v_op_id IS NOT NULL THEN
        DELETE FROM mvp_movimientos_caja WHERE operacion_id = v_op_id;
        GET DIAGNOSTICS v_del_mov = ROW_COUNT;
        IF v_del_mov <> v_n_mov THEN
            RAISE EXCEPTION 'Inconsistencia: se esperaban % movimientos y se borraron %', v_n_mov, v_del_mov
                USING ERRCODE = 'P0001';
        END IF;

        DELETE FROM mvp_operacion_caja WHERE id = v_op_id;
        GET DIAGNOSTICS v_del_op = ROW_COUNT;
        IF v_del_op <> 1 THEN
            RAISE EXCEPTION 'Inconsistencia: no se borró la operación de caja' USING ERRCODE = 'P0001';
        END IF;
    END IF;

    DELETE FROM mvp_ventas WHERE id = p_venta_id;
    GET DIAGNOSTICS v_del_venta = ROW_COUNT;
    IF v_del_venta <> 1 THEN
        RAISE EXCEPTION 'Inconsistencia: no se borró la venta' USING ERRCODE = 'P0001';
    END IF;

    RETURN json_build_object(
        'ok', true,
        'venta_id', p_venta_id,
        'nro_factura', v_venta.nro_factura,
        'estado_previo', v_venta.estado,
        'total', v_venta.total,
        'items_borrados', v_n_items,
        'movimientos_borrados', v_del_mov,
        'movimientos_rendicion_borrados', v_del_transf,
        'operaciones_borradas', v_del_op,
        'caja_afectada', v_caja_nom,
        'periodo', v_periodo.codigo
    );
END;
$$;


ALTER FUNCTION public.fn_baja_venta(p_venta_id uuid, p_clave text, p_motivo text) OWNER TO postgres;

--
-- Name: FUNCTION fn_baja_venta(p_venta_id uuid, p_clave text, p_motivo text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fn_baja_venta(p_venta_id uuid, p_clave text, p_motivo text) IS 'RN-V10. Baja física de una venta con bitácora en mvp_ventas_bajas. Solo admin + segunda credencial (hash bcrypt en mvp_config_seguridad). Estados habilitados: ASIGNADO, ENTREGADA, COBRADO. Guardas: período ABIERTO, caja no rendida (rama SOCIO por mvp_rendiciones, rama REPARTIDOR por TRANSFERENCIA de barrido), saldo resultante no negativo, sin asientos de ctacte. Atómica. El nro_factura queda liberado para recarga.';


--
-- Name: fn_caja_real_cobro(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_caja_real_cobro(p_venta_id uuid) RETURNS text
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  SELECT cj.nombre
  FROM mvp_operacion_caja oc
  JOIN mvp_tipo_operaciones t ON t.id = oc.tipo_operacion_id
  JOIN mvp_cajas cj ON cj.id = oc.caja_destino_id
  WHERE oc.documento_tipo = 'VENTA'
    AND oc.documento_id = p_venta_id
    AND t.codigo = 'COBRO'
    AND oc.estado = 'CONFIRMADA'
  ORDER BY oc.fecha DESC
  LIMIT 1;
$$;


ALTER FUNCTION public.fn_caja_real_cobro(p_venta_id uuid) OWNER TO postgres;

--
-- Name: fn_cancelar_prestamo_socio(uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_cancelar_prestamo_socio(p_operacion_prestamo_id uuid, p_observaciones text DEFAULT NULL::text) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol              varchar;
    v_usuario_id       uuid := auth.uid();
    v_tipo_prestamo    varchar;
    v_estado_prestamo  varchar;
    v_caja_prestamista uuid;
    v_caja_deudor      uuid;
    v_deudor_user      uuid;
    v_monto            numeric;
    v_saldo_deudor     numeric;
    v_tipo_op_id       integer;
    v_cancel_id        uuid := gen_random_uuid();
    v_fecha            timestamptz := NOW();
    v_ya_cancelado     boolean;
BEGIN
    v_rol := get_user_rol();
    IF v_rol <> 'socio' THEN
        RAISE EXCEPTION 'Operación reservada al rol socio. Rol actual: %', v_rol
            USING ERRCODE = 'P0001';
    END IF;

    SELECT t.codigo, oc.estado, oc.caja_origen_id, oc.caja_destino_id
      INTO v_tipo_prestamo, v_estado_prestamo, v_caja_prestamista, v_caja_deudor
    FROM mvp_operacion_caja oc
    JOIN mvp_tipo_operaciones t ON t.id = oc.tipo_operacion_id
    WHERE oc.id = p_operacion_prestamo_id;

    IF v_tipo_prestamo IS NULL THEN
        RAISE EXCEPTION 'Transferencia inexistente: %', p_operacion_prestamo_id
            USING ERRCODE = 'P0001';
    END IF;
    IF v_tipo_prestamo <> 'PRESTAMO_ENTRE_SOCIOS' THEN
        RAISE EXCEPTION 'La operación referida no es una transferencia entre cajas delegadas'
            USING ERRCODE = 'P0001';
    END IF;
    IF v_estado_prestamo <> 'CONFIRMADA' THEN
        RAISE EXCEPTION 'La transferencia no está en estado que permita devolución: %', v_estado_prestamo
            USING ERRCODE = 'P0001';
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM mvp_operacion_caja
        WHERE operacion_relacionada_id = p_operacion_prestamo_id
    ) INTO v_ya_cancelado;
    IF v_ya_cancelado THEN
        RAISE EXCEPTION 'La transferencia ya fue devuelta'
            USING ERRCODE = 'P0001';
    END IF;

    SELECT user_id INTO v_deudor_user
    FROM mvp_cajas WHERE id = v_caja_deudor FOR UPDATE;
    IF v_deudor_user IS DISTINCT FROM v_usuario_id THEN
        RAISE EXCEPTION 'Solo el Socio receptor de la transferencia puede devolverla'
            USING ERRCODE = 'P0001';
    END IF;

    SELECT ABS(monto) INTO v_monto
    FROM mvp_movimientos_caja
    WHERE operacion_id = p_operacion_prestamo_id
      AND caja_id = v_caja_deudor
    LIMIT 1;
    IF v_monto IS NULL OR v_monto <= 0 THEN
        RAISE EXCEPTION 'No se pudo determinar el monto de la transferencia original'
            USING ERRCODE = 'P0001';
    END IF;

    v_saldo_deudor := calcular_saldo_caja(v_caja_deudor);
    IF v_saldo_deudor < v_monto THEN
        RAISE EXCEPTION 'Saldo insuficiente para devolver la transferencia: saldo %, monto %', v_saldo_deudor, v_monto
            USING ERRCODE = 'P0001', HINT = 'SALDO_INSUFICIENTE';
    END IF;

    SELECT id INTO v_tipo_op_id FROM mvp_tipo_operaciones
    WHERE codigo = 'CANCELACION_PRESTAMO_ENTRE_SOCIOS' AND activa = true;
    IF v_tipo_op_id IS NULL THEN
        RAISE EXCEPTION 'Tipo de operación CANCELACION_PRESTAMO_ENTRE_SOCIOS no encontrado en catálogo';
    END IF;

    INSERT INTO mvp_operacion_caja
        (id, tipo_operacion_id, fecha, usuario_id, estado,
         caja_origen_id, caja_destino_id, operacion_relacionada_id, observaciones)
    VALUES
        (v_cancel_id, v_tipo_op_id, v_fecha, v_usuario_id, 'CONFIRMADA',
         v_caja_deudor, v_caja_prestamista, p_operacion_prestamo_id, p_observaciones);

    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), v_caja_deudor, -ABS(v_monto), v_fecha,
         'TRANSFERENCIA', v_cancel_id::text, v_cancel_id);

    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), v_caja_prestamista, ABS(v_monto), v_fecha,
         'TRANSFERENCIA', v_cancel_id::text, v_cancel_id);

    RETURN json_build_object('ok', true, 'operacion_codigo', 'CANCELACION_PRESTAMO_ENTRE_SOCIOS',
                             'operacion_id', v_cancel_id, 'prestamo_id', p_operacion_prestamo_id, 'monto', v_monto);
END;
$$;


ALTER FUNCTION public.fn_cancelar_prestamo_socio(p_operacion_prestamo_id uuid, p_observaciones text) OWNER TO postgres;

--
-- Name: fn_carga_rapida_venta(uuid, date, uuid, jsonb, uuid, character varying, boolean, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_carga_rapida_venta(p_socio_id uuid, p_fecha date, p_cliente_id uuid, p_items jsonb, p_repartidor_id uuid, p_nro_factura character varying, p_cobrada boolean, p_socio_receptor_id uuid DEFAULT NULL::uuid) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_user_id        uuid := auth.uid();
    v_rol            varchar;
    v_periodo        mvp_periodo%ROWTYPE;
    v_total          numeric(15,2) := 0;
    v_estado         varchar;
    v_socio_cobrador uuid := NULL;
    v_venta_id       uuid := gen_random_uuid();
    v_item           jsonb;
    v_prod_activo    boolean;
    v_cant           numeric;
    v_pl             numeric;
    v_pr             numeric;
    v_n_items        integer := 0;
    v_receptor_user  uuid;
    v_caja_id        uuid;
    v_tipo_op_id     integer;
    v_operacion_id   uuid;
    v_movimiento_id  uuid;
BEGIN
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'No autenticado' USING ERRCODE = '28000';
    END IF;
    v_rol := public.get_user_rol();
    IF v_rol IS NULL OR v_rol NOT IN ('admin', 'tesorero') AND NOT public.es_tesorero() THEN
        RAISE EXCEPTION 'Rol % no autorizado para carga rapida de ventas', v_rol USING ERRCODE = '42501';
    END IF;

    SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'No hay periodo ABIERTO' USING ERRCODE = 'P0001';
    END IF;
    IF p_fecha < v_periodo.fecha_inicio OR p_fecha > v_periodo.fecha_fin THEN
        RAISE EXCEPTION 'La fecha % esta fuera del periodo abierto (% a %)',
            p_fecha, v_periodo.fecha_inicio, v_periodo.fecha_fin USING ERRCODE = '22023';
    END IF;

    PERFORM 1 FROM mvp_socios WHERE id = p_socio_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Socio autor % no existe', p_socio_id USING ERRCODE = 'P0002';
    END IF;

    PERFORM 1 FROM mvp_clientes WHERE id = p_cliente_id AND activo = true;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Cliente % no existe o no esta activo', p_cliente_id USING ERRCODE = 'P0002';
    END IF;

    PERFORM 1 FROM mvp_repartidores WHERE user_id = p_repartidor_id AND activo = true;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'El usuario % no tiene capacidad de repartidor activa', p_repartidor_id USING ERRCODE = '22023';
    END IF;

    IF p_nro_factura IS NULL OR btrim(p_nro_factura) = '' THEN
        RAISE EXCEPTION 'El numero de formulario/factura es obligatorio' USING ERRCODE = '22023';
    END IF;

    IF p_items IS NULL OR jsonb_typeof(p_items) <> 'array' OR jsonb_array_length(p_items) = 0 THEN
        RAISE EXCEPTION 'La venta no tiene items' USING ERRCODE = '22023';
    END IF;
    FOR v_item IN SELECT * FROM jsonb_array_elements(p_items)
    LOOP
        SELECT activo INTO v_prod_activo FROM mvp_productos WHERE id = (v_item->>'producto_id')::uuid;
        IF v_prod_activo IS NULL THEN
            RAISE EXCEPTION 'Producto % inexistente', v_item->>'producto_id' USING ERRCODE = 'P0002';
        END IF;
        IF v_prod_activo IS NOT TRUE THEN
            RAISE EXCEPTION 'Producto % inactivo', v_item->>'producto_id' USING ERRCODE = '22023';
        END IF;
        v_cant := (v_item->>'cantidad')::numeric;
        v_pl   := (v_item->>'precio_lista')::numeric;
        v_pr   := (v_item->>'precio_real')::numeric;
        IF v_cant IS NULL OR v_cant <= 0 THEN
            RAISE EXCEPTION 'Cantidad invalida en item %', v_item->>'producto_id' USING ERRCODE = '22023';
        END IF;
        IF v_pl IS NULL OR v_pr IS NULL OR v_pl < 0 OR v_pr < 0 THEN
            RAISE EXCEPTION 'Precios invalidos en item %', v_item->>'producto_id' USING ERRCODE = '22023';
        END IF;
        v_total := v_total + (v_pr * v_cant);
        v_n_items := v_n_items + 1;
    END LOOP;
    IF v_total <= 0 THEN
        RAISE EXCEPTION 'Total invalido (%)', v_total USING ERRCODE = '22023';
    END IF;

    IF p_cobrada THEN
        IF p_socio_receptor_id IS NULL THEN
            RAISE EXCEPTION 'Falta el socio receptor de la caja para una venta cobrada' USING ERRCODE = '22023';
        END IF;
        SELECT s.user_id INTO v_receptor_user FROM mvp_socios s WHERE s.id = p_socio_receptor_id;
        IF v_receptor_user IS NULL THEN
            RAISE EXCEPTION 'Socio receptor % no existe', p_socio_receptor_id USING ERRCODE = 'P0002';
        END IF;
        SELECT c.id INTO v_caja_id FROM mvp_cajas c
        WHERE c.user_id = v_receptor_user AND c.tipo = 'SOCIO';
        IF v_caja_id IS NULL THEN
            RAISE EXCEPTION 'El socio receptor % no tiene Caja Delegada (SOCIO)', p_socio_receptor_id USING ERRCODE = 'P0002';
        END IF;
        v_estado := 'COBRADO';
        v_socio_cobrador := p_socio_receptor_id;
    ELSE
        v_estado := 'ENTREGADA';
        v_socio_cobrador := NULL;
    END IF;

    INSERT INTO mvp_ventas
        (id, cliente_id, socio_id, socio_cobrador_id, fecha_entrega, estado, total, repartidor_id, nro_factura)
    VALUES
        (v_venta_id, p_cliente_id, p_socio_id, v_socio_cobrador, p_fecha, v_estado, v_total, p_repartidor_id, p_nro_factura);

    INSERT INTO mvp_ventas_detalle (venta_id, producto_id, cantidad, precio_lista, precio_real)
    SELECT v_venta_id,
           (it->>'producto_id')::uuid,
           (it->>'cantidad')::numeric,
           (it->>'precio_lista')::numeric,
           (it->>'precio_real')::numeric
    FROM jsonb_array_elements(p_items) it;

    IF p_cobrada THEN
        SELECT id INTO v_tipo_op_id FROM mvp_tipo_operaciones WHERE codigo = 'COBRO' AND activa = true;
        IF v_tipo_op_id IS NULL THEN
            RAISE EXCEPTION 'Tipo de operacion COBRO no encontrado' USING ERRCODE = 'P0002';
        END IF;
        v_operacion_id := gen_random_uuid();
        INSERT INTO mvp_operacion_caja
            (id, tipo_operacion_id, fecha, usuario_id, estado,
             caja_destino_id, tercero_id, tipo_tercero, documento_tipo, documento_id)
        VALUES
            (v_operacion_id, v_tipo_op_id, public.fn_ts_desde_fecha_local(p_fecha), v_user_id, 'CONFIRMADA',
             v_caja_id, p_cliente_id, 'CLIENTE', 'VENTA', v_venta_id);
        INSERT INTO mvp_movimientos_caja
            (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
        VALUES
            (gen_random_uuid(), v_caja_id, v_total, public.fn_ts_desde_fecha_local(p_fecha), 'VENTA', v_venta_id::varchar, v_operacion_id)
        RETURNING id INTO v_movimiento_id;
    END IF;

    RETURN json_build_object(
        'ok', true,
        'venta_id', v_venta_id,
        'estado', v_estado,
        'total', v_total,
        'items', v_n_items,
        'cobrada', p_cobrada,
        'caja_destino_id', v_caja_id,
        'operacion_id', v_operacion_id,
        'movimiento_id', v_movimiento_id
    );
END;
$$;


ALTER FUNCTION public.fn_carga_rapida_venta(p_socio_id uuid, p_fecha date, p_cliente_id uuid, p_items jsonb, p_repartidor_id uuid, p_nro_factura character varying, p_cobrada boolean, p_socio_receptor_id uuid) OWNER TO postgres;

--
-- Name: fn_crear_usuario(uuid, text, text, uuid, numeric, numeric, text, boolean, text, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_crear_usuario(p_user_id uuid, p_rol text, p_nombre text, p_cliente_id uuid DEFAULT NULL::uuid, p_porc_ganancia numeric DEFAULT 0, p_porc_venta numeric DEFAULT 0, p_caja_nombre text DEFAULT NULL::text, p_es_repartidor boolean DEFAULT false, p_telefono text DEFAULT NULL::text, p_rol_tesorero boolean DEFAULT false) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth', 'pg_temp'
    AS $$
DECLARE
  v_rol_ejecutor   text;
  v_email          text;
  v_caja_nombre    text;
  v_crear_repartidor boolean;
BEGIN
  -- ===========================================================
  -- 1) Validación: quién ejecuta debe ser admin o socio activo.
  --    FIX C-7 BIS: protección contra NULL (sesión sin JWT).
  -- ===========================================================
  v_rol_ejecutor := get_user_rol();

  IF v_rol_ejecutor IS NULL OR v_rol_ejecutor NOT IN ('admin', 'socio') THEN
    RAISE EXCEPTION 'Solo admin o socio pueden crear usuarios. Rol del ejecutor: %.', COALESCE(v_rol_ejecutor, 'sin sesión');
  END IF;

  -- 1.1) Si es socio, solo puede crear operadores (RN-A01.1 v1.5).
  IF v_rol_ejecutor = 'socio' AND p_rol IS DISTINCT FROM 'operador' THEN
    RAISE EXCEPTION 'Los socios solo pueden crear usuarios con rol operador. Rol solicitado: %.', p_rol;
  END IF;

  -- 1.2) Solo admin puede activar capacidad repartidor adicional (Decisión 6).
  --      Nota: el rol primario 'repartidor' implica fila en mvp_repartidores
  --      independientemente de p_es_repartidor (ver sección 9).
  IF p_es_repartidor = true AND v_rol_ejecutor != 'admin' THEN
    RAISE EXCEPTION 'Solo el administrador puede activar capacidad repartidor adicional. Rol del ejecutor: %.', v_rol_ejecutor;
  END IF;

  -- ===========================================================
  -- 2) Validación de inputs básicos.
  -- ===========================================================
  IF p_user_id IS NULL THEN
    RAISE EXCEPTION 'El UUID del usuario es obligatorio.';
  END IF;

  IF p_rol IS NULL OR p_rol NOT IN ('admin','socio','operador','repartidor') THEN
    RAISE EXCEPTION 'Rol inválido: %. Valores permitidos: admin, socio, operador, repartidor.', p_rol;
  END IF;

  IF p_nombre IS NULL OR length(trim(p_nombre)) = 0 THEN
    RAISE EXCEPTION 'El nombre es obligatorio.';
  END IF;

  -- 2.1) Defensivo: p_es_repartidor no puede ser NULL (Decisión 5, validación 2).
  IF p_es_repartidor IS NULL THEN
    RAISE EXCEPTION 'p_es_repartidor no puede ser NULL. Pasar true o false explícitamente.';
  END IF;

  -- 2.2) RN-U05.1: operador no puede tener capacidad repartidor (Decisión 5, validación 1).
  IF p_rol = 'operador' AND p_es_repartidor = true THEN
    RAISE EXCEPTION 'Un usuario con rol operador no puede tener capacidad repartidor (RN-U05.1).';
  END IF;

  -- ===========================================================
  -- 3) Validación: p_user_id existe en auth.users.
  -- ===========================================================
  SELECT email INTO v_email
  FROM auth.users
  WHERE id = p_user_id;

  IF v_email IS NULL THEN
    RAISE EXCEPTION 'El UUID ingresado no corresponde a ningún usuario de Supabase Auth.';
  END IF;

  -- ===========================================================
  -- 4) Validación: la fila en mvp_users DEBE existir.
  -- ===========================================================
  IF NOT EXISTS (SELECT 1 FROM public.mvp_users WHERE id = p_user_id) THEN
    RAISE EXCEPTION 'El usuario % no fue creado por el trigger handle_new_user. Flujo D-MVP no respetado.', v_email;
  END IF;

  -- ===========================================================
  -- 5) Validación específica por rol del usuario a crear.
  -- ===========================================================
  IF p_rol = 'operador' THEN
    IF p_cliente_id IS NULL THEN
      RAISE EXCEPTION 'cliente_id es obligatorio para rol operador.';
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM public.mvp_clientes
      WHERE id = p_cliente_id AND activo = true
    ) THEN
      RAISE EXCEPTION 'El cliente_id % no existe o no está activo.', p_cliente_id;
    END IF;

    IF EXISTS (
      SELECT 1 FROM public.mvp_users
      WHERE rol = 'operador'
        AND cliente_id = p_cliente_id
        AND activo = true
        AND id != p_user_id
    ) THEN
      RAISE EXCEPTION 'Ya existe un operador activo para el cliente %. Desactivá el actual antes de crear uno nuevo.', p_cliente_id;
    END IF;
  END IF;

  -- Capacidad Tesorero (RN-U09, B-3): flag ortogonal, solo sobre Socio, unico, activado por admin.
  IF p_rol_tesorero = true THEN
    IF v_rol_ejecutor != 'admin' THEN
      RAISE EXCEPTION 'Solo el administrador puede activar la capacidad de Tesorero (RN-U09).';
    END IF;
    IF p_rol != 'socio' THEN
      RAISE EXCEPTION 'La capacidad de Tesorero solo puede asignarse a un Socio. Rol solicitado: %.', p_rol;
    END IF;
    IF EXISTS (SELECT 1 FROM public.mvp_users WHERE rol_tesorero = true AND id != p_user_id) THEN
      RAISE EXCEPTION 'Ya existe un Tesorero. Desactiva el actual antes de asignar uno nuevo.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM public.mvp_cajas WHERE tipo = 'CENTRAL') THEN
      RAISE EXCEPTION 'No existe Caja Central en el sistema.';
    END IF;
  END IF;

  IF p_rol = 'socio' THEN
    IF p_porc_ganancia < 0 OR p_porc_ganancia > 100 THEN
      RAISE EXCEPTION 'porc_ganancia debe estar entre 0 y 100. Valor recibido: %.', p_porc_ganancia;
    END IF;
    IF p_porc_venta < 0 OR p_porc_venta > 100 THEN
      RAISE EXCEPTION 'porc_venta debe estar entre 0 y 100. Valor recibido: %.', p_porc_venta;
    END IF;
  END IF;

  -- ===========================================================
  -- 5.5) Decidir si crear capacidad repartidor.
  --      - Si rol primario es 'repartidor': SIEMPRE se crea (Decisión 2).
  --      - Si rol es admin/tesorero/socio: depende de p_es_repartidor.
  --      - Si rol es operador: nunca (validado en 2.2).
  -- ===========================================================
  v_crear_repartidor := (p_rol = 'repartidor') OR (p_es_repartidor = true);

  -- 5.6) Defensivo: no debe existir ya fila activa en mvp_repartidores
  --      para este user_id (Decisión 5, validación 4).
  IF v_crear_repartidor = true THEN
    IF EXISTS (
      SELECT 1 FROM public.mvp_repartidores
      WHERE user_id = p_user_id AND activo = true
    ) THEN
      RAISE EXCEPTION 'El usuario % ya tiene capacidad repartidor activa.', v_email;
    END IF;
  END IF;

  -- ===========================================================
  -- 6) UPDATE en mvp_users.
  -- ===========================================================
  UPDATE public.mvp_users
  SET
    nombre = trim(p_nombre),
    rol = p_rol,
    rol_tesorero = COALESCE(p_rol_tesorero, false),
    cliente_id = CASE WHEN p_rol = 'operador' THEN p_cliente_id ELSE NULL END,
    telefono = p_telefono,                    -- RN-U08
    activo = true,
    updated_at = now()
  WHERE id = p_user_id;

  -- ===========================================================
  -- 7) INSERT en mvp_socios (solo si rol='socio').
  -- ===========================================================
  IF p_rol = 'socio' THEN
    INSERT INTO public.mvp_socios (user_id, porc_ganancia, porc_venta)
    VALUES (p_user_id, p_porc_ganancia, p_porc_venta);
  END IF;

  -- ===========================================================
  -- 8) INSERT en mvp_cajas SOCIO (solo si rol='socio').
  -- ===========================================================
  IF p_rol = 'socio' THEN
    v_caja_nombre := COALESCE(NULLIF(trim(p_caja_nombre), ''), 'Caja ' || trim(p_nombre));
    INSERT INTO public.mvp_cajas (nombre, tipo, user_id)
    VALUES (v_caja_nombre, 'SOCIO', p_user_id);
  END IF;

  -- ===========================================================
  -- 9) INSERT en mvp_repartidores (si v_crear_repartidor).
  -- ===========================================================
  IF v_crear_repartidor = true THEN
    INSERT INTO public.mvp_repartidores (user_id, activo)
    VALUES (p_user_id, true);
  END IF;

  -- ===========================================================
  -- 10) INSERT en mvp_cajas REPARTIDOR (si v_crear_repartidor).
  --     Nombre: "Caja Repartidor — {nombre}" (Decisión 3).
  -- ===========================================================
  IF v_crear_repartidor = true THEN
    INSERT INTO public.mvp_cajas (nombre, tipo, user_id)
    VALUES ('Caja Repartidor — ' || trim(p_nombre), 'REPARTIDOR', p_user_id);
  END IF;

  RETURN p_user_id;
END;
$$;


ALTER FUNCTION public.fn_crear_usuario(p_user_id uuid, p_rol text, p_nombre text, p_cliente_id uuid, p_porc_ganancia numeric, p_porc_venta numeric, p_caja_nombre text, p_es_repartidor boolean, p_telefono text, p_rol_tesorero boolean) OWNER TO postgres;

--
-- Name: fn_ctacte_resumen_socios(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_ctacte_resumen_socios() RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol    varchar;
    v_result json;
BEGIN
    v_rol := get_user_rol();
    IF v_rol NOT IN ('admin','tesorero') AND NOT public.es_tesorero() THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol;
    END IF;

    SELECT COALESCE(json_agg(json_build_object(
        'socio_id', s.user_id,
        'nombre',   u.nombre,
        'haber',    COALESCE(saldo.haber, 0)
    ) ORDER BY u.nombre), '[]'::json)
    INTO v_result
    FROM mvp_socios s
    JOIN mvp_users u ON u.id = s.user_id
    LEFT JOIN LATERAL (
        SELECT SUM(c.monto_haber - c.monto_debe) FILTER (WHERE c.afecta_saldo) AS haber
        FROM mvp_ctacte c WHERE c.socio_id = s.user_id
    ) saldo ON true;

    RETURN v_result;
END;
$$;


ALTER FUNCTION public.fn_ctacte_resumen_socios() OWNER TO postgres;

--
-- Name: fn_cuenta_socio(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_cuenta_socio(p_socio_id uuid DEFAULT NULL::uuid) RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol          varchar;
    v_caller       uuid := auth.uid();
    v_socio        uuid;
    v_total_div    numeric := 0;
    v_total_ing    numeric := 0;
    v_total_adel   numeric := 0;
    v_total_liq    numeric := 0;
    v_total_retiro numeric := 0;
    v_total_aporte numeric := 0;
    v_haber        numeric := 0;
BEGIN
    v_rol := get_user_rol();
    v_socio := COALESCE(p_socio_id, v_caller);

    IF v_socio IS DISTINCT FROM v_caller AND v_rol NOT IN ('tesorero','admin') AND NOT public.es_tesorero() THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol;
    END IF;

    PERFORM 1 FROM mvp_socios WHERE user_id = v_socio;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Socio inexistente: %', v_socio;
    END IF;

    SELECT
        COALESCE(SUM(monto_haber) FILTER (WHERE tipo_mov_ctacte = 'DIVIDENDOS'), 0),
        COALESCE(SUM(monto_haber) FILTER (WHERE tipo_mov_ctacte = 'INGRESO'),    0),
        COALESCE(SUM(monto_debe)  FILTER (WHERE tipo_mov_ctacte = 'ADELANTO'),   0),
        COALESCE(SUM(monto_debe)  FILTER (WHERE tipo_mov_ctacte = 'LIQUIDACION'),0),
        COALESCE(SUM(monto_debe)  FILTER (WHERE tipo_mov_ctacte = 'RETIRO'),     0),
        COALESCE(SUM(monto_haber) FILTER (WHERE tipo_mov_ctacte = 'APORTE'),     0),
        COALESCE(SUM(monto_haber - monto_debe) FILTER (WHERE afecta_saldo),      0)
      INTO v_total_div, v_total_ing, v_total_adel, v_total_liq, v_total_retiro, v_total_aporte, v_haber
      FROM mvp_ctacte
     WHERE socio_id = v_socio;

    RETURN json_build_object(
        'socio_id',            v_socio,
        'total_dividendos',    v_total_div,
        'total_ingresos',      v_total_ing,
        'total_adelantos',     v_total_adel,
        'total_liquidaciones', v_total_liq,
        'total_retiros',       v_total_retiro,
        'total_aportes',       v_total_aporte,
        'haber',               v_haber
    );
END;
$$;


ALTER FUNCTION public.fn_cuenta_socio(p_socio_id uuid) OWNER TO postgres;

--
-- Name: fn_dashboard_cajas_repartidores(integer, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_dashboard_cajas_repartidores(p_limite integer DEFAULT 50, p_orden text DEFAULT 'fecha'::text, p_dir text DEFAULT 'desc'::text) RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol       varchar;
    v_periodo   mvp_periodo;
    v_resumen   json;
    v_movs      json;
    v_total     integer;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Sesión sin usuario autenticado.' USING ERRCODE = '28000';
    END IF;

    v_rol := get_user_rol();
    IF v_rol IS NULL OR v_rol NOT IN ('admin', 'socio', 'tesorero') THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol USING ERRCODE = '42501';
    END IF;

    IF p_orden NOT IN ('fecha', 'repartidor', 'tipo', 'monto') THEN
        RAISE EXCEPTION 'Columna de orden inválida: %', p_orden USING ERRCODE = '22023';
    END IF;
    IF p_dir NOT IN ('asc', 'desc') THEN
        RAISE EXCEPTION 'Dirección de orden inválida: %', p_dir USING ERRCODE = '22023';
    END IF;
    IF p_limite IS NULL OR p_limite < 1 OR p_limite > 1000 THEN
        RAISE EXCEPTION 'Límite inválido: %', p_limite USING ERRCODE = '22023';
    END IF;

    SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'No hay periodo abierto' USING ERRCODE = 'P0001';
    END IF;

    -- === RESUMEN: una fila por Caja Repartidora ===
    SELECT COALESCE(json_agg(obj ORDER BY nom), '[]'::json)
    INTO v_resumen
    FROM (
        SELECT u.nombre AS nom, json_build_object(
            'repartidor_id', u.id,
            'nombre',        u.nombre,
            'es_tester',     u.es_tester,
            'caja_id',       c.id,
            'cobrado', COALESCE((
                SELECT SUM(m.monto) FROM mvp_movimientos_caja m
                JOIN mvp_operacion_caja o ON o.id = m.operacion_id
                WHERE m.caja_id = c.id AND m.tipo_referencia = 'VENTA'
                  AND o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'), 0),
            'rendido', COALESCE((
                SELECT SUM(-m.monto) FROM mvp_movimientos_caja m
                JOIN mvp_operacion_caja o ON o.id = m.operacion_id
                WHERE m.caja_id = c.id AND m.tipo_referencia = 'TRANSFERENCIA'
                  AND m.monto < 0
                  AND o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'), 0),
            'rendiciones_admin', COALESCE((
                SELECT count(DISTINCT o.id) FROM mvp_movimientos_caja m
                JOIN mvp_operacion_caja o ON o.id = m.operacion_id
                WHERE m.caja_id = c.id AND m.tipo_referencia = 'TRANSFERENCIA'
                  AND m.monto < 0
                  AND o.usuario_id <> c.user_id
                  AND o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'), 0),
            'saldo_pendiente', calcular_saldo_caja(c.id)
        ) AS obj
        FROM mvp_cajas c
        JOIN mvp_users u ON u.id = c.user_id
        WHERE c.tipo = 'REPARTIDOR' AND u.activo
    ) r;

    -- === DETALLE: un movimiento por línea, todas las cajas ===
    WITH base AS (
        SELECT
            m.fecha                                   AS ts,
            u.nombre                                  AS repartidor,
            u.es_tester                               AS es_tester,
            CASE
                WHEN m.tipo_referencia = 'VENTA' THEN 'COBRO'
                WHEN m.tipo_referencia = 'TRANSFERENCIA' AND m.monto < 0
                     AND o.usuario_id <> c.user_id       THEN 'RENDICIÓN ADMIN'
                WHEN m.tipo_referencia = 'TRANSFERENCIA' AND m.monto < 0
                                                         THEN 'RENDICIÓN'
                ELSE m.tipo_referencia::text
            END                                       AS tipo,
            CASE
                WHEN m.tipo_referencia = 'VENTA'
                     THEN COALESCE(cli.razon_social, 'Venta')
                WHEN m.tipo_referencia = 'TRANSFERENCIA' AND m.monto < 0
                     THEN 'Rendición → Caja Delegada'
                ELSE COALESCE(o.observaciones, m.tipo_referencia::text)
            END                                       AS concepto,
            m.monto                                   AS monto
        FROM mvp_movimientos_caja m
        JOIN mvp_operacion_caja o ON o.id = m.operacion_id
        JOIN mvp_cajas c          ON c.id = m.caja_id
        JOIN mvp_users u          ON u.id = c.user_id
        LEFT JOIN mvp_ventas   v   ON v.id = (CASE WHEN m.tipo_referencia = 'VENTA'
                                                   THEN m.referencia_id END)::uuid
        LEFT JOIN mvp_clientes cli ON cli.id = v.cliente_id
        WHERE c.tipo = 'REPARTIDOR'
          AND o.periodo_id = v_periodo.id
          AND o.estado = 'CONFIRMADA'
    ),
    ord AS (
        SELECT b.*, row_number() OVER (ORDER BY
            CASE WHEN p_orden = 'fecha'      AND p_dir = 'asc'  THEN b.ts         END ASC,
            CASE WHEN p_orden = 'fecha'      AND p_dir = 'desc' THEN b.ts         END DESC,
            CASE WHEN p_orden = 'repartidor' AND p_dir = 'asc'  THEN b.repartidor END ASC,
            CASE WHEN p_orden = 'repartidor' AND p_dir = 'desc' THEN b.repartidor END DESC,
            CASE WHEN p_orden = 'tipo'       AND p_dir = 'asc'  THEN b.tipo       END ASC,
            CASE WHEN p_orden = 'tipo'       AND p_dir = 'desc' THEN b.tipo       END DESC,
            CASE WHEN p_orden = 'monto'      AND p_dir = 'asc'  THEN b.monto      END ASC,
            CASE WHEN p_orden = 'monto'      AND p_dir = 'desc' THEN b.monto      END DESC,
            b.ts DESC
        ) AS rn
        FROM base b
    )
    SELECT
        COALESCE(json_agg(json_build_object(
            'fecha',      to_char(ts, 'YYYY-MM-DD HH24:MI'),
            'repartidor', repartidor,
            'es_tester',  es_tester,
            'tipo',       tipo,
            'concepto',   concepto,
            'monto',      monto
        ) ORDER BY rn), '[]'::json),
        (SELECT count(*)::integer FROM base)
    INTO v_movs, v_total
    FROM ord
    WHERE rn <= p_limite;

    RETURN json_build_object(
        'periodo_codigo',     v_periodo.codigo,
        'resumen',            v_resumen,
        'movimientos',        v_movs,
        'total_movimientos',  v_total,
        'limite',             p_limite,
        'orden',              p_orden,
        'dir',                p_dir
    );
END;
$$;


ALTER FUNCTION public.fn_dashboard_cajas_repartidores(p_limite integer, p_orden text, p_dir text) OWNER TO postgres;

--
-- Name: FUNCTION fn_dashboard_cajas_repartidores(p_limite integer, p_orden text, p_dir text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fn_dashboard_cajas_repartidores(p_limite integer, p_orden text, p_dir text) IS 'PATCH-DASHBOARD. Tab Cajas Repartidoras: resumen agregado por caja + detalle de movimientos del período abierto. Read-only. Guard: admin/socio/tesorero (excluye operador). Sort server-side. RENDICIÓN ADMIN se deriva estructuralmente (operacion.usuario_id <> caja.user_id), no del texto de observaciones.';


--
-- Name: fn_dashboard_delegadas_header(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_dashboard_delegadas_header() RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol varchar; v_periodo mvp_periodo;
    v_recaudacion numeric; v_gastos numeric; v_saldo_real numeric;
    v_transito numeric; v_cajas integer; v_pendientes integer;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Sesión sin usuario autenticado.' USING ERRCODE = '28000';
    END IF;
    v_rol := get_user_rol();
    IF v_rol IS NULL OR v_rol NOT IN ('admin', 'socio', 'tesorero') THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol USING ERRCODE = '42501';
    END IF;
    SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'No hay periodo abierto' USING ERRCODE = 'P0001';
    END IF;

    SELECT
        COALESCE(SUM(m.monto) FILTER (WHERE m.tipo_referencia = 'VENTA'), 0)
      + COALESCE(SUM(m.monto) FILTER (
            WHERE m.tipo_referencia = 'TRANSFERENCIA' AND m.monto > 0
              AND cori.tipo = 'REPARTIDOR'), 0),
        COALESCE(SUM(ABS(m.monto)) FILTER (WHERE m.tipo_referencia = 'EGRESO'), 0)
    INTO v_recaudacion, v_gastos
    FROM mvp_movimientos_caja m
    JOIN mvp_operacion_caja o  ON o.id = m.operacion_id
    JOIN mvp_cajas c           ON c.id = m.caja_id
    JOIN mvp_users u           ON u.id = c.user_id
    LEFT JOIN mvp_cajas cori   ON cori.id = o.caja_origen_id
    WHERE c.tipo = 'SOCIO'
      AND u.activo
      AND o.periodo_id = v_periodo.id
      AND o.estado = 'CONFIRMADA';

    SELECT COALESCE(SUM(calcular_saldo_caja(c.id)), 0), count(*)::integer
    INTO v_saldo_real, v_cajas
    FROM mvp_cajas c JOIN mvp_users u ON u.id = c.user_id
    WHERE c.tipo = 'SOCIO' AND u.activo;

    SELECT COALESCE(SUM(calcular_saldo_caja(c.id)), 0),
           count(*) FILTER (WHERE calcular_saldo_caja(c.id) > 0)::integer
    INTO v_transito, v_pendientes
    FROM mvp_cajas c JOIN mvp_users u ON u.id = c.user_id
    WHERE c.tipo = 'REPARTIDOR' AND u.activo;

    RETURN json_build_object(
        'periodo_codigo',      v_periodo.codigo,
        'cajas_delegadas',     v_cajas,
        'recaudacion',         v_recaudacion,
        'gastos',              v_gastos,
        'estado_resultados',   v_recaudacion - v_gastos,
        'saldo_real_total',    v_saldo_real,
        'en_transito',         v_transito,
        'repartidores_sin_rendir', v_pendientes
    );
END;
$$;


ALTER FUNCTION public.fn_dashboard_delegadas_header() OWNER TO postgres;

--
-- Name: FUNCTION fn_dashboard_delegadas_header(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fn_dashboard_delegadas_header() IS 'PATCH-DASHBOARD-2. Header del bloque Cajas Delegadas. Recaudación = ventas directas + rendiciones desde Caja Repartidora. saldo_real_total = suma física, sin filtro de período: detecta descuadres. en_transito = saldo de Cajas Repartidoras sin rendir. NO excluye tester: cuenta lo mismo que fn_dashboard_periodo, para que la identidad ER_delegadas + en_transito = ER_empresa cierre también con datos de prueba (RN-U10 Límite 3: los datos del tester conviven con los reales y se borran antes del cierre).';


--
-- Name: fn_dashboard_periodo(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_dashboard_periodo() RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  v_rol              varchar;
  v_caller           uuid := auth.uid();
  v_es_socio         boolean;
  v_periodo          mvp_periodo;
  v_periodo_ant_id   uuid;
  v_central_id       uuid;
  v_V                numeric;
  v_C                numeric;
  v_Dv               numeric;
  v_resultado        numeric;
  v_saldo_repartir   numeric;
  v_plantas          numeric;
  v_saldo_central_ant numeric;
  v_a_proximo        numeric;
  v_serie            json;
  v_reparto          json;
  v_estado_res       json;
  v_caja_central     json;
  v_cajas_socios     json;
BEGIN
  v_rol      := get_user_rol();
  v_es_socio := COALESCE(v_rol = 'socio', false);

  SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
  IF v_periodo.id IS NULL THEN
    RAISE EXCEPTION 'No hay periodo abierto' USING ERRCODE = 'P0001';
  END IF;

  SELECT id INTO v_periodo_ant_id
  FROM mvp_periodo
  WHERE fecha_fin < v_periodo.fecha_inicio
  ORDER BY fecha_fin DESC LIMIT 1;

  SELECT id INTO v_central_id FROM mvp_cajas WHERE tipo = 'CENTRAL' LIMIT 1;

  SELECT
    COALESCE(SUM(m.monto)      FILTER (WHERE m.tipo_referencia = 'VENTA'),  0),
    COALESCE(SUM(ABS(m.monto)) FILTER (WHERE m.tipo_referencia = 'EGRESO'), 0)
  INTO v_V, v_C
  FROM mvp_movimientos_caja m
  JOIN mvp_operacion_caja o ON o.id = m.operacion_id
  WHERE o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA';

  SELECT COALESCE(SUM(s.porc_venta / 100.0 * v_V), 0)
  INTO v_Dv FROM mvp_socios s WHERE s.porc_venta > 0;

  v_resultado      := v_V - v_C;
  v_saldo_repartir := v_V - v_C - v_Dv;

  SELECT COALESCE(SUM(vd.cantidad), 0)
  INTO v_plantas
  FROM mvp_ventas vt
  JOIN mvp_ventas_detalle vd ON vd.venta_id = vt.id
  WHERE vt.estado IN ('ENTREGADA','COBRADO')
    AND vt.fecha_entrega BETWEEN v_periodo.fecha_inicio AND v_periodo.fecha_fin;

  SELECT COALESCE(json_agg(json_build_object(
           'dia', dia, 'ventas_acum', ventas_acum, 'gastos_acum', gastos_acum
         ) ORDER BY dia), '[]'::json)
  INTO v_serie
  FROM (
    SELECT dia,
           SUM(vd) OVER (ORDER BY dia) AS ventas_acum,
           SUM(gd) OVER (ORDER BY dia) AS gastos_acum
    FROM (
      SELECT fn_fecha_local(o.fecha) AS dia,
             COALESCE(SUM(m.monto)      FILTER (WHERE m.tipo_referencia='VENTA'),  0) AS vd,
             COALESCE(SUM(ABS(m.monto)) FILTER (WHERE m.tipo_referencia='EGRESO'), 0) AS gd
      FROM mvp_movimientos_caja m
      JOIN mvp_operacion_caja o ON o.id = m.operacion_id
      WHERE o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'
      GROUP BY fn_fecha_local(o.fecha)
    ) d
  ) s;

  SELECT COALESCE(json_agg(json_build_object(
           'socio', nombre, 'tipo', tipo, 'monto', monto, 'pct', pct
         ) ORDER BY nombre), '[]'::json)
  INTO v_reparto
  FROM (
    SELECT u.nombre,
           CASE WHEN s.porc_venta > 0 THEN 'VENTA' ELSE 'GANANCIA' END AS tipo,
           CASE WHEN s.porc_venta > 0 THEN ROUND(s.porc_venta    / 100.0 * v_V, 2)
                ELSE                       ROUND(s.porc_ganancia / 100.0 * v_saldo_repartir, 2) END AS monto,
           CASE WHEN s.porc_venta > 0 THEN s.porc_venta ELSE s.porc_ganancia END AS pct
    FROM mvp_socios s
    JOIN mvp_users u ON u.id = s.user_id
    WHERE s.porc_venta > 0 OR s.porc_ganancia > 0
  ) r;

  v_estado_res := json_build_object(
    'periodo_id',             v_periodo.id,
    'periodo_codigo',         v_periodo.codigo,
    'periodo_inicio',         v_periodo.fecha_inicio,
    'periodo_fin',            v_periodo.fecha_fin,
    'periodo_estado',         v_periodo.estado,
    'plantas_vendidas',       v_plantas,
    'ventas_cobradas',        v_V,
    'gastos_compras',         v_C,
    'resultado',              v_resultado,
    'pct_gastos_ventas',      CASE WHEN v_V > 0 THEN ROUND(v_C / v_V * 100, 2) ELSE 0 END,
    'precio_prom_planta',     CASE WHEN v_plantas > 0 THEN ROUND(v_V / v_plantas, 2) ELSE 0 END,
    'liquidacion_pct_ventas', v_Dv,
    'saldo_a_repartir',       v_saldo_repartir,
    'serie_diaria',           v_serie,
    'reparto',                v_reparto,
    'fecha_actualizacion',    to_char(now() AT TIME ZONE 'America/Argentina/Buenos_Aires',
                                      'YYYY-MM-DD"T"HH24:MI:SS')
  );

  SELECT COALESCE((
    SELECT cd.saldo_final FROM mvp_cierre_detalle cd
    JOIN mvp_cierres ci ON ci.id = cd.cierre_id
    WHERE ci.periodo_id = v_periodo_ant_id AND cd.caja_id = v_central_id LIMIT 1
  ), 0) INTO v_saldo_central_ant;

  SELECT COALESCE(SUM(CASE WHEN saldo_final < 0 THEN -saldo_final ELSE 0 END), 0)
  INTO v_a_proximo
  FROM (
    SELECT
      COALESCE((SELECT cd.saldo_final FROM mvp_cierre_detalle cd
                JOIN mvp_cierres ci ON ci.id = cd.cierre_id
                WHERE ci.periodo_id = v_periodo_ant_id AND cd.caja_id = c.id LIMIT 1), 0)
      + COALESCE((SELECT SUM(m.monto) FROM mvp_movimientos_caja m
                  JOIN mvp_operacion_caja o ON o.id = m.operacion_id
                  WHERE m.caja_id = c.id AND o.periodo_id = v_periodo.id AND o.estado='CONFIRMADA'), 0)
      AS saldo_final
    FROM mvp_cajas c WHERE c.tipo = 'SOCIO'
  ) x;

  v_caja_central := json_build_object(
    'saldo_mes_anterior',     v_saldo_central_ant,
    'estado_resultados',      v_resultado,
    'liquidacion_pct_ventas', v_Dv,
    'a_proximo_mes',          v_a_proximo,
    'saldo_a_repartir',       v_saldo_repartir,
    'saldo_real',             calcular_saldo_caja(v_central_id)
  );

  -- Cajas socios: SOLO caja delegada (flujo comercial). El flujo personal
  -- (ctacte: dividendos, adelantos, liquidacion) NO se muestra en el Dashboard;
  -- vive en SCR-MiCtacte / SCR-ConsultaCte.
  SELECT COALESCE(json_agg(obj ORDER BY socio), '[]'::json)
  INTO v_cajas_socios
  FROM (
    SELECT u.nombre AS socio, json_build_object(
      'socio',   u.nombre,
      'caja_id', c.id,
      'tipo_participacion',
        CASE WHEN s.porc_venta    > 0 THEN 'VENTA'
             WHEN s.porc_ganancia > 0 THEN 'GANANCIA'
             ELSE 'SIN_PARTICIPACION' END,
      'ventas_cobradas', COALESCE((
        SELECT SUM(m.monto) FROM mvp_movimientos_caja m
        JOIN mvp_operacion_caja o ON o.id = m.operacion_id
        WHERE m.caja_id = c.id AND m.tipo_referencia='VENTA'
          AND o.periodo_id = v_periodo.id AND o.estado='CONFIRMADA'), 0),
      'gastos_compras', COALESCE((
        SELECT SUM(ABS(m.monto)) FROM mvp_movimientos_caja m
        JOIN mvp_operacion_caja o ON o.id = m.operacion_id
        WHERE m.caja_id = c.id AND m.tipo_referencia='EGRESO'
          AND o.periodo_id = v_periodo.id AND o.estado='CONFIRMADA'), 0),
      'venta_cobrada_repartidor', COALESCE((
        SELECT SUM(m.monto) FROM mvp_movimientos_caja m
        JOIN mvp_operacion_caja o   ON o.id = m.operacion_id
        JOIN mvp_cajas cori         ON cori.id = o.caja_origen_id
        WHERE m.caja_id = c.id AND m.tipo_referencia='TRANSFERENCIA' AND m.monto > 0
          AND cori.tipo = 'REPARTIDOR'
          AND o.periodo_id = v_periodo.id AND o.estado='CONFIRMADA'), 0),
      'transferencias_recibidas', COALESCE((
        SELECT SUM(m.monto) FROM mvp_movimientos_caja m
        JOIN mvp_operacion_caja o   ON o.id = m.operacion_id
        LEFT JOIN mvp_cajas cori    ON cori.id = o.caja_origen_id
        WHERE m.caja_id = c.id AND m.tipo_referencia='TRANSFERENCIA' AND m.monto > 0
          AND COALESCE(cori.tipo,'') <> 'REPARTIDOR'
          AND o.periodo_id = v_periodo.id AND o.estado='CONFIRMADA'), 0),
      'transferencias_enviadas', COALESCE((
        SELECT SUM(-m.monto) FROM mvp_movimientos_caja m
        JOIN mvp_operacion_caja o ON o.id = m.operacion_id
        WHERE m.caja_id = c.id AND m.tipo_referencia='TRANSFERENCIA' AND m.monto < 0
          AND o.periodo_id = v_periodo.id AND o.estado='CONFIRMADA'), 0),
      'saldo_caja',
        COALESCE((SELECT cd.saldo_final FROM mvp_cierre_detalle cd
                  JOIN mvp_cierres ci ON ci.id = cd.cierre_id
                  WHERE ci.periodo_id = v_periodo_ant_id AND cd.caja_id = c.id LIMIT 1), 0)
        + COALESCE((SELECT SUM(m.monto) FROM mvp_movimientos_caja m
                    JOIN mvp_operacion_caja o ON o.id = m.operacion_id
                    WHERE m.caja_id = c.id AND o.periodo_id = v_periodo.id AND o.estado='CONFIRMADA'), 0)
    ) AS obj
    FROM mvp_cajas c
    JOIN mvp_users  u ON u.id = c.user_id
    JOIN mvp_socios s ON s.user_id = c.user_id
    WHERE c.tipo = 'SOCIO'
      AND u.activo
      AND (NOT v_es_socio OR c.user_id = v_caller)
  ) cs;

  RETURN json_build_object(
    'estado_resultados', v_estado_res,
    'caja_central',      v_caja_central,
    'cajas_socios',      v_cajas_socios
  );
END;
$$;


ALTER FUNCTION public.fn_dashboard_periodo() OWNER TO postgres;

--
-- Name: fn_ejecutar_cierre(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_ejecutar_cierre(p_periodo_id uuid DEFAULT NULL::uuid) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol            varchar;
    v_usuario        uuid := auth.uid();
    v_periodo        mvp_periodo;
    v_central_id     uuid;
    v_preview        json;
    v_central        json;
    v_socio          json;
    v_sum_gan        numeric;
    v_V              numeric;
    v_C              numeric;
    v_Dv             numeric;
    v_ER             numeric;
    v_cierre_id      uuid := gen_random_uuid();
    v_tipo_barrido   integer;
    v_fecha_periodo   timestamp;   -- v1.1: fecha de las operaciones del cierre = fin del PERIODO
    v_total_cajas    integer;
    v_cajas_cerradas integer := 0;
    v_total_swept    numeric := 0;
    v_caja_id        uuid;
    v_pg             numeric;
    v_pv             numeric;
    v_si             numeric;
    v_ing            numeric;
    v_egr            numeric;
    v_sf_op          numeric;
    v_transfer       numeric;
    v_monto_div      numeric;
    v_tipo_div       varchar;
    v_porc_apl       numeric;
    v_op             uuid;
    v_op_div         uuid;        -- B1.6: operacion DIVIDENDOS
    v_tipo_dividendos integer;    -- B1.6: tipo_operacion DIVIDENDOS
    v_socio_user     uuid;        -- B1.6: user_id del socio (ctacte.socio_id)
    v_next_inicio    date;
    v_next_fin       date;
    v_next_codigo    varchar;
    v_tipo_cierre_prestamo integer;     -- B-Cierre: tipo CIERRE_PRESTAMO_DELEGADO
    v_prestamo            record;        -- B-Cierre: prestamo pendiente a saldar
    v_prestamos_saldados  integer := 0;  -- B-Cierre: contador de prestamos saldados
BEGIN
    -- 1. Guardas
    v_rol := get_user_rol();
    IF v_rol IS NULL OR (v_rol NOT IN ('tesorero', 'admin') AND NOT public.es_tesorero()) THEN
        RAISE EXCEPTION 'Operacion no autorizada para rol: %', v_rol USING ERRCODE = 'P0001';
    END IF;

    IF p_periodo_id IS NULL THEN
        SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    ELSE
        SELECT * INTO v_periodo FROM mvp_periodo WHERE id = p_periodo_id;
    END IF;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'Periodo no encontrado o no hay vigente' USING ERRCODE = 'P0001';
    END IF;
    IF v_periodo.estado = 'CERRADO' THEN
        RAISE EXCEPTION 'El periodo % ya esta cerrado', v_periodo.codigo USING ERRCODE = 'P0001';
    END IF;
    IF EXISTS (SELECT 1 FROM mvp_cierres WHERE periodo_id = v_periodo.id) THEN
        RAISE EXCEPTION 'El periodo % ya tiene un cierre', v_periodo.codigo USING ERRCODE = 'P0001';
    END IF;

    -- B1.6: guarda de rendicion. No cerrar si hay cajas SOCIO sin rendir el periodo.
    IF EXISTS (
        SELECT 1 FROM mvp_cajas c
         LEFT JOIN mvp_users  u ON u.id = c.user_id
         LEFT JOIN mvp_socios s ON s.user_id = c.user_id
         WHERE c.tipo = 'SOCIO'
           -- Tester-Puro con caja limpia (post LIMPIADOR) no rinde. Si la caja tiene
           -- saldo, el LIMPIADOR no corrio y sus operaciones de prueba estan sumando
           -- en V: la guarda debe seguir exigiendolo.
           AND NOT (COALESCE(u.es_tester, false)
                     AND COALESCE(s.porc_venta, 0) = 0
                     AND COALESCE(s.porc_ganancia, 0) = 0
                     AND public.calcular_saldo_caja(c.id) = 0)
           AND NOT EXISTS (
               SELECT 1 FROM mvp_rendiciones r
                WHERE r.caja_id = c.id AND r.periodo_id = v_periodo.id
           )
    ) THEN
        RAISE EXCEPTION 'Hay cajas SOCIO sin rendir en el periodo %', v_periodo.codigo
            USING ERRCODE = 'P0001', HINT = 'RENDICION_PENDIENTE';
    END IF;

    -- D-J: guarda de rendicion REPARTIDOR. No cerrar si alguna caja REPARTIDOR
    --      conserva saldo sin rendir: esa venta ya computa en V pero su efectivo
    --      no llego a Central via barrido (LEC-b). Rendir con fn_rendir_dia /
    --      fn_rendir_dia_administrativo antes de cerrar.
    IF EXISTS (
        SELECT 1 FROM mvp_cajas c
         WHERE c.tipo = 'REPARTIDOR'
           AND public.calcular_saldo_caja(c.id) > 0
    ) THEN
        RAISE EXCEPTION 'Hay cajas REPARTIDOR sin rendir en el periodo %', v_periodo.codigo
            USING ERRCODE = 'P0001', HINT = 'REPARTIDOR_SIN_RENDIR';
    END IF;

    -- Guarda dura: las ganancias se reparten totalmente.
    SELECT COALESCE(SUM(porc_ganancia), 0) INTO v_sum_gan FROM mvp_socios;
    IF v_sum_gan <> 100 THEN
        RAISE EXCEPTION 'Suma porc_ganancia = % (debe ser 100)', v_sum_gan USING ERRCODE = 'P0001';
    END IF;

    SELECT id INTO v_central_id FROM mvp_cajas WHERE tipo = 'CENTRAL' LIMIT 1;
    IF v_central_id IS NULL THEN
        RAISE EXCEPTION 'No existe Caja Central' USING ERRCODE = 'P0001';
    END IF;


    -- v1.1: las operaciones que genera el cierre (barrido, dividendos, prestamos)

    --       se fechan en el ultimo instante del PERIODO que se cierra, no en el now()

    --       de la ejecucion. Fecha CRUDA a proposito: mvp_movimientos_caja.fecha guarda

    --       UTC sin zona, y con fn_ts_desde_fecha_local el 30/06 23:59:59 se iria a

    --       2026-07-01 02:59:59 UTC, cayendo en el mes siguiente. Asi cae en junio leido

    --       de las dos formas. El momento real de ejecucion queda en mvp_cierres.fecha_cierre.

    v_fecha_periodo := v_periodo.fecha_fin::timestamp + interval '23 hours 59 minutes 59 seconds';

    v_tipo_barrido := COALESCE(
        (SELECT id FROM mvp_tipo_operaciones WHERE codigo = 'CIERRE' AND activa LIMIT 1),
        (SELECT id FROM mvp_tipo_operaciones WHERE codigo = 'TRANSFERENCIA' AND activa LIMIT 1)
    );
    IF v_tipo_barrido IS NULL THEN
        RAISE EXCEPTION 'No hay tipo de operacion para el barrido (CIERRE/TRANSFERENCIA)';
    END IF;

    -- B1.6: tipo de operacion para el posteo de dividendos a ctacte.
    SELECT id INTO v_tipo_dividendos FROM mvp_tipo_operaciones
     WHERE codigo = 'DIVIDENDOS' AND activa LIMIT 1;
    IF v_tipo_dividendos IS NULL THEN
        RAISE EXCEPTION 'No hay tipo de operacion DIVIDENDOS';
    END IF;

    -- 2. Saldos por caja: reuso del cerebro (fn_preview_cierre).
    v_preview := fn_preview_cierre(v_periodo.id);

    -- 3. V y C brutos por tipo_referencia del movimiento.
    SELECT COALESCE(SUM(m.monto) FILTER (WHERE m.tipo_referencia = 'VENTA'), 0),
           COALESCE(SUM(ABS(m.monto)) FILTER (WHERE m.tipo_referencia = 'EGRESO'), 0)
      INTO v_V, v_C
      FROM mvp_movimientos_caja m
      JOIN mvp_operacion_caja o ON o.id = m.operacion_id
     WHERE o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA';

    -- 4. Dividendos, orden NO invertible.
    SELECT COALESCE(SUM(porc_venta / 100.0 * v_V), 0) INTO v_Dv
      FROM mvp_socios WHERE porc_venta > 0;
    v_ER := v_V - v_C - v_Dv;

    -- 5. Cabecera del cierre.
    SELECT COUNT(*) INTO v_total_cajas FROM mvp_cajas WHERE tipo IN ('SOCIO', 'CENTRAL');
    INSERT INTO mvp_cierres (id, periodo_id, total_cajas, cajas_cerradas, fecha_cierre, usuario_cierre)
    VALUES (v_cierre_id, v_periodo.id, v_total_cajas, 0, now(), v_usuario);

    -- 5.5 Saldo de prestamos entre cajas delegadas pendientes (antes del barrido, RN-T14).
    --     No mueve efectivo (el barrido ya refleja la plata) ni toca la cuenta corriente
    --     del socio. Solo crea la operacion vinculante que marca el prestamo como no-pendiente,
    --     garantizando la no-arrastrabilidad al periodo siguiente.
    SELECT id INTO v_tipo_cierre_prestamo FROM mvp_tipo_operaciones
     WHERE codigo = 'CIERRE_PRESTAMO_DELEGADO' AND activa LIMIT 1;
    IF v_tipo_cierre_prestamo IS NULL THEN
        RAISE EXCEPTION 'No hay tipo de operacion CIERRE_PRESTAMO_DELEGADO';
    END IF;

    FOR v_prestamo IN
        SELECT op.id, op.caja_origen_id, op.caja_destino_id
          FROM mvp_operacion_caja op
          JOIN mvp_tipo_operaciones t ON t.id = op.tipo_operacion_id
         WHERE t.codigo = 'PRESTAMO_ENTRE_SOCIOS'
           AND op.estado = 'CONFIRMADA'
           AND NOT EXISTS (
               SELECT 1 FROM mvp_operacion_caja c
                WHERE c.operacion_relacionada_id = op.id
           )
    LOOP
        INSERT INTO mvp_operacion_caja
            (id, tipo_operacion_id, fecha, usuario_id, estado,
             caja_origen_id, caja_destino_id, periodo_id, operacion_relacionada_id)
        VALUES
            (gen_random_uuid(), v_tipo_cierre_prestamo, v_fecha_periodo, v_usuario, 'CONFIRMADA',
             v_prestamo.caja_origen_id, v_prestamo.caja_destino_id, v_periodo.id, v_prestamo.id);
        v_prestamos_saldados := v_prestamos_saldados + 1;
    END LOOP;

    -- 6. Detalle por caja SOCIO + barrido/arrastre.
    FOR v_socio IN SELECT * FROM json_array_elements(v_preview -> 'socios')
    LOOP
        v_caja_id := (v_socio ->> 'caja_id')::uuid;
        v_si      := (v_socio ->> 'saldo_inicial')::numeric;
        v_ing     := (v_socio ->> 'total_ingresos')::numeric;
        v_egr     := (v_socio ->> 'total_egresos')::numeric;
        v_sf_op   := (v_socio ->> 'saldo_final')::numeric;

        SELECT s.porc_ganancia, s.porc_venta, c.user_id INTO v_pg, v_pv, v_socio_user
          FROM mvp_cajas c JOIN mvp_socios s ON s.user_id = c.user_id
         WHERE c.id = v_caja_id;

        IF COALESCE(v_pg, 0) > 0 THEN
            v_monto_div := v_pg / 100.0 * v_ER; v_tipo_div := 'GANANCIA'; v_porc_apl := v_pg;
        ELSIF COALESCE(v_pv, 0) > 0 THEN
            v_monto_div := v_pv / 100.0 * v_V;  v_tipo_div := 'VENTA';    v_porc_apl := v_pv;
        ELSE
            v_monto_div := 0; v_tipo_div := NULL; v_porc_apl := NULL;
        END IF;

        -- B1.6: postear el dividendo al HABER de la cuenta corriente del socio.
        IF v_monto_div > 0 AND v_socio_user IS NOT NULL THEN
            v_op_div := gen_random_uuid();
            INSERT INTO mvp_operacion_caja
                (id, tipo_operacion_id, fecha, usuario_id, estado, tercero_id, tipo_tercero, periodo_id)
            VALUES
                (v_op_div, v_tipo_dividendos, v_fecha_periodo, v_usuario, 'CONFIRMADA', v_socio_user, 'SOCIO', v_periodo.id);
            INSERT INTO mvp_ctacte
                (socio_id, operacion_id, tipo_mov_ctacte, monto_haber, fecha)
            VALUES
                (v_socio_user, v_op_div, 'DIVIDENDOS', v_monto_div, v_fecha_periodo);
        END IF;

        INSERT INTO mvp_cierre_detalle
            (id, cierre_id, caja_id, saldo_inicial, saldo_final, total_ingresos, total_egresos,
             monto_dividendos, monto_transferido_tesoreria, porc_aplicado, tipo_dividendo_aplicado)
        VALUES
            (gen_random_uuid(), v_cierre_id, v_caja_id, v_si, LEAST(v_sf_op, 0), v_ing, v_egr,
             v_monto_div, GREATEST(v_sf_op, 0), v_porc_apl, v_tipo_div);

        v_transfer := GREATEST(v_sf_op, 0);

        IF v_transfer > 0 THEN
            v_op := gen_random_uuid();
            INSERT INTO mvp_operacion_caja
                (id, tipo_operacion_id, fecha, usuario_id, estado, caja_origen_id, caja_destino_id, periodo_id)
            VALUES
                (v_op, v_tipo_barrido, v_fecha_periodo, v_usuario, 'CONFIRMADA', v_caja_id, v_central_id, v_periodo.id);
            INSERT INTO mvp_movimientos_caja (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
            VALUES (gen_random_uuid(), v_caja_id,    -v_transfer, v_fecha_periodo, 'CIERRE', v_op::text, v_op);
            INSERT INTO mvp_movimientos_caja (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
            VALUES (gen_random_uuid(), v_central_id,  v_transfer, v_fecha_periodo, 'CIERRE', v_op::text, v_op);
            v_total_swept    := v_total_swept + v_transfer;
            v_cajas_cerradas := v_cajas_cerradas + 1;
        END IF;
    END LOOP;

    -- 7. Detalle de Central (post-barrido).
    v_central := v_preview -> 'central';
    INSERT INTO mvp_cierre_detalle
        (id, cierre_id, caja_id, saldo_inicial, saldo_final, total_ingresos, total_egresos,
         monto_dividendos, monto_transferido_tesoreria, porc_aplicado, tipo_dividendo_aplicado)
    VALUES
        (gen_random_uuid(), v_cierre_id, v_central_id,
         (v_central ->> 'saldo_inicial')::numeric,
         (v_central ->> 'saldo_inicial')::numeric + (v_central ->> 'total_ingresos')::numeric + v_total_swept - (v_central ->> 'total_egresos')::numeric,
         (v_central ->> 'total_ingresos')::numeric + v_total_swept,
         (v_central ->> 'total_egresos')::numeric,
         0, 0, NULL, NULL);

    UPDATE mvp_cierres SET cajas_cerradas = v_cajas_cerradas WHERE id = v_cierre_id;

    -- 8. Resumen del periodo.
    INSERT INTO mvp_cierre_resumen
        (id, cierre_id, total_ventas, total_compras, cantidad_ventas, cantidad_compras,
         cantidad_productos_vendidos, cantidad_clientes_activos, cantidad_proveedores_activos)
    VALUES
        (gen_random_uuid(), v_cierre_id, v_V, v_C,
         (SELECT COUNT(*) FROM mvp_movimientos_caja m JOIN mvp_operacion_caja o ON o.id = m.operacion_id
            WHERE o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA' AND m.tipo_referencia = 'VENTA'),
         (SELECT COUNT(*) FROM mvp_movimientos_caja m JOIN mvp_operacion_caja o ON o.id = m.operacion_id
            WHERE o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA' AND m.tipo_referencia = 'EGRESO'),
         COALESCE((SELECT ROUND(SUM(vd.cantidad))::integer
            FROM mvp_ventas vt JOIN mvp_ventas_detalle vd ON vd.venta_id = vt.id
            WHERE vt.estado IN ('ENTREGADA','COBRADO')
              AND vt.fecha_entrega BETWEEN v_periodo.fecha_inicio AND v_periodo.fecha_fin), 0),
         COALESCE((SELECT COUNT(DISTINCT vt.cliente_id) FROM mvp_ventas vt
            WHERE vt.estado IN ('ENTREGADA','COBRADO')
              AND vt.fecha_entrega BETWEEN v_periodo.fecha_inicio AND v_periodo.fecha_fin), 0),
         COALESCE((SELECT COUNT(DISTINCT e.proveedor_id) FROM mvp_egresos e
            JOIN mvp_operacion_caja o ON o.documento_id = e.id AND o.documento_tipo = 'EGRESO'
            WHERE o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'
              AND e.proveedor_id IS NOT NULL), 0));

    -- 9. Cerrar periodo actual y abrir/crear el siguiente.
    UPDATE mvp_periodo SET estado = 'CERRADO', updated_at = now() WHERE id = v_periodo.id;

    v_next_inicio := (v_periodo.fecha_fin + INTERVAL '1 day')::date;
    v_next_fin    := (date_trunc('month', v_next_inicio) + INTERVAL '1 month - 1 day')::date;
    v_next_codigo := to_char(v_next_inicio, 'YYYY-MM');
    IF NOT EXISTS (SELECT 1 FROM mvp_periodo WHERE codigo = v_next_codigo) THEN
        INSERT INTO mvp_periodo (codigo, fecha_inicio, fecha_fin, estado)
        VALUES (v_next_codigo, v_next_inicio, v_next_fin, 'ABIERTO');
    ELSE
        UPDATE mvp_periodo SET estado = 'ABIERTO', updated_at = now()
         WHERE codigo = v_next_codigo AND estado <> 'CERRADO';
    END IF;

    RETURN json_build_object(
        'ok', true, 'cierre_id', v_cierre_id, 'periodo_cerrado', v_periodo.codigo,
        'V', v_V, 'C', v_C, 'Dv', v_Dv, 'ER', v_ER,
        'total_transferido', v_total_swept, 'cajas_barridas', v_cajas_cerradas,
        'prestamos_saldados', v_prestamos_saldados,
        'periodo_siguiente', v_next_codigo
    );
END;
$$;


ALTER FUNCTION public.fn_ejecutar_cierre(p_periodo_id uuid) OWNER TO postgres;

--
-- Name: fn_fecha_cobro(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_fecha_cobro(p_venta_id uuid) RETURNS date
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  SELECT public.fn_fecha_local(MAX(oc.fecha))
  FROM mvp_operacion_caja oc
  JOIN mvp_tipo_operaciones t ON t.id = oc.tipo_operacion_id
  WHERE oc.documento_tipo = 'VENTA'
    AND oc.documento_id = p_venta_id
    AND t.codigo = 'COBRO'
    AND oc.estado = 'CONFIRMADA';
$$;


ALTER FUNCTION public.fn_fecha_cobro(p_venta_id uuid) OWNER TO postgres;

--
-- Name: fn_fecha_local(timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_fecha_local(p_ts timestamp without time zone) RETURNS date
    LANGUAGE sql STABLE
    SET search_path TO 'public', 'pg_temp'
    AS $$
  SELECT (p_ts AT TIME ZONE 'UTC' AT TIME ZONE 'America/Argentina/Buenos_Aires')::date;
$$;


ALTER FUNCTION public.fn_fecha_local(p_ts timestamp without time zone) OWNER TO postgres;

--
-- Name: fn_fecha_local_desde_ts(timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_fecha_local_desde_ts(p_ts timestamp without time zone) RETURNS date
    LANGUAGE sql STABLE
    SET search_path TO 'public', 'pg_temp'
    AS $$
  SELECT (p_ts AT TIME ZONE 'UTC' AT TIME ZONE 'America/Argentina/Buenos_Aires')::date;
$$;


ALTER FUNCTION public.fn_fecha_local_desde_ts(p_ts timestamp without time zone) OWNER TO postgres;

--
-- Name: FUNCTION fn_fecha_local_desde_ts(p_ts timestamp without time zone); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fn_fecha_local_desde_ts(p_ts timestamp without time zone) IS 'Devuelve la fecha LOCAL (America/Argentina/Buenos_Aires) de un timestamp guardado en UTC sin zona. Inversa de fn_ts_desde_fecha_local. Usar en todo filtro por fecha sobre columnas fecha de mvp_ctacte, mvp_movimientos_caja, mvp_operacion_caja, mvp_egresos y mvp_rendiciones, que se estampan con NOW() en UTC mientras el negocio opera en UTC-3.';


--
-- Name: fn_guard_periodo_operacion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_guard_periodo_operacion() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  IF NEW.periodo_id IS NULL THEN
    RAISE EXCEPTION 'No hay periodo vigente (ABIERTO) para asignar a la operacion';
  END IF;
  IF (SELECT estado FROM mvp_periodo WHERE id = NEW.periodo_id) <> 'ABIERTO' THEN
    RAISE EXCEPTION 'El periodo de la operacion no esta ABIERTO (cierre en curso o cerrado)';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_guard_periodo_operacion() OWNER TO postgres;

--
-- Name: fn_haber_ctacte_a_fecha(uuid, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_haber_ctacte_a_fecha(p_socio_id uuid, p_fecha date) RETURNS numeric
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  SELECT COALESCE(SUM(monto_haber - monto_debe) FILTER (WHERE afecta_saldo), 0)
    FROM mvp_ctacte
   WHERE socio_id = p_socio_id
     AND fecha < public.fn_ts_desde_fecha_local(p_fecha + 1);
$$;


ALTER FUNCTION public.fn_haber_ctacte_a_fecha(p_socio_id uuid, p_fecha date) OWNER TO postgres;

--
-- Name: fn_informe_cierre(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_informe_cierre(p_periodo_id uuid DEFAULT NULL::uuid) RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol               varchar;
    v_periodo           mvp_periodo;
    v_cierre            mvp_cierres;
    v_resumen           mvp_cierre_resumen;
    v_periodo_ant_id    uuid;
    v_central_id        uuid;
    v_corte             timestamp;
    v_V                 numeric;
    v_C                 numeric;
    v_Dv                numeric;
    v_resultado         numeric;
    v_base_gan          numeric;
    v_total_div         numeric;
    v_plantas           integer;
    v_saldo_central_ant numeric;
    v_a_proximo         numeric;
    v_advertencias      text[] := ARRAY[]::text[];
    v_meta              json;
    v_resumen_json      json;
    v_caja_central      json;
    v_cajas_socios      json;
    v_reparto           json;
    v_ventas            json;
    v_compras           json;
    v_ventas_total      numeric;
    v_ventas_items      numeric;
    v_ventas_cant       integer;
    v_compras_sub       numeric;
    v_gastos_sub        numeric;
    v_compras_total     numeric;
    v_es_definitivo     boolean;
    v_txt               text;
    v_cant_ventas_live  integer;
    v_cant_compras_live integer;
    v_clientes_live     integer;
    v_proveedores_live  integer;
    v_sum_gan           numeric;
    -- MARCADOR: fn_informe_cierre v2 2026-07-30 PATCH-Ctacte-B2
    v_ctacte            json;
    v_ctacte_socios     json;
    v_ctacte_totales    json;
    v_ctacte_adv        json;
    v_ctacte_advf       json;
    v_ctacte_div        numeric;
    v_reparto_div       numeric;
    v_desalineados      text;
BEGIN
    v_rol := get_user_rol();
    IF v_rol IS NULL OR (v_rol NOT IN ('tesorero', 'admin') AND NOT public.es_tesorero()) THEN
        RAISE EXCEPTION 'Operacion no autorizada para rol: %', v_rol
            USING ERRCODE = 'P0001';
    END IF;

    IF p_periodo_id IS NULL THEN
        SELECT * INTO v_periodo FROM mvp_periodo
         WHERE estado = 'CERRADO' ORDER BY fecha_fin DESC LIMIT 1;
    ELSE
        SELECT * INTO v_periodo FROM mvp_periodo WHERE id = p_periodo_id;
    END IF;

    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'Periodo no encontrado o no existe ningun periodo cerrado'
            USING ERRCODE = 'P0001', HINT = 'INFORME_PERIODO_INEXISTENTE';
    END IF;

    v_es_definitivo := (v_periodo.estado = 'CERRADO');

    IF v_es_definitivo THEN
        SELECT * INTO v_cierre FROM mvp_cierres WHERE periodo_id = v_periodo.id;
        IF v_cierre.id IS NULL THEN
            RAISE EXCEPTION 'No hay cierre registrado para el periodo %', v_periodo.codigo
                USING ERRCODE = 'P0001', HINT = 'INFORME_SIN_CIERRE';
        END IF;

        SELECT * INTO v_resumen FROM mvp_cierre_resumen WHERE cierre_id = v_cierre.id;
        IF v_resumen.id IS NULL THEN
            RAISE EXCEPTION 'No hay resumen registrado para el cierre del periodo %', v_periodo.codigo
                USING ERRCODE = 'P0001', HINT = 'INFORME_SIN_RESUMEN';
        END IF;
    END IF;

    v_corte := (v_periodo.fecha_fin + INTERVAL '1 day')::timestamp;

    SELECT id INTO v_central_id FROM mvp_cajas WHERE tipo = 'CENTRAL' LIMIT 1;

    SELECT id INTO v_periodo_ant_id FROM mvp_periodo
     WHERE fecha_fin < v_periodo.fecha_inicio ORDER BY fecha_fin DESC LIMIT 1;

    IF v_es_definitivo THEN
        v_V       := v_resumen.total_ventas;
        v_C       := v_resumen.total_compras;
        v_plantas := v_resumen.cantidad_productos_vendidos;

        SELECT COALESCE(SUM(cd.monto_dividendos), 0) INTO v_Dv
          FROM mvp_cierre_detalle cd
         WHERE cd.cierre_id = v_cierre.id AND cd.tipo_dividendo_aplicado = 'VENTA';

        SELECT COALESCE(SUM(cd.monto_dividendos), 0) INTO v_total_div
          FROM mvp_cierre_detalle cd WHERE cd.cierre_id = v_cierre.id;
    ELSE
        SELECT COALESCE(SUM(m.monto) FILTER (WHERE m.tipo_referencia = 'VENTA'), 0),
               COALESCE(SUM(ABS(m.monto)) FILTER (WHERE m.tipo_referencia = 'EGRESO'), 0),
               COUNT(*) FILTER (WHERE m.tipo_referencia = 'VENTA'),
               COUNT(*) FILTER (WHERE m.tipo_referencia = 'EGRESO')
          INTO v_V, v_C, v_cant_ventas_live, v_cant_compras_live
          FROM mvp_movimientos_caja m
          JOIN mvp_operacion_caja o ON o.id = m.operacion_id
         WHERE o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA';

        SELECT COALESCE(ROUND(SUM(vd.cantidad))::integer, 0) INTO v_plantas
          FROM mvp_ventas vt JOIN mvp_ventas_detalle vd ON vd.venta_id = vt.id
         WHERE vt.estado IN ('ENTREGADA','COBRADO')
           AND vt.fecha_entrega BETWEEN v_periodo.fecha_inicio AND v_periodo.fecha_fin;

        SELECT COALESCE(COUNT(DISTINCT vt.cliente_id), 0) INTO v_clientes_live
          FROM mvp_ventas vt
         WHERE vt.estado IN ('ENTREGADA','COBRADO')
           AND vt.fecha_entrega BETWEEN v_periodo.fecha_inicio AND v_periodo.fecha_fin;

        SELECT COALESCE(COUNT(DISTINCT e.proveedor_id), 0) INTO v_proveedores_live
          FROM mvp_egresos e
          JOIN mvp_operacion_caja o ON o.documento_id = e.id AND o.documento_tipo = 'EGRESO'
         WHERE o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'
           AND e.proveedor_id IS NOT NULL;

        SELECT ROUND(COALESCE(SUM(porc_venta / 100.0 * v_V), 0), 2) INTO v_Dv
          FROM mvp_socios WHERE porc_venta > 0;
    END IF;

    v_resultado := v_V - v_C;
    v_base_gan  := v_V - v_C - v_Dv;

    SELECT COALESCE((
        SELECT cd.saldo_final FROM mvp_cierre_detalle cd
          JOIN mvp_cierres ci ON ci.id = cd.cierre_id
         WHERE ci.periodo_id = v_periodo_ant_id AND cd.caja_id = v_central_id
         LIMIT 1), 0)
      INTO v_saldo_central_ant;

    IF v_es_definitivo THEN
        SELECT COALESCE(SUM(CASE WHEN cd.saldo_final < 0 THEN -cd.saldo_final ELSE 0 END), 0)
          INTO v_a_proximo
          FROM mvp_cierre_detalle cd
          JOIN mvp_cajas c ON c.id = cd.caja_id
         WHERE cd.cierre_id = v_cierre.id AND c.tipo = 'SOCIO';
    ELSE
        SELECT COALESCE(SUM(CASE WHEN calcular_saldo_caja(c.id) < 0
                                 THEN -calcular_saldo_caja(c.id) ELSE 0 END), 0)
          INTO v_a_proximo
          FROM mvp_cajas c JOIN mvp_users u ON u.id = c.user_id
         WHERE c.tipo = 'SOCIO' AND u.activo;
    END IF;

    IF v_plantas = 0 THEN
        v_advertencias := v_advertencias
            || 'Plantas vendidas en cero: no se puede calcular el precio promedio por planta.'::text;
    END IF;

    IF v_es_definitivo AND ROUND(v_total_div, 2) <> ROUND(v_resultado, 2) THEN
        v_advertencias := v_advertencias || format(
            'Los dividendos distribuidos (%s) no coinciden con el resultado del periodo (%s).',
            ROUND(v_total_div, 2), ROUND(v_resultado, 2));
    END IF;

    IF NOT v_es_definitivo THEN
        v_advertencias := v_advertencias
            || 'Informe PROVISORIO sobre un periodo no cerrado: las cifras cambian con cada operacion y el reparto es una proyeccion, no un resultado.'::text;

        SELECT string_agg(u.nombre || ' (' ||
                          to_char(calcular_saldo_caja(c.id), 'FM999G999G990D00') || ')', ', ')
          INTO v_txt
          FROM mvp_cajas c JOIN mvp_users u ON u.id = c.user_id
         WHERE c.tipo = 'REPARTIDOR' AND u.activo AND calcular_saldo_caja(c.id) <> 0;
        IF v_txt IS NOT NULL THEN
            v_advertencias := v_advertencias
                || ('Cajas repartidoras con saldo sin rendir: ' || v_txt ||
                    '. Sus ventas ya cuentan en el total cobrado, pero ese efectivo no esta en ninguna caja delegada. Si el cierre se ejecuta asi, el reparto de dividendos sale mal.');
        END IF;

        SELECT string_agg(c.nombre, ', ') INTO v_txt
          FROM mvp_cajas c
          JOIN mvp_users  u ON u.id = c.user_id
          LEFT JOIN mvp_socios s ON s.user_id = c.user_id
         WHERE c.tipo = 'SOCIO' AND u.activo
           AND NOT (COALESCE(u.es_tester, false)
                    AND COALESCE(s.porc_venta, 0) = 0
                    AND COALESCE(s.porc_ganancia, 0) = 0
                    AND public.calcular_saldo_caja(c.id) = 0)
           AND NOT EXISTS (SELECT 1 FROM mvp_rendiciones r
                            WHERE r.caja_id = c.id AND r.periodo_id = v_periodo.id);
        IF v_txt IS NOT NULL THEN
            v_advertencias := v_advertencias
                || ('Cajas delegadas sin rendir en el periodo: ' || v_txt || '.');
        END IF;

        SELECT COALESCE(SUM(porc_ganancia), 0) INTO v_sum_gan FROM mvp_socios;
        IF v_sum_gan <> 100 THEN
            v_advertencias := v_advertencias || format(
                'Los porcentajes de ganancia suman %s%% en vez de 100%%: el cierre no va a poder ejecutarse.',
                v_sum_gan);
        END IF;

        SELECT string_agg(u.nombre, ', ') INTO v_txt
          FROM mvp_socios s JOIN mvp_users u ON u.id = s.user_id
         WHERE s.porc_venta > 0 AND s.porc_ganancia > 0;
        IF v_txt IS NOT NULL THEN
            v_advertencias := v_advertencias
                || ('Socios con doble porcentaje cargado (' || v_txt ||
                    '): cobran por ganancia, pero su porcentaje de venta igual descuenta del resultado.');
        END IF;
    END IF;

    SELECT string_agg(c.nombre, ', ') INTO v_txt
      FROM mvp_cajas c
      JOIN mvp_users  u ON u.id = c.user_id
      LEFT JOIN mvp_socios s ON s.user_id = c.user_id
     WHERE COALESCE(u.es_tester, false)
       AND COALESCE(s.porc_venta, 0) = 0
       AND COALESCE(s.porc_ganancia, 0) = 0
       AND (public.calcular_saldo_caja(c.id) <> 0
            OR EXISTS (SELECT 1 FROM mvp_movimientos_caja m
                         JOIN mvp_operacion_caja o ON o.id = m.operacion_id
                        WHERE m.caja_id = c.id
                          AND o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'));
    IF v_txt IS NOT NULL THEN
        v_advertencias := v_advertencias
            || ('Cajas de tester con operaciones de prueba sin limpiar: ' || v_txt ||
                '. Esas operaciones computan en las ventas y en los gastos del periodo. Correr el LIMPIADOR antes del cierre.');
    END IF;

    v_resumen_json := json_build_object(
        'ventas_cobradas',         v_V,
        'gastos_compras',          v_C,
        'resultado_periodo',       v_resultado,
        'plantas_vendidas',        v_plantas,
        'precio_prom_planta',      CASE WHEN v_plantas > 0 THEN ROUND(v_V / v_plantas, 2) ELSE 0 END,
        'pct_gastos_ventas',       CASE WHEN v_V > 0 THEN ROUND(v_C / v_V * 100, 2) ELSE 0 END,
        'dividendos_venta',        v_Dv,
        'base_dividendo_ganancia', v_base_gan,
        'cantidad_ventas',         COALESCE(v_resumen.cantidad_ventas, v_cant_ventas_live),
        'cantidad_compras',        COALESCE(v_resumen.cantidad_compras, v_cant_compras_live),
        'clientes_activos',        COALESCE(v_resumen.cantidad_clientes_activos, v_clientes_live),
        'proveedores_activos',     COALESCE(v_resumen.cantidad_proveedores_activos, v_proveedores_live)
    );

    v_caja_central := json_build_object(
        'saldo_mes_anterior',      v_saldo_central_ant,
        'resultado_periodo',       v_resultado,
        'dividendos_venta',        v_Dv,
        'a_proximo_mes',           v_a_proximo,
        'base_dividendo_ganancia', v_base_gan,
        'saldo_final_central',     CASE WHEN v_es_definitivo THEN COALESCE((
            SELECT cd.saldo_final FROM mvp_cierre_detalle cd
             WHERE cd.cierre_id = v_cierre.id AND cd.caja_id = v_central_id), 0)
            ELSE calcular_saldo_caja(v_central_id) END
    );

    WITH base AS (
        SELECT c.id AS caja_id, u.nombre AS socio, u.es_tester,
               COALESCE(cd.monto_transferido_tesoreria, calcular_saldo_caja(c.id)) AS saldo_caja,
               COALESCE(cd.monto_dividendos, 0) AS monto_dividendos,
               COALESCE((SELECT SUM(m.monto) FROM mvp_movimientos_caja m
                           JOIN mvp_operacion_caja o ON o.id = m.operacion_id
                          WHERE m.caja_id = c.id AND m.tipo_referencia = 'VENTA'
                            AND o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'), 0) AS ventas_cobradas,
               COALESCE((SELECT SUM(m.monto) FROM mvp_movimientos_caja m
                           JOIN mvp_operacion_caja o ON o.id = m.operacion_id
                           JOIN mvp_cajas cori ON cori.id = o.caja_origen_id
                          WHERE m.caja_id = c.id AND m.tipo_referencia = 'TRANSFERENCIA' AND m.monto > 0
                            AND cori.tipo = 'REPARTIDOR'
                            AND o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'), 0) AS venta_cobrada_repartidor,
               COALESCE((SELECT SUM(ABS(m.monto)) FROM mvp_movimientos_caja m
                           JOIN mvp_operacion_caja o ON o.id = m.operacion_id
                          WHERE m.caja_id = c.id AND m.tipo_referencia = 'EGRESO'
                            AND o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'), 0) AS gastos_compras,
               COALESCE((SELECT SUM(m.monto) FROM mvp_movimientos_caja m
                           JOIN mvp_operacion_caja o ON o.id = m.operacion_id
                           LEFT JOIN mvp_cajas cori ON cori.id = o.caja_origen_id
                          WHERE m.caja_id = c.id AND m.tipo_referencia = 'TRANSFERENCIA' AND m.monto > 0
                            AND COALESCE(cori.tipo, '') <> 'REPARTIDOR'
                            AND o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'), 0) AS transf_recibidas,
               COALESCE((SELECT SUM(-m.monto) FROM mvp_movimientos_caja m
                           JOIN mvp_operacion_caja o ON o.id = m.operacion_id
                          WHERE m.caja_id = c.id AND m.tipo_referencia = 'TRANSFERENCIA' AND m.monto < 0
                            AND o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'), 0) AS transf_enviadas,
               COALESCE((SELECT COUNT(*) FROM mvp_movimientos_caja m
                           JOIN mvp_operacion_caja o ON o.id = m.operacion_id
                          WHERE m.caja_id = c.id
                            AND o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'), 0) AS movimientos
          FROM mvp_cajas c
          JOIN mvp_users u ON u.id = c.user_id
          LEFT JOIN mvp_cierre_detalle cd
                 ON cd.caja_id = c.id AND cd.cierre_id = v_cierre.id
         WHERE c.tipo = 'SOCIO'
           AND (cd.caja_id IS NOT NULL OR NOT v_es_definitivo)
           AND (v_es_definitivo OR u.activo)
    )
    SELECT COALESCE(json_agg(json_build_object(
               'socio',                    socio,
               'ventas_cobradas',          ventas_cobradas,
               'venta_cobrada_repartidor', venta_cobrada_repartidor,
               'gastos_compras',           gastos_compras,
               'transf_recibidas',         transf_recibidas,
               'transf_enviadas',          transf_enviadas,
               'saldo_caja',               saldo_caja
           ) ORDER BY socio), '[]'::json)
      INTO v_cajas_socios
      FROM base
     WHERE NOT es_tester OR movimientos > 0 OR monto_dividendos <> 0;

    SELECT COALESCE(json_agg(json_build_object(
               'socio',            nombre,
               'tipo',             tipo,
               'dividendo',        dividendo,
               'saldo_anterior',   saldo_anterior,
               'saldo_disponible', saldo_anterior + dividendo
           ) ORDER BY nombre), '[]'::json)
      INTO v_reparto
      FROM (
        SELECT u.nombre,
               CASE WHEN v_es_definitivo                        THEN cd.tipo_dividendo_aplicado
                    WHEN COALESCE(s.porc_ganancia, 0) > 0       THEN 'GANANCIA'
                    WHEN COALESCE(s.porc_venta, 0) > 0          THEN 'VENTA'
               END AS tipo,
               CASE WHEN v_es_definitivo                        THEN COALESCE(cd.monto_dividendos, 0)
                    WHEN COALESCE(s.porc_ganancia, 0) > 0       THEN ROUND(s.porc_ganancia / 100.0 * v_base_gan, 2)
                    WHEN COALESCE(s.porc_venta, 0) > 0          THEN ROUND(s.porc_venta / 100.0 * v_V, 2)
                    ELSE 0
               END AS dividendo,
               CASE WHEN v_es_definitivo
                    THEN COALESCE(hb.haber, 0) - COALESCE(cd.monto_dividendos, 0)
                    ELSE COALESCE(hb.haber, 0)
               END AS saldo_anterior
          FROM mvp_cajas c
          JOIN mvp_users u  ON u.id = c.user_id
          JOIN mvp_socios s ON s.user_id = c.user_id
          LEFT JOIN mvp_cierre_detalle cd
                 ON cd.caja_id = c.id AND cd.cierre_id = v_cierre.id
          LEFT JOIN LATERAL (
              SELECT SUM(ct.monto_haber - ct.monto_debe) AS haber
                FROM mvp_ctacte ct
               WHERE ct.socio_id = s.user_id AND ct.afecta_saldo
                 AND ct.fecha < v_corte
          ) hb ON true
         WHERE c.tipo = 'SOCIO'
           AND (v_es_definitivo OR u.activo)
           AND (NOT u.es_tester
                OR COALESCE(hb.haber, 0) <> 0
                OR COALESCE(cd.monto_dividendos, 0) <> 0)
      ) r;


    SELECT COALESCE(json_agg(json_build_object(
               'fecha',        fecha,
               'cliente',      cliente,
               'nro_factura',  nro_factura,
               'caja_destino', caja_destino,
               'total',        total,
               'items',        items
           ) ORDER BY fecha, nro_factura), '[]'::json),
           COALESCE(SUM(total), 0),
           COALESCE(SUM(items_total), 0),
           COUNT(*)
      INTO v_ventas, v_ventas_total, v_ventas_items, v_ventas_cant
      FROM (
        SELECT vt.fecha_entrega AS fecha,
               cl.razon_social  AS cliente,
               vt.nro_factura   AS nro_factura,
               cj.nombre        AS caja_destino,
               m.monto          AS total,
               COALESCE((SELECT SUM(vd.cantidad * vd.precio_real)
                           FROM mvp_ventas_detalle vd
                          WHERE vd.venta_id = vt.id), 0) AS items_total,
               COALESCE((SELECT json_agg(json_build_object(
                             'producto', pr.nombre,
                             'cantidad', vd.cantidad,
                             'precio',   vd.precio_real,
                             'subtotal', ROUND(vd.cantidad * vd.precio_real, 2)
                         ) ORDER BY pr.nombre)
                           FROM mvp_ventas_detalle vd
                           JOIN mvp_productos pr ON pr.id = vd.producto_id
                          WHERE vd.venta_id = vt.id), '[]'::json) AS items
          FROM mvp_movimientos_caja m
          JOIN mvp_operacion_caja o ON o.id = m.operacion_id
          JOIN mvp_ventas vt ON vt.id = o.documento_id AND o.documento_tipo = 'VENTA'
          JOIN mvp_clientes cl ON cl.id = vt.cliente_id
          JOIN mvp_cajas cj ON cj.id = m.caja_id
         WHERE m.tipo_referencia = 'VENTA'
           AND o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'
      ) v;

    IF ROUND(v_ventas_total, 2) <> ROUND(v_ventas_items, 2) THEN
        v_advertencias := v_advertencias || format(
            'El total cobrado (%s) difiere de la suma de los items de venta (%s).',
            ROUND(v_ventas_total, 2), ROUND(v_ventas_items, 2));
    END IF;

    IF ROUND(v_ventas_total, 2) <> ROUND(v_V, 2) THEN
        v_advertencias := v_advertencias || format(
            'El detalle de ventas (%s) no cuadra con el total de ventas del cierre (%s).',
            ROUND(v_ventas_total, 2), ROUND(v_V, 2));
    END IF;

    SELECT COALESCE(json_agg(json_build_object(
               'fecha',       fecha,
               'tipo',        tipo,
               'proveedor',   proveedor,
               'descripcion', descripcion,
               'socio',       socio,
               'monto',       monto
           ) ORDER BY fecha, proveedor), '[]'::json),
           COALESCE(SUM(monto) FILTER (WHERE tipo = 'COMPRA'), 0),
           COALESCE(SUM(monto) FILTER (WHERE tipo = 'GASTO'), 0),
           COALESCE(SUM(monto), 0)
      INTO v_compras, v_compras_sub, v_gastos_sub, v_compras_total
      FROM (
        SELECT e.fecha        AS fecha,
               e.tipo         AS tipo,
               pv.nombre      AS proveedor,
               e.descripcion  AS descripcion,
               u.nombre       AS socio,
               ABS(m.monto)   AS monto
          FROM mvp_movimientos_caja m
          JOIN mvp_operacion_caja o ON o.id = m.operacion_id
          JOIN mvp_egresos e ON e.id = o.documento_id AND o.documento_tipo = 'EGRESO'
          JOIN mvp_cajas cj ON cj.id = m.caja_id
          LEFT JOIN mvp_proveedores pv ON pv.id = e.proveedor_id
          LEFT JOIN mvp_users u ON u.id = cj.user_id
         WHERE m.tipo_referencia = 'EGRESO'
           AND o.periodo_id = v_periodo.id AND o.estado = 'CONFIRMADA'
      ) g;

    IF ROUND(v_compras_total, 2) <> ROUND(v_C, 2) THEN
        v_advertencias := v_advertencias || format(
            'El detalle de compras y gastos (%s) no cuadra con el total del cierre (%s).',
            ROUND(v_compras_total, 2), ROUND(v_C, 2));
    END IF;

    v_ctacte         := public.fn_movimientos_ctacte_todos(v_periodo.id);
    v_ctacte_socios  := v_ctacte -> 'socios';
    v_ctacte_totales := v_ctacte -> 'totales';
    v_ctacte_adv     := v_ctacte -> 'advertencias';
    v_ctacte_advf    := v_ctacte -> 'advertencias_fecha';

    IF json_array_length(v_ctacte_adv) > 0 THEN
        v_advertencias := v_advertencias || format(
            'El bloque de cuentas corrientes no cuadra en %s socio(s).',
            json_array_length(v_ctacte_adv));
    END IF;

    IF json_array_length(v_ctacte_advf) > 0 THEN
        v_advertencias := v_advertencias || format(
            'Hay %s asiento(s) de cuenta corriente imputados a este periodo con fecha fuera de su rango.',
            json_array_length(v_ctacte_advf));
    END IF;

    IF v_es_definitivo THEN
        SELECT COALESCE(SUM((e ->> 'dividendo')::numeric), 0) INTO v_reparto_div
          FROM json_array_elements(v_reparto) e;

        SELECT COALESCE(SUM((m ->> 'haber')::numeric), 0) INTO v_ctacte_div
          FROM json_array_elements(v_ctacte_socios) cs,
               json_array_elements(cs -> 'movimientos') m
         WHERE m ->> 'tipo' = 'DIVIDENDOS';

        IF ROUND(v_ctacte_div, 2) <> ROUND(v_reparto_div, 2) THEN
            v_advertencias := v_advertencias || format(
                'Los dividendos asentados en cuenta corriente (%s) no coinciden con el reparto del cierre (%s).',
                ROUND(v_ctacte_div, 2), ROUND(v_reparto_div, 2));
        END IF;

        SELECT string_agg(r ->> 'socio', ', ') INTO v_desalineados
          FROM json_array_elements(v_reparto) r
          JOIN json_array_elements(v_ctacte_socios) cs
            ON cs ->> 'nombre' = r ->> 'socio'
         WHERE ROUND((r ->> 'saldo_disponible')::numeric, 2)
            <> ROUND((cs ->> 'saldo_periodo')::numeric, 2);
        IF v_desalineados IS NOT NULL THEN
            v_advertencias := v_advertencias || format(
                'El saldo disponible del reparto no coincide con el saldo de cuenta corriente al cierre para: %s.',
                v_desalineados);
        END IF;
    END IF;

    v_meta := json_build_object(
        'periodo_codigo',  v_periodo.codigo,
        'periodo_inicio',  v_periodo.fecha_inicio,
        'periodo_fin',     v_periodo.fecha_fin,
        'periodo_estado',  v_periodo.estado,
        'caracter',        CASE WHEN v_es_definitivo THEN 'DEFINITIVO' ELSE 'PROVISORIO' END,
        'fecha_cierre',    to_char(v_cierre.fecha_cierre AT TIME ZONE 'America/Argentina/Buenos_Aires',
                                   'YYYY-MM-DD"T"HH24:MI:SS'),
        'fecha_emision',   to_char(now() AT TIME ZONE 'America/Argentina/Buenos_Aires',
                                   'YYYY-MM-DD"T"HH24:MI:SS'),
        'version_informe', 2,
        'advertencias',    to_json(v_advertencias)
    );

    RETURN json_build_object(
        'meta', v_meta,
        'dashboard', json_build_object(
            'resumen',       v_resumen_json,
            'caja_central',  v_caja_central,
            'cajas_socios',  v_cajas_socios,
            'reparto',       v_reparto
        ),
        'ventas', json_build_object(
            'operaciones',          v_ventas,
            'cantidad_operaciones', v_ventas_cant,
            'total',                v_ventas_total
        ),
        'compras', json_build_object(
            'filas',            v_compras,
            'subtotal_compras', v_compras_sub,
            'subtotal_gastos',  v_gastos_sub,
            'total',            v_compras_total
        ),
        'ctacte', json_build_object(
            'socios',  v_ctacte_socios,
            'totales', v_ctacte_totales
        )
    );
END;
$$;


ALTER FUNCTION public.fn_informe_cierre(p_periodo_id uuid) OWNER TO postgres;

--
-- Name: fn_listar_movimientos_mi_caja(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_listar_movimientos_mi_caja(p_caja_id uuid) RETURNS TABLE(mov_id uuid, mov_fecha timestamp without time zone, mov_monto numeric, tipo_referencia character varying, tipo_codigo character varying, tipo_nombre character varying, contraparte character varying)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM mvp_cajas c
    WHERE c.id = p_caja_id
      AND c.tipo = 'SOCIO'
      AND c.user_id = auth.uid()
  ) THEN
    RAISE EXCEPTION 'Caja % no pertenece al usuario o no es tipo SOCIO', p_caja_id
      USING ERRCODE = '42501';
  END IF;

  RETURN QUERY
  SELECT
    m.id,
    m.fecha,
    m.monto,
    m.tipo_referencia,
    t.codigo,
    t.nombre,
    CASE
      WHEN t.codigo = 'COBRO' THEN (
        SELECT cl.razon_social
        FROM mvp_clientes cl
        WHERE cl.id = COALESCE(
          o.tercero_id,
          (SELECT v.cliente_id FROM mvp_ventas v WHERE v.id = o.documento_id)
        )
      )
      WHEN t.codigo = 'PAGO' THEN (
        SELECT CASE WHEN p.activo THEN p.nombre ELSE p.nombre || ' (baja)' END
        FROM mvp_egresos e
        LEFT JOIN mvp_proveedores p ON p.id = e.proveedor_id
        WHERE e.id = o.documento_id
      )
      WHEN t.codigo IN (
        'TRANSFERENCIA','ADELANTO',
        'PRESTAMO_ENTRE_SOCIOS','CANCELACION_PRESTAMO_ENTRE_SOCIOS',
        'ASISTENCIA_CAJA_DELEGADA','RECAUDACION_ANTICIPADA'
      ) THEN
        CASE
          WHEN o.caja_origen_id = p_caja_id
            THEN (SELECT c2.nombre FROM mvp_cajas c2 WHERE c2.id = o.caja_destino_id)
          WHEN o.caja_destino_id = p_caja_id
            THEN (SELECT c2.nombre FROM mvp_cajas c2 WHERE c2.id = o.caja_origen_id)
          ELSE NULL
        END
      ELSE NULL
    END
  FROM mvp_movimientos_caja m
  LEFT JOIN mvp_operacion_caja o   ON o.id = m.operacion_id
  LEFT JOIN mvp_tipo_operaciones t ON t.id = o.tipo_operacion_id
  WHERE m.caja_id = p_caja_id
  ORDER BY m.fecha DESC;
END;$$;


ALTER FUNCTION public.fn_listar_movimientos_mi_caja(p_caja_id uuid) OWNER TO postgres;

--
-- Name: fn_listar_prestamos_socio(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_listar_prestamos_socio() RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol        varchar;
    v_mi_caja    uuid;
    v_periodo_id uuid;
    v_dados      json;
    v_recibidos  json;
BEGIN
    v_rol := get_user_rol();
    IF v_rol <> 'socio' THEN
        RAISE EXCEPTION 'Operación reservada al rol socio. Rol actual: %', v_rol
            USING ERRCODE = 'P0001';
    END IF;

    SELECT id INTO v_mi_caja
    FROM mvp_cajas
    WHERE tipo = 'SOCIO' AND user_id = auth.uid()
    LIMIT 1;
    IF v_mi_caja IS NULL THEN
        RAISE EXCEPTION 'El socio no tiene caja asignada'
            USING ERRCODE = 'P0001';
    END IF;

    -- Período vigente: se muestran las transferencias de este período
    -- MÁS todas las pendientes de cualquier período (no son arrastrables ni obligan devolución).
    v_periodo_id := fn_periodo_vigente_id();

    SELECT COALESCE(json_agg(x ORDER BY x.fecha DESC), '[]'::json) INTO v_dados
    FROM (
        SELECT
            op.id AS operacion_id,
            u.nombre AS contraparte,
            (SELECT ABS(m.monto) FROM mvp_movimientos_caja m
              WHERE m.operacion_id = op.id AND m.caja_id = op.caja_origen_id LIMIT 1) AS monto,
            op.fecha,
            CASE WHEN EXISTS (SELECT 1 FROM mvp_operacion_caja c
                              WHERE c.operacion_relacionada_id = op.id)
                 THEN 'SALDADA' ELSE 'PENDIENTE' END AS estado
        FROM mvp_operacion_caja op
        JOIN mvp_tipo_operaciones t ON t.id = op.tipo_operacion_id
        JOIN mvp_cajas cd ON cd.id = op.caja_destino_id
        JOIN mvp_users u ON u.id = cd.user_id
        WHERE t.codigo = 'PRESTAMO_ENTRE_SOCIOS'
          AND op.caja_origen_id = v_mi_caja
          AND (op.periodo_id = v_periodo_id
               OR NOT EXISTS (SELECT 1 FROM mvp_operacion_caja c
                              WHERE c.operacion_relacionada_id = op.id))
    ) x;

    SELECT COALESCE(json_agg(y ORDER BY y.fecha DESC), '[]'::json) INTO v_recibidos
    FROM (
        SELECT
            op.id AS operacion_id,
            u.nombre AS contraparte,
            (SELECT ABS(m.monto) FROM mvp_movimientos_caja m
              WHERE m.operacion_id = op.id AND m.caja_id = op.caja_destino_id LIMIT 1) AS monto,
            op.fecha,
            CASE WHEN EXISTS (SELECT 1 FROM mvp_operacion_caja c
                              WHERE c.operacion_relacionada_id = op.id)
                 THEN 'SALDADA' ELSE 'PENDIENTE' END AS estado
        FROM mvp_operacion_caja op
        JOIN mvp_tipo_operaciones t ON t.id = op.tipo_operacion_id
        JOIN mvp_cajas co ON co.id = op.caja_origen_id
        JOIN mvp_users u ON u.id = co.user_id
        WHERE t.codigo = 'PRESTAMO_ENTRE_SOCIOS'
          AND op.caja_destino_id = v_mi_caja
          AND (op.periodo_id = v_periodo_id
               OR NOT EXISTS (SELECT 1 FROM mvp_operacion_caja c
                              WHERE c.operacion_relacionada_id = op.id))
    ) y;

    RETURN json_build_object('dados', v_dados, 'recibidos', v_recibidos);
END;
$$;


ALTER FUNCTION public.fn_listar_prestamos_socio() OWNER TO postgres;

--
-- Name: fn_listar_rendiciones_pendientes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_listar_rendiciones_pendientes() RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol  varchar;
    v_out  json;
BEGIN
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Sesión sin usuario autenticado.' USING ERRCODE = '28000';
    END IF;

    v_rol := get_user_rol();
    IF v_rol IS DISTINCT FROM 'admin' THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol USING ERRCODE = '42501';
    END IF;

    SELECT COALESCE(json_agg(t ORDER BY t.nombre), '[]'::json) INTO v_out
    FROM (
        SELECT
            u.id                              AS repartidor_id,
            u.nombre                          AS nombre,
            cr.id                             AS caja_repartidor_id,
            calcular_saldo_caja(cr.id)        AS saldo,
            cs.id                             AS caja_delegada_id,
            (cs.id IS NOT NULL)               AS puede_rendirse
        FROM mvp_repartidores r
        JOIN mvp_users  u  ON u.id = r.user_id AND u.activo = true
        JOIN mvp_cajas  cr ON cr.user_id = r.user_id AND cr.tipo = 'REPARTIDOR'
        LEFT JOIN mvp_cajas cs ON cs.user_id = r.user_id AND cs.tipo = 'SOCIO'
        WHERE r.activo = true
          AND calcular_saldo_caja(cr.id) > 0
    ) t;

    RETURN v_out;
END;
$$;


ALTER FUNCTION public.fn_listar_rendiciones_pendientes() OWNER TO postgres;

--
-- Name: FUNCTION fn_listar_rendiciones_pendientes(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fn_listar_rendiciones_pendientes() IS 'RN-T12. Lista repartidores activos con saldo > 0 en su Caja Repartidor. Solo rol admin. Alimenta SCR-RendicionAdministrativa.';


--
-- Name: fn_listar_socios(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_listar_socios() RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol    varchar;
    v_result json;
BEGIN
    v_rol := get_user_rol();
    IF v_rol NOT IN ('admin','tesorero') AND NOT public.es_tesorero() THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol USING ERRCODE='P0001';
    END IF;
    SELECT COALESCE(json_agg(json_build_object(
        'socio_id', s.user_id, 'nombre', u.nombre
    ) ORDER BY u.nombre), '[]'::json)
    INTO v_result
    FROM mvp_socios s
    JOIN mvp_users u ON u.id = s.user_id
    WHERE u.activo = true;
    RETURN v_result;
END;
$$;


ALTER FUNCTION public.fn_listar_socios() OWNER TO postgres;

--
-- Name: fn_listar_socios_para_prestamo(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_listar_socios_para_prestamo() RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol varchar;
    v_resultado json;
BEGIN
    v_rol := get_user_rol();
    IF v_rol <> 'socio' THEN
        RAISE EXCEPTION 'Operación reservada al rol socio. Rol actual: %', v_rol
            USING ERRCODE = 'P0001';
    END IF;

    SELECT COALESCE(json_agg(
             json_build_object('caja_id', c.id, 'socio_nombre', u.nombre)
             ORDER BY u.nombre
           ), '[]'::json)
    INTO v_resultado
    FROM mvp_cajas c
    JOIN mvp_users u ON u.id = c.user_id
    WHERE c.tipo = 'SOCIO'
      AND u.activo = true
      AND c.user_id <> auth.uid();

    RETURN v_resultado;
END;
$$;


ALTER FUNCTION public.fn_listar_socios_para_prestamo() OWNER TO postgres;

--
-- Name: fn_listar_transferencias_periodo(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_listar_transferencias_periodo() RETURNS TABLE(operacion_id uuid, fecha timestamp without time zone, tipo_codigo character varying, tipo_nombre character varying, monto numeric, origen character varying, destino character varying, observaciones text, nro_comprobante integer)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol varchar;
BEGIN
    v_rol := get_user_rol();
    IF v_rol IS NULL OR (v_rol NOT IN ('tesorero', 'admin') AND NOT public.es_tesorero()) THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol
            USING ERRCODE = 'P0001', HINT = 'NO_AUTORIZADO';
    END IF;

    RETURN QUERY
    SELECT
        o.id,
        o.fecha,
        t.codigo,
        t.nombre,
        COALESCE((SELECT ABS(m.monto) FROM mvp_movimientos_caja m
                   WHERE m.operacion_id = o.id AND m.caja_id = o.caja_origen_id
                   LIMIT 1), 0),
        (SELECT c.nombre FROM mvp_cajas c WHERE c.id = o.caja_origen_id),
        COALESCE(
            (SELECT c.nombre FROM mvp_cajas c WHERE c.id = o.caja_destino_id),
            (SELECT u.nombre FROM mvp_users u WHERE u.id = o.tercero_id)
        ),
        o.observaciones,
        o.nro_comprobante
      FROM mvp_operacion_caja o
      JOIN mvp_tipo_operaciones t ON t.id = o.tipo_operacion_id
     WHERE o.periodo_id = fn_periodo_vigente_id()
       AND o.estado = 'CONFIRMADA'
       AND t.codigo IN ('ASISTENCIA_CAJA_DELEGADA', 'RECAUDACION_ANTICIPADA', 'ADELANTO')
     ORDER BY o.fecha DESC;
END;
$$;


ALTER FUNCTION public.fn_listar_transferencias_periodo() OWNER TO postgres;

--
-- Name: fn_listar_ventas_pendientes_caja(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_listar_ventas_pendientes_caja(p_caja_id uuid) RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_uid       uuid := auth.uid();
    v_rol       varchar;
    v_caja_tipo varchar;
    v_caja_user uuid;
    v_saldo     numeric;
    v_out       json;
BEGIN
    IF v_uid IS NULL THEN
        RAISE EXCEPTION 'Sesión sin usuario autenticado.' USING ERRCODE = '28000';
    END IF;
    v_rol := get_user_rol();

    SELECT tipo, user_id INTO v_caja_tipo, v_caja_user
      FROM mvp_cajas WHERE id = p_caja_id;
    IF v_caja_tipo IS NULL THEN
        RAISE EXCEPTION 'Caja inexistente.' USING ERRCODE = 'P0002';
    END IF;
    IF v_caja_tipo <> 'REPARTIDOR' THEN
        RAISE EXCEPTION 'La caja no es de tipo REPARTIDOR.' USING ERRCODE = '22023';
    END IF;

    IF v_rol IS DISTINCT FROM 'admin' AND v_caja_user IS DISTINCT FROM v_uid THEN
        RAISE EXCEPTION 'No autorizado a listar esta caja.' USING ERRCODE = '42501';
    END IF;

    v_saldo := public.calcular_saldo_caja(p_caja_id);
    IF v_saldo <= 0 THEN
        RETURN '[]'::json;
    END IF;

    -- Predicado por acumulación: de las ventas VENTA sin par A-bis, ordenadas de
    -- más nueva a más vieja, se listan las que caben dentro del saldo real de la
    -- caja. El residuo del barrido viejo (cuya plata ya salió) queda por fuera del
    -- saldo y se descarta. Correcto también en el caso mixto (venta nueva + residuo).
    SELECT COALESCE(json_agg(
               json_build_object(
                   'venta_id',              q.venta_id,
                   'nro_factura',           q.nro_factura,
                   'fecha_entrega',         q.fecha_entrega,
                   'cliente_razon_social',  q.cliente_razon_social,
                   'monto',                 q.monto
               ) ORDER BY q.fecha_entrega, q.nro_factura), '[]'::json)
      INTO v_out
    FROM (
        SELECT
            v.id            AS venta_id,
            v.nro_factura   AS nro_factura,
            v.fecha_entrega AS fecha_entrega,
            cl.razon_social AS cliente_razon_social,
            m.monto         AS monto,
            SUM(m.monto) OVER (ORDER BY m.fecha DESC, v.id) - m.monto AS acum_antes
        FROM mvp_movimientos_caja m
        JOIN mvp_ventas   v  ON v.id = m.referencia_id::uuid
        LEFT JOIN mvp_clientes cl ON cl.id = v.cliente_id
        WHERE m.caja_id = p_caja_id
          AND m.tipo_referencia = 'VENTA'
          AND NOT EXISTS (
              SELECT 1 FROM mvp_movimientos_caja t
               WHERE t.caja_id = m.caja_id
                 AND t.tipo_referencia = 'TRANSFERENCIA'
                 AND t.referencia_id = m.referencia_id
          )
    ) q
    WHERE q.acum_antes < v_saldo;

    RETURN v_out;
END;
$$;


ALTER FUNCTION public.fn_listar_ventas_pendientes_caja(p_caja_id uuid) OWNER TO postgres;

--
-- Name: FUNCTION fn_listar_ventas_pendientes_caja(p_caja_id uuid); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fn_listar_ventas_pendientes_caja(p_caja_id uuid) IS 'D-J paso 4-bis. Lista las ventas rendibles de una caja REPARTIDOR. Predicado por acumulación: de los movimientos VENTA sin par TRANSFERENCIA A-bis, ordenados de más nuevo a más viejo, incluye los que caben dentro del saldo real de la caja; el residuo del barrido viejo (plata ya barrida) queda fuera. Guarda saldo<=0 -> []. Autorización: admin cualquier caja, repartidor solo la propia. Alimenta SCR-Rendición y SCR-RendicionAdministrativa (D-N.3).';


--
-- Name: fn_movimientos_ctacte(uuid, date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_movimientos_ctacte(p_socio_id uuid DEFAULT NULL::uuid, p_desde date DEFAULT NULL::date, p_hasta date DEFAULT NULL::date) RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol    varchar;
    v_caller uuid := auth.uid();
    v_socio  uuid;
    v_movs   json;
    v_haber  numeric := 0;
BEGIN
    v_rol := get_user_rol();
    v_socio := COALESCE(p_socio_id, v_caller);

    IF v_socio IS DISTINCT FROM v_caller AND v_rol NOT IN ('tesorero','admin') AND NOT public.es_tesorero() THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol;
    END IF;

    PERFORM 1 FROM mvp_socios WHERE user_id = v_socio;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Socio inexistente: %', v_socio;
    END IF;

    WITH base AS (
        SELECT
            c.id, c.fecha, c.tipo_mov_ctacte,
            COALESCE(c.descripcion, t.nombre) AS detalle,
            o.nro_comprobante, c.monto_debe, c.monto_haber, c.afecta_saldo,
            SUM(CASE WHEN c.afecta_saldo THEN c.monto_haber - c.monto_debe ELSE 0 END)
                OVER (ORDER BY c.fecha, c.id ROWS UNBOUNDED PRECEDING) AS saldo_corrido
        FROM mvp_ctacte c
        JOIN mvp_operacion_caja o ON o.id = c.operacion_id
        LEFT JOIN mvp_tipo_operaciones t ON t.id = o.tipo_operacion_id
        WHERE c.socio_id = v_socio
    )
    SELECT COALESCE(json_agg(json_build_object(
        'id', id, 'fecha', fecha, 'tipo', tipo_mov_ctacte, 'detalle', detalle,
        'nro_comprobante', nro_comprobante, 'debe', monto_debe, 'haber', monto_haber,
        'afecta_saldo', afecta_saldo, 'saldo', saldo_corrido,
        -- ADITIVO: fecha local del asiento. `fecha` se conserva tal cual para no
        -- romper a los consumidores actuales. La UI deberia pasar a mostrar esta,
        -- porque es la que ahora se usa para filtrar.
        'fecha_local', public.fn_fecha_local_desde_ts(fecha)
    ) ORDER BY fecha, id), '[]'::json)
    INTO v_movs
    FROM base
    -- Comparacion en HORA LOCAL: `fecha` guarda UTC sin zona y el cliente
    -- construye p_desde / p_hasta en hora local. Comparar crudo perdia todo lo
    -- cargado despues de las 21:00 locales.
    WHERE (p_desde IS NULL OR public.fn_fecha_local_desde_ts(fecha) >= p_desde)
      AND (p_hasta IS NULL OR public.fn_fecha_local_desde_ts(fecha) <= p_hasta);

    SELECT COALESCE(SUM(monto_haber - monto_debe) FILTER (WHERE afecta_saldo), 0)
      INTO v_haber FROM mvp_ctacte WHERE socio_id = v_socio;

    RETURN json_build_object(
        'socio_id', v_socio, 'desde', p_desde, 'hasta', p_hasta,
        'haber', v_haber, 'movimientos', v_movs
    );
END;
$$;


ALTER FUNCTION public.fn_movimientos_ctacte(p_socio_id uuid, p_desde date, p_hasta date) OWNER TO postgres;

--
-- Name: fn_movimientos_ctacte_todos(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_movimientos_ctacte_todos(p_periodo_id uuid DEFAULT NULL::uuid, p_socio_id uuid DEFAULT NULL::uuid) RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    -- MARCADOR: fn_movimientos_ctacte_todos v1.1 2026-07-30 PATCH-Ctacte-B1
    v_rol        varchar;
    v_periodo    mvp_periodo;
    v_socios     json;
    v_adv        json;
    v_adv_fecha  json;
BEGIN
    v_rol := get_user_rol();
    IF v_rol IS NULL OR (v_rol NOT IN ('tesorero', 'admin') AND NOT public.es_tesorero()) THEN
        RAISE EXCEPTION 'Operacion no autorizada para rol: %', v_rol USING ERRCODE = 'P0001';
    END IF;

    IF p_periodo_id IS NULL THEN
        SELECT * INTO v_periodo FROM mvp_periodo
         WHERE estado = 'CERRADO' ORDER BY fecha_fin DESC LIMIT 1;
    ELSE
        SELECT * INTO v_periodo FROM mvp_periodo WHERE id = p_periodo_id;
    END IF;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'Periodo no encontrado o no hay ninguno CERRADO' USING ERRCODE = 'P0001';
    END IF;

    WITH asiento AS (
        SELECT c.id, c.socio_id, c.fecha, c.created_at, c.tipo_mov_ctacte,
               COALESCE(c.descripcion, t.nombre) AS detalle,
               o.nro_comprobante, c.monto_debe, c.monto_haber, c.afecta_saldo,
               CASE WHEN c.afecta_saldo THEN c.monto_haber - c.monto_debe ELSE 0 END AS delta,
               o.periodo_id, p.fecha_inicio AS p_ini, p.fecha_fin AS p_fin
          FROM mvp_ctacte c
          JOIN mvp_operacion_caja o ON o.id = c.operacion_id
          LEFT JOIN mvp_tipo_operaciones t ON t.id = o.tipo_operacion_id
          LEFT JOIN mvp_periodo p ON p.id = o.periodo_id
         WHERE (p_socio_id IS NULL OR c.socio_id = p_socio_id)
    ),
    clasif AS (
        SELECT a.*,
               CASE WHEN a.periodo_id = v_periodo.id            THEN 'PERIODO'
                    WHEN a.p_fin < v_periodo.fecha_inicio       THEN 'ANTERIOR'
                    WHEN a.p_ini > v_periodo.fecha_fin          THEN 'POSTERIOR'
                    ELSE 'SIN_CLASIFICAR' END AS clase
          FROM asiento a
    ),
    inicial AS (
        SELECT socio_id, SUM(delta) AS monto
          FROM clasif WHERE clase = 'ANTERIOR' GROUP BY socio_id
    ),
    posterior AS (
        SELECT socio_id, SUM(delta) AS monto
          FROM clasif WHERE clase = 'POSTERIOR' GROUP BY socio_id
    ),
    huerfano AS (
        SELECT socio_id, SUM(delta) AS monto, COUNT(*) AS cant
          FROM clasif WHERE clase = 'SIN_CLASIFICAR' GROUP BY socio_id
    ),
    perpetuo AS (
        SELECT socio_id, SUM(delta) AS monto FROM clasif GROUP BY socio_id
    ),
    movs AS (
        SELECT c.*,
               SUM(c.delta) OVER (PARTITION BY c.socio_id
                                  ORDER BY c.fecha, c.created_at, c.id
                                  ROWS UNBOUNDED PRECEDING) AS acum,
               ROW_NUMBER() OVER (PARTITION BY c.socio_id
                                  ORDER BY c.fecha DESC, c.created_at DESC, c.id DESC) AS rn_desc
          FROM clasif c WHERE c.clase = 'PERIODO'
    ),
    det AS (
        SELECT m.socio_id,
               COUNT(*) AS cant,
               SUM(m.delta) AS delta_periodo,
               MAX(CASE WHEN m.rn_desc = 1
                        THEN COALESCE(i.monto, 0) + m.acum END) AS saldo_ultima_fila,
               json_agg(json_build_object(
                   'id',              m.id,
                   'fecha',           m.fecha,
                   'fecha_local',     public.fn_fecha_local_desde_ts(m.fecha),
                   'tipo',            m.tipo_mov_ctacte,
                   'detalle',         m.detalle,
                   'nro_comprobante', m.nro_comprobante,
                   'debe',            m.monto_debe,
                   'haber',           m.monto_haber,
                   'afecta_saldo',    m.afecta_saldo,
                   'saldo',           COALESCE(i.monto, 0) + m.acum
               ) ORDER BY m.fecha, m.created_at, m.id) AS movimientos
          FROM movs m
          LEFT JOIN inicial i ON i.socio_id = m.socio_id
         GROUP BY m.socio_id, i.monto
    ),
    socios_base AS (
        SELECT u.id AS socio_id, u.nombre, COALESCE(u.es_tester, false) AS es_tester
          FROM mvp_socios s
          JOIN mvp_users  u ON u.id = s.user_id
         WHERE (p_socio_id IS NULL OR u.id = p_socio_id)
    )
    SELECT COALESCE(json_agg(json_build_object(
               'socio_id',       b.socio_id,
               'nombre',         b.nombre,
               'es_tester',      b.es_tester,
               'saldo_inicial',  COALESCE(i.monto, 0),
               'saldo_periodo',  COALESCE(i.monto, 0) + COALESCE(d.delta_periodo, 0),
               'saldo_actual',   COALESCE(pp.monto, 0),
               'cantidad_movimientos', COALESCE(d.cant, 0),
               'movimientos',    COALESCE(d.movimientos, '[]'::json),
               'ok_cuadre',      (COALESCE(d.cant, 0) = 0
                                  OR COALESCE(d.saldo_ultima_fila, 0)
                                     = COALESCE(i.monto, 0) + COALESCE(d.delta_periodo, 0)),
               'ok_perpetuo',    (COALESCE(pp.monto, 0)
                                  = COALESCE(i.monto, 0) + COALESCE(d.delta_periodo, 0)
                                    + COALESCE(po.monto, 0)),
               'asientos_sin_clasificar', COALESCE(h.cant, 0)
           ) ORDER BY b.nombre), '[]'::json)
      INTO v_socios
      FROM socios_base b
      LEFT JOIN inicial   i  ON i.socio_id  = b.socio_id
      LEFT JOIN posterior po ON po.socio_id = b.socio_id
      LEFT JOIN perpetuo  pp ON pp.socio_id = b.socio_id
      LEFT JOIN huerfano  h  ON h.socio_id  = b.socio_id
      LEFT JOIN det       d  ON d.socio_id  = b.socio_id
     WHERE COALESCE(d.cant, 0) > 0 OR COALESCE(i.monto, 0) <> 0;

    SELECT COALESCE(json_agg(json_build_object(
               'codigo', CASE WHEN NOT (e ->> 'ok_cuadre')::boolean   THEN 'CUADRE_SOCIO'
                              WHEN NOT (e ->> 'ok_perpetuo')::boolean THEN 'CUADRE_PERPETUO'
                              ELSE 'ASIENTO_SIN_PERIODO' END,
               'socio_id', e ->> 'socio_id',
               'nombre',   e ->> 'nombre',
               'saldo_inicial',            (e ->> 'saldo_inicial')::numeric,
               'saldo_periodo',            (e ->> 'saldo_periodo')::numeric,
               'saldo_actual',             (e ->> 'saldo_actual')::numeric,
               'cantidad_movimientos',     (e ->> 'cantidad_movimientos')::int,
               'ok_cuadre',                (e ->> 'ok_cuadre')::boolean,
               'ok_perpetuo',              (e ->> 'ok_perpetuo')::boolean,
               'asientos_sin_clasificar',  (e ->> 'asientos_sin_clasificar')::int
           )), '[]'::json)
      INTO v_adv
      FROM json_array_elements(v_socios) e
     WHERE NOT (e ->> 'ok_cuadre')::boolean
        OR NOT (e ->> 'ok_perpetuo')::boolean
        OR (e ->> 'asientos_sin_clasificar')::int > 0;

    SELECT COALESCE(json_agg(json_build_object(
               'codigo', 'FECHA_FUERA_DE_PERIODO',
               'ctacte_id', c.id, 'socio_id', c.socio_id,
               'tipo', c.tipo_mov_ctacte,
               'fecha_local', public.fn_fecha_local_desde_ts(c.fecha),
               'periodo_imputado', v_periodo.codigo)), '[]'::json)
      INTO v_adv_fecha
      FROM mvp_ctacte c
      JOIN mvp_operacion_caja o ON o.id = c.operacion_id
     WHERE o.periodo_id = v_periodo.id
       AND (p_socio_id IS NULL OR c.socio_id = p_socio_id)
       AND public.fn_fecha_local_desde_ts(c.fecha)
           NOT BETWEEN v_periodo.fecha_inicio AND v_periodo.fecha_fin;

    RETURN json_build_object(
        'version_reporte', 1,
        'periodo', json_build_object(
            'id', v_periodo.id, 'codigo', v_periodo.codigo, 'estado', v_periodo.estado,
            'fecha_inicio', v_periodo.fecha_inicio, 'fecha_fin', v_periodo.fecha_fin),
        'emitido_en', to_char(now() AT TIME ZONE 'America/Argentina/Buenos_Aires',
                              'YYYY-MM-DD"T"HH24:MI:SS'),
        'socios', v_socios,
        'totales', (
            SELECT json_build_object(
                'cantidad_socios',       COUNT(*),
                'cantidad_movimientos',  COALESCE(SUM((e ->> 'cantidad_movimientos')::int), 0),
                'saldo_inicial',         COALESCE(SUM((e ->> 'saldo_inicial')::numeric), 0),
                'saldo_periodo',         COALESCE(SUM((e ->> 'saldo_periodo')::numeric), 0),
                'saldo_actual',          COALESCE(SUM((e ->> 'saldo_actual')::numeric), 0))
              FROM json_array_elements(v_socios) e),
        'advertencias', v_adv,
        'advertencias_fecha', v_adv_fecha
    );
END;
$$;


ALTER FUNCTION public.fn_movimientos_ctacte_todos(p_periodo_id uuid, p_socio_id uuid) OWNER TO postgres;

--
-- Name: fn_mvp_clientes_creado_por_inmutable(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_mvp_clientes_creado_por_inmutable() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
BEGIN
  IF NEW.creado_por IS DISTINCT FROM OLD.creado_por THEN
    RAISE EXCEPTION 'creado_por es inmutable (auditoria, RN-U10.1 LIMITE 1)'
      USING ERRCODE = 'P0001';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_mvp_clientes_creado_por_inmutable() OWNER TO postgres;

--
-- Name: fn_nombre_socio(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_nombre_socio(p_socio_id uuid) RETURNS text
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  SELECT u.nombre
  FROM mvp_socios s
  JOIN mvp_users u ON u.id = s.user_id
  WHERE s.id = p_socio_id;
$$;


ALTER FUNCTION public.fn_nombre_socio(p_socio_id uuid) OWNER TO postgres;

--
-- Name: fn_periodo_vigente(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_periodo_vigente() RETURNS public.mvp_periodo
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT * FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1; $$;


ALTER FUNCTION public.fn_periodo_vigente() OWNER TO postgres;

--
-- Name: fn_periodo_vigente_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_periodo_vigente_id() RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$ SELECT id FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1; $$;


ALTER FUNCTION public.fn_periodo_vigente_id() OWNER TO postgres;

--
-- Name: fn_precierre_estado(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_precierre_estado(p_periodo_id uuid DEFAULT NULL::uuid) RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol        varchar;
    v_periodo    mvp_periodo;
    v_preview    json;
    v_sum_gan    numeric;
    v_c1_det     json;   v_c1_activo boolean;
    v_c3_det     json;   v_c3_activo boolean;
    v_c4_det     json;   v_c4_activo boolean;
    v_c5_det     json;   v_c5_activo boolean;
    v_c2_activo  boolean;
    v_ultimo     json;
BEGIN
    -- Acceso: solo Tesorero/Admin.
    v_rol := get_user_rol();
    IF v_rol IS NULL OR (v_rol NOT IN ('tesorero', 'admin') AND NOT public.es_tesorero()) THEN
        RAISE EXCEPTION 'Operacion no autorizada para rol: %', v_rol USING ERRCODE = 'P0001';
    END IF;

    -- Periodo: el vigente (ABIERTO) si no se pasa.
    IF p_periodo_id IS NULL THEN
        SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    ELSE
        SELECT * INTO v_periodo FROM mvp_periodo WHERE id = p_periodo_id;
    END IF;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'Periodo no encontrado o no hay vigente' USING ERRCODE = 'P0001';
    END IF;

    v_preview := fn_preview_cierre(v_periodo.id);

    -- C1 (ROJO): cajas SOCIO sin rendir.
    SELECT COALESCE(json_agg(json_build_object('caja_id', c.id, 'nombre', c.nombre)), '[]'::json)
      INTO v_c1_det
      FROM mvp_cajas c
      LEFT JOIN mvp_users  u ON u.id = c.user_id
      LEFT JOIN mvp_socios s ON s.user_id = c.user_id
     WHERE c.tipo = 'SOCIO'
       AND NOT (COALESCE(u.es_tester, false)
                     AND COALESCE(s.porc_venta, 0) = 0
                     AND COALESCE(s.porc_ganancia, 0) = 0
                     AND public.calcular_saldo_caja(c.id) = 0)
       AND NOT EXISTS (SELECT 1 FROM mvp_rendiciones r
                        WHERE r.caja_id = c.id AND r.periodo_id = v_periodo.id);
    v_c1_activo := (json_array_length(v_c1_det) > 0);

    -- C2 (ROJO): suma de porc_ganancia distinta de 100.
    SELECT COALESCE(SUM(porc_ganancia), 0) INTO v_sum_gan FROM mvp_socios;
    v_c2_activo := (v_sum_gan <> 100);

    -- C3 (AMARILLO): prestamos entre socios pendientes (cualquier periodo: no son arrastrables).
    SELECT COALESCE(json_agg(json_build_object(
               'operacion_id', op.id,
               'prestamista', up.nombre,
               'deudor', ud.nombre,
               'monto', (SELECT ABS(m.monto) FROM mvp_movimientos_caja m
                          WHERE m.operacion_id = op.id AND m.caja_id = op.caja_origen_id LIMIT 1)
           )), '[]'::json)
      INTO v_c3_det
      FROM mvp_operacion_caja op
      JOIN mvp_tipo_operaciones t ON t.id = op.tipo_operacion_id
      JOIN mvp_cajas cp ON cp.id = op.caja_origen_id
      JOIN mvp_cajas cd ON cd.id = op.caja_destino_id
      JOIN mvp_users up ON up.id = cp.user_id
      JOIN mvp_users ud ON ud.id = cd.user_id
     WHERE t.codigo = 'PRESTAMO_ENTRE_SOCIOS'
       AND op.estado = 'CONFIRMADA'
       AND NOT EXISTS (SELECT 1 FROM mvp_operacion_caja c
                        WHERE c.operacion_relacionada_id = op.id);
    v_c3_activo := (json_array_length(v_c3_det) > 0);

    -- C4 (AMARILLO): socios con doble tipo de dividendo cargado.
    SELECT COALESCE(json_agg(json_build_object('user_id', s.user_id, 'nombre', u.nombre)), '[]'::json)
      INTO v_c4_det
      FROM mvp_socios s
      JOIN mvp_users u ON u.id = s.user_id
     WHERE s.porc_venta > 0 AND s.porc_ganancia > 0;
    v_c4_activo := (json_array_length(v_c4_det) > 0);

    -- C5 (AMARILLO): cajas delegadas que cierran con saldo deudor (se arrastra).
    SELECT COALESCE(json_agg(elem), '[]'::json) INTO v_c5_det
      FROM json_array_elements(v_preview -> 'socios') elem
     WHERE (elem ->> 'saldo_deudor')::numeric > 0;
    v_c5_activo := (json_array_length(v_c5_det) > 0);

    -- Tarjeta del ultimo cierre ejecutado.
    SELECT json_build_object(
               'cierre_id', x.id, 'periodo', p.codigo,
               'fecha', to_char(x.fecha_cierre AT TIME ZONE 'America/Argentina/Buenos_Aires',
                                'YYYY-MM-DD"T"HH24:MI:SS'),
               'total_ventas', r.total_ventas, 'total_compras', r.total_compras)
      INTO v_ultimo
      FROM mvp_cierres x
      JOIN mvp_periodo p ON p.id = x.periodo_id
      LEFT JOIN mvp_cierre_resumen r ON r.cierre_id = x.id
     WHERE v_periodo.estado <> 'CERRADO'
        OR x.periodo_id = v_periodo.id
     ORDER BY x.fecha_cierre DESC NULLS LAST
     LIMIT 1;

    RETURN json_build_object(
        'periodo', json_build_object('id', v_periodo.id, 'codigo', v_periodo.codigo, 'estado', v_periodo.estado),
        'puede_cerrar', (NOT v_c1_activo AND NOT v_c2_activo),
        'checks', json_build_array(
            json_build_object('codigo', 'C1_RENDICION', 'nivel', 'ROJO', 'activo', v_c1_activo,
                'mensaje', 'Hay cajas delegadas sin rendir. Cada socio debe rendir su caja antes del cierre.',
                'detalle', v_c1_det),
            json_build_object('codigo', 'C2_GANANCIA', 'nivel', 'ROJO', 'activo', v_c2_activo,
                'mensaje', 'Los porcentajes de ganancia no suman 100%. Revisa la configuracion de los socios.',
                'detalle', json_build_object('suma_porc_ganancia', v_sum_gan)),
            json_build_object('codigo', 'C3_PRESTAMO', 'nivel', 'AMARILLO', 'activo', v_c3_activo,
                'mensaje', 'Hay transferencias entre cajas delegadas sin devolver; el cierre las dara por saldadas.',
                'detalle', v_c3_det),
            json_build_object('codigo', 'C4_DOBLE_PORC', 'nivel', 'AMARILLO', 'activo', v_c4_activo,
                'mensaje', 'Un socio tiene dividendo por ventas y por ganancia a la vez; deberia quedar uno solo en cero.',
                'detalle', v_c4_det),
            json_build_object('codigo', 'C5_DEUDOR', 'nivel', 'AMARILLO', 'activo', v_c5_activo,
                'mensaje', 'Una o mas cajas delegadas cierran con saldo deudor; ese saldo se arrastra al proximo periodo.',
                'detalle', v_c5_det)
        ),
        'preview', v_preview,
        'ultimo_cierre', v_ultimo
    );
END;
$$;


ALTER FUNCTION public.fn_precierre_estado(p_periodo_id uuid) OWNER TO postgres;

--
-- Name: fn_preview_cierre(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_preview_cierre(p_periodo_id uuid DEFAULT NULL::uuid) RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  v_rol varchar;
  v_periodo mvp_periodo;
  v_periodo_anterior_id uuid;
  v_resultado json;
BEGIN
  v_rol := get_user_rol();
  IF v_rol IS NOT NULL AND v_rol NOT IN ('tesorero', 'admin') AND NOT public.es_tesorero() THEN
    RAISE EXCEPTION 'Operacion no autorizada para rol: %', v_rol USING ERRCODE = 'P0001';
  END IF;

  IF p_periodo_id IS NULL THEN
    SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
  ELSE
    SELECT * INTO v_periodo FROM mvp_periodo WHERE id = p_periodo_id;
  END IF;

  IF v_periodo.id IS NULL THEN
    RAISE EXCEPTION 'Periodo no encontrado o no hay periodo vigente' USING ERRCODE = 'P0001';
  END IF;

  SELECT id INTO v_periodo_anterior_id
  FROM mvp_periodo
  WHERE fecha_fin < v_periodo.fecha_inicio
  ORDER BY fecha_fin DESC
  LIMIT 1;

  WITH base AS (
    SELECT
      c.id AS caja_id,
      c.nombre,
      c.tipo,
      (SELECT u.nombre FROM mvp_users u WHERE u.id = c.user_id) AS socio_nombre,
      COALESCE((
        SELECT cd.saldo_final
        FROM mvp_cierre_detalle cd
        JOIN mvp_cierres ci ON ci.id = cd.cierre_id
        WHERE ci.periodo_id = v_periodo_anterior_id AND cd.caja_id = c.id
        LIMIT 1
      ), 0) AS saldo_inicial,
      COALESCE((
        SELECT SUM(m.monto) FILTER (WHERE m.monto > 0)
        FROM mvp_movimientos_caja m
        JOIN mvp_operacion_caja o ON o.id = m.operacion_id
        WHERE m.caja_id = c.id AND o.periodo_id = v_periodo.id
      ), 0) AS total_ingresos,
      COALESCE((
        SELECT SUM(-m.monto) FILTER (WHERE m.monto < 0)
        FROM mvp_movimientos_caja m
        JOIN mvp_operacion_caja o ON o.id = m.operacion_id
        WHERE m.caja_id = c.id AND o.periodo_id = v_periodo.id
      ), 0) AS total_egresos
    FROM mvp_cajas c
    WHERE c.tipo IN ('SOCIO', 'CENTRAL')
  ),
  calc AS (
    SELECT base.*, (saldo_inicial + total_ingresos - total_egresos) AS saldo_final
    FROM base
  )
  SELECT json_build_object(
    'periodo', json_build_object('id', v_periodo.id, 'codigo', v_periodo.codigo, 'estado', v_periodo.estado),
    'socios', COALESCE((
      SELECT json_agg(json_build_object(
        'caja_id', caja_id,
        'nombre', nombre,
        'socio', socio_nombre,
        'saldo_inicial', saldo_inicial,
        'total_ingresos', total_ingresos,
        'total_egresos', total_egresos,
        'saldo_final', saldo_final,
        'monto_a_transferir', GREATEST(saldo_final, 0),
        'saldo_deudor', CASE WHEN saldo_final < 0 THEN -saldo_final ELSE 0 END
      ) ORDER BY nombre)
      FROM calc WHERE tipo = 'SOCIO'
    ), '[]'::json),
    'central', (
      SELECT json_build_object(
        'caja_id', caja_id,
        'nombre', nombre,
        'saldo_inicial', saldo_inicial,
        'total_ingresos', total_ingresos,
        'total_egresos', total_egresos,
        'saldo_final', saldo_final
      )
      FROM calc WHERE tipo = 'CENTRAL' LIMIT 1
    ),
    'total_a_transferir', COALESCE((
      SELECT SUM(GREATEST(saldo_final, 0)) FROM calc WHERE tipo = 'SOCIO'
    ), 0)
  ) INTO v_resultado;

  RETURN v_resultado;
END;
$$;


ALTER FUNCTION public.fn_preview_cierre(p_periodo_id uuid) OWNER TO postgres;

--
-- Name: fn_rango_fecha_operacion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_rango_fecha_operacion() RETURNS json
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol     varchar;
    v_periodo mvp_periodo;
    v_hoy     date;
BEGIN
    v_rol := get_user_rol();
    IF v_rol IS NULL OR (v_rol NOT IN ('tesorero', 'admin') AND NOT public.es_tesorero()) THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol USING ERRCODE = 'P0001';
    END IF;

    SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'No hay período abierto'
            USING ERRCODE = 'P0001', HINT = 'SIN_PERIODO_ABIERTO';
    END IF;

    v_hoy := (NOW() AT TIME ZONE 'America/Argentina/Buenos_Aires')::date;

    RETURN json_build_object(
        'periodo_codigo',  v_periodo.codigo,
        'fecha_min',       v_periodo.fecha_inicio,
        'fecha_max',       LEAST(v_periodo.fecha_fin, v_hoy),
        'hoy',             v_hoy,
        'periodo_vencido', (v_hoy > v_periodo.fecha_fin)
    );
END;
$$;


ALTER FUNCTION public.fn_rango_fecha_operacion() OWNER TO postgres;

--
-- Name: fn_registrar_adelanto(uuid, uuid, numeric, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_registrar_adelanto(p_caja_central uuid, p_socio_id uuid, p_monto numeric, p_fecha date DEFAULT NULL::date) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol          varchar;
    v_tipo_op_id   integer;
    v_operacion_id uuid := gen_random_uuid();
    v_usuario_id   uuid := auth.uid();
    v_saldo        numeric;
    v_saldo_fecha  numeric;
    v_nro          integer := nextval('mvp_operacion_caja_nro_comprobante_seq');
    v_periodo      mvp_periodo;
    v_hoy_local    date;
    v_tope_local   date;
    v_fecha_local  date;
    v_fecha        timestamp;
BEGIN
    v_rol := get_user_rol();
    IF v_rol IS NULL OR (v_rol NOT IN ('tesorero', 'admin') AND NOT public.es_tesorero()) THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol;
    END IF;
    IF p_monto IS NULL OR p_monto <= 0 THEN
        RAISE EXCEPTION 'Monto inválido: %', p_monto;
    END IF;

    PERFORM 1 FROM mvp_socios WHERE user_id = p_socio_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Socio inexistente: %', p_socio_id;
    END IF;

    -- FECHA DE OPERACIÓN (D-1, Modo D)
    SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'No hay período abierto'
            USING ERRCODE = 'P0001', HINT = 'SIN_PERIODO_ABIERTO';
    END IF;
    v_hoy_local   := (NOW() AT TIME ZONE 'America/Argentina/Buenos_Aires')::date;
    v_tope_local  := LEAST(v_periodo.fecha_fin, v_hoy_local);
    v_fecha_local := COALESCE(p_fecha, v_tope_local);
    IF v_fecha_local < v_periodo.fecha_inicio OR v_fecha_local > v_tope_local THEN
        RAISE EXCEPTION 'La fecha % está fuera del rango permitido (% a %)',
            v_fecha_local, v_periodo.fecha_inicio, v_tope_local
            USING ERRCODE = 'P0001', HINT = 'FECHA_FUERA_DE_RANGO';
    END IF;
    v_fecha := CASE WHEN v_fecha_local = v_hoy_local
                    THEN (NOW() AT TIME ZONE 'UTC')
                    ELSE public.fn_ts_desde_fecha_local(v_fecha_local) + interval '12 hours' END;

    PERFORM 1 FROM mvp_cajas WHERE id = p_caja_central FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Caja inexistente: %', p_caja_central;
    END IF;

    -- D-4 condición 1: la Central tenía fondos al día de la operación.
    IF v_fecha_local < v_hoy_local THEN
        v_saldo_fecha := public.fn_saldo_caja_a_fecha(p_caja_central, v_fecha_local);
        IF v_saldo_fecha < p_monto THEN
            RAISE EXCEPTION 'La Caja Central no tenía fondos suficientes el %: saldo a esa fecha %, adelanto %. Registrá primero los ingresos anteriores a esa fecha.',
                v_fecha_local, v_saldo_fecha, p_monto
                USING ERRCODE = 'P0001', HINT = 'SALDO_INSUFICIENTE_A_FECHA';
        END IF;
    END IF;

    -- Vigente: invariante física (la Central no puede quedar en negativo hoy).
    v_saldo := calcular_saldo_caja(p_caja_central);
    IF v_saldo < p_monto THEN
        RAISE EXCEPTION 'Saldo insuficiente en Caja Central: saldo %, monto %', v_saldo, p_monto
            USING ERRCODE = 'P0001', HINT = 'SALDO_INSUFICIENTE';
    END IF;

    SELECT id INTO v_tipo_op_id FROM mvp_tipo_operaciones
    WHERE codigo = 'ADELANTO' AND activa = true;
    IF v_tipo_op_id IS NULL THEN
        RAISE EXCEPTION 'Tipo de operación ADELANTO no encontrado en catálogo';
    END IF;

    INSERT INTO mvp_operacion_caja
        (id, tipo_operacion_id, fecha, usuario_id, estado, caja_origen_id,
         tercero_id, tipo_tercero, nro_comprobante, periodo_id)
    VALUES
        (v_operacion_id, v_tipo_op_id, v_fecha, v_usuario_id, 'CONFIRMADA', p_caja_central,
         p_socio_id, 'SOCIO', v_nro, v_periodo.id);

    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), p_caja_central, -ABS(p_monto), v_fecha,
         'ADELANTO', v_operacion_id::text, v_operacion_id);

    INSERT INTO mvp_ctacte
        (socio_id, operacion_id, tipo_mov_ctacte, monto_debe, fecha)
    VALUES
        (p_socio_id, v_operacion_id, 'ADELANTO', ABS(p_monto), v_fecha);

    RETURN json_build_object('ok', true, 'operacion_codigo', 'ADELANTO',
                             'operacion_id', v_operacion_id, 'socio_id', p_socio_id,
                             'nro_comprobante', v_nro, 'fecha', v_fecha,
                             'fecha_local', v_fecha_local);
END;
$$;


ALTER FUNCTION public.fn_registrar_adelanto(p_caja_central uuid, p_socio_id uuid, p_monto numeric, p_fecha date) OWNER TO postgres;

--
-- Name: fn_registrar_aporte(uuid, numeric, uuid, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_registrar_aporte(p_caja_id uuid, p_monto numeric, p_socio_id uuid DEFAULT NULL::uuid, p_fecha date DEFAULT NULL::date) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol          varchar;
    v_tipo_op_id   integer;
    v_operacion_id uuid := gen_random_uuid();
    v_usuario_id   uuid := auth.uid();
    v_nro          integer := nextval('mvp_operacion_caja_nro_comprobante_seq');
    v_periodo      mvp_periodo;
    v_hoy_local    date;
    v_tope_local   date;
    v_fecha_local  date;
    v_fecha        timestamp;
BEGIN
    v_rol := get_user_rol();
    IF v_rol IS NULL OR (v_rol NOT IN ('tesorero', 'admin') AND NOT public.es_tesorero()) THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol;
    END IF;
    IF p_monto IS NULL OR p_monto <= 0 THEN
        RAISE EXCEPTION 'Monto inválido: %', p_monto;
    END IF;

    -- FECHA DE OPERACIÓN (D-1, Modo D)
    SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'No hay período abierto'
            USING ERRCODE = 'P0001', HINT = 'SIN_PERIODO_ABIERTO';
    END IF;
    v_hoy_local   := (NOW() AT TIME ZONE 'America/Argentina/Buenos_Aires')::date;
    v_tope_local  := LEAST(v_periodo.fecha_fin, v_hoy_local);
    v_fecha_local := COALESCE(p_fecha, v_tope_local);
    IF v_fecha_local < v_periodo.fecha_inicio OR v_fecha_local > v_tope_local THEN
        RAISE EXCEPTION 'La fecha % está fuera del rango permitido (% a %)',
            v_fecha_local, v_periodo.fecha_inicio, v_tope_local
            USING ERRCODE = 'P0001', HINT = 'FECHA_FUERA_DE_RANGO';
    END IF;
    v_fecha := CASE WHEN v_fecha_local = v_hoy_local
                    THEN (NOW() AT TIME ZONE 'UTC')
                    ELSE public.fn_ts_desde_fecha_local(v_fecha_local) + interval '12 hours' END;

    IF p_socio_id IS NOT NULL THEN
        PERFORM 1 FROM mvp_socios WHERE user_id = p_socio_id;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Socio inexistente: %', p_socio_id;
        END IF;
    END IF;

    SELECT id INTO v_tipo_op_id FROM mvp_tipo_operaciones
    WHERE codigo = 'APORTE' AND activa = true;
    IF v_tipo_op_id IS NULL THEN
        RAISE EXCEPTION 'Tipo de operación APORTE no encontrado en catálogo';
    END IF;

    INSERT INTO mvp_operacion_caja
        (id, tipo_operacion_id, fecha, usuario_id, estado, caja_destino_id,
         tercero_id, tipo_tercero, nro_comprobante, periodo_id)
    VALUES
        (v_operacion_id, v_tipo_op_id, v_fecha, v_usuario_id, 'CONFIRMADA', p_caja_id,
         p_socio_id, CASE WHEN p_socio_id IS NOT NULL THEN 'SOCIO' END, v_nro, v_periodo.id);

    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), p_caja_id, ABS(p_monto), v_fecha,
         'APORTE', v_operacion_id::text, v_operacion_id);

    IF p_socio_id IS NOT NULL THEN
        INSERT INTO mvp_ctacte
            (socio_id, operacion_id, tipo_mov_ctacte, monto_haber, afecta_saldo, fecha)
        VALUES
            (p_socio_id, v_operacion_id, 'APORTE', ABS(p_monto), false, v_fecha);
    END IF;

    RETURN json_build_object('ok', true, 'operacion_codigo', 'APORTE',
                             'operacion_id', v_operacion_id, 'socio_id', p_socio_id,
                             'nro_comprobante', v_nro, 'fecha', v_fecha,
                             'fecha_local', v_fecha_local);
END;
$$;


ALTER FUNCTION public.fn_registrar_aporte(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date) OWNER TO postgres;

--
-- Name: fn_registrar_cobro_venta(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_registrar_cobro_venta(p_venta_id uuid, p_socio_cobrador_id uuid) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol            varchar;
    v_user_id        uuid;
    v_venta          mvp_ventas%ROWTYPE;
    v_socio_user_id  uuid;
    v_caja_id        uuid;
    v_tipo_op_id     integer;
    v_operacion_id   uuid := gen_random_uuid();
    v_movimiento_id  uuid;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'No autenticado' USING ERRCODE = '28000';
    END IF;
    v_rol := public.get_user_rol();
    IF v_rol IS NULL THEN
        RAISE EXCEPTION 'Usuario sin rol asignado (user_id=%)', v_user_id USING ERRCODE = '42501';
    END IF;
    IF v_rol NOT IN ('socio', 'admin', 'tesorero') THEN
        RAISE EXCEPTION 'Rol % no autorizado para registrar cobro diferido', v_rol USING ERRCODE = '42501';
    END IF;
    SELECT * INTO v_venta FROM mvp_ventas WHERE id = p_venta_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Venta % no existe', p_venta_id USING ERRCODE = 'P0002';
    END IF;
    IF v_venta.estado <> 'ENTREGADA' THEN
        RAISE EXCEPTION 'La venta % está en estado %; el cobro diferido solo aplica a ENTREGADA', p_venta_id, v_venta.estado USING ERRCODE = '22023';
    END IF;
    IF v_venta.total IS NULL OR v_venta.total <= 0 THEN
        RAISE EXCEPTION 'La venta % tiene total inválido (%)', p_venta_id, v_venta.total USING ERRCODE = '22023';
    END IF;
    SELECT s.user_id INTO v_socio_user_id FROM mvp_socios s WHERE s.id = p_socio_cobrador_id;
    IF v_socio_user_id IS NULL THEN
        RAISE EXCEPTION 'Socio cobrador % no existe', p_socio_cobrador_id USING ERRCODE = 'P0002';
    END IF;
    IF v_rol = 'socio' AND v_socio_user_id <> v_user_id THEN
        RAISE EXCEPTION 'El socio autenticado solo puede registrar cobros contra su propia caja' USING ERRCODE = '42501';
    END IF;
    SELECT c.id INTO v_caja_id FROM mvp_cajas c
    WHERE c.user_id = v_socio_user_id AND c.tipo = 'SOCIO';
    IF v_caja_id IS NULL THEN
        RAISE EXCEPTION 'El socio % no tiene caja SOCIO asignada', p_socio_cobrador_id USING ERRCODE = 'P0002';
    END IF;
    SELECT id INTO v_tipo_op_id FROM mvp_tipo_operaciones WHERE codigo = 'COBRO' AND activa = true;
    IF v_tipo_op_id IS NULL THEN
        RAISE EXCEPTION 'Tipo de operación COBRO no encontrado en catálogo';
    END IF;
    UPDATE mvp_ventas
    SET estado = 'COBRADO', socio_cobrador_id = p_socio_cobrador_id, updated_at = now()
    WHERE id = p_venta_id;
    INSERT INTO mvp_operacion_caja
        (id, tipo_operacion_id, fecha, usuario_id, estado,
         caja_destino_id, tercero_id, tipo_tercero, documento_tipo, documento_id)
    VALUES
        (v_operacion_id, v_tipo_op_id, now(), v_user_id, 'CONFIRMADA',
         v_caja_id, v_venta.cliente_id, 'CLIENTE', 'VENTA', p_venta_id);
    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), v_caja_id, v_venta.total, now(), 'VENTA', p_venta_id::varchar, v_operacion_id)
    RETURNING id INTO v_movimiento_id;
    RETURN json_build_object(
        'ok', true, 'operacion_codigo', 'COBRO',
        'operacion_id', v_operacion_id, 'venta_id', p_venta_id,
        'caja_id', v_caja_id, 'movimiento_id', v_movimiento_id, 'monto', v_venta.total
    );
END;
$$;


ALTER FUNCTION public.fn_registrar_cobro_venta(p_venta_id uuid, p_socio_cobrador_id uuid) OWNER TO postgres;

--
-- Name: fn_registrar_egreso(uuid, uuid, numeric); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_registrar_egreso(p_egreso_id uuid, p_caja_id uuid, p_monto numeric) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol           varchar;
    v_tipo_op_id    integer;
    v_operacion_id  uuid := gen_random_uuid();
    v_usuario_id    uuid := auth.uid();
    v_saldo         numeric;
    v_caja_ok       boolean;
    v_egreso        mvp_egresos%ROWTYPE;
BEGIN
    v_rol := get_user_rol();
    IF v_rol IS DISTINCT FROM 'socio' THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol;
    END IF;
    IF p_monto IS NULL OR p_monto <= 0 THEN
        RAISE EXCEPTION 'Monto inválido: %', p_monto;
    END IF;

    -- v1.1 GUARDA 1 (pertenencia): la caja tiene que ser la caja delegada del ejecutante.
    --      Sin esto, p_caja_id llega del cliente y un socio puede pagar desde la caja de otro.
    SELECT EXISTS (
        SELECT 1 FROM mvp_cajas c
         WHERE c.id = p_caja_id AND c.tipo = 'SOCIO' AND c.user_id = v_usuario_id
    ) INTO v_caja_ok;
    IF NOT v_caja_ok THEN
        RAISE EXCEPTION 'La caja % no es tu caja delegada', p_caja_id
            USING ERRCODE = '42501';
    END IF;

    -- v1.2 GUARDA 2 (fidelidad documental): el efectivo que sale de la caja tiene que
    --      ser exactamente el del comprobante. Sin esta guarda p_monto viaja libre desde
    --      el cliente y la caja diverge del egreso documentado, sin que nada lo detecte.
    --      El cierre toma C de los movimientos, asi que la divergencia se propaga al
    --      resultado del periodo y al reparto de dividendos. Referencia: junio 2026,
    --      dos comprobantes de 374000 y 497200 pagados ambos por 469700 (+68200).
    --      No existe pago parcial en el modelo: mvp_egresos no tiene saldo ni estado.
    --      Va ANTES del control de saldo: si el monto esta mal, 'saldo insuficiente'
    --      seria un diagnostico enganoso.
    SELECT * INTO v_egreso FROM mvp_egresos WHERE id = p_egreso_id;
    IF v_egreso.id IS NULL THEN
        RAISE EXCEPTION 'El comprobante de egreso no existe'
            USING ERRCODE = 'P0002', HINT = 'EGRESO_INEXISTENTE';
    END IF;
    IF ROUND(p_monto, 2) <> v_egreso.monto THEN
        RAISE EXCEPTION 'El monto a pagar (%) no coincide con el del comprobante (%)',
            ROUND(p_monto, 2), v_egreso.monto
            USING ERRCODE = 'P0001', HINT = 'MONTO_DISTINTO_DEL_COMPROBANTE';
    END IF;

    -- v1.2 GUARDA 3 (pago unico): un comprobante se paga una sola vez. mvp_operacion_caja
    --      no tiene unicidad sobre (documento_tipo, documento_id), asi que sin esto el
    --      mismo egreso puede descontarse dos veces de la caja.
    IF EXISTS (
        SELECT 1 FROM mvp_operacion_caja
         WHERE documento_tipo = 'EGRESO' AND documento_id = p_egreso_id
           AND estado = 'CONFIRMADA'
    ) THEN
        RAISE EXCEPTION 'El comprobante ya fue pagado'
            USING ERRCODE = 'P0001', HINT = 'EGRESO_YA_PAGADO';
    END IF;

    -- v1.2 GUARDA 4 (saldo): la caja delegada NO puede quedar en negativo.
    --      Es efectivo de Hidroplanta en custodia: no se puede pagar lo que no se tiene.
    --      A la caja delegada solo entra plata por cobro de ventas o por transferencia
    --      desde otra caja delegada con saldo (RN-T14). El flujo personal (aportes,
    --      adelantos, retiros) va por Caja Central y la cuenta corriente: NO la alimenta.
    --      Mismo patron de guarda que fn_registrar_prestamo_socio y fn_registrar_transferencia.
    --      Sin esta guarda, la caja queda en rojo, no se puede rendir (fn_rendir_caja_socio
    --      exige 0 <= efectivo <= saldo_libro) y el cierre mensual queda bloqueado para
    --      TODA la cooperativa, sin forma de destrabarlo desde la app.
    v_saldo := calcular_saldo_caja(p_caja_id);
    IF v_saldo < p_monto THEN
        RAISE EXCEPTION 'Saldo insuficiente en tu caja delegada: saldo %, egreso %. Cobrá ventas pendientes o pedile una transferencia a otro socio.', v_saldo, p_monto
            USING ERRCODE = 'P0001';
    END IF;

    SELECT id INTO v_tipo_op_id FROM mvp_tipo_operaciones
    WHERE codigo = 'PAGO' AND activa = true;
    IF v_tipo_op_id IS NULL THEN
        RAISE EXCEPTION 'Tipo de operación PAGO no encontrado en catálogo';
    END IF;

    INSERT INTO mvp_operacion_caja
        (id, tipo_operacion_id, fecha, usuario_id, estado,
         caja_origen_id, documento_tipo, documento_id)
    VALUES
        (v_operacion_id, v_tipo_op_id, NOW(), v_usuario_id, 'CONFIRMADA',
         p_caja_id, 'EGRESO', p_egreso_id);

    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), p_caja_id, -ABS(p_monto), NOW(),
         'EGRESO', p_egreso_id::text, v_operacion_id);

    RETURN json_build_object('ok', true, 'operacion_codigo', 'PAGO', 'operacion_id', v_operacion_id);
END;
$$;


ALTER FUNCTION public.fn_registrar_egreso(p_egreso_id uuid, p_caja_id uuid, p_monto numeric) OWNER TO postgres;

--
-- Name: fn_registrar_entrega(uuid, numeric); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_registrar_entrega(p_venta_id uuid, p_monto numeric DEFAULT NULL::numeric) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_user_id        uuid;
    v_venta          mvp_ventas%ROWTYPE;
    v_cap_ok         boolean;
    v_caja_id        uuid;
    v_tipo_op_id     integer;
    v_operacion_id   uuid;
    v_movimiento_id  uuid;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'No autenticado' USING ERRCODE = '28000';
    END IF;
    SELECT * INTO v_venta FROM mvp_ventas WHERE id = p_venta_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Venta % no existe', p_venta_id USING ERRCODE = 'P0002';
    END IF;
    IF v_venta.estado <> 'ASIGNADO' THEN
        RAISE EXCEPTION 'La venta % está en estado %; solo se entrega desde ASIGNADO', p_venta_id, v_venta.estado USING ERRCODE = '22023';
    END IF;
    IF v_venta.repartidor_id <> v_user_id THEN
        RAISE EXCEPTION 'Solo el repartidor asignado puede registrar la entrega de la venta %', p_venta_id USING ERRCODE = '42501';
    END IF;
    SELECT true INTO v_cap_ok FROM mvp_repartidores r
    WHERE r.user_id = v_user_id AND r.activo = true;
    IF v_cap_ok IS NOT TRUE THEN
        RAISE EXCEPTION 'El usuario no tiene capacidad de repartidor activa' USING ERRCODE = '42501';
    END IF;

    IF p_monto IS NULL THEN
        UPDATE mvp_ventas SET estado = 'ENTREGADA', updated_at = now() WHERE id = p_venta_id;
        RETURN json_build_object('ok', true, 'camino', 'B', 'venta_id', p_venta_id, 'estado', 'ENTREGADA');
    END IF;

    IF v_venta.total IS NULL OR v_venta.total <= 0 THEN
        RAISE EXCEPTION 'La venta % tiene total inválido (%)', p_venta_id, v_venta.total USING ERRCODE = '22023';
    END IF;
    IF p_monto <> v_venta.total THEN
        RAISE EXCEPTION 'El importe ingresado (%) no coincide con el total (%); no se admiten cobros parciales', p_monto, v_venta.total USING ERRCODE = '22023';
    END IF;
    SELECT c.id INTO v_caja_id FROM mvp_cajas c
    WHERE c.user_id = v_user_id AND c.tipo = 'REPARTIDOR';
    IF v_caja_id IS NULL THEN
        RAISE EXCEPTION 'El repartidor no tiene caja REPARTIDOR asignada' USING ERRCODE = 'P0002';
    END IF;
    SELECT id INTO v_tipo_op_id FROM mvp_tipo_operaciones WHERE codigo = 'COBRO' AND activa = true;
    IF v_tipo_op_id IS NULL THEN
        RAISE EXCEPTION 'Tipo de operación COBRO no encontrado en catálogo';
    END IF;
    v_operacion_id := gen_random_uuid();
    UPDATE mvp_ventas SET estado = 'COBRADO', updated_at = now() WHERE id = p_venta_id;
    INSERT INTO mvp_operacion_caja
        (id, tipo_operacion_id, fecha, usuario_id, estado,
         caja_destino_id, tercero_id, tipo_tercero, documento_tipo, documento_id)
    VALUES
        (v_operacion_id, v_tipo_op_id, now(), v_user_id, 'CONFIRMADA',
         v_caja_id, v_venta.cliente_id, 'CLIENTE', 'VENTA', p_venta_id);
    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), v_caja_id, v_venta.total, now(), 'VENTA', p_venta_id::varchar, v_operacion_id)
    RETURNING id INTO v_movimiento_id;
    RETURN json_build_object(
        'ok', true, 'camino', 'A', 'operacion_codigo', 'COBRO',
        'operacion_id', v_operacion_id, 'venta_id', p_venta_id, 'estado', 'COBRADO',
        'caja_id', v_caja_id, 'movimiento_id', v_movimiento_id, 'monto', v_venta.total
    );
END;
$$;


ALTER FUNCTION public.fn_registrar_entrega(p_venta_id uuid, p_monto numeric) OWNER TO postgres;

--
-- Name: fn_registrar_ingreso(uuid, numeric, uuid, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_registrar_ingreso(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date DEFAULT NULL::date) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol          varchar;
    v_tipo_op_id   integer;
    v_operacion_id uuid := gen_random_uuid();
    v_usuario_id   uuid := auth.uid();
    v_nro          integer := nextval('mvp_operacion_caja_nro_comprobante_seq');
    v_periodo      mvp_periodo;
    v_hoy_local    date;
    v_tope_local   date;
    v_fecha_local  date;
    v_fecha        timestamp;
BEGIN
    v_rol := get_user_rol();
    IF v_rol IS NULL OR (v_rol NOT IN ('tesorero', 'admin') AND NOT public.es_tesorero()) THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol;
    END IF;
    IF p_monto IS NULL OR p_monto <= 0 THEN
        RAISE EXCEPTION 'Monto inválido: %', p_monto;
    END IF;
    IF p_socio_id IS NULL THEN
        RAISE EXCEPTION 'El ingreso debe atribuirse a un socio';
    END IF;
    PERFORM 1 FROM mvp_socios WHERE user_id = p_socio_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Socio inexistente: %', p_socio_id;
    END IF;

    -- FECHA DE OPERACIÓN (D-1, Modo D)
    SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'No hay período abierto'
            USING ERRCODE = 'P0001', HINT = 'SIN_PERIODO_ABIERTO';
    END IF;
    v_hoy_local   := (NOW() AT TIME ZONE 'America/Argentina/Buenos_Aires')::date;
    v_tope_local  := LEAST(v_periodo.fecha_fin, v_hoy_local);
    v_fecha_local := COALESCE(p_fecha, v_tope_local);
    IF v_fecha_local < v_periodo.fecha_inicio OR v_fecha_local > v_tope_local THEN
        RAISE EXCEPTION 'La fecha % está fuera del rango permitido (% a %)',
            v_fecha_local, v_periodo.fecha_inicio, v_tope_local
            USING ERRCODE = 'P0001', HINT = 'FECHA_FUERA_DE_RANGO';
    END IF;
    v_fecha := CASE WHEN v_fecha_local = v_hoy_local
                    THEN (NOW() AT TIME ZONE 'UTC')
                    ELSE public.fn_ts_desde_fecha_local(v_fecha_local) + interval '12 hours' END;

    PERFORM 1 FROM mvp_cajas WHERE id = p_caja_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Caja inexistente: %', p_caja_id;
    END IF;

    SELECT id INTO v_tipo_op_id FROM mvp_tipo_operaciones
    WHERE codigo = 'INGRESO' AND activa = true;
    IF v_tipo_op_id IS NULL THEN
        RAISE EXCEPTION 'Tipo de operación INGRESO no encontrado en catálogo';
    END IF;

    INSERT INTO mvp_operacion_caja
        (id, tipo_operacion_id, fecha, usuario_id, estado, caja_destino_id,
         tercero_id, tipo_tercero, nro_comprobante, periodo_id)
    VALUES
        (v_operacion_id, v_tipo_op_id, v_fecha, v_usuario_id, 'CONFIRMADA', p_caja_id,
         p_socio_id, 'SOCIO', v_nro, v_periodo.id);

    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), p_caja_id, ABS(p_monto), v_fecha,
         'INGRESO', v_operacion_id::text, v_operacion_id);

    INSERT INTO mvp_ctacte
        (socio_id, operacion_id, tipo_mov_ctacte, monto_haber, afecta_saldo, fecha)
    VALUES
        (p_socio_id, v_operacion_id, 'INGRESO', ABS(p_monto), true, v_fecha);

    RETURN json_build_object('ok', true, 'operacion_codigo', 'INGRESO',
                             'operacion_id', v_operacion_id, 'socio_id', p_socio_id,
                             'nro_comprobante', v_nro, 'fecha', v_fecha,
                             'fecha_local', v_fecha_local);
END;
$$;


ALTER FUNCTION public.fn_registrar_ingreso(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date) OWNER TO postgres;

--
-- Name: fn_registrar_prestamo_socio(uuid, uuid, numeric, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_registrar_prestamo_socio(p_caja_origen_id uuid, p_caja_destino_id uuid, p_monto numeric, p_observaciones text DEFAULT NULL::text) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol            varchar;
    v_usuario_id     uuid := auth.uid();
    v_tipo_op_id     integer;
    v_operacion_id   uuid := gen_random_uuid();
    v_fecha          timestamptz := NOW();
    v_origen_tipo    varchar;
    v_origen_user    uuid;
    v_destino_tipo   varchar;
    v_saldo_origen   numeric;
BEGIN
    v_rol := get_user_rol();
    IF v_rol <> 'socio' THEN
        RAISE EXCEPTION 'Operación reservada al rol socio. Rol actual: %', v_rol
            USING ERRCODE = 'P0001';
    END IF;
    IF p_caja_origen_id = p_caja_destino_id THEN
        RAISE EXCEPTION 'La caja de origen y destino no pueden ser la misma'
            USING ERRCODE = 'P0001';
    END IF;
    IF p_monto IS NULL OR p_monto <= 0 THEN
        RAISE EXCEPTION 'Monto inválido: %', p_monto
            USING ERRCODE = 'P0001';
    END IF;
    SELECT tipo, user_id INTO v_origen_tipo, v_origen_user
    FROM mvp_cajas WHERE id = p_caja_origen_id FOR UPDATE;
    IF v_origen_tipo IS NULL THEN
        RAISE EXCEPTION 'Caja de origen inexistente: %', p_caja_origen_id
            USING ERRCODE = 'P0001';
    END IF;
    IF v_origen_tipo <> 'SOCIO' OR v_origen_user IS DISTINCT FROM v_usuario_id THEN
        RAISE EXCEPTION 'La caja de origen debe ser la caja delegada del Socio que ejecuta la transferencia'
            USING ERRCODE = 'P0001';
    END IF;
    SELECT tipo INTO v_destino_tipo
    FROM mvp_cajas WHERE id = p_caja_destino_id;
    IF v_destino_tipo IS NULL THEN
        RAISE EXCEPTION 'Caja de destino inexistente: %', p_caja_destino_id
            USING ERRCODE = 'P0001';
    END IF;
    IF v_destino_tipo <> 'SOCIO' THEN
        RAISE EXCEPTION 'La caja de destino debe ser una caja de socio'
            USING ERRCODE = 'P0001';
    END IF;
    v_saldo_origen := calcular_saldo_caja(p_caja_origen_id);
    IF v_saldo_origen < p_monto THEN
        RAISE EXCEPTION 'Saldo insuficiente en la caja de origen: saldo %, monto %', v_saldo_origen, p_monto
            USING ERRCODE = 'P0001', HINT = 'SALDO_INSUFICIENTE';
    END IF;
    SELECT id INTO v_tipo_op_id FROM mvp_tipo_operaciones
    WHERE codigo = 'PRESTAMO_ENTRE_SOCIOS' AND activa = true;
    IF v_tipo_op_id IS NULL THEN
        RAISE EXCEPTION 'Tipo de operación PRESTAMO_ENTRE_SOCIOS no encontrado en catálogo';
    END IF;
    INSERT INTO mvp_operacion_caja
        (id, tipo_operacion_id, fecha, usuario_id, estado, caja_origen_id, caja_destino_id, observaciones)
    VALUES
        (v_operacion_id, v_tipo_op_id, v_fecha, v_usuario_id, 'CONFIRMADA',
         p_caja_origen_id, p_caja_destino_id, p_observaciones);
    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), p_caja_origen_id, -ABS(p_monto), v_fecha,
         'TRANSFERENCIA', v_operacion_id::text, v_operacion_id);
    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), p_caja_destino_id, ABS(p_monto), v_fecha,
         'TRANSFERENCIA', v_operacion_id::text, v_operacion_id);
    RETURN json_build_object('ok', true, 'operacion_codigo', 'PRESTAMO_ENTRE_SOCIOS', 'operacion_id', v_operacion_id);
END;
$$;


ALTER FUNCTION public.fn_registrar_prestamo_socio(p_caja_origen_id uuid, p_caja_destino_id uuid, p_monto numeric, p_observaciones text) OWNER TO postgres;

--
-- Name: fn_registrar_retiro(uuid, numeric, uuid, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_registrar_retiro(p_caja_id uuid, p_monto numeric, p_socio_id uuid DEFAULT NULL::uuid, p_fecha date DEFAULT NULL::date) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol          varchar;
    v_tipo_op_id   integer;
    v_operacion_id uuid := gen_random_uuid();
    v_usuario_id   uuid := auth.uid();
    v_saldo_origen numeric;
    v_saldo_fecha  numeric;
    v_haber        numeric;
    v_haber_fecha  numeric;
    v_nro          integer := nextval('mvp_operacion_caja_nro_comprobante_seq');
    v_periodo      mvp_periodo;
    v_hoy_local    date;
    v_tope_local   date;
    v_fecha_local  date;
    v_fecha        timestamp;
BEGIN
    v_rol := get_user_rol();
    IF v_rol IS NULL OR (v_rol NOT IN ('tesorero', 'admin') AND NOT public.es_tesorero()) THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol;
    END IF;
    IF p_monto IS NULL OR p_monto <= 0 THEN
        RAISE EXCEPTION 'Monto inválido: %', p_monto;
    END IF;
    IF p_socio_id IS NOT NULL THEN
        PERFORM 1 FROM mvp_socios WHERE user_id = p_socio_id;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Socio inexistente: %', p_socio_id;
        END IF;
    END IF;

    -- FECHA DE OPERACIÓN (D-1, Modo D)
    SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'No hay período abierto'
            USING ERRCODE = 'P0001', HINT = 'SIN_PERIODO_ABIERTO';
    END IF;
    v_hoy_local   := (NOW() AT TIME ZONE 'America/Argentina/Buenos_Aires')::date;
    v_tope_local  := LEAST(v_periodo.fecha_fin, v_hoy_local);
    v_fecha_local := COALESCE(p_fecha, v_tope_local);
    IF v_fecha_local < v_periodo.fecha_inicio OR v_fecha_local > v_tope_local THEN
        RAISE EXCEPTION 'La fecha % está fuera del rango permitido (% a %)',
            v_fecha_local, v_periodo.fecha_inicio, v_tope_local
            USING ERRCODE = 'P0001', HINT = 'FECHA_FUERA_DE_RANGO';
    END IF;
    v_fecha := CASE WHEN v_fecha_local = v_hoy_local
                    THEN (NOW() AT TIME ZONE 'UTC')
                    ELSE public.fn_ts_desde_fecha_local(v_fecha_local) + interval '12 hours' END;

    PERFORM 1 FROM mvp_cajas WHERE id = p_caja_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Caja inexistente: %', p_caja_id;
    END IF;

    -- D-4 condición 1: la Central tenía fondos al día de la operación.
    IF v_fecha_local < v_hoy_local THEN
        v_saldo_fecha := public.fn_saldo_caja_a_fecha(p_caja_id, v_fecha_local);
        IF v_saldo_fecha < p_monto THEN
            RAISE EXCEPTION 'La Caja Central no tenía fondos suficientes el %: saldo a esa fecha %, retiro %. Registrá primero los ingresos anteriores a esa fecha.',
                v_fecha_local, v_saldo_fecha, p_monto
                USING ERRCODE = 'P0001', HINT = 'SALDO_INSUFICIENTE_A_FECHA';
        END IF;

        -- D-4 condición 2: el socio tenía haber al día de la operación.
        IF p_socio_id IS NOT NULL THEN
            v_haber_fecha := public.fn_haber_ctacte_a_fecha(p_socio_id, v_fecha_local);
            IF (v_haber_fecha - p_monto) < 0 THEN
                RAISE EXCEPTION 'Sobregiro al %: haber del socio a esa fecha %, retiro %',
                    v_fecha_local, v_haber_fecha, p_monto
                    USING ERRCODE = 'P0001', HINT = 'SOBREGIRO_A_FECHA';
            END IF;
        END IF;
    END IF;

    -- Vigente: no sobregiro del haber actual (RN-T21).
    IF p_socio_id IS NOT NULL THEN
        SELECT COALESCE(SUM(monto_haber - monto_debe) FILTER (WHERE afecta_saldo), 0)
          INTO v_haber FROM mvp_ctacte WHERE socio_id = p_socio_id;
        IF (v_haber - p_monto) < 0 THEN
            RAISE EXCEPTION 'Sobregiro no permitido: haber %, retiro %', v_haber, p_monto
                USING ERRCODE = 'P0001', HINT = 'SOBREGIRO_NO_PERMITIDO';
        END IF;
    END IF;

    -- Vigente: invariante física.
    v_saldo_origen := calcular_saldo_caja(p_caja_id);
    IF v_saldo_origen < p_monto THEN
        RAISE EXCEPTION 'Saldo insuficiente en Caja Central: saldo %, monto %', v_saldo_origen, p_monto
            USING ERRCODE = 'P0001', HINT = 'SALDO_INSUFICIENTE';
    END IF;

    SELECT id INTO v_tipo_op_id FROM mvp_tipo_operaciones
    WHERE codigo = 'RETIRO_DIVIDENDOS' AND activa = true;
    IF v_tipo_op_id IS NULL THEN
        RAISE EXCEPTION 'Tipo de operación RETIRO_DIVIDENDOS no encontrado en catálogo';
    END IF;

    INSERT INTO mvp_operacion_caja
        (id, tipo_operacion_id, fecha, usuario_id, estado, caja_origen_id,
         tercero_id, tipo_tercero, nro_comprobante, periodo_id)
    VALUES
        (v_operacion_id, v_tipo_op_id, v_fecha, v_usuario_id, 'CONFIRMADA', p_caja_id,
         p_socio_id, CASE WHEN p_socio_id IS NOT NULL THEN 'SOCIO' END, v_nro, v_periodo.id);

    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), p_caja_id, -ABS(p_monto), v_fecha,
         'RETIRO', v_operacion_id::text, v_operacion_id);

    IF p_socio_id IS NOT NULL THEN
        INSERT INTO mvp_ctacte
            (socio_id, operacion_id, tipo_mov_ctacte, monto_debe, fecha)
        VALUES
            (p_socio_id, v_operacion_id, 'RETIRO', ABS(p_monto), v_fecha);
    END IF;

    RETURN json_build_object('ok', true, 'operacion_codigo', 'RETIRO_DIVIDENDOS',
                             'operacion_id', v_operacion_id, 'socio_id', p_socio_id,
                             'nro_comprobante', v_nro, 'fecha', v_fecha,
                             'fecha_local', v_fecha_local);
END;
$$;


ALTER FUNCTION public.fn_registrar_retiro(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date) OWNER TO postgres;

--
-- Name: fn_registrar_transferencia(uuid, uuid, numeric, timestamp with time zone, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_registrar_transferencia(p_caja_origen_id uuid, p_caja_destino_id uuid, p_monto numeric, p_fecha timestamp with time zone DEFAULT now(), p_notas text DEFAULT NULL::text) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_rol           varchar;
    v_uid           uuid := auth.uid();
    v_es_tes        boolean;
    v_periodo       mvp_periodo;
    v_tipo_origen   varchar;
    v_user_origen   uuid;
    v_tipo_destino  varchar;
    v_codigo        varchar;
    v_tipo_op_id    integer;
    v_caja_socio    uuid;
    v_socio_nombre  varchar;
    v_saldo_origen  numeric;
    v_fecha_local   date;
    v_operacion_id  uuid := gen_random_uuid();
    v_fecha         timestamptz := COALESCE(p_fecha, NOW());
    v_nro           integer;
BEGIN
    IF v_uid IS NULL THEN
        RAISE EXCEPTION 'Sesión sin usuario autenticado.' USING ERRCODE = '28000';
    END IF;
    v_rol    := get_user_rol();
    v_es_tes := public.es_tesorero();

    IF p_caja_origen_id = p_caja_destino_id THEN
        RAISE EXCEPTION 'La caja de origen y la de destino no pueden ser la misma'
            USING ERRCODE = 'P0001';
    END IF;
    IF p_monto IS NULL OR p_monto <= 0 THEN
        RAISE EXCEPTION 'Monto inválido: %', p_monto USING ERRCODE = 'P0001';
    END IF;

    SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'No hay período abierto' USING ERRCODE = 'P0001';
    END IF;

    v_fecha_local := (v_fecha AT TIME ZONE 'America/Argentina/Buenos_Aires')::date;
    IF v_fecha_local < v_periodo.fecha_inicio OR v_fecha_local > v_periodo.fecha_fin THEN
        RAISE EXCEPTION 'La fecha % cae fuera del período vigente (% a %)',
            v_fecha_local, v_periodo.fecha_inicio, v_periodo.fecha_fin
            USING ERRCODE = 'P0001', HINT = 'FECHA_FUERA_DE_PERIODO';
    END IF;

    PERFORM 1 FROM mvp_cajas
     WHERE id IN (p_caja_origen_id, p_caja_destino_id)
     ORDER BY id FOR UPDATE;

    SELECT tipo, user_id INTO v_tipo_origen, v_user_origen
      FROM mvp_cajas WHERE id = p_caja_origen_id;
    IF v_tipo_origen IS NULL THEN
        RAISE EXCEPTION 'Caja de origen inexistente: %', p_caja_origen_id USING ERRCODE = 'P0001';
    END IF;
    SELECT tipo INTO v_tipo_destino FROM mvp_cajas WHERE id = p_caja_destino_id;
    IF v_tipo_destino IS NULL THEN
        RAISE EXCEPTION 'Caja de destino inexistente: %', p_caja_destino_id USING ERRCODE = 'P0001';
    END IF;

    IF v_tipo_origen = 'CENTRAL' AND v_tipo_destino = 'SOCIO' THEN
        v_codigo := 'ASISTENCIA_CAJA_DELEGADA';
        IF v_rol NOT IN ('tesorero', 'admin') AND NOT v_es_tes THEN
            RAISE EXCEPTION 'Solo la Tesorería puede sacar fondos de la Caja Central'
                USING ERRCODE = 'P0001', HINT = 'NO_AUTORIZADO';
        END IF;

    ELSIF v_tipo_origen = 'SOCIO' AND v_tipo_destino = 'CENTRAL' THEN
        v_codigo := 'RECAUDACION_ANTICIPADA';
        IF v_rol IS DISTINCT FROM 'admin' AND v_user_origen IS DISTINCT FROM v_uid THEN
            RAISE EXCEPTION 'La entrega de fondos a Caja Central la registra el Socio titular de la caja'
                USING ERRCODE = 'P0001', HINT = 'NO_AUTORIZADO';
        END IF;

    ELSIF v_tipo_origen = 'SOCIO' AND v_tipo_destino = 'SOCIO' THEN
        RAISE EXCEPTION 'Entre cajas delegadas se usa la transferencia entre Socios, no esta operación'
            USING ERRCODE = 'P0001', HINT = 'USAR_RN_T14';

    ELSIF v_tipo_origen = 'REPARTIDOR' OR v_tipo_destino = 'REPARTIDOR' THEN
        RAISE EXCEPTION 'Las cajas de Repartidor solo se mueven por rendición'
            USING ERRCODE = 'P0001', HINT = 'USAR_RENDICION';

    ELSE
        RAISE EXCEPTION 'Combinación de cajas no permitida: % -> %', v_tipo_origen, v_tipo_destino
            USING ERRCODE = 'P0001';
    END IF;

    v_caja_socio := CASE WHEN v_tipo_origen = 'SOCIO' THEN p_caja_origen_id ELSE p_caja_destino_id END;
    IF EXISTS (SELECT 1 FROM mvp_rendiciones r
                WHERE r.caja_id = v_caja_socio AND r.periodo_id = v_periodo.id) THEN
        SELECT nombre INTO v_socio_nombre FROM mvp_cajas WHERE id = v_caja_socio;
        RAISE EXCEPTION 'La caja "%" ya fue rendida en el período; la operación rompería el arqueo',
            v_socio_nombre USING ERRCODE = 'P0001', HINT = 'CAJA_YA_RENDIDA';
    END IF;

    v_saldo_origen := calcular_saldo_caja(p_caja_origen_id);
    IF v_saldo_origen < p_monto THEN
        RAISE EXCEPTION 'Saldo insuficiente en la caja de origen: saldo %, monto solicitado %',
            v_saldo_origen, p_monto
            USING ERRCODE = 'P0001', HINT = 'SALDO_INSUFICIENTE';
    END IF;

    SELECT id INTO v_tipo_op_id FROM mvp_tipo_operaciones
     WHERE codigo = v_codigo AND activa = true;
    IF v_tipo_op_id IS NULL THEN
        RAISE EXCEPTION 'Tipo de operación % no encontrado en catálogo', v_codigo;
    END IF;

    v_nro := nextval('mvp_operacion_caja_nro_comprobante_seq');

    INSERT INTO mvp_operacion_caja
        (id, tipo_operacion_id, fecha, usuario_id, estado,
         caja_origen_id, caja_destino_id, observaciones, nro_comprobante)
    VALUES
        (v_operacion_id, v_tipo_op_id, v_fecha, v_uid, 'CONFIRMADA',
         p_caja_origen_id, p_caja_destino_id, p_notas, v_nro);

    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), p_caja_origen_id, -ABS(p_monto), v_fecha,
         'TRANSFERENCIA', v_operacion_id::text, v_operacion_id);

    INSERT INTO mvp_movimientos_caja
        (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
    VALUES
        (gen_random_uuid(), p_caja_destino_id, ABS(p_monto), v_fecha,
         'TRANSFERENCIA', v_operacion_id::text, v_operacion_id);

    RETURN json_build_object('ok', true, 'operacion_codigo', v_codigo,
                             'operacion_id', v_operacion_id, 'nro_comprobante', v_nro);
END;
$$;


ALTER FUNCTION public.fn_registrar_transferencia(p_caja_origen_id uuid, p_caja_destino_id uuid, p_monto numeric, p_fecha timestamp with time zone, p_notas text) OWNER TO postgres;

--
-- Name: fn_rendir_caja_socio(numeric); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_rendir_caja_socio(p_efectivo numeric) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
-- MARCADOR_RENDICION_V1_1_FECHA_PERIODO
-- v1.1 (2026-08-01). Los artefactos contables de la rendicion (operacion,
--   movimiento de caja y asiento de cuenta corriente) se fechan en el ultimo
--   instante del PERIODO que se rinde, no en el now() de la ejecucion.
--   Criterio unico con fn_ejecutar_cierre v1.1.
--   Fecha CRUDA a proposito: las columnas .fecha son timestamp sin zona y
--   guardan UTC; con fn_ts_desde_fecha_local el 31/07 23:59:59 se iria a
--   2026-08-01 02:59:59 UTC, cayendo en el mes siguiente.
--   mvp_rendiciones.fecha conserva el instante real del acto (auditoria),
--   analogo a mvp_cierres.fecha_cierre.
DECLARE
    v_usuario_id    uuid := auth.uid();
    v_caja_id       uuid;
    v_periodo       mvp_periodo;
    v_fecha_periodo timestamp;
    v_saldo_libro   numeric;
    v_faltante      numeric;
    v_tipo_op_id    integer;
    v_operacion_id  uuid;
BEGIN
    IF p_efectivo IS NULL OR p_efectivo < 0 THEN
        RAISE EXCEPTION 'Efectivo declarado inválido: %', p_efectivo;
    END IF;

    SELECT id INTO v_caja_id
      FROM mvp_cajas
     WHERE user_id = v_usuario_id AND tipo = 'SOCIO'
     FOR UPDATE;
    IF v_caja_id IS NULL THEN
        RAISE EXCEPTION 'No tiene caja delegada (SOCIO) asociada';
    END IF;

    SELECT * INTO v_periodo FROM mvp_periodo WHERE estado = 'ABIERTO' LIMIT 1;
    IF v_periodo.id IS NULL THEN
        RAISE EXCEPTION 'No hay período vigente';
    END IF;

    v_fecha_periodo := v_periodo.fecha_fin::timestamp
                       + interval '23 hours 59 minutes 59 seconds';

    IF EXISTS (SELECT 1 FROM mvp_rendiciones
                WHERE caja_id = v_caja_id AND periodo_id = v_periodo.id) THEN
        RAISE EXCEPTION 'La caja ya fue rendida en este período';
    END IF;

    v_saldo_libro := TRUNC(calcular_saldo_caja(v_caja_id));

    IF p_efectivo > v_saldo_libro THEN
        RAISE EXCEPTION 'Sobrante no permitido: efectivo % mayor que saldo de libro %',
            p_efectivo, v_saldo_libro
            USING ERRCODE = 'P0001', HINT = 'SOBRANTE_NO_PERMITIDO';
    END IF;

    v_faltante := v_saldo_libro - p_efectivo;

    IF v_faltante > 0 THEN
        SELECT id INTO v_tipo_op_id FROM mvp_tipo_operaciones
         WHERE codigo = 'LIQUIDACION' AND activa = true;
        IF v_tipo_op_id IS NULL THEN
            RAISE EXCEPTION 'Tipo de operación LIQUIDACION no encontrado en catálogo';
        END IF;

        v_operacion_id := gen_random_uuid();

        INSERT INTO mvp_operacion_caja
            (id, tipo_operacion_id, fecha, usuario_id, estado, caja_origen_id,
             tercero_id, tipo_tercero, periodo_id, nro_comprobante)
        VALUES
            (v_operacion_id, v_tipo_op_id, v_fecha_periodo, v_usuario_id, 'CONFIRMADA', v_caja_id,
             v_usuario_id, 'SOCIO', v_periodo.id, nextval('mvp_operacion_caja_nro_comprobante_seq'));

        INSERT INTO mvp_movimientos_caja
            (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
        VALUES
            (gen_random_uuid(), v_caja_id, -v_faltante, v_fecha_periodo,
             'LIQUIDACION', v_operacion_id::text, v_operacion_id);

        INSERT INTO mvp_ctacte
            (socio_id, operacion_id, tipo_mov_ctacte, monto_debe, fecha)
        VALUES
            (v_usuario_id, v_operacion_id, 'LIQUIDACION', v_faltante, v_fecha_periodo);
    END IF;

    INSERT INTO mvp_rendiciones
        (caja_id, socio_id, periodo_id, saldo_libro, efectivo_declarado,
         faltante, operacion_liquidacion_id, usuario_id, fecha)
    VALUES
        (v_caja_id, v_usuario_id, v_periodo.id, v_saldo_libro, p_efectivo,
         v_faltante, v_operacion_id, v_usuario_id, (now() AT TIME ZONE 'UTC'));

    RETURN json_build_object(
        'ok', true, 'caja_id', v_caja_id, 'periodo_id', v_periodo.id,
        'saldo_libro', v_saldo_libro, 'efectivo_declarado', p_efectivo,
        'faltante', v_faltante, 'operacion_liquidacion_id', v_operacion_id
    );
END;
$$;


ALTER FUNCTION public.fn_rendir_caja_socio(p_efectivo numeric) OWNER TO postgres;

--
-- Name: fn_rendir_dia(uuid[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_rendir_dia(p_venta_ids uuid[]) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_uid          uuid := auth.uid();
    v_caja_rep_id  uuid;
    v_caja_soc_id  uuid;
    v_tipo_op_id   integer;
    v_operacion_id uuid := gen_random_uuid();
    v_fecha        timestamptz := now();
    v_venta_id     uuid;
    v_monto        numeric;
    v_total        numeric := 0;
    v_n            integer := 0;
    v_saldo_post   numeric;
BEGIN
    -- 1. Autenticación
    IF v_uid IS NULL THEN
        RAISE EXCEPTION 'Sesión sin usuario autenticado.' USING ERRCODE = '28000';
    END IF;

    -- 2. Capacidad repartidor
    IF NOT EXISTS (
        SELECT 1 FROM mvp_repartidores WHERE user_id = v_uid AND activo = true
    ) THEN
        RAISE EXCEPTION 'El usuario no tiene capacidad repartidor activa.' USING ERRCODE = '42501';
    END IF;

    -- 3. Entrada no vacía
    IF p_venta_ids IS NULL OR array_length(p_venta_ids, 1) IS NULL THEN
        RAISE EXCEPTION 'No se seleccionaron ventas para rendir.' USING ERRCODE = '22023';
    END IF;

    -- 4. Cajas origen (repartidor) y destino (socio del mismo usuario)
    SELECT id INTO v_caja_rep_id
      FROM mvp_cajas WHERE user_id = v_uid AND tipo = 'REPARTIDOR'
      FOR UPDATE;
    IF v_caja_rep_id IS NULL THEN
        RAISE EXCEPTION 'No existe caja REPARTIDOR para el usuario.' USING ERRCODE = 'P0002';
    END IF;

    SELECT id INTO v_caja_soc_id
      FROM mvp_cajas WHERE user_id = v_uid AND tipo = 'SOCIO';
    IF v_caja_soc_id IS NULL THEN
        RAISE EXCEPTION 'No existe caja SOCIO destino. La rendición de repartidor único no está habilitada.'
            USING ERRCODE = '22023';
    END IF;

    -- 5. Tipo de operación
    SELECT id INTO v_tipo_op_id
      FROM mvp_tipo_operaciones WHERE codigo = 'TRANSFERENCIA' AND activa = true;
    IF v_tipo_op_id IS NULL THEN
        RAISE EXCEPTION 'Tipo de operación TRANSFERENCIA no encontrado en catálogo.';
    END IF;

    -- 6. Cabecera de la operación (una sola: el acto físico de rendir)
    INSERT INTO mvp_operacion_caja
        (id, tipo_operacion_id, fecha, usuario_id, estado,
         caja_origen_id, caja_destino_id, observaciones)
    VALUES
        (v_operacion_id, v_tipo_op_id, v_fecha, v_uid, 'CONFIRMADA',
         v_caja_rep_id, v_caja_soc_id, 'Rendición diaria repartidor (selectiva)');

    -- 7. Validar y procesar cada venta seleccionada, sin duplicados
    FOR v_venta_id IN SELECT DISTINCT unnest(p_venta_ids)
    LOOP
        -- Debe existir UN movimiento VENTA vivo en la caja repartidor por esta venta.
        SELECT m.monto INTO v_monto
          FROM mvp_movimientos_caja m
         WHERE m.caja_id = v_caja_rep_id
           AND m.tipo_referencia = 'VENTA'
           AND m.referencia_id = v_venta_id::text
         LIMIT 1;

        IF v_monto IS NULL THEN
            RAISE EXCEPTION 'La venta % no tiene cobro pendiente en esta caja de repartidor.', v_venta_id
                USING ERRCODE = '22023';
        END IF;

        -- No debe estar ya rendida: sin movimiento TRANSFERENCIA previo por esta venta en esta caja.
        IF EXISTS (
            SELECT 1 FROM mvp_movimientos_caja m
             WHERE m.caja_id = v_caja_rep_id
               AND m.tipo_referencia = 'TRANSFERENCIA'
               AND m.referencia_id = v_venta_id::text
        ) THEN
            RAISE EXCEPTION 'La venta % ya fue rendida.', v_venta_id USING ERRCODE = '22023';
        END IF;

        -- Par de movimientos, ambos trazados a la venta.
        INSERT INTO mvp_movimientos_caja
            (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
        VALUES
            (gen_random_uuid(), v_caja_rep_id, -ABS(v_monto), v_fecha,
             'TRANSFERENCIA', v_venta_id::text, v_operacion_id);

        INSERT INTO mvp_movimientos_caja
            (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
        VALUES
            (gen_random_uuid(), v_caja_soc_id, ABS(v_monto), v_fecha,
             'TRANSFERENCIA', v_venta_id::text, v_operacion_id);

        v_total := v_total + ABS(v_monto);
        v_n := v_n + 1;
    END LOOP;

    -- 8. Guarda de consistencia: si no se procesó ninguna, no dejar operación vacía.
    IF v_n = 0 THEN
        RAISE EXCEPTION 'Ninguna de las ventas indicadas pudo rendirse.' USING ERRCODE = '22023';
    END IF;

    -- 9. Assert relajado (D-K): el remanente es válido, la caja NO debe quedar negativa.
    v_saldo_post := calcular_saldo_caja(v_caja_rep_id);
    IF v_saldo_post < 0 THEN
        RAISE EXCEPTION 'La rendición dejaría la caja REPARTIDOR en negativo (saldo %).', v_saldo_post
            USING ERRCODE = 'P0001';
    END IF;

    RETURN json_build_object(
        'ok', true,
        'operacion_codigo', 'RENDICION',
        'operacion_id', v_operacion_id,
        'caja_origen_id', v_caja_rep_id,
        'caja_destino_id', v_caja_soc_id,
        'ventas_rendidas', v_n,
        'monto_rendido', v_total,
        'saldo_remanente', v_saldo_post
    );
END;
$$;


ALTER FUNCTION public.fn_rendir_dia(p_venta_ids uuid[]) OWNER TO postgres;

--
-- Name: FUNCTION fn_rendir_dia(p_venta_ids uuid[]); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fn_rendir_dia(p_venta_ids uuid[]) IS 'D-J/D-K. Rendición selectiva del repartidor logueado. Recibe el subconjunto de venta_ids a rendir. Emite UNA operación TRANSFERENCIA (acto físico) con 2N movimientos: por cada venta, -monto en caja REPARTIDOR y +monto en caja SOCIO, ambos con referencia_id = venta_id (trazabilidad venta por venta, A-bis). Valida por venta: cobro vivo en la caja y no rendido previamente. Remanente permitido (assert saldo >= 0). El barrido total se elimina.';


--
-- Name: fn_rendir_dia_administrativo(uuid, uuid[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_rendir_dia_administrativo(p_repartidor_id uuid, p_venta_ids uuid[]) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
    v_uid          uuid := auth.uid();
    v_rol          varchar;
    v_nombre       varchar;
    v_caja_rep_id  uuid;
    v_caja_soc_id  uuid;
    v_tipo_op_id   integer;
    v_operacion_id uuid := gen_random_uuid();
    v_fecha        timestamptz := now();
    v_venta_id     uuid;
    v_monto        numeric;
    v_total        numeric := 0;
    v_n            integer := 0;
    v_saldo_post   numeric;
BEGIN
    -- 1. Autenticación
    IF v_uid IS NULL THEN
        RAISE EXCEPTION 'Sesión sin usuario autenticado.' USING ERRCODE = '28000';
    END IF;

    -- 2. Rol admin (esto es lo administrativo)
    v_rol := get_user_rol();
    IF v_rol IS DISTINCT FROM 'admin' THEN
        RAISE EXCEPTION 'Operación no autorizada para rol: %', v_rol USING ERRCODE = '42501';
    END IF;

    -- 3. Repartidor indicado, existente y activo
    IF p_repartidor_id IS NULL THEN
        RAISE EXCEPTION 'Debe indicarse el repartidor a rendir.' USING ERRCODE = '22023';
    END IF;

    SELECT u.nombre INTO v_nombre
      FROM mvp_users u
     WHERE u.id = p_repartidor_id AND u.activo = true;
    IF v_nombre IS NULL THEN
        RAISE EXCEPTION 'Usuario inexistente o inactivo: %', p_repartidor_id USING ERRCODE = 'P0002';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM mvp_repartidores
         WHERE user_id = p_repartidor_id AND activo = true
    ) THEN
        RAISE EXCEPTION 'El usuario % no tiene capacidad repartidor activa.', v_nombre USING ERRCODE = '42501';
    END IF;

    -- 4. Entrada no vacía
    IF p_venta_ids IS NULL OR array_length(p_venta_ids, 1) IS NULL THEN
        RAISE EXCEPTION 'No se seleccionaron ventas para rendir.' USING ERRCODE = '22023';
    END IF;

    -- 5. Cajas origen (repartidor) y destino (delegada del mismo usuario)
    SELECT id INTO v_caja_rep_id
      FROM mvp_cajas WHERE user_id = p_repartidor_id AND tipo = 'REPARTIDOR'
      FOR UPDATE;
    IF v_caja_rep_id IS NULL THEN
        RAISE EXCEPTION 'No existe caja REPARTIDOR para %.', v_nombre USING ERRCODE = 'P0002';
    END IF;

    SELECT id INTO v_caja_soc_id
      FROM mvp_cajas WHERE user_id = p_repartidor_id AND tipo = 'SOCIO';
    IF v_caja_soc_id IS NULL THEN
        RAISE EXCEPTION 'No existe Caja Delegada destino para %. La rendición administrativa de repartidor único no está habilitada.', v_nombre
            USING ERRCODE = '22023';
    END IF;

    -- 6. Tipo de operación
    SELECT id INTO v_tipo_op_id
      FROM mvp_tipo_operaciones WHERE codigo = 'TRANSFERENCIA' AND activa = true;
    IF v_tipo_op_id IS NULL THEN
        RAISE EXCEPTION 'Tipo de operación TRANSFERENCIA no encontrado en catálogo.';
    END IF;

    -- 7. Cabecera (una sola: el acto físico de rendir)
    INSERT INTO mvp_operacion_caja
        (id, tipo_operacion_id, fecha, usuario_id, estado,
         caja_origen_id, caja_destino_id, observaciones)
    VALUES
        (v_operacion_id, v_tipo_op_id, v_fecha, v_uid, 'CONFIRMADA',
         v_caja_rep_id, v_caja_soc_id,
         'Rendición administrativa (selectiva) — repartidor: ' || v_nombre);

    -- 8. Validar y procesar cada venta, sin duplicados
    FOR v_venta_id IN SELECT DISTINCT unnest(p_venta_ids)
    LOOP
        SELECT m.monto INTO v_monto
          FROM mvp_movimientos_caja m
         WHERE m.caja_id = v_caja_rep_id
           AND m.tipo_referencia = 'VENTA'
           AND m.referencia_id = v_venta_id::text
         LIMIT 1;

        IF v_monto IS NULL THEN
            RAISE EXCEPTION 'La venta % no tiene cobro pendiente en la caja de %.', v_venta_id, v_nombre
                USING ERRCODE = '22023';
        END IF;

        IF EXISTS (
            SELECT 1 FROM mvp_movimientos_caja m
             WHERE m.caja_id = v_caja_rep_id
               AND m.tipo_referencia = 'TRANSFERENCIA'
               AND m.referencia_id = v_venta_id::text
        ) THEN
            RAISE EXCEPTION 'La venta % ya fue rendida.', v_venta_id USING ERRCODE = '22023';
        END IF;

        INSERT INTO mvp_movimientos_caja
            (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
        VALUES
            (gen_random_uuid(), v_caja_rep_id, -ABS(v_monto), v_fecha,
             'TRANSFERENCIA', v_venta_id::text, v_operacion_id);

        INSERT INTO mvp_movimientos_caja
            (id, caja_id, monto, fecha, tipo_referencia, referencia_id, operacion_id)
        VALUES
            (gen_random_uuid(), v_caja_soc_id, ABS(v_monto), v_fecha,
             'TRANSFERENCIA', v_venta_id::text, v_operacion_id);

        v_total := v_total + ABS(v_monto);
        v_n := v_n + 1;
    END LOOP;

    -- 9. Consistencia: no dejar operación vacía
    IF v_n = 0 THEN
        RAISE EXCEPTION 'Ninguna de las ventas indicadas pudo rendirse.' USING ERRCODE = '22023';
    END IF;

    -- 10. Assert relajado (D-K): remanente válido, caja NO negativa
    v_saldo_post := calcular_saldo_caja(v_caja_rep_id);
    IF v_saldo_post < 0 THEN
        RAISE EXCEPTION 'La rendición dejaría la caja REPARTIDOR de % en negativo (saldo %).', v_nombre, v_saldo_post
            USING ERRCODE = 'P0001';
    END IF;

    RETURN json_build_object(
        'ok', true,
        'operacion_codigo', 'RENDICION_ADMIN',
        'operacion_id', v_operacion_id,
        'repartidor_id', p_repartidor_id,
        'repartidor_nombre', v_nombre,
        'caja_origen_id', v_caja_rep_id,
        'caja_destino_id', v_caja_soc_id,
        'ventas_rendidas', v_n,
        'monto_rendido', v_total,
        'saldo_remanente', v_saldo_post,
        'ejecutado_por', v_uid
    );
END;
$$;


ALTER FUNCTION public.fn_rendir_dia_administrativo(p_repartidor_id uuid, p_venta_ids uuid[]) OWNER TO postgres;

--
-- Name: FUNCTION fn_rendir_dia_administrativo(p_repartidor_id uuid, p_venta_ids uuid[]); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.fn_rendir_dia_administrativo(p_repartidor_id uuid, p_venta_ids uuid[]) IS 'RN-T12 / D-J / D-K. Rendición administrativa SELECTIVA de excepción. Solo rol admin. p_repartidor_id = mvp_users.id del repartidor (NO la PK de mvp_repartidores). p_venta_ids = subconjunto a rendir. Emite UNA operación TRANSFERENCIA (acto físico) con 2N movimientos: por cada venta, -monto en caja REPARTIDOR y +monto en Caja Delegada, ambos con referencia_id = venta_id (A-bis). Valida por venta: cobro vivo y no rendida previamente. Remanente permitido (assert saldo >= 0). El barrido total se elimina. Sin restricción de fecha (decisión 2026-07-14).';


--
-- Name: fn_saldo_caja_a_fecha(uuid, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_saldo_caja_a_fecha(p_caja_id uuid, p_fecha date) RETURNS numeric
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  SELECT COALESCE(SUM(monto), 0)
    FROM mvp_movimientos_caja
   WHERE caja_id = p_caja_id
     AND fecha < public.fn_ts_desde_fecha_local(p_fecha + 1);
$$;


ALTER FUNCTION public.fn_saldo_caja_a_fecha(p_caja_id uuid, p_fecha date) OWNER TO postgres;

--
-- Name: fn_saldo_neto_periodo(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_saldo_neto_periodo(p_caja_id uuid, p_periodo_id uuid) RETURNS numeric
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
  SELECT COALESCE(SUM(m.monto), 0)
  FROM mvp_movimientos_caja m
  JOIN mvp_operacion_caja o ON o.id = m.operacion_id
  WHERE m.caja_id = p_caja_id AND o.periodo_id = p_periodo_id;
$$;


ALTER FUNCTION public.fn_saldo_neto_periodo(p_caja_id uuid, p_periodo_id uuid) OWNER TO postgres;

--
-- Name: fn_socio_actual(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_socio_actual() RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
    SELECT id FROM public.mvp_socios WHERE user_id = auth.uid() LIMIT 1;
$$;


ALTER FUNCTION public.fn_socio_actual() OWNER TO postgres;

--
-- Name: fn_test_conexion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_test_conexion() RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
DECLARE
  v_status BOOLEAN;
  v_ts     TIMESTAMPTZ;
BEGIN
  INSERT INTO mvp_test_ping DEFAULT VALUES;
  SELECT on_line, updated_at INTO v_status, v_ts
    FROM mvp_system_status WHERE id = 1;
  RETURN json_build_object(
    'on_line',    v_status,
    'updated_at', v_ts,
    'mensaje',    CASE WHEN v_status THEN 'Base de datos ON LINE'
                       ELSE 'Conectado (on_line=false)' END
  );
END;
$$;


ALTER FUNCTION public.fn_test_conexion() OWNER TO postgres;

--
-- Name: fn_toggle_online(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_toggle_online() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE mvp_system_status
    SET on_line = NOT on_line, updated_at = now()
    WHERE id = 1;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_toggle_online() OWNER TO postgres;

--
-- Name: fn_ts_desde_fecha_local(date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_ts_desde_fecha_local(p_fecha date) RETURNS timestamp without time zone
    LANGUAGE sql STABLE
    SET search_path TO 'public', 'pg_temp'
    AS $$
  SELECT ((p_fecha::timestamp AT TIME ZONE 'America/Argentina/Buenos_Aires') AT TIME ZONE 'UTC');
$$;


ALTER FUNCTION public.fn_ts_desde_fecha_local(p_fecha date) OWNER TO postgres;

--
-- Name: fn_validar_operador_no_repartidor(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_validar_operador_no_repartidor() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF (SELECT rol FROM public.mvp_users WHERE id = NEW.user_id) = 'operador' THEN
    RAISE EXCEPTION 'Un usuario con rol operador no puede tener capacidad repartidor (RN-U05.1)';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_validar_operador_no_repartidor() OWNER TO postgres;

--
-- Name: get_user_rol(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_rol() RETURNS character varying
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
    SELECT rol FROM public.mvp_users WHERE id = auth.uid() LIMIT 1;
$$;


ALTER FUNCTION public.get_user_rol() OWNER TO postgres;

--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_temp'
    AS $$
BEGIN
  -- Fila base incompleta. Rol 'repartidor' (NO 'operador') + cliente_id NULL + activo=false
  -- para satisfacer mvp_users_cliente_id_check. fn_crear_usuario completa rol real,
  -- cliente_id y activo=true en un UPDATE atómico posterior.
  INSERT INTO public.mvp_users (id, email, rol, nombre, cliente_id, activo)
  VALUES (
    NEW.id,
    NEW.email,
    'repartidor',
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email, 'Usuario'),
    NULL,
    false
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.handle_new_user() OWNER TO postgres;

--
-- Name: handle_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.handle_updated_at() OWNER TO postgres;

--
-- Name: FUNCTION handle_updated_at(); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.handle_updated_at() IS 'Trigger function genérica que actualiza updated_at = now() en cada UPDATE. Reutilizable por cualquier tabla del schema con campo updated_at. Creada en Etapa 3-A para mvp_reglas_negocio. Aplicable a futuras tablas.';


--
-- Name: rls_auto_enable(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.rls_auto_enable() RETURNS event_trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


ALTER FUNCTION public.rls_auto_enable() OWNER TO postgres;

--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_updated_at() OWNER TO postgres;

--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_realtime_admin;

--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO supabase_realtime_admin;

--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_realtime_admin;

--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_realtime_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_realtime_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) OWNER TO supabase_realtime_admin;

--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_realtime_admin;

--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_realtime_admin;

--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_realtime_admin;

--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO supabase_realtime_admin;

--
-- Name: send_binary(bytea, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) OWNER TO supabase_realtime_admin;

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_realtime_admin;

--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_realtime_admin;

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- Name: wal2json_escape_identifier(text); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.wal2json_escape_identifier(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


ALTER FUNCTION realtime.wal2json_escape_identifier(name text) OWNER TO supabase_realtime_admin;

--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION storage.allow_any_operation(expected_operations text[]) OWNER TO supabase_storage_admin;

--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION storage.allow_only_operation(expected_operation text) OWNER TO supabase_storage_admin;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION storage.enforce_bucket_name_length() OWNER TO supabase_storage_admin;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) OWNER TO supabase_storage_admin;

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO supabase_storage_admin;

--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text, sort_order text) OWNER TO supabase_storage_admin;

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.protect_delete() OWNER TO supabase_storage_admin;

--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) OWNER TO supabase_storage_admin;

--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text, sort_order text, sort_column text, sort_column_after text) OWNER TO supabase_storage_admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    custom_claims_allowlist text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


ALTER TABLE auth.custom_oauth_providers OWNER TO supabase_auth_admin;

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


ALTER TABLE auth.oauth_authorizations OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE auth.oauth_client_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


ALTER TABLE auth.oauth_clients OWNER TO supabase_auth_admin;

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


ALTER TABLE auth.oauth_consents OWNER TO supabase_auth_admin;

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


ALTER TABLE auth.webauthn_challenges OWNER TO supabase_auth_admin;

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


ALTER TABLE auth.webauthn_credentials OWNER TO supabase_auth_admin;

--
-- Name: mvp_cajas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_cajas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nombre character varying NOT NULL,
    tipo character varying NOT NULL,
    user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mvp_cajas_tipo_check CHECK (((tipo)::text = ANY ((ARRAY['CENTRAL'::character varying, 'SOCIO'::character varying, 'REPARTIDOR'::character varying])::text[])))
);


ALTER TABLE public.mvp_cajas OWNER TO postgres;

--
-- Name: mvp_cierre_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_cierre_detalle (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cierre_id uuid NOT NULL,
    caja_id uuid NOT NULL,
    saldo_inicial numeric(15,2) NOT NULL,
    saldo_final numeric(15,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    total_ingresos numeric(15,2) DEFAULT 0 NOT NULL,
    total_egresos numeric(15,2) DEFAULT 0 NOT NULL,
    monto_dividendos numeric(15,2) DEFAULT 0 NOT NULL,
    monto_transferido_tesoreria numeric(15,2) DEFAULT 0 NOT NULL,
    porc_aplicado numeric(5,2),
    tipo_dividendo_aplicado character varying(10),
    CONSTRAINT mvp_cierre_detalle_tipo_div_check CHECK (((tipo_dividendo_aplicado IS NULL) OR ((tipo_dividendo_aplicado)::text = ANY ((ARRAY['GANANCIA'::character varying, 'VENTA'::character varying])::text[]))))
);


ALTER TABLE public.mvp_cierre_detalle OWNER TO postgres;

--
-- Name: mvp_cierre_resumen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_cierre_resumen (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cierre_id uuid NOT NULL,
    total_ventas numeric(15,2) DEFAULT 0 NOT NULL,
    total_compras numeric(15,2) DEFAULT 0 NOT NULL,
    cantidad_ventas integer DEFAULT 0 NOT NULL,
    cantidad_compras integer DEFAULT 0 NOT NULL,
    cantidad_productos_vendidos integer DEFAULT 0 NOT NULL,
    cantidad_clientes_activos integer DEFAULT 0 NOT NULL,
    cantidad_proveedores_activos integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mvp_cierre_resumen OWNER TO postgres;

--
-- Name: COLUMN mvp_cierre_resumen.cantidad_productos_vendidos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_cierre_resumen.cantidad_productos_vendidos IS 'Plantas vendidas del periodo: SUM(mvp_ventas_detalle.cantidad) de ventas ENTREGADA/COBRADO con fecha_entrega en el rango. Universo distinto al de total_ventas (D-K6).';


--
-- Name: COLUMN mvp_cierre_resumen.cantidad_clientes_activos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_cierre_resumen.cantidad_clientes_activos IS 'Clientes distintos con al menos una venta ENTREGADA/COBRADO con fecha_entrega en el rango del periodo.';


--
-- Name: COLUMN mvp_cierre_resumen.cantidad_proveedores_activos; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_cierre_resumen.cantidad_proveedores_activos IS 'Proveedores distintos con al menos un egreso pagado (operacion CONFIRMADA) imputado al periodo.';


--
-- Name: mvp_cierres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_cierres (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    periodo_id uuid NOT NULL,
    total_cajas integer,
    cajas_cerradas integer DEFAULT 0 NOT NULL,
    fecha_cierre timestamp with time zone,
    usuario_cierre uuid
);


ALTER TABLE public.mvp_cierres OWNER TO postgres;

--
-- Name: mvp_clientes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_clientes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    razon_social character varying NOT NULL,
    cuit character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    creado_por uuid DEFAULT auth.uid(),
    socio_captador_id uuid DEFAULT public.fn_socio_actual()
);


ALTER TABLE public.mvp_clientes OWNER TO postgres;

--
-- Name: COLUMN mvp_clientes.socio_captador_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_clientes.socio_captador_id IS 'Socio que consiguio al cliente (dato comercial). Distinto de creado_por, que es auditoria de quien tipeo el registro y es la clave del LIMPIADOR (RN-U10.1 LIMITE 1). Nullable por los 20 clientes previos a la columna; obligatorio en UI.';


--
-- Name: mvp_config_seguridad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_config_seguridad (
    id integer DEFAULT 1 NOT NULL,
    clave_baja_venta_hash text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mvp_config_seguridad_singleton CHECK ((id = 1))
);


ALTER TABLE public.mvp_config_seguridad OWNER TO postgres;

--
-- Name: mvp_ctacte; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_ctacte (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    socio_id uuid NOT NULL,
    operacion_id uuid NOT NULL,
    tipo_mov_ctacte character varying NOT NULL,
    monto_debe numeric(15,2) DEFAULT 0 NOT NULL,
    monto_haber numeric(15,2) DEFAULT 0 NOT NULL,
    fecha timestamp without time zone DEFAULT (now() AT TIME ZONE 'UTC'::text) NOT NULL,
    descripcion text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    afecta_saldo boolean DEFAULT true NOT NULL,
    CONSTRAINT mvp_ctacte_afecta_saldo_check CHECK (((((tipo_mov_ctacte)::text = 'APORTE'::text) AND (afecta_saldo = false)) OR (((tipo_mov_ctacte)::text <> 'APORTE'::text) AND (afecta_saldo = true)))),
    CONSTRAINT mvp_ctacte_montos_check CHECK (((((tipo_mov_ctacte)::text = ANY ((ARRAY['DIVIDENDOS'::character varying, 'INGRESO'::character varying, 'APORTE'::character varying])::text[])) AND (monto_haber > (0)::numeric) AND (monto_debe = (0)::numeric)) OR (((tipo_mov_ctacte)::text = ANY ((ARRAY['ADELANTO'::character varying, 'LIQUIDACION'::character varying, 'RETIRO'::character varying])::text[])) AND (monto_debe > (0)::numeric) AND (monto_haber = (0)::numeric)))),
    CONSTRAINT mvp_ctacte_tipo_mov_ctacte_check CHECK (((tipo_mov_ctacte)::text = ANY ((ARRAY['DIVIDENDOS'::character varying, 'INGRESO'::character varying, 'APORTE'::character varying, 'ADELANTO'::character varying, 'LIQUIDACION'::character varying, 'RETIRO'::character varying])::text[])))
);


ALTER TABLE public.mvp_ctacte OWNER TO postgres;

--
-- Name: COLUMN mvp_ctacte.afecta_saldo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_ctacte.afecta_saldo IS 'true: integra el saldo retirable (no patrimonial). false: patrimonial (APORTE), visible en el libro pero fuera del saldo.';


--
-- Name: mvp_egresos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_egresos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    socio_id uuid NOT NULL,
    proveedor_id uuid,
    tipo character varying NOT NULL,
    monto numeric(15,2) NOT NULL,
    fecha date DEFAULT ((now() AT TIME ZONE 'America/Argentina/Buenos_Aires'::text))::date NOT NULL,
    descripcion character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mvp_egresos_tipo_check CHECK (((tipo)::text = ANY ((ARRAY['COMPRA'::character varying, 'GASTO'::character varying])::text[])))
);


ALTER TABLE public.mvp_egresos OWNER TO postgres;

--
-- Name: mvp_movimientos_caja; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_movimientos_caja (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    caja_id uuid NOT NULL,
    monto numeric(15,2) NOT NULL,
    fecha timestamp without time zone DEFAULT (now() AT TIME ZONE 'UTC'::text) NOT NULL,
    tipo_referencia character varying NOT NULL,
    referencia_id character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    operacion_id uuid NOT NULL,
    CONSTRAINT mvp_movimientos_caja_tipo_referencia_check CHECK (((tipo_referencia)::text = ANY ((ARRAY['VENTA'::character varying, 'EGRESO'::character varying, 'TRANSFERENCIA'::character varying, 'CIERRE'::character varying, 'APORTE'::character varying, 'RETIRO'::character varying, 'ADELANTO'::character varying, 'LIQUIDACION'::character varying, 'INGRESO'::character varying])::text[])))
);


ALTER TABLE public.mvp_movimientos_caja OWNER TO postgres;

--
-- Name: mvp_operacion_caja; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_operacion_caja (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tipo_operacion_id integer NOT NULL,
    fecha timestamp without time zone DEFAULT (now() AT TIME ZONE 'UTC'::text) NOT NULL,
    usuario_id uuid NOT NULL,
    estado character varying DEFAULT 'CONFIRMADA'::character varying NOT NULL,
    caja_origen_id uuid,
    caja_destino_id uuid,
    tercero_id uuid,
    tipo_tercero character varying,
    referencia_externa character varying,
    observaciones text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    documento_tipo character varying,
    documento_id uuid,
    operacion_relacionada_id uuid,
    periodo_id uuid DEFAULT public.fn_periodo_vigente_id() NOT NULL,
    nro_comprobante integer,
    CONSTRAINT mvp_operacion_caja_documento_tipo_check CHECK (((documento_tipo IS NULL) OR ((documento_tipo)::text = ANY ((ARRAY['VENTA'::character varying, 'EGRESO'::character varying])::text[])))),
    CONSTRAINT mvp_operacion_caja_estado_check CHECK (((estado)::text = ANY ((ARRAY['PENDIENTE'::character varying, 'CONFIRMADA'::character varying, 'ANULADA'::character varying, 'REVERSADA'::character varying])::text[]))),
    CONSTRAINT mvp_operacion_caja_tipo_tercero_check CHECK (((tipo_tercero IS NULL) OR ((tipo_tercero)::text = ANY ((ARRAY['CLIENTE'::character varying, 'PROVEEDOR'::character varying, 'SOCIO'::character varying])::text[]))))
);


ALTER TABLE public.mvp_operacion_caja OWNER TO postgres;

--
-- Name: COLUMN mvp_operacion_caja.nro_comprobante; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_operacion_caja.nro_comprobante IS 'Comprobante secuencial global de operaciones que generan asiento de ctacte. NULL en operaciones comerciales sin ctacte.';


--
-- Name: mvp_operacion_caja_nro_comprobante_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mvp_operacion_caja_nro_comprobante_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mvp_operacion_caja_nro_comprobante_seq OWNER TO postgres;

--
-- Name: mvp_productos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_productos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nombre character varying NOT NULL,
    precio_lista numeric(15,2) NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    sigla character varying(4),
    CONSTRAINT mvp_productos_sigla_formato_check CHECK (((sigla IS NULL) OR ((sigla)::text ~ '^[a-z]{2,4}$'::text)))
);


ALTER TABLE public.mvp_productos OWNER TO postgres;

--
-- Name: mvp_proveedores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_proveedores (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nombre character varying NOT NULL,
    cuit_cuil character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    creado_por uuid DEFAULT auth.uid()
);


ALTER TABLE public.mvp_proveedores OWNER TO postgres;

--
-- Name: mvp_reglas_negocio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_reglas_negocio (
    id character varying(20) NOT NULL,
    id_base character varying(20) NOT NULL,
    version smallint DEFAULT 0 NOT NULL,
    titulo character varying(200) NOT NULL,
    modulo character varying(30) NOT NULL,
    estado character varying(15) NOT NULL,
    sustituida_por character varying(20),
    causa_sustitucion text,
    definicion character varying(500) NOT NULL,
    descripcion_completa character varying(1500),
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    tablas_relacionadas text[] DEFAULT '{}'::text[] NOT NULL,
    rpcs_relacionadas text[] DEFAULT '{}'::text[] NOT NULL,
    pantallas_relacionadas text[] DEFAULT '{}'::text[] NOT NULL,
    version_doc character varying(10) NOT NULL,
    fecha_actualizacion date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id_version_sistema smallint DEFAULT 1 NOT NULL,
    definicion_usuario jsonb,
    CONSTRAINT chk_definicion_no_vacia CHECK ((length(TRIM(BOTH FROM definicion)) > 0)),
    CONSTRAINT chk_estado_valido CHECK (((estado)::text = ANY ((ARRAY['VIGENTE'::character varying, 'PROPUESTA'::character varying])::text[]))),
    CONSTRAINT chk_modulo_valido CHECK (((modulo)::text = ANY ((ARRAY['usuarios'::character varying, 'ventas'::character varying, 'compras_gastos'::character varying, 'tesoreria'::character varying, 'dashboard'::character varying, 'caja_central'::character varying, 'administracion'::character varying, 'sistema'::character varying, 'estadisticas'::character varying])::text[]))),
    CONSTRAINT chk_sustitucion_coherente CHECK (((sustituida_por IS NULL) AND (causa_sustitucion IS NULL))),
    CONSTRAINT chk_tags_minimo_dos CHECK ((array_length(tags, 1) >= 2)),
    CONSTRAINT chk_version_no_negativa CHECK ((version >= 0))
);


ALTER TABLE public.mvp_reglas_negocio OWNER TO postgres;

--
-- Name: TABLE mvp_reglas_negocio; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.mvp_reglas_negocio IS 'Catálogo de Reglas de Negocio del MVP, derivado de Reglas_Negocio_v1_7.md. Regenerable vía TRUNCATE + INSERT. Solo contiene RN en estado VIGENTE o PROPUESTA. Las RN SUSTITUIDAS viven solo en el MD por trazabilidad.';


--
-- Name: COLUMN mvp_reglas_negocio.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_reglas_negocio.id IS 'Identificador único de la RN (formato RN-XXNN o RN-XXNN.M). Implementa RN-* en sí mismas.';


--
-- Name: COLUMN mvp_reglas_negocio.id_base; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_reglas_negocio.id_base IS 'ID sin sufijo de versión. Agrupa todas las versiones de una misma RN.';


--
-- Name: COLUMN mvp_reglas_negocio.estado; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_reglas_negocio.estado IS 'Estado de la RN. VIGENTE: activa. PROPUESTA: redactada sin aprobar (badge en app).';


--
-- Name: COLUMN mvp_reglas_negocio.tags; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_reglas_negocio.tags IS 'Tags para filtrado en SCR-Reglas. Mínimo 2 elementos. Vocabulario en RN_Template_v2.md §5.';


--
-- Name: COLUMN mvp_reglas_negocio.tablas_relacionadas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_reglas_negocio.tablas_relacionadas IS 'Metadata de trazabilidad. NO se muestra en SCR-Reglas. Solo para consultas técnicas.';


--
-- Name: COLUMN mvp_reglas_negocio.rpcs_relacionadas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_reglas_negocio.rpcs_relacionadas IS 'Metadata de trazabilidad. NO se muestra en SCR-Reglas. Solo para consultas técnicas.';


--
-- Name: COLUMN mvp_reglas_negocio.pantallas_relacionadas; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_reglas_negocio.pantallas_relacionadas IS 'Metadata de trazabilidad. SE muestra en SCR-Reglas como referencia cruzada.';


--
-- Name: COLUMN mvp_reglas_negocio.id_version_sistema; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_reglas_negocio.id_version_sistema IS 'Release del sistema donde aplica la RN: 1 = MVP v1; 2 = diferida a versiones futuras.';


--
-- Name: COLUMN mvp_reglas_negocio.definicion_usuario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_reglas_negocio.definicion_usuario IS 'Tercer nivel de lectura: definición consolidada para el usuario del sistema (SCR-Reglas). Estructura: {visible, texto, absorbe[], cubierta_por, motivo, version}. Revisión v1.1 2026-07-03: incorpora el concepto de dos flujos (comercial/caja delegada vs personal/cuenta corriente).';


--
-- Name: mvp_rendiciones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_rendiciones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    caja_id uuid NOT NULL,
    socio_id uuid NOT NULL,
    periodo_id uuid NOT NULL,
    saldo_libro numeric(15,2) NOT NULL,
    efectivo_declarado numeric(15,2) NOT NULL,
    faltante numeric(15,2) NOT NULL,
    operacion_liquidacion_id uuid,
    usuario_id uuid NOT NULL,
    fecha timestamp without time zone DEFAULT (now() AT TIME ZONE 'UTC'::text) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mvp_rendiciones_montos_check CHECK (((efectivo_declarado >= (0)::numeric) AND (faltante >= (0)::numeric) AND (faltante = (saldo_libro - efectivo_declarado))))
);


ALTER TABLE public.mvp_rendiciones OWNER TO postgres;

--
-- Name: mvp_repartidores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_repartidores (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mvp_repartidores OWNER TO postgres;

--
-- Name: TABLE mvp_repartidores; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.mvp_repartidores IS 'Capacidad ortogonal repartidor (RN-U05.1). user_id UNIQUE FK a mvp_users. Trigger trg_validar_operador_no_repartidor bloquea operadores.';


--
-- Name: mvp_socios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_socios (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    porc_ganancia numeric(5,2) NOT NULL,
    porc_venta numeric(5,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mvp_socios OWNER TO postgres;

--
-- Name: mvp_system_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_system_status (
    id integer NOT NULL,
    on_line boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mvp_system_status_singleton_chk CHECK ((id = 1))
);


ALTER TABLE public.mvp_system_status OWNER TO postgres;

--
-- Name: TABLE mvp_system_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.mvp_system_status IS 'Singleton de estado de conectividad del sistema. Una sola fila con id=1. Conmutada vía fn_toggle_online() por trigger.';


--
-- Name: COLUMN mvp_system_status.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_system_status.id IS 'Siempre 1. Restringido por CHECK.';


--
-- Name: COLUMN mvp_system_status.on_line; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_system_status.on_line IS 'Estado actual de conectividad. true = online, false = offline.';


--
-- Name: COLUMN mvp_system_status.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_system_status.updated_at IS 'Última actualización del estado. Trigger set_updated_at() lo mantiene.';


--
-- Name: mvp_tipo_operaciones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_tipo_operaciones (
    id integer NOT NULL,
    codigo character varying NOT NULL,
    nombre character varying NOT NULL,
    descripcion text,
    modulo character varying NOT NULL,
    ambito character varying NOT NULL,
    cantidad_mov smallint NOT NULL,
    usa_caja_origen boolean DEFAULT false NOT NULL,
    usa_caja_destino boolean DEFAULT false NOT NULL,
    usa_tercero boolean DEFAULT false NOT NULL,
    tipo_tercero character varying,
    requiere_documento boolean DEFAULT false NOT NULL,
    tipo_documento character varying,
    rpc_handler character varying,
    roles_permitidos text[] DEFAULT '{}'::text[] NOT NULL,
    metadata jsonb,
    activa boolean DEFAULT true NOT NULL,
    orden smallint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    usa_ctacte boolean DEFAULT false NOT NULL,
    ctacte_efecto character varying,
    mov_es_multiplo boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_mov_multiplo_coherente CHECK (((mov_es_multiplo = false) OR (cantidad_mov > 0))),
    CONSTRAINT ck_multiplo_requiere_base CHECK (((NOT mov_es_multiplo) OR (cantidad_mov > 0))),
    CONSTRAINT mvp_tipo_operaciones_ambito_check CHECK (((ambito)::text = ANY ((ARRAY['COMERCIAL'::character varying, 'PATRIMONIAL'::character varying, 'INTERNA'::character varying, 'ADMINISTRATIVA'::character varying])::text[]))),
    CONSTRAINT mvp_tipo_operaciones_ctacte_check CHECK ((((usa_ctacte = false) AND (ctacte_efecto IS NULL)) OR ((usa_ctacte = true) AND ((ctacte_efecto)::text = ANY ((ARRAY['DEBE'::character varying, 'HABER'::character varying])::text[]))))),
    CONSTRAINT mvp_tipo_operaciones_modulo_check CHECK (((modulo)::text = ANY ((ARRAY['VENTA'::character varying, 'COMPRA'::character varying, 'ADMINISTRACION'::character varying, 'TESORERIA'::character varying])::text[]))),
    CONSTRAINT mvp_tipo_operaciones_tipo_tercero_check CHECK (((tipo_tercero IS NULL) OR ((tipo_tercero)::text = ANY ((ARRAY['CLIENTE'::character varying, 'PROVEEDOR'::character varying, 'SOCIO'::character varying])::text[]))))
);


ALTER TABLE public.mvp_tipo_operaciones OWNER TO postgres;

--
-- Name: COLUMN mvp_tipo_operaciones.cantidad_mov; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_tipo_operaciones.cantidad_mov IS 'Movimientos de caja por acto elemental. Si mov_es_multiplo = false es la cantidad EXACTA que debe tener toda operacion del tipo. Si es true, es la BASE: la operacion tiene cantidad_mov x N movimientos (N >= 1). Cero = la operacion no escribe movimientos (solo ctacte). Ningun RPC lo valida hoy: es metadato declarativo verificable a posteriori.';


--
-- Name: COLUMN mvp_tipo_operaciones.mov_es_multiplo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_tipo_operaciones.mov_es_multiplo IS 'true: una operacion del tipo agrupa N actos elementales y escribe cantidad_mov x N movimientos. Caso vigente: TRANSFERENCIA, por la rendicion selectiva de fn_rendir_dia (2 patas por venta rendida, A-bis). false: cantidad exacta.';


--
-- Name: mvp_tipo_operaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_tipo_operaciones ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.mvp_tipo_operaciones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mvp_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_users (
    id uuid NOT NULL,
    email character varying NOT NULL,
    rol character varying NOT NULL,
    cliente_id uuid,
    nombre character varying NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    telefono character varying,
    rol_tesorero boolean DEFAULT false NOT NULL,
    es_tester boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_tesorero_es_socio CHECK (((rol_tesorero = false) OR ((rol)::text = 'socio'::text))),
    CONSTRAINT chk_tester_es_socio CHECK (((es_tester = false) OR ((rol)::text = 'socio'::text))),
    CONSTRAINT mvp_users_cliente_id_check CHECK (((((rol)::text = 'operador'::text) AND (cliente_id IS NOT NULL)) OR (((rol)::text <> 'operador'::text) AND (cliente_id IS NULL)))),
    CONSTRAINT mvp_users_rol_check CHECK (((rol)::text = ANY ((ARRAY['admin'::character varying, 'tesorero'::character varying, 'socio'::character varying, 'operador'::character varying, 'repartidor'::character varying])::text[])))
);


ALTER TABLE public.mvp_users OWNER TO postgres;

--
-- Name: COLUMN mvp_users.rol_tesorero; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_users.rol_tesorero IS 'Capacidad ortogonal Tesorero (RN-U09, DEC-048, modelo B-3). Segundo rol asignable solo a un Socio (chk_tesorero_es_socio). Unicidad a lo sumo uno via uq_unico_tesorero. El Admin cubre tesoreria de forma inherente cuando ningun Socio la tiene.';


--
-- Name: COLUMN mvp_users.es_tester; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.mvp_users.es_tester IS 'Marca de usuario de prueba. Excluye de reportes patrimoniales y habilita el label TESTER en el Dashboard. Base para PEN-028 / RLS-DT03 (aislación de tester a nivel RLS).';


--
-- Name: mvp_ventas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_ventas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cliente_id uuid NOT NULL,
    socio_id uuid NOT NULL,
    socio_cobrador_id uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    fecha_entrega date NOT NULL,
    estado character varying NOT NULL,
    total numeric(15,2) NOT NULL,
    notas text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    repartidor_id uuid,
    nro_factura character varying(50),
    motivo_anulacion character varying(40),
    fecha_asignacion date,
    fecha_anulacion date,
    CONSTRAINT mvp_ventas_estado_check CHECK (((estado)::text = ANY ((ARRAY['PEDIDO'::character varying, 'ASIGNADO'::character varying, 'ENTREGADA'::character varying, 'COBRADO'::character varying, 'ANULADA'::character varying])::text[]))),
    CONSTRAINT mvp_ventas_estado_coherencia_check CHECK (((((estado)::text = 'PEDIDO'::text) AND (repartidor_id IS NULL) AND (nro_factura IS NULL) AND (socio_cobrador_id IS NULL)) OR (((estado)::text = 'ASIGNADO'::text) AND (repartidor_id IS NOT NULL) AND (nro_factura IS NOT NULL) AND (socio_cobrador_id IS NULL)) OR (((estado)::text = 'ENTREGADA'::text) AND (repartidor_id IS NOT NULL) AND (nro_factura IS NOT NULL) AND (socio_cobrador_id IS NULL)) OR (((estado)::text = 'COBRADO'::text) AND (repartidor_id IS NOT NULL) AND (nro_factura IS NOT NULL)) OR (((estado)::text = 'COBRADO'::text) AND (repartidor_id IS NULL) AND (nro_factura IS NULL) AND (socio_cobrador_id IS NOT NULL)) OR (((estado)::text = 'ANULADA'::text) AND (repartidor_id IS NULL) AND (nro_factura IS NULL) AND (socio_cobrador_id IS NULL)))),
    CONSTRAINT mvp_ventas_motivo_anulacion_check CHECK (((((estado)::text = 'ANULADA'::text) AND ((motivo_anulacion)::text = ANY ((ARRAY['DESISTIMIENTO_CLIENTE'::character varying, 'FALTA_STOCK'::character varying])::text[]))) OR (((estado)::text <> 'ANULADA'::text) AND (motivo_anulacion IS NULL))))
);


ALTER TABLE public.mvp_ventas OWNER TO postgres;

--
-- Name: mvp_ventas_bajas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_ventas_bajas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    venta_id uuid NOT NULL,
    periodo_id uuid NOT NULL,
    fecha_baja timestamp with time zone DEFAULT now() NOT NULL,
    usuario_baja_id uuid NOT NULL,
    estado_previo character varying(20) NOT NULL,
    nro_factura character varying(50),
    fecha_entrega date NOT NULL,
    cliente_id uuid,
    cliente_razon_social character varying,
    socio_id uuid,
    socio_nombre text,
    repartidor_nombre text,
    total numeric(15,2) NOT NULL,
    caja_afectada_id uuid,
    caja_afectada_nombre character varying,
    motivo text,
    snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mvp_ventas_bajas_estado_previo_check CHECK (((estado_previo)::text = ANY ((ARRAY['ASIGNADO'::character varying, 'ENTREGADA'::character varying, 'COBRADO'::character varying])::text[])))
);


ALTER TABLE public.mvp_ventas_bajas OWNER TO postgres;

--
-- Name: mvp_ventas_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mvp_ventas_detalle (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    venta_id uuid NOT NULL,
    producto_id uuid NOT NULL,
    cantidad numeric(10,2) NOT NULL,
    precio_lista numeric(15,2) NOT NULL,
    precio_real numeric(15,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mvp_ventas_detalle OWNER TO postgres;

--
-- Name: v_ventas_consulta; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_ventas_consulta WITH (security_invoker='true') AS
 SELECT v.id AS venta_id,
    v.estado,
    v.cliente_id,
    c.razon_social AS cliente_razon_social,
    v.socio_id,
    public.fn_nombre_socio(v.socio_id) AS socio_nombre,
    v.socio_cobrador_id,
    public.fn_caja_real_cobro(v.id) AS caja_destino,
    v.repartidor_id,
    ur.nombre AS repartidor_nombre,
    v.nro_factura,
    v.total,
    v.fecha_entrega,
    public.fn_fecha_cobro(v.id) AS fecha_cobro,
        CASE v.estado
            WHEN 'PEDIDO'::text THEN public.fn_fecha_local(v.created_at)
            WHEN 'ASIGNADO'::text THEN v.fecha_asignacion
            WHEN 'ENTREGADA'::text THEN v.fecha_entrega
            WHEN 'COBRADO'::text THEN public.fn_fecha_cobro(v.id)
            WHEN 'ANULADA'::text THEN v.fecha_anulacion
            ELSE NULL::date
        END AS fecha_efectiva
   FROM ((public.mvp_ventas v
     LEFT JOIN public.mvp_clientes c ON ((c.id = v.cliente_id)))
     LEFT JOIN public.mvp_users ur ON ((ur.id = v.repartidor_id)));


ALTER VIEW public.v_ventas_consulta OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    selected_columns text[],
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


ALTER TABLE realtime.subscription OWNER TO supabase_realtime_admin;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE storage.buckets_analytics OWNER TO supabase_storage_admin;

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.buckets_vectors OWNER TO supabase_storage_admin;

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.vector_indexes OWNER TO supabase_storage_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: supabase_migrations; Owner: postgres
--

CREATE TABLE supabase_migrations.schema_migrations (
    version text NOT NULL,
    statements text[],
    name text,
    created_by text,
    idempotency_key text,
    rollback text[]
);


ALTER TABLE supabase_migrations.schema_migrations OWNER TO postgres;

--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at, custom_claims_allowlist) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
52145560-ffc2-4d29-b702-bd1893a62035	52145560-ffc2-4d29-b702-bd1893a62035	{"sub": "52145560-ffc2-4d29-b702-bd1893a62035", "email": "hectorjorgeaguirre@hotmail.com", "email_verified": false, "phone_verified": false}	email	2026-04-18 13:31:02.805678+00	2026-04-18 13:31:02.805736+00	2026-04-18 13:31:02.805736+00	df7fff83-c8f4-430b-8fef-adac8ecd7595
20f0a578-b9b3-4e56-a634-aa3ff7970b77	20f0a578-b9b3-4e56-a634-aa3ff7970b77	{"sub": "20f0a578-b9b3-4e56-a634-aa3ff7970b77", "email": "hectorag@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-04-18 15:10:32.473784+00	2026-04-18 15:10:32.473844+00	2026-04-18 15:10:32.473844+00	52397a3b-6df8-40ca-ad74-8961c55ac76c
259e6361-632b-4584-b7c8-90a8c3b411a5	259e6361-632b-4584-b7c8-90a8c3b411a5	{"sub": "259e6361-632b-4584-b7c8-90a8c3b411a5", "email": "ferrando.rodolfo@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-04-24 00:35:49.017726+00	2026-04-24 00:35:49.017788+00	2026-04-24 00:35:49.017788+00	2f5c1f77-c9b7-4e0e-bf4b-6d6379ba1e3d
8855cdde-cd2a-4422-9220-041f5da8f61f	8855cdde-cd2a-4422-9220-041f5da8f61f	{"sub": "8855cdde-cd2a-4422-9220-041f5da8f61f", "email": "patferrari56@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-04-24 00:37:53.053312+00	2026-04-24 00:37:53.053357+00	2026-04-24 00:37:53.053357+00	f2bd3caf-c485-4d9d-9737-1d0da54b120b
f96a856d-9da8-4873-9256-62ec1e3a7c55	f96a856d-9da8-4873-9256-62ec1e3a7c55	{"sub": "f96a856d-9da8-4873-9256-62ec1e3a7c55", "email": "lucaspeirano@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-06-20 21:44:40.775624+00	2026-06-20 21:44:40.775713+00	2026-06-20 21:44:40.775713+00	3279b3fd-04ae-405e-af8a-a0efd3dd9615
2a08da39-1889-4a3c-a67b-fe63deb762a8	2a08da39-1889-4a3c-a67b-fe63deb762a8	{"sub": "2a08da39-1889-4a3c-a67b-fe63deb762a8", "email": "jb486005@gmail.com", "email_verified": true, "phone_verified": false}	email	2026-04-24 00:36:59.713733+00	2026-04-24 00:36:59.713806+00	2026-07-02 17:48:10.624268+00	1dac6a00-bb41-4a7f-a348-cc680574977a
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
56781821-ea59-4423-b58f-4fe072c6fb16	2026-08-01 13:07:10.238454+00	2026-08-01 13:07:10.238454+00	password	89f8071a-4485-489c-b21b-e6d8fe595532
7b73418f-2eda-4817-b40f-fc09fd8a48f8	2026-08-01 22:39:41.922771+00	2026-08-01 22:39:41.922771+00	password	aa1ea7af-d595-4495-8ee0-73a2e3bceeb4
c45c80e9-f81c-4239-92b6-05581ac1188f	2026-08-01 22:48:48.535323+00	2026-08-01 22:48:48.535323+00	password	ca2e59e0-f00d-42e3-8230-3331d2213061
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
5199fffd-2779-430d-989d-ff7fdb260688	2a08da39-1889-4a3c-a67b-fe63deb762a8	recovery_token	6e2ec74f54955d935a8d5dd62b47dd820f5a462508eb8643fdc6cde7	jb486005@gmail.com	2026-07-02 18:07:43.563978	2026-07-02 18:07:43.563978
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	1029	he6f4z3c2zmh	2a08da39-1889-4a3c-a67b-fe63deb762a8	f	2026-08-01 13:07:10.235775+00	2026-08-01 13:07:10.235775+00	\N	56781821-ea59-4423-b58f-4fe072c6fb16
00000000-0000-0000-0000-000000000000	1041	avdghxj7n37z	20f0a578-b9b3-4e56-a634-aa3ff7970b77	f	2026-08-01 22:39:41.919732+00	2026-08-01 22:39:41.919732+00	\N	7b73418f-2eda-4817-b40f-fc09fd8a48f8
00000000-0000-0000-0000-000000000000	1042	5yeccuydmors	20f0a578-b9b3-4e56-a634-aa3ff7970b77	f	2026-08-01 22:48:48.531688+00	2026-08-01 22:48:48.531688+00	\N	c45c80e9-f81c-4239-92b6-05581ac1188f
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
c45c80e9-f81c-4239-92b6-05581ac1188f	20f0a578-b9b3-4e56-a634-aa3ff7970b77	2026-08-01 22:48:48.522492+00	2026-08-01 22:48:48.522492+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	200.85.110.54	\N	\N	\N	\N	\N
56781821-ea59-4423-b58f-4fe072c6fb16	2a08da39-1889-4a3c-a67b-fe63deb762a8	2026-08-01 13:07:10.234793+00	2026-08-01 13:07:10.234793+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	186.19.192.30	\N	\N	\N	\N	\N
7b73418f-2eda-4817-b40f-fc09fd8a48f8	20f0a578-b9b3-4e56-a634-aa3ff7970b77	2026-08-01 22:39:41.914184+00	2026-08-01 22:39:41.914184+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	200.85.110.54	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
00000000-0000-0000-0000-000000000000	52145560-ffc2-4d29-b702-bd1893a62035	authenticated	authenticated	hectorjorgeaguirre@hotmail.com	$2a$06$0nnZas5yPscAmSDUBzd0xuOVst7X2KhUVjebWhRLQS24My6kwb2Sq	2026-04-18 13:31:02.814347+00	\N		\N		\N			\N	2026-07-25 00:06:02.450403+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-04-18 13:31:02.792918+00	2026-07-25 00:06:02.452865+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	259e6361-632b-4584-b7c8-90a8c3b411a5	authenticated	authenticated	ferrando.rodolfo@gmail.com	$2a$06$289OVZySoj45cO.7RNJg/uiIiMZYkHdKsK3VFvuvRpXT1UV66jt6y	2026-04-24 00:35:49.026363+00	\N		\N		\N			\N	2026-08-01 13:04:13.735597+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-04-24 00:35:48.990123+00	2026-08-01 13:04:13.745523+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f96a856d-9da8-4873-9256-62ec1e3a7c55	authenticated	authenticated	lucaspeirano@gmail.com	$2a$10$.brSTSgGfRtAhK6vFT2Czuc1IdC18jTinMeOzEEAFEBANKR6g9PzG	2026-06-20 21:44:40.781381+00	\N		\N		\N			\N	2026-08-01 13:05:27.187978+00	{"provider": "email", "providers": ["email"]}	{"full_name": "Lucas Peirano", "email_verified": true}	\N	2026-06-20 21:44:40.75331+00	2026-08-01 13:05:27.193412+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	8855cdde-cd2a-4422-9220-041f5da8f61f	authenticated	authenticated	patferrari56@gmail.com	$2a$06$6QjC8mPdKGGk3uHdTtN5Qe3jqQV5lFJkd1CEA3bjilUtNgZqJopda	2026-04-24 00:37:53.054738+00	\N		\N		\N			\N	2026-08-01 13:06:23.079291+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-04-24 00:37:53.051723+00	2026-08-01 13:06:23.088886+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	2a08da39-1889-4a3c-a67b-fe63deb762a8	authenticated	authenticated	jb486005@gmail.com	$2a$10$m7ATi6uNx1isdy6UHunc0.alg/HvI/iMGJCvJdkhOOlVRQgqP7Qn2	2026-04-24 00:36:59.718457+00	\N		\N	6e2ec74f54955d935a8d5dd62b47dd820f5a462508eb8643fdc6cde7	2026-07-02 18:07:41.509316+00			\N	2026-08-01 13:07:10.234652+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-04-24 00:36:59.700771+00	2026-08-01 13:07:10.236763+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	20f0a578-b9b3-4e56-a634-aa3ff7970b77	authenticated	authenticated	hectorag@gmail.com	$2a$06$pKftI4Fk0CyiX5/YVPSJIebBzOURqXG4JalhSlqTAEmajfv5jj/WG	2026-04-18 15:10:32.479704+00	\N		\N		\N			\N	2026-08-01 22:48:48.521404+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-04-18 15:10:32.44696+00	2026-08-01 22:48:48.533377+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: mvp_cajas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_cajas (id, nombre, tipo, user_id, created_at, updated_at) FROM stdin;
6638fa38-c9bd-4004-8a84-891005d8f0b9	Caja Patricia	SOCIO	8855cdde-cd2a-4422-9220-041f5da8f61f	2026-04-26 16:50:38.112479+00	2026-04-26 16:50:38.112479+00
300b4667-734d-45e0-a92a-a78737f75eb8	Caja Rodolfo Rolando	SOCIO	259e6361-632b-4584-b7c8-90a8c3b411a5	2026-04-26 16:50:38.112479+00	2026-04-26 16:50:38.112479+00
f2016a87-e798-4e74-a11b-43a2679dc5b6	Caja Javier Benítez	SOCIO	2a08da39-1889-4a3c-a67b-fe63deb762a8	2026-04-26 16:50:38.112479+00	2026-04-26 16:50:38.112479+00
fc3431c5-7d76-43cf-a7c2-5a338bdc1380	Caja Central	CENTRAL	\N	2026-04-26 16:50:38.112479+00	2026-04-26 16:53:23.471553+00
d9746a8e-262d-4359-9589-6f232f5d9e0f	Caja Repartidor — Javier Benítez	REPARTIDOR	2a08da39-1889-4a3c-a67b-fe63deb762a8	2026-05-31 01:16:16.791294+00	2026-05-31 01:16:16.791294+00
2671b2e0-e9a7-43ff-bdfb-35581d3f1be8	Caja Repartidor — Patricia	REPARTIDOR	8855cdde-cd2a-4422-9220-041f5da8f61f	2026-05-31 01:22:10.103822+00	2026-05-31 01:22:10.103822+00
88ce6836-bb6c-4380-863d-7a8c5957d906	Caja Repartidor — Rodolfo Rolando	REPARTIDOR	259e6361-632b-4584-b7c8-90a8c3b411a5	2026-05-31 01:28:36.250206+00	2026-05-31 01:28:36.250206+00
c2c653b5-bd3b-4e71-a5b4-bc8599183e33	Caja Lucas Peirano	SOCIO	f96a856d-9da8-4873-9256-62ec1e3a7c55	2026-06-20 21:44:40.830145+00	2026-06-20 21:44:40.830145+00
a8558e4c-0468-4a56-a0b0-776f4eb7fdbf	Caja Repartidor — Lucas Peirano	REPARTIDOR	f96a856d-9da8-4873-9256-62ec1e3a7c55	2026-06-28 00:11:39.90615+00	2026-06-28 00:11:39.90615+00
\.


--
-- Data for Name: mvp_cierre_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_cierre_detalle (id, cierre_id, caja_id, saldo_inicial, saldo_final, created_at, updated_at, total_ingresos, total_egresos, monto_dividendos, monto_transferido_tesoreria, porc_aplicado, tipo_dividendo_aplicado) FROM stdin;
9fa3a4f1-a0ea-4df5-936f-7534d6a9aa58	ee471bc7-bda9-4101-8401-dc8c6c32c272	f2016a87-e798-4e74-a11b-43a2679dc5b6	0.00	0.00	2026-07-02 18:48:46.701648+00	2026-07-02 18:48:46.701648+00	1075800.00	117017.48	1288179.51	958782.52	50.00	GANANCIA
a1ea4e51-4369-4662-83bc-0fefa19a90ad	ee471bc7-bda9-4101-8401-dc8c6c32c272	c2c653b5-bd3b-4e71-a5b4-bc8599183e33	0.00	0.00	2026-07-02 18:48:46.701648+00	2026-07-02 18:48:46.701648+00	0.00	0.00	0.00	0.00	\N	\N
dc9b3975-be70-44be-92de-5e561c08b402	ee471bc7-bda9-4101-8401-dc8c6c32c272	6638fa38-c9bd-4004-8a84-891005d8f0b9	0.00	0.00	2026-07-02 18:48:46.701648+00	2026-07-02 18:48:46.701648+00	0.00	0.00	446917.50	0.00	10.00	VENTA
5a1fa7de-4b6d-49fd-b4c8-1c1383735b16	ee471bc7-bda9-4101-8401-dc8c6c32c272	300b4667-734d-45e0-a92a-a78737f75eb8	0.00	0.00	2026-07-02 18:48:46.701648+00	2026-07-02 18:48:46.701648+00	3408375.00	1343881.00	1288179.51	2064494.00	50.00	GANANCIA
036dfb31-4b4f-4ee3-8593-cd52b441f177	ee471bc7-bda9-4101-8401-dc8c6c32c272	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	0.00	3023276.52	2026-07-02 18:48:46.701648+00	2026-07-02 18:48:46.701648+00	3023276.52	0.00	0.00	0.00	\N	\N
15ebd99e-e0bf-47b5-8875-f93a4220a97c	22099cda-3cf6-4439-a176-083454f01084	f2016a87-e798-4e74-a11b-43a2679dc5b6	0.00	0.00	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	1414700.00	1414700.00	1395247.68	0.00	50.00	GANANCIA
59571346-ba36-43c7-a001-09bb61137451	22099cda-3cf6-4439-a176-083454f01084	c2c653b5-bd3b-4e71-a5b4-bc8599183e33	0.00	0.00	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	0.00	0.00	0.00	0.00	\N	\N
b00cdbf5-8fdd-4a97-917b-ce55540f9fa1	22099cda-3cf6-4439-a176-083454f01084	6638fa38-c9bd-4004-8a84-891005d8f0b9	0.00	0.00	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	0.00	0.00	434010.00	0.00	10.00	VENTA
fad40f02-d053-4dd2-bc14-4c804e95f12f	22099cda-3cf6-4439-a176-083454f01084	300b4667-734d-45e0-a92a-a78737f75eb8	0.00	0.00	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	2925400.00	1682512.15	1395247.68	1242887.85	50.00	GANANCIA
cc6af53a-938f-4001-8844-f4e0e25e7da3	22099cda-3cf6-4439-a176-083454f01084	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	3023276.52	1689805.35	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	2219805.35	3553276.52	0.00	0.00	\N	\N
\.


--
-- Data for Name: mvp_cierre_resumen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_cierre_resumen (id, cierre_id, total_ventas, total_compras, cantidad_ventas, cantidad_compras, cantidad_productos_vendidos, cantidad_clientes_activos, cantidad_proveedores_activos, created_at, updated_at) FROM stdin;
7051eb5b-1754-4bc0-b7d8-f063ab7f2262	ee471bc7-bda9-4101-8401-dc8c6c32c272	4469175.00	1445898.48	65	14	2283	13	8	2026-07-02 18:48:46.701648+00	2026-07-28 22:41:58.029919+00
6dd5a4d6-71ff-4220-ab41-ed0511a54fb9	22099cda-3cf6-4439-a176-083454f01084	4340100.00	1115594.65	61	10	2083	11	7	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00
\.


--
-- Data for Name: mvp_cierres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_cierres (id, created_at, updated_at, periodo_id, total_cajas, cajas_cerradas, fecha_cierre, usuario_cierre) FROM stdin;
ee471bc7-bda9-4101-8401-dc8c6c32c272	2026-07-02 18:48:46.701648+00	2026-07-02 18:48:46.701648+00	3cc69ffa-6f76-4970-bc03-4e5ee0153175	5	2	2026-07-02 18:48:46.701648+00	20f0a578-b9b3-4e56-a634-aa3ff7970b77
22099cda-3cf6-4439-a176-083454f01084	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	cc61b1c7-afaf-453e-9254-6b2d24809465	5	1	2026-08-01 13:16:25.481153+00	20f0a578-b9b3-4e56-a634-aa3ff7970b77
\.


--
-- Data for Name: mvp_clientes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_clientes (id, razon_social, cuit, created_at, updated_at, activo, creado_por, socio_captador_id) FROM stdin;
7c954936-e1a4-4c2e-80dd-7a6c958274f4	botanab	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
3c6706bb-e519-439c-9ea4-36095cb6c678	botanap	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	Champa	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
819465e3-bd53-4571-897b-e4a9d4cae03d	Coffee Paseo	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
b921f754-c413-45f9-bbf1-594e2f9b4353	Colorada	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
689d38aa-edf0-4007-a698-69c57b72821a	Crudo	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
6965ccba-cf7a-4427-8e2a-f897edd04aed	Culto	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
170cec38-63b0-4969-92a7-ec872bebc116	DAV	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
f72561fb-b0a1-4d09-acba-a4abe0bb4beb	Flanders	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
10a150de-5f46-47af-a303-30e1bcd42f90	Frik´s	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
7e992fe9-d375-47b4-acb9-bbf185071bda	Homero	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
69486c3e-c091-48f5-9bb0-8d91f279b976	Pio	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
b18b5501-ed98-480b-aeca-c8312cc58bb7	Plenta	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
6b1f8b3c-5537-4c84-a955-5d128bfc3fc6	Rodolfo	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
ae45363b-7cb9-47d6-befd-0f8d058ea3eb	Roseta	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
db735bfa-0343-4745-aa54-5dd0c15db45b	Trebol	\N	2026-06-07 17:21:36.68051+00	2026-06-07 17:21:36.68051+00	t	\N	\N
575b9d5a-7152-43b5-af6d-7bd90bc6e780	Ulises	\N	2026-06-18 23:01:04.263592+00	2026-06-18 23:01:04.263592+00	t	\N	\N
beca476c-87f4-48cf-adeb-90b904d48a10	San Cayetano	\N	2026-06-22 12:11:55.933595+00	2026-06-22 12:11:55.933595+00	t	\N	\N
3249bfe8-6aeb-449c-a605-647b9cae453c	BotanaM	\N	2026-06-22 13:00:54.017652+00	2026-06-22 13:00:54.017652+00	t	\N	\N
469c1269-5dd0-453b-99ca-a00adf8ebf87	Hidrofood	\N	2026-06-29 21:16:04.80438+00	2026-06-29 21:16:04.80438+00	t	\N	\N
6f5a2c3a-7240-4f3c-bc02-41accaad8a44	Tio Ulises	\N	2026-07-30 15:54:28.331935+00	2026-07-30 15:54:28.331935+00	t	20f0a578-b9b3-4e56-a634-aa3ff7970b77	\N
\.


--
-- Data for Name: mvp_config_seguridad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_config_seguridad (id, clave_baja_venta_hash, updated_at) FROM stdin;
1	$2a$06$NtP3WW28bnqgtjHtU0GY4.wASO5jw3gj/UFvshOHzsqLF/M6R5ONi	2026-07-20 14:46:33.7992+00
\.


--
-- Data for Name: mvp_ctacte; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_ctacte (id, socio_id, operacion_id, tipo_mov_ctacte, monto_debe, monto_haber, fecha, descripcion, created_at, updated_at, afecta_saldo) FROM stdin;
c426e3d6-0256-4908-9bc6-bc474f1b3167	2a08da39-1889-4a3c-a67b-fe63deb762a8	90255a93-ddba-4cf0-9c85-34da7525b675	DIVIDENDOS	0.00	1288179.51	2026-06-30 23:59:59	\N	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	t
ef107104-fe89-4907-ae69-602ad47504da	8855cdde-cd2a-4422-9220-041f5da8f61f	c27dd104-74c8-4093-98ee-9a825c4758f2	DIVIDENDOS	0.00	446917.50	2026-06-30 23:59:59	\N	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	t
db004312-85d4-4878-b0ef-e44461770895	259e6361-632b-4584-b7c8-90a8c3b411a5	0af005c3-b2d7-459d-8c5f-d294a375285d	DIVIDENDOS	0.00	1288179.51	2026-06-30 23:59:59	\N	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	t
82c7d2e3-8f31-4ca7-80bd-18aad32334cb	2a08da39-1889-4a3c-a67b-fe63deb762a8	ea62e998-c467-49b5-ad79-d169ee6cda41	RETIRO	1000000.00	0.00	2026-07-14 07:48:45.300016	\N	2026-07-14 07:48:45.300016+00	2026-07-14 07:48:45.300016+00	t
eabb7b4d-02e1-4635-9911-23ffd4675e8c	2a08da39-1889-4a3c-a67b-fe63deb762a8	0fab4864-0955-4c3b-8574-0e5b6743dcfc	RETIRO	288179.51	0.00	2026-07-21 18:56:12.760376	\N	2026-07-21 18:56:12.760376+00	2026-07-21 18:56:12.760376+00	t
4a081fae-e3af-4ab2-bc41-af716f5d70b4	259e6361-632b-4584-b7c8-90a8c3b411a5	46fce66a-5f08-43ec-9646-b8fb3dbcb599	RETIRO	1288179.51	0.00	2026-07-21 18:59:37.320904	\N	2026-07-21 18:59:37.320904+00	2026-07-21 18:59:37.320904+00	t
c41ce614-6a55-4046-b48d-c43c185d1a89	8855cdde-cd2a-4422-9220-041f5da8f61f	04750226-ea44-4006-806d-1520120af314	RETIRO	446917.50	0.00	2026-07-25 01:18:51.93948	\N	2026-07-25 01:18:51.93948+00	2026-07-25 01:18:51.93948+00	t
eb12e577-b7f5-4acd-aa73-6714e9f0273f	8855cdde-cd2a-4422-9220-041f5da8f61f	77087c85-c563-480d-9a98-d83f6b49634f	ADELANTO	160000.00	0.00	2026-07-27 00:06:12.514247	\N	2026-07-27 00:06:12.514247+00	2026-07-27 00:06:12.514247+00	t
0cae9fa9-9cf9-4dd7-b1fe-6abaa07c14c4	8855cdde-cd2a-4422-9220-041f5da8f61f	6c6bfecd-aa47-423a-bc76-a4bbeed96f4f	ADELANTO	100000.00	0.00	2026-07-28 13:20:56.629222	\N	2026-07-28 13:20:56.629222+00	2026-07-28 13:20:56.629222+00	t
6377d9ac-120b-44e7-8240-9b9cc6eab721	2a08da39-1889-4a3c-a67b-fe63deb762a8	84ad83fb-589a-424b-a015-74e0aeeb3f40	ADELANTO	100000.00	0.00	2026-07-01 15:00:00	\N	2026-07-30 04:01:56.285608+00	2026-07-30 04:01:56.285608+00	t
87c69e65-8397-4e46-8462-836420693479	2a08da39-1889-4a3c-a67b-fe63deb762a8	258307dd-a0cf-4596-8669-c835d4fea220	ADELANTO	20000.00	0.00	2026-07-23 15:00:00	\N	2026-07-30 04:08:05.088588+00	2026-07-30 04:08:05.088588+00	t
b7db20d5-da15-4c63-8ed3-086a76ffd95c	2a08da39-1889-4a3c-a67b-fe63deb762a8	64fa5586-7eb9-4d17-95c0-f8cdfad2a5e2	ADELANTO	50000.00	0.00	2026-07-29 15:00:00	\N	2026-07-30 04:13:04.535086+00	2026-07-30 04:13:04.535086+00	t
dd16313e-a631-4b50-9a9c-92f66792a057	8855cdde-cd2a-4422-9220-041f5da8f61f	4d7755cb-ea5d-4d18-8a2c-124e57e02824	ADELANTO	100000.00	0.00	2026-07-31 17:00:37.326167	\N	2026-07-31 17:00:37.326167+00	2026-07-31 17:00:37.326167+00	t
9cb53817-d5bb-4a7d-bdb5-f937da0bfe23	2a08da39-1889-4a3c-a67b-fe63deb762a8	d3801db4-f058-4e9b-b25c-a7f460dbc071	DIVIDENDOS	0.00	1395247.68	2026-07-31 23:59:59	\N	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	t
c2b99571-426b-4b9a-b135-4dd96a828712	8855cdde-cd2a-4422-9220-041f5da8f61f	c033f196-9028-4f71-b74e-179116db6b71	DIVIDENDOS	0.00	434010.00	2026-07-31 23:59:59	\N	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	t
34944ec0-a7c7-4a21-84cb-c6f625e626e7	259e6361-632b-4584-b7c8-90a8c3b411a5	5acbea1f-b7c5-4f5b-91c4-fe8eab9a8025	DIVIDENDOS	0.00	1395247.68	2026-07-31 23:59:59	\N	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	t
1f76170b-a88b-4992-bbab-b8643c53434b	2a08da39-1889-4a3c-a67b-fe63deb762a8	eee91392-638f-4e63-ae95-07618b73233c	LIQUIDACION	1004700.00	0.00	2026-07-31 23:59:59	\N	2026-08-01 13:07:51.19579+00	2026-08-01 14:56:35.887997+00	t
\.


--
-- Data for Name: mvp_egresos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_egresos (id, socio_id, proveedor_id, tipo, monto, fecha, descripcion, created_at, updated_at) FROM stdin;
1c64dbe3-ea47-4cf3-9f40-5d80e40c5460	56eb204d-9859-4fec-a799-7a38ee21626b	e1e40efd-b972-4f73-9aab-b584fe86974d	COMPRA	47118.00	2026-06-17	Lechugas	2026-06-26 15:44:01.25824+00	2026-06-26 15:44:01.25824+00
8032d08d-83f1-4d71-a9d7-cc0875fb8493	56eb204d-9859-4fec-a799-7a38ee21626b	2d5e1cb7-772d-43df-96bf-9cce68d74439	COMPRA	66000.00	2026-06-17	Nitrato de Potasio	2026-06-26 15:47:04.869142+00	2026-06-26 15:47:04.869142+00
c21b486b-bcd1-4fff-8bc7-9d1993ce09d3	56eb204d-9859-4fec-a799-7a38ee21626b	2730fa75-fe67-442c-a43a-5c4c645e9a72	COMPRA	93200.00	2026-06-16	Asian, Microgreens, y espuma fenolica	2026-06-26 15:48:49.43972+00	2026-06-26 15:48:49.43972+00
74abfe5c-a8d1-485b-ba12-74215dea3f7b	56eb204d-9859-4fec-a799-7a38ee21626b	4c18dd67-24e9-488a-b895-188731bc1a9e	GASTO	72363.00	2026-06-26	Seguro camioneta	2026-06-26 13:57:58.916949+00	2026-06-30 23:33:11.252275+00
45b1af66-f64b-4ce2-b488-3201d72ae06d	36b55efb-e01d-49ee-9259-87c36318d581	20986897-3e23-41c1-8405-1336e714fe31	GASTO	50000.00	2026-06-30	nafta camioneta	2026-06-30 12:26:45.728097+00	2026-06-30 23:33:11.252275+00
76e4e23e-207a-4e89-bef4-4d065954cadb	56eb204d-9859-4fec-a799-7a38ee21626b	2730fa75-fe67-442c-a43a-5c4c645e9a72	COMPRA	374000.00	2026-06-30	Microgreens - 156	2026-06-30 14:05:48+00	2026-07-01 14:20:48.389297+00
17cd798f-5dfc-45db-8f56-7c1c61cdb1e0	56eb204d-9859-4fec-a799-7a38ee21626b	64fea813-ac79-48b4-92a2-a6b08d53b8a5	COMPRA	497200.00	2026-06-30	Rucula - 452	2026-06-30 14:12:41+00	2026-07-01 14:21:39.706648+00
42501e2c-5f54-4b6e-b555-ed181ca0d5ed	56eb204d-9859-4fec-a799-7a38ee21626b	2730fa75-fe67-442c-a43a-5c4c645e9a72	COMPRA	64800.00	2026-06-30	Asian - 27	2026-06-30 14:13:34+00	2026-07-01 14:22:44.937924+00
172cd1ac-a530-42f8-ad7c-b62f9e65c0ee	56eb204d-9859-4fec-a799-7a38ee21626b	64fea813-ac79-48b4-92a2-a6b08d53b8a5	COMPRA	6000.00	2026-06-30	Albahaca - 4	2026-06-30 14:14:27+00	2026-07-01 14:23:43.148846+00
77830fda-dcaf-450a-8361-cba8efd22e33	36b55efb-e01d-49ee-9259-87c36318d581	422a53ab-b2b0-48e6-adaf-151bf0890ab6	GASTO	50000.00	2026-07-21	Acido nitrico	2026-07-23 05:42:48.634784+00	2026-07-23 05:42:48.634784+00
0f16ad90-d250-4a13-beae-02918ccffb2d	36b55efb-e01d-49ee-9259-87c36318d581	cd5b81ef-d03c-4756-93f8-1f8423da80ea	GASTO	22617.48	2026-06-24	Bolsa pp y bolsa camiseta x 5	2026-06-26 15:55:37.219814+00	2026-06-30 23:27:30.610857+00
1dcfa50b-3338-45f4-b3d7-88361c7c95f5	56eb204d-9859-4fec-a799-7a38ee21626b	2621807f-8dc7-4a42-a2f9-6b4d36961bba	GASTO	20000.00	2026-06-12	Apoyo interno	2026-06-30 12:43:25.213773+00	2026-06-30 23:27:30.610857+00
baa6c125-cb62-43b1-9fe8-1c6acd628d56	36b55efb-e01d-49ee-9259-87c36318d581	2d5e1cb7-772d-43df-96bf-9cce68d74439	GASTO	4500.00	2026-06-11	Cloro x 5 lts	2026-06-26 15:54:13.094261+00	2026-06-30 23:27:30.610857+00
216376b6-b1e4-4052-b532-789d0cb58f39	36b55efb-e01d-49ee-9259-87c36318d581	cd5b81ef-d03c-4756-93f8-1f8423da80ea	GASTO	39900.00	2026-06-11	Bolsas camisetas, bandas elasticas, form presupuesto	2026-06-26 15:53:10.527139+00	2026-06-30 23:27:30.610857+00
2e869684-2432-41a0-a8de-2250199bd0a4	56eb204d-9859-4fec-a799-7a38ee21626b	2621807f-8dc7-4a42-a2f9-6b4d36961bba	GASTO	20000.00	2026-06-06	Apoyo interno	2026-06-30 12:44:18.821148+00	2026-06-30 23:27:30.610857+00
65617666-1bce-41a8-9191-f1f9b8264d3d	56eb204d-9859-4fec-a799-7a38ee21626b	5c16fe64-103a-4416-a756-82d82600a0b8	GASTO	97057.65	2026-07-16	VTV Camioneta	2026-07-28 13:11:39.86428+00	2026-07-28 13:11:39.86428+00
2eb165e7-4820-4218-9d6b-20846bae1633	56eb204d-9859-4fec-a799-7a38ee21626b	cd5b81ef-d03c-4756-93f8-1f8423da80ea	GASTO	31400.00	2026-07-25	Bolsas camisetas, bandas elasticas	2026-07-28 13:13:39.740578+00	2026-07-28 13:13:39.740578+00
fb074af0-9489-4c48-bd27-249169b4ec5d	56eb204d-9859-4fec-a799-7a38ee21626b	4caee9dd-3901-4324-8415-feafc893b8f6	GASTO	90000.00	2026-07-12	Electricidad	2026-07-28 13:16:47.700067+00	2026-07-29 02:19:17.483766+00
63d6bca1-5b47-4a36-85f2-bae6c56a1016	56eb204d-9859-4fec-a799-7a38ee21626b	65480fa1-acf4-498d-8085-b48fe1ba05fb	GASTO	108450.00	2026-07-20	Nafta camioneta	2026-07-28 13:15:59.892109+00	2026-07-29 02:20:52.946794+00
ed9ac0f3-4053-43ef-a7c6-8e1fb4fa1406	56eb204d-9859-4fec-a799-7a38ee21626b	64fea813-ac79-48b4-92a2-a6b08d53b8a5	COMPRA	315937.00	2026-07-28	Compra de plantas del mes	2026-07-28 19:56:49.338334+00	2026-07-29 02:22:23.872906+00
34150dd6-8189-437a-a6e1-80b08370ed8c	56eb204d-9859-4fec-a799-7a38ee21626b	cd5b81ef-d03c-4756-93f8-1f8423da80ea	GASTO	15000.00	2026-07-01	Factura pendiente de Junio . Bolsas pp	2026-07-29 16:39:20.866107+00	2026-07-29 16:39:20.866107+00
5f906378-457c-4d2d-8ce7-c272f6e19e63	56eb204d-9859-4fec-a799-7a38ee21626b	64fea813-ac79-48b4-92a2-a6b08d53b8a5	COMPRA	211350.00	2026-07-30	Compra de plantas para reventa	2026-07-30 16:13:33.999016+00	2026-07-30 16:13:33.999016+00
9f23e992-08ea-4abe-a590-7362c513145a	56eb204d-9859-4fec-a799-7a38ee21626b	64fea813-ac79-48b4-92a2-a6b08d53b8a5	COMPRA	144400.00	2026-07-30	Plantas para reventa	2026-07-30 18:11:46.538167+00	2026-07-30 18:11:46.538167+00
838bf1ba-135e-429a-a496-57ccbd897e57	56eb204d-9859-4fec-a799-7a38ee21626b	2730fa75-fe67-442c-a43a-5c4c645e9a72	COMPRA	52000.00	2026-07-31	Caja placa fenolica para hidroponia	2026-07-31 21:03:51.364527+00	2026-07-31 21:03:51.364527+00
\.


--
-- Data for Name: mvp_movimientos_caja; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_movimientos_caja (id, caja_id, monto, fecha, tipo_referencia, referencia_id, created_at, updated_at, operacion_id) FROM stdin;
80d91e4f-103e-4182-9733-e87faea79f0a	f2016a87-e798-4e74-a11b-43a2679dc5b6	-50000.00	2026-06-30 12:26:45.829535	EGRESO	45b1af66-f64b-4ce2-b488-3201d72ae06d	2026-06-30 12:26:45.829535+00	2026-06-30 12:26:45.829535+00	748bc60d-1bb9-49a3-bb9d-6aa9ac15643e
14eb6feb-b9f6-40e9-afeb-b0fc066f0ccc	300b4667-734d-45e0-a92a-a78737f75eb8	-20000.00	2026-06-30 12:44:18.914982	EGRESO	2e869684-2432-41a0-a8de-2250199bd0a4	2026-06-30 12:44:18.914982+00	2026-06-30 12:44:18.914982+00	604b3faa-13a4-41ab-8d3d-4975cdb01d6c
fdc24f52-7d56-4530-87e2-38a6ef07d70e	300b4667-734d-45e0-a92a-a78737f75eb8	103500.00	2026-06-26 03:00:00	VENTA	88099e84-762a-47a7-90c0-bdce1a66b9f7	2026-06-30 13:11:45.932917+00	2026-06-30 13:11:45.932917+00	9528f35c-dfd3-4260-9abb-22b88313665d
c5ff03cd-622a-4a81-92d8-4059d74e22af	f2016a87-e798-4e74-a11b-43a2679dc5b6	10500.00	2026-06-26 03:00:00	VENTA	7101d972-7b99-417b-8e7d-55dbaff920c9	2026-06-30 13:17:17.975895+00	2026-06-30 13:17:17.975895+00	8fb54c2f-f50f-4042-9a01-d0199ea95b57
963a38c6-a2d9-4fa1-bc24-2fc1a5a6a944	f2016a87-e798-4e74-a11b-43a2679dc5b6	57000.00	2026-06-26 03:00:00	VENTA	8ea0dce0-24cc-4b24-a0c8-118b0db24736	2026-06-30 13:26:44.362654+00	2026-06-30 13:26:44.362654+00	0b3b7538-4102-4a93-9247-c093904bcec4
cb034a7e-7ca8-450d-9ecc-a53821aa4e27	f2016a87-e798-4e74-a11b-43a2679dc5b6	55000.00	2026-06-29 03:00:00	VENTA	a01e692c-973e-455b-ad10-7e5774ffa206	2026-06-30 14:09:52.622324+00	2026-06-30 14:09:52.622324+00	f67b3db7-3ebc-45e6-ae32-0e2d401f161c
82bd3e47-5ea9-40a0-9a44-b1dff3054bb5	300b4667-734d-45e0-a92a-a78737f75eb8	25200.00	2026-06-06 03:00:00	VENTA	1689ef65-5132-4c7f-a938-0c98bfa683c0	2026-06-30 14:55:40.575433+00	2026-06-30 14:55:40.575433+00	c47ddd3b-8e51-44bb-8f19-7cd49dfc9646
90a03d0b-afef-4d47-a404-b3d16b70f20c	300b4667-734d-45e0-a92a-a78737f75eb8	-469700.00	2026-06-30 14:12:41.868581	EGRESO	17cd798f-5dfc-45db-8f56-7c1c61cdb1e0	2026-07-01 14:12:41.868581+00	2026-07-02 16:03:41.065271+00	69621422-2681-4606-ab2f-ba6f96f8f64f
a0502ffa-d683-409f-abf4-ca404106be84	f2016a87-e798-4e74-a11b-43a2679dc5b6	17000.00	2026-07-01 03:00:00	VENTA	97126300-4dbc-46a2-aa0b-4efa71d764b4	2026-07-09 12:30:59.263762+00	2026-07-09 12:30:59.263762+00	5cc5b701-31c8-4221-9021-270ddab0312c
44b3174e-5d20-4701-81db-66ed6e30051c	300b4667-734d-45e0-a92a-a78737f75eb8	156000.00	2026-07-02 03:00:00	VENTA	1cc32153-fd17-4e31-a7fb-8a3d622781c5	2026-07-09 12:36:25.96423+00	2026-07-09 12:36:25.96423+00	8ae13712-7e67-4dc7-8fac-eb02f8c6d86d
366e5414-6374-4a83-93e7-72cb29407703	f2016a87-e798-4e74-a11b-43a2679dc5b6	36500.00	2026-07-03 03:00:00	VENTA	2797cc16-57c2-4b55-81a0-f5a23bac2f28	2026-07-09 12:39:14.952396+00	2026-07-09 12:39:14.952396+00	c5593964-c83e-48c8-ad30-ca48e7b86a3c
3f4cea39-dc2a-4d4b-85f0-53afb2e48f82	f2016a87-e798-4e74-a11b-43a2679dc5b6	-958782.52	2026-06-30 23:59:59	CIERRE	72387cb4-9799-430b-b1aa-c5d908faeab3	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	72387cb4-9799-430b-b1aa-c5d908faeab3
6e2224cf-f6ea-4374-b24d-16ebd672ae25	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	958782.52	2026-06-30 23:59:59	CIERRE	72387cb4-9799-430b-b1aa-c5d908faeab3	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	72387cb4-9799-430b-b1aa-c5d908faeab3
2569da3e-8f9e-45ae-887e-07736e810b56	300b4667-734d-45e0-a92a-a78737f75eb8	-2064494.00	2026-06-30 23:59:59	CIERRE	723b5366-0ff4-43bb-8f26-89605e1e39f3	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	723b5366-0ff4-43bb-8f26-89605e1e39f3
ddabeb77-6578-4708-b026-0876eada8d1f	d9746a8e-262d-4359-9589-6f232f5d9e0f	100000.00	2026-06-18 22:30:11.426226	VENTA	fb5a8110-a2be-4037-aa7f-c7289c8f83f1	2026-06-18 22:30:11.426226+00	2026-06-18 22:30:11.426226+00	3191f7fb-568d-4131-b16c-6c29d5075935
dcbca21c-72fb-4f9c-b5d9-01a5ab55bc7f	d9746a8e-262d-4359-9589-6f232f5d9e0f	29600.00	2026-06-18 22:30:24.203827	VENTA	f72ebf0e-a320-4e85-ab95-e363c4e9449b	2026-06-18 22:30:24.203827+00	2026-06-18 22:30:24.203827+00	5dcb48c2-3d3a-4b69-9cc8-d0e82a61572b
8d8cb8bd-1113-4013-9d39-d65fc2a759dd	d9746a8e-262d-4359-9589-6f232f5d9e0f	46500.00	2026-06-18 22:30:33.991201	VENTA	195ae60e-73b7-41e5-ac13-6c11ae9b6c38	2026-06-18 22:30:33.991201+00	2026-06-18 22:30:33.991201+00	4fa9752b-348c-4232-bcc2-6c6b90588110
b44b6e62-46cd-4a25-b4dd-92857a3fe3a8	d9746a8e-262d-4359-9589-6f232f5d9e0f	-176100.00	2026-06-18 22:31:00.931682	TRANSFERENCIA	b7fe1661-b4a5-4a4d-806a-56c136ed5f49	2026-06-18 22:31:00.931682+00	2026-06-18 22:31:00.931682+00	b7fe1661-b4a5-4a4d-806a-56c136ed5f49
d54286d1-230b-4399-8dd5-967b9d8398f9	f2016a87-e798-4e74-a11b-43a2679dc5b6	176100.00	2026-06-18 22:31:00.931682	TRANSFERENCIA	b7fe1661-b4a5-4a4d-806a-56c136ed5f49	2026-06-18 22:31:00.931682+00	2026-06-18 22:31:00.931682+00	b7fe1661-b4a5-4a4d-806a-56c136ed5f49
7abe546a-6b20-4fbb-8ae2-9749067ff5b4	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	2064494.00	2026-06-30 23:59:59	CIERRE	723b5366-0ff4-43bb-8f26-89605e1e39f3	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	723b5366-0ff4-43bb-8f26-89605e1e39f3
0c517bff-ecff-4d28-ab47-b26dc14e4e2d	300b4667-734d-45e0-a92a-a78737f75eb8	-15000.00	2026-07-29 16:39:21.001716	EGRESO	34150dd6-8189-437a-a6e1-80b08370ed8c	2026-07-29 16:39:21.001716+00	2026-07-29 16:39:21.001716+00	417dc165-9fe9-4e35-bc15-4f1d22683354
01f93d47-92d8-4c18-a512-3d616c619f6c	300b4667-734d-45e0-a92a-a78737f75eb8	76000.00	2026-06-03 03:00:00	VENTA	49d70853-4652-454b-9419-822b7caeede1	2026-06-19 04:30:53.285777+00	2026-06-22 14:24:00.313966+00	fef55013-c767-44f1-81e9-6fcd5c4fadb6
28a3b149-1045-4f91-8eaa-7d8e590219e0	f2016a87-e798-4e74-a11b-43a2679dc5b6	17000.00	2026-06-03 03:00:00	VENTA	f804bca9-18b7-4105-8129-7b8f63e9ca9e	2026-06-19 04:32:51.146645+00	2026-06-22 14:24:00.313966+00	6722efbf-d4df-42a8-9c8c-d3e46e9b921b
707fc319-39e8-4e3f-a869-8235f4e7fbea	f2016a87-e798-4e74-a11b-43a2679dc5b6	21200.00	2026-06-03 03:00:00	VENTA	007b8f1d-a423-4ba5-8dd3-b5e724da3180	2026-06-19 04:35:52.075925+00	2026-06-22 14:24:00.313966+00	d8e0b4e0-8452-436b-9fab-d364c3b5aeb0
d593abff-2bc1-434d-987b-996b3e967efd	f2016a87-e798-4e74-a11b-43a2679dc5b6	25500.00	2026-06-03 03:00:00	VENTA	8b780d2c-5189-4172-803a-1632b72c2890	2026-06-19 04:37:06.603739+00	2026-06-22 14:24:00.313966+00	87a2c4cd-5518-4f72-800d-249613d24bce
b7d7390e-fe40-4007-856b-c5a720c723c0	300b4667-734d-45e0-a92a-a78737f75eb8	165500.00	2026-06-04 03:00:00	VENTA	493b3c7e-029c-4fc1-a8a4-f690dcf0401c	2026-06-19 04:40:42.01634+00	2026-06-22 14:24:00.313966+00	080776e2-5d72-4825-8c3f-dd57416f41e7
a408481f-37c0-4362-9c6a-c8b82a19b1d8	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	-1000000.00	2026-07-14 07:48:45.300016	RETIRO	ea62e998-c467-49b5-ad79-d169ee6cda41	2026-07-14 07:48:45.300016+00	2026-07-14 07:48:45.300016+00	ea62e998-c467-49b5-ad79-d169ee6cda41
b8c8779f-03a5-448e-a631-f2bc6ed09fdf	300b4667-734d-45e0-a92a-a78737f75eb8	163600.00	2026-06-04 03:00:00	VENTA	d185c422-7924-4918-9cac-f536a7d6783e	2026-06-22 11:54:06.796917+00	2026-06-22 14:24:00.313966+00	f8032098-ad1d-4308-8020-c3f41e1749ff
6ad46c08-8e32-4e9f-aebe-9d664a02c309	300b4667-734d-45e0-a92a-a78737f75eb8	98000.00	2026-06-04 03:00:00	VENTA	dd4bacb2-b66e-4684-afce-ef3607a88f64	2026-06-22 11:57:11.861703+00	2026-06-22 14:24:00.313966+00	54ce5480-86b9-4fdc-873f-d06afa700d56
caebd855-2ca0-48b7-bad6-511c42537ee9	300b4667-734d-45e0-a92a-a78737f75eb8	50000.00	2026-06-05 03:00:00	VENTA	b2287a3d-ce8f-4d2f-bad4-bbe12e58de8c	2026-06-22 12:00:02.169845+00	2026-06-22 14:24:00.313966+00	b6878022-4c6a-4e32-8b11-25f2b89002d2
bf7a8110-a185-4fc8-9029-ee94000e6f66	f2016a87-e798-4e74-a11b-43a2679dc5b6	49000.00	2026-06-05 03:00:00	VENTA	1c577f66-ef47-48b0-a8a6-50126d1183f5	2026-06-22 12:02:31.448238+00	2026-06-22 14:24:00.313966+00	2f7b081e-16f7-43f9-b2ac-b59415df6f7e
17cbbd89-2c56-4971-97fc-820d3a5ef576	f2016a87-e798-4e74-a11b-43a2679dc5b6	69000.00	2026-06-05 03:00:00	VENTA	a13ffb73-62e3-4499-8370-975121e99ba6	2026-06-22 12:04:09.667167+00	2026-06-22 14:24:00.313966+00	4832ece6-8fce-40de-b978-2169d0d7bf9f
05ada71e-2e2f-4108-8227-c40e0daf77ec	300b4667-734d-45e0-a92a-a78737f75eb8	-20000.00	2026-07-23 15:00:00	TRANSFERENCIA	b4678879-776d-4b1b-94d6-7c224dfb94e1	2026-07-30 04:06:15.654521+00	2026-07-30 04:06:15.654521+00	b4678879-776d-4b1b-94d6-7c224dfb94e1
aae601e0-8446-4fc9-a720-0d3fe7a52640	300b4667-734d-45e0-a92a-a78737f75eb8	81500.00	2026-07-06 03:00:00	VENTA	883b349b-cc83-4bd3-9b03-9e9441dcc35d	2026-07-19 17:21:57.88095+00	2026-07-19 17:21:57.88095+00	2d83904c-3869-4e1e-a675-e2880422f00d
b5640a62-75b5-4860-9dca-650b26b23c52	f2016a87-e798-4e74-a11b-43a2679dc5b6	17000.00	2026-07-08 03:00:00	VENTA	3e36ab98-2292-47f2-9790-ff9c61179100	2026-07-19 17:25:53.385734+00	2026-07-19 17:25:53.385734+00	8f09741b-eaa8-45e4-bd0c-06be6f7a410d
25ec24ea-f64b-4cfa-963b-57bef92b8a5a	300b4667-734d-45e0-a92a-a78737f75eb8	124500.00	2026-07-09 03:00:00	VENTA	84fe840f-c94b-4e45-9ed1-a5735aca0f7c	2026-07-19 17:29:59.858871+00	2026-07-19 17:29:59.858871+00	2ca1f1b0-97f9-45ad-8f05-1e001298f3f3
85d457de-6f6a-4739-af24-7b25dd4dc144	f2016a87-e798-4e74-a11b-43a2679dc5b6	23300.00	2026-06-05 03:00:00	VENTA	a2838726-29d8-4fe7-9497-cfa20da0892c	2026-06-22 12:10:12.197307+00	2026-06-22 14:24:00.313966+00	d4aed9a7-31d3-4945-84a1-39f1dc35600a
f60ac079-3f24-4b94-9333-19bd1dd9db5b	300b4667-734d-45e0-a92a-a78737f75eb8	36500.00	2026-06-05 03:00:00	VENTA	c41cc71e-5a93-473d-8017-968b9bc8323d	2026-06-22 12:11:15.291194+00	2026-06-22 14:24:00.313966+00	7037c5fc-9a78-46c3-857f-3f2c75b2d7a6
4f4e06f9-c929-420e-9928-4f66847f8e03	f2016a87-e798-4e74-a11b-43a2679dc5b6	20000.00	2026-06-05 03:00:00	VENTA	317b6891-99dc-49a5-9baa-cc5f36ae0fa5	2026-06-22 12:12:53.106907+00	2026-06-22 14:24:00.313966+00	c4fea509-2d18-4bac-bf9d-18cfa6d4823a
419dc4f3-ee85-40a0-9244-3a3728e4f2de	300b4667-734d-45e0-a92a-a78737f75eb8	76000.00	2026-06-06 03:00:00	VENTA	63ffd0fa-c1c0-41e6-a588-1c160c756217	2026-06-22 12:14:23.830753+00	2026-06-22 14:24:00.313966+00	b2959fd6-ab7d-42fa-b798-2724de78b24a
a8c44af4-4371-4a77-80ac-8121d127b064	300b4667-734d-45e0-a92a-a78737f75eb8	44000.00	2026-07-10 03:00:00	VENTA	b849d43d-e4a6-4aed-862c-e35460fbdecb	2026-07-19 17:33:49.948156+00	2026-07-19 17:33:49.948156+00	2db8fd70-d4ff-4cf8-a6d7-ad8e91f46127
8f789dba-8ba3-4bab-a342-55ecbdb4a0d5	f2016a87-e798-4e74-a11b-43a2679dc5b6	68000.00	2026-06-08 03:00:00	VENTA	4c4bc996-3a72-4f73-9918-5e261c79d0eb	2026-06-22 12:17:08.469447+00	2026-06-22 14:24:00.313966+00	c18eefeb-2e4e-4098-81b7-22fe3f61eefb
a096f399-3194-4ce6-8bc4-99bf7129be89	f2016a87-e798-4e74-a11b-43a2679dc5b6	47500.00	2026-07-13 03:00:00	VENTA	0cc8cee0-3a1b-4fd4-910b-aceb1ee24267	2026-07-19 17:36:24.698842+00	2026-07-19 17:36:24.698842+00	79c4bdda-3dd1-4201-93dd-b42cb102ad22
24414655-3a20-4418-942a-1531a38061af	300b4667-734d-45e0-a92a-a78737f75eb8	91200.00	2026-07-15 03:00:00	VENTA	62438726-116a-4fa4-88a9-cb3171a0fb23	2026-07-19 17:41:29.956024+00	2026-07-19 17:41:29.956024+00	af25c185-fd20-42ba-b14d-90bf4faf4005
ef83ec87-99d4-43f4-a249-91752d911d53	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	-1288179.51	2026-07-21 18:59:37.320904	RETIRO	46fce66a-5f08-43ec-9646-b8fb3dbcb599	2026-07-21 18:59:37.320904+00	2026-07-21 18:59:37.320904+00	46fce66a-5f08-43ec-9646-b8fb3dbcb599
e9875159-80dc-4e8d-9b90-06aeee949547	f2016a87-e798-4e74-a11b-43a2679dc5b6	28000.00	2026-07-29 03:00:00	VENTA	b5562eec-d4d4-4351-a218-040d00f6f48e	2026-07-30 15:53:09.315009+00	2026-07-30 15:53:09.315009+00	9a14921a-94aa-4458-aec8-efe4289110c6
b10613bb-de6e-4277-b0e1-8951150490f1	300b4667-734d-45e0-a92a-a78737f75eb8	-15000.00	2026-06-30 12:49:13.162251	TRANSFERENCIA	fc8fb835-ef74-4b10-9864-6350baba9fc9	2026-06-30 12:49:13.162251+00	2026-06-30 12:49:13.162251+00	fc8fb835-ef74-4b10-9864-6350baba9fc9
26ea84cf-cffc-4c4c-b927-d5cf3f502e27	f2016a87-e798-4e74-a11b-43a2679dc5b6	15000.00	2026-06-30 12:49:13.162251	TRANSFERENCIA	fc8fb835-ef74-4b10-9864-6350baba9fc9	2026-06-30 12:49:13.162251+00	2026-06-30 12:49:13.162251+00	fc8fb835-ef74-4b10-9864-6350baba9fc9
31f4b674-69d4-438d-8453-cb719447476f	300b4667-734d-45e0-a92a-a78737f75eb8	75500.00	2026-06-26 03:00:00	VENTA	7b33a6b7-ab46-4d21-9684-4c3fe05a1a55	2026-06-30 13:13:11.487218+00	2026-06-30 13:13:11.487218+00	6e510b80-02bb-4ac6-8534-bf188d81cf63
4d628221-537b-454c-bd29-c96d83aeec62	300b4667-734d-45e0-a92a-a78737f75eb8	90500.00	2026-06-23 03:00:00	VENTA	7ce777ee-51e0-4863-a637-8ca5aa89d05c	2026-06-30 13:19:35.252977+00	2026-06-30 13:19:35.252977+00	a9382fd3-203f-40f7-9703-e9fcc555e01f
b852908d-4882-48bc-bb87-4449f1533263	f2016a87-e798-4e74-a11b-43a2679dc5b6	48500.00	2026-06-08 03:00:00	VENTA	84a3d414-e734-4364-89ea-02ff7a53bf90	2026-06-22 12:17:58.263968+00	2026-06-22 14:24:00.313966+00	0b15d928-f703-4118-8fe4-3d2ffb1c1e1d
ad02985a-4782-4c13-8594-10b858f1a701	f2016a87-e798-4e74-a11b-43a2679dc5b6	25400.00	2026-06-08 03:00:00	VENTA	87cc40f2-9e57-414e-9ef6-b784691c2759	2026-06-22 12:18:47.312853+00	2026-06-22 14:24:00.313966+00	52497025-847d-4a1f-bf1f-6212bc2981e8
5ecde398-d40b-49d5-a81b-f7775b95c5e0	300b4667-734d-45e0-a92a-a78737f75eb8	112000.00	2026-06-08 03:00:00	VENTA	571ca198-ca4f-40c3-8254-e813922b76d9	2026-06-22 12:20:17.988002+00	2026-06-22 14:24:00.313966+00	87a67e6f-ef47-482c-9b6d-bb6325c58dd3
078b6f76-4101-43c9-94e4-da8e40ba4cc4	f2016a87-e798-4e74-a11b-43a2679dc5b6	27500.00	2026-06-10 03:00:00	VENTA	17f303ca-9003-4aec-a554-60e68579c17e	2026-06-22 12:21:10.20233+00	2026-06-22 14:24:00.313966+00	e7c220ab-1903-4b2c-84e9-4010db3be2b8
e2fe7349-fab8-4cf8-ac83-dbf1b780bd00	f2016a87-e798-4e74-a11b-43a2679dc5b6	17000.00	2026-06-10 03:00:00	VENTA	b48fe808-7668-4d53-ba45-9efcac9ab9e6	2026-06-22 12:21:52.374101+00	2026-06-22 14:24:00.313966+00	ea032237-ec7f-4561-92d1-9220ebe2250f
f36ece0f-d116-4896-b47c-bdbe18b5bd87	300b4667-734d-45e0-a92a-a78737f75eb8	70500.00	2026-06-10 03:00:00	VENTA	8f108d53-a2fe-4205-87a9-2d3b39034110	2026-06-22 12:23:24.963704+00	2026-06-22 14:24:00.313966+00	bfdaa095-8845-4555-8511-461b43f16673
82e5481d-0991-4eb7-b2c4-479802c1363a	300b4667-734d-45e0-a92a-a78737f75eb8	24100.00	2026-06-12 03:00:00	VENTA	dc5e9eac-3542-4690-b0ae-03f43c81252f	2026-06-22 12:24:43.332879+00	2026-06-22 14:24:00.313966+00	93da5b67-7615-44a4-8976-4249f483ddb4
87b03ced-bb72-4f46-9756-bed925c680ec	300b4667-734d-45e0-a92a-a78737f75eb8	73100.00	2026-06-12 03:00:00	VENTA	d5845dc2-f1d0-42bb-b87b-d6d09f044431	2026-06-22 12:25:39.465747+00	2026-06-22 14:24:00.313966+00	3a7b14fb-7a5e-4381-8ce1-d526bfac8c0a
be1472a0-77e9-41c0-ad9a-1e3336d73201	300b4667-734d-45e0-a92a-a78737f75eb8	82500.00	2026-06-12 03:00:00	VENTA	f70adcf3-d2d2-4b8d-804c-68610ed560a8	2026-06-22 12:26:53.23068+00	2026-06-22 14:24:00.313966+00	4d538fe2-bf28-4e52-b2af-cfb05b6f3537
c8047e96-192d-4dd5-bf82-17adc2254f58	300b4667-734d-45e0-a92a-a78737f75eb8	78500.00	2026-06-12 03:00:00	VENTA	36c8bd18-7284-42ca-889b-63d87b15a78f	2026-06-22 12:29:02.877621+00	2026-06-22 14:24:00.313966+00	60a73379-23c0-4494-87d8-89e5e4a8021a
59d370f6-793e-4d87-bbf8-96eab8bd61b9	f2016a87-e798-4e74-a11b-43a2679dc5b6	65500.00	2026-06-10 03:00:00	VENTA	10494094-7a23-4270-966e-9c1d02e62d65	2026-06-22 12:31:25.167271+00	2026-06-22 14:24:00.313966+00	e7501a63-ca24-4b49-9870-12ef349783d8
119afad1-6848-41ad-90df-df71ca447221	300b4667-734d-45e0-a92a-a78737f75eb8	183000.00	2026-06-11 03:00:00	VENTA	ca2a904a-e22b-4709-a314-ceeeb8f3691d	2026-06-22 12:32:54.63034+00	2026-06-22 14:24:00.313966+00	c1d93875-771a-4c17-ac8f-626d0cfbcef5
2949cf29-3759-4b4f-b8f0-82a5c0cd851f	300b4667-734d-45e0-a92a-a78737f75eb8	33800.00	2026-06-15 03:00:00	VENTA	3bd0e3bc-c051-48ba-b3e3-c57736a5290c	2026-06-22 12:39:26.043965+00	2026-06-22 14:24:00.313966+00	87a6db66-ab2a-417b-bba3-34477f15b3de
e9a9dfef-646e-4424-ad78-5e2d15b41037	300b4667-734d-45e0-a92a-a78737f75eb8	40500.00	2026-06-15 03:00:00	VENTA	6f5e9a40-d0c7-442e-9c11-037e36f21670	2026-06-22 12:40:34.294196+00	2026-06-22 14:24:00.313966+00	ede82d5d-10c3-48a8-8268-e316f4c7c559
24bc0cef-3c7e-4d59-a6c0-bcf4b357061f	300b4667-734d-45e0-a92a-a78737f75eb8	56100.00	2026-06-15 03:00:00	VENTA	58d6bfbd-c188-4362-bf46-8d0c4ff215b5	2026-06-22 12:41:34.798974+00	2026-06-22 14:24:00.313966+00	be17aaa5-689a-49d6-a601-4c39cde84b25
78eb44c9-6cb2-42f1-9b66-645f57c8b485	f2016a87-e798-4e74-a11b-43a2679dc5b6	25500.00	2026-06-16 03:00:00	VENTA	697218c2-76c0-447e-a4fc-b8353ecde81b	2026-06-22 12:42:30.909684+00	2026-06-22 14:24:00.313966+00	8c5bf80a-aeff-4671-a9f9-46d699c8a738
c86e66c9-8dee-4cc8-ae17-e3c053215225	f2016a87-e798-4e74-a11b-43a2679dc5b6	27500.00	2026-06-16 03:00:00	VENTA	fe84c328-e264-4abc-9f2f-400f209afefa	2026-06-22 12:45:47.551971+00	2026-06-22 14:24:00.313966+00	d935f23e-51e9-4992-8363-e2ef0ccf2fce
374c1138-3aad-40da-bef8-f788d321da7e	f2016a87-e798-4e74-a11b-43a2679dc5b6	17000.00	2026-06-17 03:00:00	VENTA	fa937de3-7822-4d7b-8e23-ded1426a2085	2026-06-22 12:48:15.680194+00	2026-06-22 14:24:00.313966+00	df33b3a5-a244-4dac-83cd-f61b48020fba
15a6b141-d851-4000-9a59-700c760fa183	300b4667-734d-45e0-a92a-a78737f75eb8	76000.00	2026-06-17 03:00:00	VENTA	b72244b1-977d-423e-b863-60fbe7d62bd7	2026-06-22 12:50:57.21166+00	2026-06-22 14:24:00.313966+00	00b5f933-2ed2-4504-92fa-89f29c171036
4ac08d3e-6fa8-4d4b-b81e-cca64b40d4ea	300b4667-734d-45e0-a92a-a78737f75eb8	177000.00	2026-06-18 03:00:00	VENTA	f34fa3a5-b67c-422d-8d88-ab734ac2a312	2026-06-22 12:54:13.012093+00	2026-06-22 14:24:00.313966+00	da710c5f-5fa2-4fd2-9d4f-b0b90094dc03
df934244-2318-44f1-81e5-a56d99621bb5	300b4667-734d-45e0-a92a-a78737f75eb8	111300.00	2026-06-18 03:00:00	VENTA	01742e1e-8dee-458b-b22c-6b140b5c0dea	2026-06-22 12:55:18.84808+00	2026-06-22 14:24:00.313966+00	ac346a5a-f79d-4bdf-9ab1-c33ae103cccd
486048c0-00cd-4146-b5fc-8944659994da	300b4667-734d-45e0-a92a-a78737f75eb8	10000.00	2026-06-18 03:00:00	VENTA	44191426-9626-4ef9-afc9-72dc89f1a732	2026-06-22 12:56:12.750673+00	2026-06-22 14:24:00.313966+00	61e318ad-6c54-44a5-a431-39396870caf7
287deeb0-72e3-4431-a894-26cfd8ae35d9	300b4667-734d-45e0-a92a-a78737f75eb8	133500.00	2026-06-30 03:00:00	VENTA	2f62512f-ccc3-45ee-a0f3-227ac57c4a3a	2026-06-30 14:02:42.949324+00	2026-06-30 14:02:42.949324+00	55057975-723c-4ce4-9214-d497fab8448c
c4ff6a23-e62d-4fca-a08f-3b623cf253a8	f2016a87-e798-4e74-a11b-43a2679dc5b6	36000.00	2026-06-29 03:00:00	VENTA	9be7c326-9a4c-4521-8700-a23113923bb4	2026-06-30 14:11:44.67418+00	2026-06-30 14:11:44.67418+00	59f15734-8aed-437c-8947-f0b126d4871e
9f9e4aef-325b-47b6-af93-fe88ce909c5a	300b4667-734d-45e0-a92a-a78737f75eb8	91750.00	2026-06-30 15:23:41.095773	VENTA	38367469-d996-4215-90ab-4bb78dd8f923	2026-06-30 15:23:41.095773+00	2026-06-30 15:23:41.095773+00	16b6f122-7cd8-46e7-8ac3-952b88e5a55d
049cdadd-da28-4be8-9528-a9b1bdc68434	300b4667-734d-45e0-a92a-a78737f75eb8	-64800.00	2026-06-30 14:13:35.068271	EGRESO	42501e2c-5f54-4b6e-b555-ed181ca0d5ed	2026-07-01 14:13:35.068271+00	2026-07-02 16:03:41.065271+00	52059cd5-f19a-4912-85d8-50762ab8ced9
c700ceca-4dee-4d0f-a7a5-b8b8d37a9163	f2016a87-e798-4e74-a11b-43a2679dc5b6	23600.00	2026-07-01 03:00:00	VENTA	cf500b07-7e2e-40ca-a145-d4daba247fd9	2026-07-09 12:32:51.128143+00	2026-07-09 12:32:51.128143+00	6ccb3301-8415-4501-93d2-35c736cee738
8596c9d5-886d-4be9-a0d4-9695c15cbfee	f2016a87-e798-4e74-a11b-43a2679dc5b6	56000.00	2026-07-03 03:00:00	VENTA	9d41438f-6faa-433b-8edf-cc25aef71047	2026-07-09 12:37:30.674931+00	2026-07-09 12:37:30.674931+00	d6c377ef-2b75-4eb7-ab48-0e2eb0bf800b
8c97a814-4466-4958-afa8-e6b249cfcbc4	300b4667-734d-45e0-a92a-a78737f75eb8	39000.00	2026-07-03 03:00:00	VENTA	7be3f424-d803-4b7e-b896-658e6587f835	2026-07-09 12:41:10.526569+00	2026-07-09 12:41:10.526569+00	b21ba1da-efd9-4aac-9bba-6daa63667b70
245e7618-cb73-4165-81e0-9dfdb813be76	f2016a87-e798-4e74-a11b-43a2679dc5b6	36500.00	2026-07-06 03:00:00	VENTA	c71f7468-f8c8-4cbc-bf4b-67916f9760e5	2026-07-19 17:18:58.639425+00	2026-07-19 17:18:58.639425+00	dc76a433-cfff-4939-9498-4b53a43b3e91
f6bb8e1b-602c-4207-bd7d-b0387748c482	300b4667-734d-45e0-a92a-a78737f75eb8	28000.00	2026-07-06 03:00:00	VENTA	7d61e654-10c5-4bda-832f-6859d7fb1dd0	2026-07-19 17:24:11.542056+00	2026-07-19 17:24:11.542056+00	ab72274d-1b5c-4fa1-a9d9-51e6523a7eaa
b583fb38-348c-4690-86ba-946bc3b33854	f2016a87-e798-4e74-a11b-43a2679dc5b6	74600.00	2026-07-08 03:00:00	VENTA	74378a5e-1e3c-4c91-b488-b5051ecf8516	2026-07-19 17:27:15.287088+00	2026-07-19 17:27:15.287088+00	11c2a2d8-52c1-480b-b117-8c572b594951
a3cee0e8-e43d-4542-9b8f-14b5f8b8510a	300b4667-734d-45e0-a92a-a78737f75eb8	38000.00	2026-07-09 03:00:00	VENTA	03848e89-39a7-43cd-8b6a-c943171b2dbb	2026-07-19 17:31:09.207138+00	2026-07-19 17:31:09.207138+00	e5e8480a-cc59-4acd-83c5-34fb49e89daf
ffbe9a3c-a74d-45c0-a0c2-e9a09f754d1f	f2016a87-e798-4e74-a11b-43a2679dc5b6	83100.00	2026-07-10 03:00:00	VENTA	779708ab-5557-4792-8875-5a24dfa8cfc2	2026-07-19 17:34:54.710093+00	2026-07-19 17:34:54.710093+00	65e89743-229a-4ebf-8b30-873c0d2d1925
5b9bfe3b-ffaf-471f-a882-77b3cf3d8569	f2016a87-e798-4e74-a11b-43a2679dc5b6	73100.00	2026-07-13 03:00:00	VENTA	54347062-c438-4699-8b35-a297b7326ceb	2026-07-19 17:38:58.237263+00	2026-07-19 17:38:58.237263+00	52363d4f-f4cb-43b4-a838-0b70bc800e5c
c6ccef58-9e51-4163-af08-b7d301f8eaae	300b4667-734d-45e0-a92a-a78737f75eb8	104000.00	2026-07-15 03:00:00	VENTA	2af9b95c-9a92-4685-bdfe-2ccbcaaf92ed	2026-07-19 17:42:31.365752+00	2026-07-19 17:42:31.365752+00	67c4a1c0-672e-4383-bf7c-eb77687c539a
9b686f78-7edd-4686-a2dc-2f8a4d9a2b59	300b4667-734d-45e0-a92a-a78737f75eb8	19000.00	2026-07-15 03:00:00	VENTA	15f22141-23dd-44c5-8dd2-95ce74c34f09	2026-07-21 20:02:35.562145+00	2026-07-21 20:02:35.562145+00	2b9b43e1-e4a3-4c87-804f-7ddc949dbd90
73ac7638-01e9-4539-b2d9-ad2b0ffba86f	f2016a87-e798-4e74-a11b-43a2679dc5b6	28000.00	2026-07-15 03:00:00	VENTA	7dd8440e-3c68-4c65-a08e-51157b687af1	2026-07-21 20:18:41.046646+00	2026-07-21 20:18:41.046646+00	6884eaeb-a9aa-48ac-8abd-dfd325effa99
df715092-5371-4c64-b6b2-5862f16c1f91	300b4667-734d-45e0-a92a-a78737f75eb8	166500.00	2026-07-16 03:00:00	VENTA	5ea2cc34-2e66-460e-873a-057ef872dceb	2026-07-21 20:21:47.517095+00	2026-07-21 20:21:47.517095+00	f63ce3e3-a152-4328-86c3-f36ba6a7679f
69bb598b-f3a2-4753-a9b2-ef2444ea732d	f2016a87-e798-4e74-a11b-43a2679dc5b6	33000.00	2026-07-17 03:00:00	VENTA	f463dc19-3f68-4ae7-937d-59ba11ff1255	2026-07-21 20:25:01.976113+00	2026-07-21 20:25:01.976113+00	a0fb0f25-fbb7-4a56-abfc-23e5517939d2
fc38db85-4e0d-48e2-968c-8370ce60bd53	f2016a87-e798-4e74-a11b-43a2679dc5b6	50100.00	2026-07-17 03:00:00	VENTA	a152067d-0684-4ca6-be03-92e9e3c75184	2026-07-21 20:28:20.423596+00	2026-07-21 20:28:20.423596+00	d722132f-f34c-4542-928d-d195af81ff5f
47a2f936-3dce-477e-a650-d584795e0d4b	f2016a87-e798-4e74-a11b-43a2679dc5b6	47500.00	2026-07-20 03:00:00	VENTA	d2875995-79bb-4cb8-841b-43a636539638	2026-07-21 20:30:11.139901+00	2026-07-21 20:30:11.139901+00	8bcda406-9b0d-41f0-854b-51a4a91c394b
a1462fb9-a853-4c68-9292-fcc45446e7e7	f2016a87-e798-4e74-a11b-43a2679dc5b6	50300.00	2026-06-19 03:00:00	VENTA	f13dc362-e0bd-40ca-ac82-6859fb5220ec	2026-06-22 12:57:24.175117+00	2026-06-22 14:24:00.313966+00	20abb5cd-117b-47a8-9ac5-96e37e981089
7d019f12-77b1-4f1f-b2b4-776b33511bed	f2016a87-e798-4e74-a11b-43a2679dc5b6	25400.00	2026-06-19 03:00:00	VENTA	bca315e2-dd3c-458e-9b67-82a444a3b6f1	2026-06-22 12:58:14.378136+00	2026-06-22 14:24:00.313966+00	e3e21f18-5724-4feb-aaa6-2d19bd3afb42
d2f511cf-c52f-4c94-afcf-c92da3ba832a	300b4667-734d-45e0-a92a-a78737f75eb8	68000.00	2026-06-18 03:00:00	VENTA	c896909f-850a-455f-9ca4-773bfe5ea508	2026-06-22 12:59:19.494236+00	2026-06-22 14:24:00.313966+00	3204ecbb-04f6-4173-987c-c0bea6936c0c
edce048c-6752-4516-b6a3-f91d8689277d	300b4667-734d-45e0-a92a-a78737f75eb8	198000.00	2026-06-22 03:00:00	VENTA	4a4eba49-618c-4e36-93f5-78117d2a956b	2026-06-22 13:04:47.39348+00	2026-06-22 14:24:00.313966+00	df4147bc-e554-4eaa-aa4c-368e1ac60d20
44a00214-c053-4501-8f89-1c5061ed0055	300b4667-734d-45e0-a92a-a78737f75eb8	134000.00	2026-06-13 03:00:00	VENTA	628bcc85-4d0d-48ae-b47b-74a373138839	2026-06-22 13:11:03.937117+00	2026-06-22 14:24:00.313966+00	7a13aeec-e56e-43f3-be15-e4c6da50547c
5cc724c4-189a-4e84-8e0f-96cca5e8c5e9	300b4667-734d-45e0-a92a-a78737f75eb8	-72363.00	2026-06-26 13:57:59.336724	EGRESO	74abfe5c-a8d1-485b-ba12-74215dea3f7b	2026-06-26 13:57:59.336724+00	2026-06-26 13:57:59.336724+00	304dfd30-c1eb-4766-bcee-5b8910a90ef4
04721e7d-bbcb-4ffd-a5a3-56b9bbba18c1	300b4667-734d-45e0-a92a-a78737f75eb8	47500.00	2026-06-22 03:00:00	VENTA	115e199b-2922-48a1-a4e6-0fd365c4709b	2026-06-26 15:34:38.096916+00	2026-06-26 15:34:38.096916+00	d6bc8b7b-aa8e-4430-8bec-b67f72d51cd7
e0ba7f75-397b-4662-8155-69f3cd255891	300b4667-734d-45e0-a92a-a78737f75eb8	63600.00	2026-06-22 03:00:00	VENTA	551c6689-b5e8-4ffa-9a02-b323f7cdeecc	2026-06-26 15:36:49.591976+00	2026-06-26 15:36:49.591976+00	a481296e-480c-4ee6-827b-15d1de6107fb
da47bd5d-a730-4bb0-b3e5-277957723887	300b4667-734d-45e0-a92a-a78737f75eb8	28000.00	2026-06-22 03:00:00	VENTA	5318c470-e889-460a-9eac-78c18942fa93	2026-06-26 15:39:08.235263+00	2026-06-26 15:39:08.235263+00	009c942c-1e92-4876-82a3-63ef50a130cf
a8481c95-e461-45dc-bfb8-4a18329d9375	300b4667-734d-45e0-a92a-a78737f75eb8	76000.00	2026-06-22 03:00:00	VENTA	527a3fa7-ba92-4930-bae1-8c198644e399	2026-06-26 15:40:21.78731+00	2026-06-26 15:40:21.78731+00	4c1450dc-e823-4079-a111-8a00aaf3e468
b5c3f04b-c735-4598-9733-13590e8699cb	300b4667-734d-45e0-a92a-a78737f75eb8	-47118.00	2026-06-26 15:44:01.427853	EGRESO	1c64dbe3-ea47-4cf3-9f40-5d80e40c5460	2026-06-26 15:44:01.427853+00	2026-06-26 15:44:01.427853+00	c0df15c1-fa8a-4c6a-aa6e-6349ed052001
3e1dc062-ab6a-4089-82e6-dccf11b9a6c7	300b4667-734d-45e0-a92a-a78737f75eb8	-66000.00	2026-06-26 15:47:04.965522	EGRESO	8032d08d-83f1-4d71-a9d7-cc0875fb8493	2026-06-26 15:47:04.965522+00	2026-06-26 15:47:04.965522+00	024b2bef-f569-4a67-b0c8-712d1609ec24
3b163211-abed-457f-9aed-5cce9ed8c710	300b4667-734d-45e0-a92a-a78737f75eb8	-93200.00	2026-06-26 15:48:49.550982	EGRESO	c21b486b-bcd1-4fff-8bc7-9d1993ce09d3	2026-06-26 15:48:49.550982+00	2026-06-26 15:48:49.550982+00	f85c2063-02c8-4a9f-8f2a-2f27f942a564
fe91b0f2-1a55-4f7e-ab55-f440889194ff	f2016a87-e798-4e74-a11b-43a2679dc5b6	-39900.00	2026-06-26 15:53:10.652051	EGRESO	216376b6-b1e4-4052-b532-789d0cb58f39	2026-06-26 15:53:10.652051+00	2026-06-26 15:53:10.652051+00	c6d398dc-3f6d-4a6b-945c-35653027ccf9
cb42fb48-9052-4039-a603-a53874809056	f2016a87-e798-4e74-a11b-43a2679dc5b6	-4500.00	2026-06-26 15:54:13.211797	EGRESO	baa6c125-cb62-43b1-9fe8-1c6acd628d56	2026-06-26 15:54:13.211797+00	2026-06-26 15:54:13.211797+00	08665cf2-337f-4b71-942d-3da529b1aac9
65c52330-6aae-4dff-9479-c088e328a085	f2016a87-e798-4e74-a11b-43a2679dc5b6	-22617.48	2026-06-26 15:55:37.429575	EGRESO	0f16ad90-d250-4a13-beae-02918ccffb2d	2026-06-26 15:55:37.429575+00	2026-06-26 15:55:37.429575+00	3f5430d0-b69f-429e-88fe-3309bb9e2969
c14c6d99-8c87-40e8-9ea2-652a3e0c2bf0	300b4667-734d-45e0-a92a-a78737f75eb8	-20000.00	2026-06-30 12:43:25.474304	EGRESO	1dcfa50b-3338-45f4-b3d7-88361c7c95f5	2026-06-30 12:43:25.474304+00	2026-06-30 12:43:25.474304+00	42973042-52ad-4790-bddc-2a43fabf72f3
af85c627-1496-4fbb-84ce-0e6a7633b929	300b4667-734d-45e0-a92a-a78737f75eb8	76000.00	2026-06-24 03:00:00	VENTA	e9606946-3545-4180-8d96-2c74eeedb662	2026-06-30 13:08:05.373579+00	2026-06-30 13:08:05.373579+00	6dfdbf95-e527-4888-8b0e-018222e0c257
b38c82b4-9f8b-4b1e-af6d-b61e9d992589	f2016a87-e798-4e74-a11b-43a2679dc5b6	29600.00	2026-06-26 03:00:00	VENTA	4e423182-706d-4218-bfa0-f4b7af3bb0b9	2026-06-30 13:16:13.31843+00	2026-06-30 13:16:13.31843+00	7097b34e-6a94-4335-a2b9-500c7afec1b6
2248542b-8fdd-4797-a521-1862211156a9	f2016a87-e798-4e74-a11b-43a2679dc5b6	46500.00	2026-06-24 03:00:00	VENTA	af3160eb-a205-4fde-b0cd-a4edc96c386a	2026-06-30 13:22:23.016304+00	2026-06-30 13:22:23.016304+00	5cbf6b16-73c0-4174-a520-9456336d02a7
95eaa6dc-be0c-4f84-b506-6619bdb6bfc4	300b4667-734d-45e0-a92a-a78737f75eb8	198000.00	2026-06-29 03:00:00	VENTA	c65f4643-4b84-43b9-8e2c-6870f06e29d7	2026-06-30 14:07:28.751543+00	2026-06-30 14:07:28.751543+00	a3ee3da1-39ee-4841-8f66-142c3053a3f8
2a9d1d35-e02f-4102-a166-608fbc595f38	f2016a87-e798-4e74-a11b-43a2679dc5b6	27500.00	2026-06-29 03:00:00	VENTA	72782f24-2f31-40ed-af31-ce5a739154db	2026-06-30 14:13:11.44965+00	2026-06-30 14:13:11.44965+00	6cd21f5e-f050-4856-af8a-c1a9c881d79d
331689e9-e150-47a0-a8df-ac5dd5ae5e76	300b4667-734d-45e0-a92a-a78737f75eb8	-469700.00	2026-06-30 14:05:48.882156	EGRESO	76e4e23e-207a-4e89-bef4-4d065954cadb	2026-07-01 14:05:48.882156+00	2026-07-02 16:03:41.065271+00	d3685083-8ce8-4304-b7fe-201e1b1e65f9
5735d715-131a-4a44-b408-84c31bf386f1	300b4667-734d-45e0-a92a-a78737f75eb8	-6000.00	2026-06-30 14:14:27.713794	EGRESO	172cd1ac-a530-42f8-ad7c-b62f9e65c0ee	2026-07-01 14:14:27.713794+00	2026-07-02 16:03:41.065271+00	ae3ddbe8-1a76-4bc3-9aca-f7a6f2316434
5bc98fd9-d791-44c7-bcb8-862f4e81a785	300b4667-734d-45e0-a92a-a78737f75eb8	76000.00	2026-07-01 03:00:00	VENTA	34256591-b222-410f-8b27-311efbc0ca97	2026-07-09 12:33:42.438072+00	2026-07-09 12:33:42.438072+00	73717c02-6db4-45cc-a455-7c5e3021ffed
52aa1a86-5868-4696-9353-de6a6eca5b46	f2016a87-e798-4e74-a11b-43a2679dc5b6	23600.00	2026-07-03 03:00:00	VENTA	b246eca0-7241-4021-b5b7-4cd720e35bcd	2026-07-09 12:38:20.384258+00	2026-07-09 12:38:20.384258+00	426bf8db-0034-4b5f-8998-987b18d31cc4
17e89eb7-ad78-47ed-b1be-ce9acbd36871	88ce6836-bb6c-4380-863d-7a8c5957d906	205325.00	2026-06-29 21:30:17.441938	VENTA	7d1084e5-b9db-475d-b230-61631e60324f	2026-06-29 21:30:17.441938+00	2026-06-29 21:30:17.441938+00	f41db1e1-ad96-409f-866e-277a7664ac5a
099d54de-302f-4f3b-9abb-346c36759669	88ce6836-bb6c-4380-863d-7a8c5957d906	-205325.00	2026-06-29 21:33:35.364906	TRANSFERENCIA	d0292698-af8b-4a6f-a033-dd754ad51de6	2026-06-29 21:33:35.364906+00	2026-06-29 21:33:35.364906+00	d0292698-af8b-4a6f-a033-dd754ad51de6
c77fb531-7aad-45fd-9a0c-4e273cf21a77	300b4667-734d-45e0-a92a-a78737f75eb8	205325.00	2026-06-29 21:33:35.364906	TRANSFERENCIA	d0292698-af8b-4a6f-a033-dd754ad51de6	2026-06-29 21:33:35.364906+00	2026-06-29 21:33:35.364906+00	d0292698-af8b-4a6f-a033-dd754ad51de6
1432a03d-12bb-4e94-b0b5-af86de8eb7f0	f2016a87-e798-4e74-a11b-43a2679dc5b6	36500.00	2026-07-01 03:00:00	VENTA	bf23060f-263a-44fd-8d57-3b6680152b08	2026-07-09 12:42:38.98681+00	2026-07-09 12:42:38.98681+00	a30e2a06-aa2a-49c4-b7ae-c6a1bfd24f64
d43f8a27-24ce-4898-978c-fd750927c838	300b4667-734d-45e0-a92a-a78737f75eb8	-100000.00	2026-07-01 15:00:00	TRANSFERENCIA	9321558b-41db-4340-bbaa-3e7af9bee03a	2026-07-30 00:50:30.924103+00	2026-07-30 00:50:30.924103+00	9321558b-41db-4340-bbaa-3e7af9bee03a
8a0950a8-6d16-4926-9242-bc420d6d4fc5	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	100000.00	2026-07-01 15:00:00	TRANSFERENCIA	9321558b-41db-4340-bbaa-3e7af9bee03a	2026-07-30 00:50:30.924103+00	2026-07-30 00:50:30.924103+00	9321558b-41db-4340-bbaa-3e7af9bee03a
0a52729b-3d77-400d-838c-8c596353ed68	f2016a87-e798-4e74-a11b-43a2679dc5b6	23600.00	2026-07-06 03:00:00	VENTA	00b2d302-308b-42ca-a711-89741e5cdcbe	2026-07-19 17:20:01.883488+00	2026-07-19 17:20:01.883488+00	f1da69a2-4f04-45c2-a1cd-f6f16f94ea5c
f07fee31-444a-4cb2-844f-9ad6496aa9f0	300b4667-734d-45e0-a92a-a78737f75eb8	48000.00	2026-07-06 03:00:00	VENTA	72fb6044-5610-43fe-90c8-2cc5ff69c86f	2026-07-19 17:25:14.548548+00	2026-07-19 17:25:14.548548+00	886118c4-cad4-4835-8acb-cf749e70f463
0bf29c91-14eb-42e5-bb52-0430b1d14593	300b4667-734d-45e0-a92a-a78737f75eb8	180500.00	2026-07-09 03:00:00	VENTA	4f7ec5be-774e-4c2f-9247-56597747bd30	2026-07-19 17:28:33.061417+00	2026-07-19 17:28:33.061417+00	2b3b5739-7950-4d2e-a348-ab6a873d89c2
c31188f7-e0fe-40c6-8014-e4f74ba3be52	f2016a87-e798-4e74-a11b-43a2679dc5b6	25800.00	2026-07-10 03:00:00	VENTA	16ac9237-cdfc-42d2-8428-e987b5d46911	2026-07-19 17:32:01.746648+00	2026-07-19 17:32:01.746648+00	9f681791-bb58-4369-836b-bb469369891c
cf7e1ef0-2626-4918-b780-f9483d0833c9	f2016a87-e798-4e74-a11b-43a2679dc5b6	47500.00	2026-07-10 03:00:00	VENTA	d0e8ebd9-1e93-419b-91e2-481a6c2a6d92	2026-07-19 17:35:37.410654+00	2026-07-19 17:35:37.410654+00	ffbb11d4-e7ed-4773-b9fd-845becde810e
46daf505-f46f-41b7-a3c3-2766bc5ecf67	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	-288179.51	2026-07-21 18:56:12.760376	RETIRO	0fab4864-0955-4c3b-8574-0e5b6743dcfc	2026-07-21 18:56:12.760376+00	2026-07-21 18:56:12.760376+00	0fab4864-0955-4c3b-8574-0e5b6743dcfc
3f9d8794-8928-40d7-9dd4-c45aa6ac27b4	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	20000.00	2026-07-23 15:00:00	TRANSFERENCIA	b4678879-776d-4b1b-94d6-7c224dfb94e1	2026-07-30 04:06:15.654521+00	2026-07-30 04:06:15.654521+00	b4678879-776d-4b1b-94d6-7c224dfb94e1
b4f0ee59-739e-4707-ab53-375845838508	f2016a87-e798-4e74-a11b-43a2679dc5b6	25500.00	2026-07-15 03:00:00	VENTA	a96bff15-ad90-4acc-ac9f-d7b2d74c98e7	2026-07-21 20:17:43.030846+00	2026-07-21 20:17:43.030846+00	f64d05c2-312e-4623-9062-f36281693e3f
929f6dd8-2818-41a9-a606-16605b4f5517	300b4667-734d-45e0-a92a-a78737f75eb8	166500.00	2026-07-16 03:00:00	VENTA	00734614-d7ae-4b68-a0b4-7c1b860fd693	2026-07-21 20:20:02.899636+00	2026-07-21 20:20:02.899636+00	882f6171-e8ee-464b-a7f0-2e2e0aa3f953
69ce637c-e9fb-4f08-929f-77910b47146d	300b4667-734d-45e0-a92a-a78737f75eb8	114500.00	2026-07-16 03:00:00	VENTA	4df3c0e8-f8aa-44d5-afde-9c0cb67b8561	2026-07-21 20:23:06.949245+00	2026-07-21 20:23:06.949245+00	91511fda-0df9-457d-9a73-fa892cb93692
760d775b-d28d-400c-9c6d-52147a3f7534	f2016a87-e798-4e74-a11b-43a2679dc5b6	30200.00	2026-07-17 03:00:00	VENTA	78be609e-d109-48e9-b670-a1e807eefd9b	2026-07-21 20:27:09.517244+00	2026-07-21 20:27:09.517244+00	01fdb02a-e03f-48d2-9fc5-242a31eb1ab2
3093ef16-a305-475a-b488-51d8aef56b10	300b4667-734d-45e0-a92a-a78737f75eb8	78500.00	2026-07-17 03:00:00	VENTA	80989874-2ba5-4b86-8215-9d5d1c6bfb97	2026-07-21 20:29:14.560255+00	2026-07-21 20:29:14.560255+00	752c07e0-a2ea-4300-98f2-b2e522d36a2f
2aa77b1c-dd2b-4301-928d-a71c33551ffa	300b4667-734d-45e0-a92a-a78737f75eb8	112000.00	2026-07-20 03:00:00	VENTA	cbb77c2e-c120-44c1-b782-007ab766e417	2026-07-21 20:31:02.249434+00	2026-07-21 20:31:02.249434+00	85ad9f1c-5b90-4369-a544-dc667d47bf15
6afe6ccd-7da2-41dc-af70-d7a735345126	300b4667-734d-45e0-a92a-a78737f75eb8	-50000.00	2026-07-29 15:00:00	TRANSFERENCIA	0d27bc62-2cf0-4693-ae76-4008badab240	2026-07-30 04:12:27.506811+00	2026-07-30 04:12:27.506811+00	0d27bc62-2cf0-4693-ae76-4008badab240
b27be46d-e792-462a-935a-988a37caf04c	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	50000.00	2026-07-29 15:00:00	TRANSFERENCIA	0d27bc62-2cf0-4693-ae76-4008badab240	2026-07-30 04:12:27.506811+00	2026-07-30 04:12:27.506811+00	0d27bc62-2cf0-4693-ae76-4008badab240
3be30111-6b69-442d-8d61-31445d556a6c	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	-100000.00	2026-07-01 15:00:00	ADELANTO	84ad83fb-589a-424b-a015-74e0aeeb3f40	2026-07-30 04:01:56.285608+00	2026-07-30 04:01:56.285608+00	84ad83fb-589a-424b-a015-74e0aeeb3f40
3bb79637-60a5-4b3f-9c36-a08fe10145fa	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	-20000.00	2026-07-23 15:00:00	ADELANTO	258307dd-a0cf-4596-8669-c835d4fea220	2026-07-30 04:08:05.088588+00	2026-07-30 04:08:05.088588+00	258307dd-a0cf-4596-8669-c835d4fea220
9a3d87da-285c-47ce-8426-59fbdeb53a52	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	-50000.00	2026-07-29 15:00:00	ADELANTO	64fa5586-7eb9-4d17-95c0-f8cdfad2a5e2	2026-07-30 04:13:04.535086+00	2026-07-30 04:13:04.535086+00	64fa5586-7eb9-4d17-95c0-f8cdfad2a5e2
16480474-6c7d-4506-924d-37e02821dfe0	300b4667-734d-45e0-a92a-a78737f75eb8	91200.00	2026-07-29 03:00:00	VENTA	28eee34d-d2e2-4338-9ec3-a275d4bc559c	2026-07-30 15:53:57.892845+00	2026-07-30 15:53:57.892845+00	44ee7f0c-5228-4094-aa9f-e746de1238ed
295e70ce-e5bc-42e6-88ad-094627124a76	300b4667-734d-45e0-a92a-a78737f75eb8	166500.00	2026-07-30 03:00:00	VENTA	b849a1fd-026a-4b16-b1e1-452eb66bce4f	2026-07-30 15:57:21.995101+00	2026-07-30 15:57:21.995101+00	7d63dd99-59ef-4c05-8db6-40ac6fcdee7f
44b9d35d-394d-45ee-a942-3ee3f4f1c25e	300b4667-734d-45e0-a92a-a78737f75eb8	145500.00	2026-07-30 03:00:00	VENTA	43dc8a2a-4e24-4a44-b359-f833c1482583	2026-07-30 15:59:42.072974+00	2026-07-30 15:59:42.072974+00	6e64709e-0b4f-42b3-9380-1810211e460d
6720b6d1-9f0f-4719-afe3-056c5e0bb76a	300b4667-734d-45e0-a92a-a78737f75eb8	-211350.00	2026-07-30 16:13:34.110178	EGRESO	5f906378-457c-4d2d-8ce7-c272f6e19e63	2026-07-30 16:13:34.110178+00	2026-07-30 16:13:34.110178+00	0149ec9e-2db1-435e-b147-0d1670a0b002
0fbdb995-8cbb-475e-bba2-7200985cabd9	f2016a87-e798-4e74-a11b-43a2679dc5b6	19000.00	2026-07-29 03:00:00	VENTA	add06fe4-df20-4f02-8802-eea46aeec65a	2026-07-30 15:55:32.587417+00	2026-07-31 13:30:41.74437+00	44b8fa4d-ed63-47f3-8c9e-2b342367fbd9
3091eeab-71cf-4356-9bdd-8bdc2aaf3280	f2016a87-e798-4e74-a11b-43a2679dc5b6	-100000.00	2026-07-31 15:00:00	TRANSFERENCIA	4af33d85-ce9f-424b-97ea-1a58c94f9417	2026-07-31 16:58:50.054954+00	2026-07-31 16:58:50.054954+00	4af33d85-ce9f-424b-97ea-1a58c94f9417
542d184a-a5e6-4bc2-978e-a234a9cd5785	300b4667-734d-45e0-a92a-a78737f75eb8	-446917.50	2026-07-01 15:00:00	TRANSFERENCIA	aa94aa1d-77a5-4045-8709-116e7925b9eb	2026-07-30 16:23:19.707725+00	2026-07-30 17:30:35.994058+00	aa94aa1d-77a5-4045-8709-116e7925b9eb
431e0a75-6859-4405-b9ba-d67760456f50	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	446917.50	2026-07-01 15:00:00	TRANSFERENCIA	aa94aa1d-77a5-4045-8709-116e7925b9eb	2026-07-30 16:23:19.707725+00	2026-07-30 17:30:35.994058+00	aa94aa1d-77a5-4045-8709-116e7925b9eb
e79f0608-1690-4e08-8d57-457b9f1270c5	300b4667-734d-45e0-a92a-a78737f75eb8	-144400.00	2026-07-30 18:11:46.644524	EGRESO	9f23e992-08ea-4abe-a590-7362c513145a	2026-07-30 18:11:46.644524+00	2026-07-30 18:11:46.644524+00	dbe8088d-4727-4802-af6a-2faae9b20fc3
6ca472cd-8c20-40a4-9647-a06a34637b00	f2016a87-e798-4e74-a11b-43a2679dc5b6	25800.00	2026-07-31 03:00:00	VENTA	12ebaa3a-23a3-425a-afa2-fa6d97d19345	2026-07-31 03:25:49.7328+00	2026-07-31 03:25:49.7328+00	f14bb95d-839b-4262-a2b4-894fe0d90442
23f8e13f-2af5-4a43-beb3-e484fc8dbbd2	f2016a87-e798-4e74-a11b-43a2679dc5b6	-50000.00	2026-07-23 05:42:49.161046	EGRESO	77830fda-dcaf-450a-8361-cba8efd22e33	2026-07-23 05:42:49.161046+00	2026-07-23 05:42:49.161046+00	941d858d-d42d-4583-a534-73999908e848
be1ff89b-1d2f-48e0-a0d8-ed7089ec990b	f2016a87-e798-4e74-a11b-43a2679dc5b6	64500.00	2026-07-31 03:00:00	VENTA	196e9aa0-d105-448d-9b93-93e787c121ab	2026-07-31 03:27:57.546374+00	2026-07-31 03:27:57.546374+00	ca7d010a-4f5d-46e0-ba4c-26439a0ddbdb
06f74ca1-dde4-4502-9659-606224a92e51	300b4667-734d-45e0-a92a-a78737f75eb8	159500.00	2026-07-31 03:00:00	VENTA	7414e697-94c7-4f60-afcf-c951238cb5a3	2026-07-31 03:30:24.504247+00	2026-07-31 03:30:24.504247+00	cdba642d-81e4-447e-af8a-3dcbe6ea03e6
57def2da-11e2-458b-a5e3-047c5d0d86b8	f2016a87-e798-4e74-a11b-43a2679dc5b6	47500.00	2026-07-31 03:00:00	VENTA	3e6e0750-9c79-4b9b-9045-5f053d49f22d	2026-07-31 03:32:06.032538+00	2026-07-31 03:32:06.032538+00	74dd49b4-4a02-4bec-84b3-1e72d400504c
1ea7f6ae-d8b1-4dfc-a678-89da0ac7e4c2	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	100000.00	2026-07-31 15:00:00	TRANSFERENCIA	4af33d85-ce9f-424b-97ea-1a58c94f9417	2026-07-31 16:58:50.054954+00	2026-07-31 16:58:50.054954+00	4af33d85-ce9f-424b-97ea-1a58c94f9417
905d0c19-3f63-4a1c-aa73-97b6d9ce8e81	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	-100000.00	2026-07-31 17:00:37.326167	ADELANTO	4d7755cb-ea5d-4d18-8a2c-124e57e02824	2026-07-31 17:00:37.326167+00	2026-07-31 17:00:37.326167+00	4d7755cb-ea5d-4d18-8a2c-124e57e02824
9968c8e8-48a0-4d76-9e1d-71964e7307b7	300b4667-734d-45e0-a92a-a78737f75eb8	-52000.00	2026-07-31 21:03:51.661423	EGRESO	838bf1ba-135e-429a-a496-57ccbd897e57	2026-07-31 21:03:51.661423+00	2026-07-31 21:03:51.661423+00	3b897f61-30c6-4775-9414-75c89109ea0d
82816d0d-68b6-45f3-a395-83252219dd8f	300b4667-734d-45e0-a92a-a78737f75eb8	-1242887.85	2026-07-31 23:59:59	CIERRE	56dae58f-ebb9-47b1-9182-ae4fb831d7d4	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	56dae58f-ebb9-47b1-9182-ae4fb831d7d4
1d0f8b69-0b30-483d-8664-d6e94fbdd7b8	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	1242887.85	2026-07-31 23:59:59	CIERRE	56dae58f-ebb9-47b1-9182-ae4fb831d7d4	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	56dae58f-ebb9-47b1-9182-ae4fb831d7d4
154f20dd-c3dd-4a94-8c91-adba0f7287e4	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	-446917.50	2026-07-25 01:18:51.93948	RETIRO	04750226-ea44-4006-806d-1520120af314	2026-07-25 01:18:51.93948+00	2026-07-25 01:18:51.93948+00	04750226-ea44-4006-806d-1520120af314
9842e2c8-0ead-491b-9adc-1bbc83a07eb2	f2016a87-e798-4e74-a11b-43a2679dc5b6	-160000.00	2026-07-26 15:00:00	TRANSFERENCIA	d3333db7-8e91-42b9-8343-9fba3942886c	2026-07-26 23:56:57.358252+00	2026-07-26 23:56:57.358252+00	d3333db7-8e91-42b9-8343-9fba3942886c
66c00d76-472b-4366-85b6-e43ad20e16fd	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	160000.00	2026-07-26 15:00:00	TRANSFERENCIA	d3333db7-8e91-42b9-8343-9fba3942886c	2026-07-26 23:56:57.358252+00	2026-07-26 23:56:57.358252+00	d3333db7-8e91-42b9-8343-9fba3942886c
325a27ff-126f-4a8b-9af5-bea9520009a0	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	-160000.00	2026-07-27 00:06:12.514247	ADELANTO	77087c85-c563-480d-9a98-d83f6b49634f	2026-07-27 00:06:12.514247+00	2026-07-27 00:06:12.514247+00	77087c85-c563-480d-9a98-d83f6b49634f
984652eb-05c2-41b3-a635-0a172a3d5b18	300b4667-734d-45e0-a92a-a78737f75eb8	120500.00	2026-07-24 03:00:00	VENTA	eac6103f-7117-460a-a092-1dd1434a0421	2026-07-28 12:31:28.827781+00	2026-07-28 12:31:28.827781+00	a3e44623-c930-4694-aab3-d038eb0b2f60
a153cc13-daf6-4c0b-b4df-2a75c8a3cf9d	300b4667-734d-45e0-a92a-a78737f75eb8	173000.00	2026-07-24 03:00:00	VENTA	3581af9a-33aa-4c4c-b720-cb71d2ae4901	2026-07-28 12:32:44.872623+00	2026-07-28 12:32:44.872623+00	8276d3cb-a43a-4cde-8d79-1708e4225d91
51879075-c244-4dd3-950a-8b9e6cd43766	f2016a87-e798-4e74-a11b-43a2679dc5b6	83100.00	2026-07-24 03:00:00	VENTA	6aac7d1f-2c7f-4685-af97-adfaeb6e9a83	2026-07-28 12:33:45.474466+00	2026-07-28 12:33:45.474466+00	669aab53-97cd-4d3a-87e1-77a8292f2368
4c313cb2-ff8f-44f0-b738-04a25f03860c	f2016a87-e798-4e74-a11b-43a2679dc5b6	47500.00	2026-07-24 03:00:00	VENTA	f6525a98-af76-4176-aef5-fd0fb627f797	2026-07-28 12:34:33.531739+00	2026-07-28 12:34:33.531739+00	a8404959-0798-4ac2-bb91-2aada87c1010
5316234a-c71f-4164-ab72-eacc47bb5c04	300b4667-734d-45e0-a92a-a78737f75eb8	131500.00	2026-07-24 03:00:00	VENTA	e7b9784f-b8e8-407c-b76b-4bb7f5764fc1	2026-07-28 12:36:11.844468+00	2026-07-28 12:36:11.844468+00	df75aeac-0cf1-49bb-a824-9afbb8ce213c
872dd639-9c7d-495c-bced-ffa84b6dcb73	300b4667-734d-45e0-a92a-a78737f75eb8	103500.00	2026-07-23 03:00:00	VENTA	e30d341f-e131-4f15-a0e4-90dd63185938	2026-07-28 12:37:26.642761+00	2026-07-28 12:37:26.642761+00	a915f244-1041-4c7a-83ad-9c85653f0f4d
1819c756-efa1-4faa-a594-a337062d7b36	300b4667-734d-45e0-a92a-a78737f75eb8	166500.00	2026-07-23 03:00:00	VENTA	2017702b-69d0-4729-80ff-d3af4ab8b100	2026-07-28 12:38:41.10112+00	2026-07-28 12:38:41.10112+00	610163ec-adf1-4b3b-ba31-a26c47052e87
f5b2a438-4ef3-41a3-b010-13a6d2f775d4	f2016a87-e798-4e74-a11b-43a2679dc5b6	23600.00	2026-07-22 03:00:00	VENTA	b05190ff-1ad6-4b03-9108-bd5f8e9e6148	2026-07-28 12:39:38.845234+00	2026-07-28 12:39:38.845234+00	606e7bf0-b52d-4ca6-9402-8de8ce6b9b54
b9d6ca51-f495-4c38-907c-92cf1e9c4f2a	f2016a87-e798-4e74-a11b-43a2679dc5b6	40000.00	2026-07-27 03:00:00	VENTA	b735f45d-c9bc-4cc9-806c-1176524507d3	2026-07-28 12:55:06.585645+00	2026-07-28 12:55:06.585645+00	1cd50303-79cc-4a6c-a0ae-e9e6fff50fa4
9127f730-af72-407e-a6be-9f48d54f8646	f2016a87-e798-4e74-a11b-43a2679dc5b6	78000.00	2026-07-21 03:00:00	VENTA	cbcaa551-5761-436d-ae52-2811789a83d4	2026-07-28 12:58:16.52675+00	2026-07-28 12:58:16.52675+00	e5349457-97cd-45b7-938d-2c9c25fc3844
80f70ec8-af71-4bc1-b2fe-9e25576b29b9	f2016a87-e798-4e74-a11b-43a2679dc5b6	23600.00	2026-07-27 03:00:00	VENTA	0648fb30-e041-407b-9b08-4c414328d015	2026-07-28 12:59:18.438289+00	2026-07-28 12:59:18.438289+00	b571df08-29ab-4571-aa30-d5d55673a25e
248f9d7e-9445-42ba-a800-5aecc6e0d689	f2016a87-e798-4e74-a11b-43a2679dc5b6	72100.00	2026-07-27 03:00:00	VENTA	009ed6cd-13cd-4a95-9874-a2dea0c9f217	2026-07-28 13:00:14.014612+00	2026-07-28 13:00:14.014612+00	84f2e240-e621-4b6d-bf8c-f2212e885c28
c12f1e1e-6682-4b70-b826-d4b4f30d9cb7	f2016a87-e798-4e74-a11b-43a2679dc5b6	25800.00	2026-07-20 03:00:00	VENTA	e1138a39-b377-4e7d-9db1-88eedaab0011	2026-07-28 13:01:06.822983+00	2026-07-28 13:01:06.822983+00	ae536c28-11ab-491d-b5ad-a02c38dbdc04
7c190f2f-1115-4bab-af21-f00659afa457	300b4667-734d-45e0-a92a-a78737f75eb8	-97057.65	2026-07-28 13:11:39.986643	EGRESO	65617666-1bce-41a8-9191-f1f9b8264d3d	2026-07-28 13:11:39.986643+00	2026-07-28 13:11:39.986643+00	96c2d3ee-38d8-49f5-acd4-fcab1211c814
2ae20a55-89d4-45b8-91ee-c1d6a9bdb95b	300b4667-734d-45e0-a92a-a78737f75eb8	-31400.00	2026-07-28 13:13:39.903953	EGRESO	2eb165e7-4820-4218-9d6b-20846bae1633	2026-07-28 13:13:39.903953+00	2026-07-28 13:13:39.903953+00	520ccb6e-a05b-4ac9-87d5-0f13a8a303fc
123786ae-48b1-417c-9f23-852132afe8c8	300b4667-734d-45e0-a92a-a78737f75eb8	-108450.00	2026-07-28 13:15:59.974801	EGRESO	63d6bca1-5b47-4a36-85f2-bae6c56a1016	2026-07-28 13:15:59.974801+00	2026-07-28 13:15:59.974801+00	b3f001f4-16ca-4c36-a8c1-bb14bef1818c
1859738b-9ffe-44a2-9dd0-1e53b48e09ff	300b4667-734d-45e0-a92a-a78737f75eb8	-90000.00	2026-07-28 13:16:47.820635	EGRESO	fb074af0-9489-4c48-bd27-249169b4ec5d	2026-07-28 13:16:47.820635+00	2026-07-28 13:16:47.820635+00	e7a1dc60-5bbb-473b-a676-1c5efccef7d5
e1ce1e49-b23a-40b5-9d66-fca0cf7a0f4a	f2016a87-e798-4e74-a11b-43a2679dc5b6	-100000.00	2026-07-28 15:00:00	TRANSFERENCIA	df89d709-91cd-4cf0-8fd2-a194a55f0bf5	2026-07-28 13:20:19.13951+00	2026-07-28 13:20:19.13951+00	df89d709-91cd-4cf0-8fd2-a194a55f0bf5
359875e2-59c2-4cc8-a558-a3af5075fd4a	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	100000.00	2026-07-28 15:00:00	TRANSFERENCIA	df89d709-91cd-4cf0-8fd2-a194a55f0bf5	2026-07-28 13:20:19.13951+00	2026-07-28 13:20:19.13951+00	df89d709-91cd-4cf0-8fd2-a194a55f0bf5
50aeee42-effd-4737-8a71-1673566e3187	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	-100000.00	2026-07-28 13:20:56.629222	ADELANTO	6c6bfecd-aa47-423a-bc76-a4bbeed96f4f	2026-07-28 13:20:56.629222+00	2026-07-28 13:20:56.629222+00	6c6bfecd-aa47-423a-bc76-a4bbeed96f4f
572099f5-3b46-453d-8667-92fd5ecbb963	300b4667-734d-45e0-a92a-a78737f75eb8	-315937.00	2026-07-28 19:56:49.632065	EGRESO	ed9ac0f3-4053-43ef-a7c6-8e1fb4fa1406	2026-07-28 19:56:49.632065+00	2026-07-28 19:56:49.632065+00	3c031f48-c661-4910-8afb-c020b26758d8
92c10f77-b7be-43c9-a235-d60fcc7829ec	f2016a87-e798-4e74-a11b-43a2679dc5b6	-1004700.00	2026-07-31 23:59:59	LIQUIDACION	eee91392-638f-4e63-ae95-07618b73233c	2026-08-01 13:07:51.19579+00	2026-08-01 14:56:35.887997+00	eee91392-638f-4e63-ae95-07618b73233c
\.


--
-- Data for Name: mvp_operacion_caja; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_operacion_caja (id, tipo_operacion_id, fecha, usuario_id, estado, caja_origen_id, caja_destino_id, tercero_id, tipo_tercero, referencia_externa, observaciones, created_at, updated_at, documento_tipo, documento_id, operacion_relacionada_id, periodo_id, nro_comprobante) FROM stdin;
5dcb48c2-3d3a-4b69-9cc8-d0e82a61572b	2	2026-06-18 22:30:24.203827	2a08da39-1889-4a3c-a67b-fe63deb762a8	CONFIRMADA	\N	d9746a8e-262d-4359-9589-6f232f5d9e0f	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-06-18 22:30:24.203827+00	2026-06-18 22:30:24.203827+00	VENTA	f72ebf0e-a320-4e85-ab95-e363c4e9449b	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
4fa9752b-348c-4232-bcc2-6c6b90588110	2	2026-06-18 22:30:33.991201	2a08da39-1889-4a3c-a67b-fe63deb762a8	CONFIRMADA	\N	d9746a8e-262d-4359-9589-6f232f5d9e0f	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-06-18 22:30:33.991201+00	2026-06-18 22:30:33.991201+00	VENTA	195ae60e-73b7-41e5-ac13-6c11ae9b6c38	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
b7fe1661-b4a5-4a4d-806a-56c136ed5f49	1	2026-06-18 22:31:00.931682	2a08da39-1889-4a3c-a67b-fe63deb762a8	CONFIRMADA	d9746a8e-262d-4359-9589-6f232f5d9e0f	f2016a87-e798-4e74-a11b-43a2679dc5b6	\N	\N	\N	Rendición diaria repartidor	2026-06-18 22:31:00.931682+00	2026-06-18 22:31:00.931682+00	\N	\N	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
3191f7fb-568d-4131-b16c-6c29d5075935	2	2026-06-01 22:30:11	2a08da39-1889-4a3c-a67b-fe63deb762a8	CONFIRMADA	\N	d9746a8e-262d-4359-9589-6f232f5d9e0f	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-18 22:30:11.426226+00	2026-06-22 11:37:55.233376+00	VENTA	fb5a8110-a2be-4037-aa7f-c7289c8f83f1	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
6ccb3301-8415-4501-93d2-35c736cee738	2	2026-07-01 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-07-09 12:32:51.128143+00	2026-07-09 12:32:51.128143+00	VENTA	cf500b07-7e2e-40ca-a145-d4daba247fd9	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
d6c377ef-2b75-4eb7-ab48-0e2eb0bf800b	2	2026-07-03 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-07-09 12:37:30.674931+00	2026-07-09 12:37:30.674931+00	VENTA	9d41438f-6faa-433b-8edf-cc25aef71047	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
b21ba1da-efd9-4aac-9bba-6daa63667b70	2	2026-07-03 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	7e992fe9-d375-47b4-acb9-bbf185071bda	CLIENTE	\N	\N	2026-07-09 12:41:10.526569+00	2026-07-09 12:41:10.526569+00	VENTA	7be3f424-d803-4b7e-b896-658e6587f835	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
9dfb0132-2f40-46ff-8e43-a479769c635d	16	2026-06-30 23:59:59	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	f2016a87-e798-4e74-a11b-43a2679dc5b6	\N	\N	\N	\N	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	\N	\N	fc8fb835-ef74-4b10-9864-6350baba9fc9	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
90255a93-ddba-4cf0-9c85-34da7525b675	13	2026-06-30 23:59:59	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	\N	2a08da39-1889-4a3c-a67b-fe63deb762a8	SOCIO	\N	\N	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	\N	\N	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
72387cb4-9799-430b-b1aa-c5d908faeab3	6	2026-06-30 23:59:59	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	f2016a87-e798-4e74-a11b-43a2679dc5b6	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	\N	\N	\N	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	\N	\N	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
c27dd104-74c8-4093-98ee-9a825c4758f2	13	2026-06-30 23:59:59	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	\N	8855cdde-cd2a-4422-9220-041f5da8f61f	SOCIO	\N	\N	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	\N	\N	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
0af005c3-b2d7-459d-8c5f-d294a375285d	13	2026-06-30 23:59:59	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	\N	259e6361-632b-4584-b7c8-90a8c3b411a5	SOCIO	\N	\N	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	\N	\N	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
723b5366-0ff4-43bb-8f26-89605e1e39f3	6	2026-06-30 23:59:59	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	\N	\N	\N	2026-07-02 18:48:46.701648+00	2026-07-13 19:48:47.971964+00	\N	\N	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
dbe8088d-4727-4802-af6a-2faae9b20fc3	3	2026-07-30 18:11:46.644524	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-30 18:11:46.644524+00	2026-07-30 18:11:46.644524+00	EGRESO	9f23e992-08ea-4abe-a590-7362c513145a	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
4af33d85-ce9f-424b-97ea-1a58c94f9417	18	2026-07-31 15:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	f2016a87-e798-4e74-a11b-43a2679dc5b6	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	\N	\N	A cuenta alquiler	2026-07-31 16:58:50.054954+00	2026-07-31 16:58:50.054954+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	76
dc76a433-cfff-4939-9498-4b53a43b3e91	2	2026-07-06 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-07-19 17:18:58.639425+00	2026-07-19 17:18:58.639425+00	VENTA	c71f7468-f8c8-4cbc-bf4b-67916f9760e5	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
ab72274d-1b5c-4fa1-a9d9-51e6523a7eaa	2	2026-07-06 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-07-19 17:24:11.542056+00	2026-07-19 17:24:11.542056+00	VENTA	7d61e654-10c5-4bda-832f-6859d7fb1dd0	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
11c2a2d8-52c1-480b-b117-8c572b594951	2	2026-07-08 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-07-19 17:27:15.287088+00	2026-07-19 17:27:15.287088+00	VENTA	74378a5e-1e3c-4c91-b488-b5051ecf8516	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
2ca1f1b0-97f9-45ad-8f05-1e001298f3f3	2	2026-07-09 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3249bfe8-6aeb-449c-a605-647b9cae453c	CLIENTE	\N	\N	2026-07-19 17:29:59.858871+00	2026-07-19 17:29:59.858871+00	VENTA	84fe840f-c94b-4e45-9ed1-a5735aca0f7c	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
9f681791-bb58-4369-836b-bb469369891c	2	2026-07-10 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-07-19 17:32:01.746648+00	2026-07-19 17:32:01.746648+00	VENTA	16ac9237-cdfc-42d2-8428-e987b5d46911	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
65e89743-229a-4ebf-8b30-873c0d2d1925	2	2026-07-10 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-07-19 17:34:54.710093+00	2026-07-19 17:34:54.710093+00	VENTA	779708ab-5557-4792-8875-5a24dfa8cfc2	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
79c4bdda-3dd1-4201-93dd-b42cb102ad22	2	2026-07-13 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-07-19 17:36:24.698842+00	2026-07-19 17:36:24.698842+00	VENTA	0cc8cee0-3a1b-4fd4-910b-aceb1ee24267	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
67c4a1c0-672e-4383-bf7c-eb77687c539a	2	2026-07-15 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	db735bfa-0343-4745-aa54-5dd0c15db45b	CLIENTE	\N	\N	2026-07-19 17:42:31.365752+00	2026-07-19 17:42:31.365752+00	VENTA	2af9b95c-9a92-4685-bdfe-2ccbcaaf92ed	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
46fce66a-5f08-43ec-9646-b8fb3dbcb599	8	2026-07-21 18:59:37.320904	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	259e6361-632b-4584-b7c8-90a8c3b411a5	SOCIO	\N	\N	2026-07-21 18:59:37.320904+00	2026-07-21 18:59:37.320904+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	17
f64d05c2-312e-4623-9062-f36281693e3f	2	2026-07-15 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-07-21 20:17:43.030846+00	2026-07-21 20:17:43.030846+00	VENTA	a96bff15-ad90-4acc-ac9f-d7b2d74c98e7	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
882f6171-e8ee-464b-a7f0-2e2e0aa3f953	2	2026-07-16 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3c6706bb-e519-439c-9ea4-36095cb6c678	CLIENTE	\N	\N	2026-07-21 20:20:02.899636+00	2026-07-21 20:20:02.899636+00	VENTA	00734614-d7ae-4b68-a0b4-7c1b860fd693	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
91511fda-0df9-457d-9a73-fa892cb93692	2	2026-07-16 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	CLIENTE	\N	\N	2026-07-21 20:23:06.949245+00	2026-07-21 20:23:06.949245+00	VENTA	4df3c0e8-f8aa-44d5-afde-9c0cb67b8561	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
01fdb02a-e03f-48d2-9fc5-242a31eb1ab2	2	2026-07-17 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-07-21 20:27:09.517244+00	2026-07-21 20:27:09.517244+00	VENTA	78be609e-d109-48e9-b670-a1e807eefd9b	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
752c07e0-a2ea-4300-98f2-b2e522d36a2f	2	2026-07-17 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	7e992fe9-d375-47b4-acb9-bbf185071bda	CLIENTE	\N	\N	2026-07-21 20:29:14.560255+00	2026-07-21 20:29:14.560255+00	VENTA	80989874-2ba5-4b86-8215-9d5d1c6bfb97	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
85ad9f1c-5b90-4369-a544-dc667d47bf15	2	2026-07-20 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	CLIENTE	\N	\N	2026-07-21 20:31:02.249434+00	2026-07-21 20:31:02.249434+00	VENTA	cbb77c2e-c120-44c1-b782-007ab766e417	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
941d858d-d42d-4583-a534-73999908e848	3	2026-07-23 05:42:49.161046	2a08da39-1889-4a3c-a67b-fe63deb762a8	CONFIRMADA	f2016a87-e798-4e74-a11b-43a2679dc5b6	\N	\N	\N	\N	\N	2026-07-23 05:42:49.161046+00	2026-07-23 05:42:49.161046+00	EGRESO	77830fda-dcaf-450a-8361-cba8efd22e33	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
d3333db7-8e91-42b9-8343-9fba3942886c	18	2026-07-26 15:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	f2016a87-e798-4e74-a11b-43a2679dc5b6	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	\N	\N	Fondeo de Caja Central, para retiro adelantado de Dividendos de Patricia.	2026-07-26 23:56:57.358252+00	2026-07-26 23:56:57.358252+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	34
a3e44623-c930-4694-aab3-d038eb0b2f60	2	2026-07-24 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	7e992fe9-d375-47b4-acb9-bbf185071bda	CLIENTE	\N	\N	2026-07-28 12:31:28.827781+00	2026-07-28 12:31:28.827781+00	VENTA	eac6103f-7117-460a-a092-1dd1434a0421	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
669aab53-97cd-4d3a-87e1-77a8292f2368	2	2026-07-24 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-07-28 12:33:45.474466+00	2026-07-28 12:33:45.474466+00	VENTA	6aac7d1f-2c7f-4685-af97-adfaeb6e9a83	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
df75aeac-0cf1-49bb-a824-9afbb8ce213c	2	2026-07-24 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	7e992fe9-d375-47b4-acb9-bbf185071bda	CLIENTE	\N	\N	2026-07-28 12:36:11.844468+00	2026-07-28 12:36:11.844468+00	VENTA	e7b9784f-b8e8-407c-b76b-4bb7f5764fc1	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
610163ec-adf1-4b3b-ba31-a26c47052e87	2	2026-07-23 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3c6706bb-e519-439c-9ea4-36095cb6c678	CLIENTE	\N	\N	2026-07-28 12:38:41.10112+00	2026-07-28 12:38:41.10112+00	VENTA	2017702b-69d0-4729-80ff-d3af4ab8b100	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
1cd50303-79cc-4a6c-a0ae-e9e6fff50fa4	2	2026-07-27 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-07-28 12:55:06.585645+00	2026-07-28 12:55:06.585645+00	VENTA	b735f45d-c9bc-4cc9-806c-1176524507d3	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
b571df08-29ab-4571-aa30-d5d55673a25e	2	2026-07-27 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-07-28 12:59:18.438289+00	2026-07-28 12:59:18.438289+00	VENTA	0648fb30-e041-407b-9b08-4c414328d015	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
ae536c28-11ab-491d-b5ad-a02c38dbdc04	2	2026-07-20 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-07-28 13:01:06.822983+00	2026-07-28 13:01:06.822983+00	VENTA	e1138a39-b377-4e7d-9db1-88eedaab0011	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
520ccb6e-a05b-4ac9-87d5-0f13a8a303fc	3	2026-07-28 13:13:39.903953	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-28 13:13:39.903953+00	2026-07-28 13:13:39.903953+00	EGRESO	2eb165e7-4820-4218-9d6b-20846bae1633	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
e7a1dc60-5bbb-473b-a676-1c5efccef7d5	3	2026-07-28 13:16:47.820635	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-28 13:16:47.820635+00	2026-07-28 13:16:47.820635+00	EGRESO	fb074af0-9489-4c48-bd27-249169b4ec5d	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
6c6bfecd-aa47-423a-bc76-a4bbeed96f4f	10	2026-07-28 13:20:56.629222	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	8855cdde-cd2a-4422-9220-041f5da8f61f	SOCIO	\N	\N	2026-07-28 13:20:56.629222+00	2026-07-28 13:20:56.629222+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	42
f14bb95d-839b-4262-a2b4-894fe0d90442	2	2026-07-31 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-07-31 03:25:49.7328+00	2026-07-31 03:25:49.7328+00	VENTA	12ebaa3a-23a3-425a-afa2-fa6d97d19345	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
4d7755cb-ea5d-4d18-8a2c-124e57e02824	10	2026-07-31 17:00:37.326167	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	8855cdde-cd2a-4422-9220-041f5da8f61f	SOCIO	\N	\N	2026-07-31 17:00:37.326167+00	2026-07-31 17:00:37.326167+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	79
73717c02-6db4-45cc-a455-7c5e3021ffed	2	2026-07-01 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	575b9d5a-7152-43b5-af6d-7bd90bc6e780	CLIENTE	\N	\N	2026-07-09 12:33:42.438072+00	2026-07-09 12:33:42.438072+00	VENTA	34256591-b222-410f-8b27-311efbc0ca97	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
426bf8db-0034-4b5f-8998-987b18d31cc4	2	2026-07-03 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-07-09 12:38:20.384258+00	2026-07-09 12:38:20.384258+00	VENTA	b246eca0-7241-4021-b5b7-4cd720e35bcd	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
a30e2a06-aa2a-49c4-b7ae-c6a1bfd24f64	2	2026-07-01 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-07-09 12:42:38.98681+00	2026-07-09 12:42:38.98681+00	VENTA	bf23060f-263a-44fd-8d57-3b6680152b08	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
d3801db4-f058-4e9b-b25c-a7f460dbc071	13	2026-07-31 23:59:59	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	\N	2a08da39-1889-4a3c-a67b-fe63deb762a8	SOCIO	\N	\N	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
c033f196-9028-4f71-b74e-179116db6b71	13	2026-07-31 23:59:59	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	\N	8855cdde-cd2a-4422-9220-041f5da8f61f	SOCIO	\N	\N	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
fef55013-c767-44f1-81e9-6fcd5c4fadb6	2	2026-06-03 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	575b9d5a-7152-43b5-af6d-7bd90bc6e780	CLIENTE	\N	\N	2026-06-19 04:30:53.285777+00	2026-06-22 14:24:00.313966+00	VENTA	49d70853-4652-454b-9419-822b7caeede1	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
6722efbf-d4df-42a8-9c8c-d3e46e9b921b	2	2026-06-03 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-19 04:32:51.146645+00	2026-06-22 14:24:00.313966+00	VENTA	f804bca9-18b7-4105-8129-7b8f63e9ca9e	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
d8e0b4e0-8452-436b-9fab-d364c3b5aeb0	2	2026-06-03 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-06-19 04:35:52.075925+00	2026-06-22 14:24:00.313966+00	VENTA	007b8f1d-a423-4ba5-8dd3-b5e724da3180	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
87a2c4cd-5518-4f72-800d-249613d24bce	2	2026-06-03 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-06-19 04:37:06.603739+00	2026-06-22 14:24:00.313966+00	VENTA	8b780d2c-5189-4172-803a-1632b72c2890	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
080776e2-5d72-4825-8c3f-dd57416f41e7	2	2026-06-04 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3c6706bb-e519-439c-9ea4-36095cb6c678	CLIENTE	\N	\N	2026-06-19 04:40:42.01634+00	2026-06-22 14:24:00.313966+00	VENTA	493b3c7e-029c-4fc1-a8a4-f690dcf0401c	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
5acbea1f-b7c5-4f5b-91c4-fe8eab9a8025	13	2026-07-31 23:59:59	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	\N	259e6361-632b-4584-b7c8-90a8c3b411a5	SOCIO	\N	\N	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
f8032098-ad1d-4308-8020-c3f41e1749ff	2	2026-06-04 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	CLIENTE	\N	\N	2026-06-22 11:54:06.796917+00	2026-06-22 14:24:00.313966+00	VENTA	d185c422-7924-4918-9cac-f536a7d6783e	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
54ce5480-86b9-4fdc-873f-d06afa700d56	2	2026-06-04 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	ae45363b-7cb9-47d6-befd-0f8d058ea3eb	CLIENTE	\N	\N	2026-06-22 11:57:11.861703+00	2026-06-22 14:24:00.313966+00	VENTA	dd4bacb2-b66e-4684-afce-ef3607a88f64	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
b6878022-4c6a-4e32-8b11-25f2b89002d2	2	2026-06-05 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	db735bfa-0343-4745-aa54-5dd0c15db45b	CLIENTE	\N	\N	2026-06-22 12:00:02.169845+00	2026-06-22 14:24:00.313966+00	VENTA	b2287a3d-ce8f-4d2f-bad4-bbe12e58de8c	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
2f7b081e-16f7-43f9-b2ac-b59415df6f7e	2	2026-06-05 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-06-22 12:02:31.448238+00	2026-06-22 14:24:00.313966+00	VENTA	1c577f66-ef47-48b0-a8a6-50126d1183f5	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
4832ece6-8fce-40de-b978-2169d0d7bf9f	2	2026-06-05 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-22 12:04:09.667167+00	2026-06-22 14:24:00.313966+00	VENTA	a13ffb73-62e3-4499-8370-975121e99ba6	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
d4aed9a7-31d3-4945-84a1-39f1dc35600a	2	2026-06-05 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-06-22 12:10:12.197307+00	2026-06-22 14:24:00.313966+00	VENTA	a2838726-29d8-4fe7-9497-cfa20da0892c	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
7037c5fc-9a78-46c3-857f-3f2c75b2d7a6	2	2026-06-05 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	7e992fe9-d375-47b4-acb9-bbf185071bda	CLIENTE	\N	\N	2026-06-22 12:11:15.291194+00	2026-06-22 14:24:00.313966+00	VENTA	c41cc71e-5a93-473d-8017-968b9bc8323d	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
c4fea509-2d18-4bac-bf9d-18cfa6d4823a	2	2026-06-05 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	beca476c-87f4-48cf-adeb-90b904d48a10	CLIENTE	\N	\N	2026-06-22 12:12:53.106907+00	2026-06-22 14:24:00.313966+00	VENTA	317b6891-99dc-49a5-9baa-cc5f36ae0fa5	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
b2959fd6-ab7d-42fa-b798-2724de78b24a	2	2026-06-06 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	575b9d5a-7152-43b5-af6d-7bd90bc6e780	CLIENTE	\N	\N	2026-06-22 12:14:23.830753+00	2026-06-22 14:24:00.313966+00	VENTA	63ffd0fa-c1c0-41e6-a588-1c160c756217	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
c18eefeb-2e4e-4098-81b7-22fe3f61eefb	2	2026-06-08 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-06-22 12:17:08.469447+00	2026-06-22 14:24:00.313966+00	VENTA	4c4bc996-3a72-4f73-9918-5e261c79d0eb	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
0b15d928-f703-4118-8fe4-3d2ffb1c1e1d	2	2026-06-08 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-22 12:17:58.263968+00	2026-06-22 14:24:00.313966+00	VENTA	84a3d414-e734-4364-89ea-02ff7a53bf90	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
52497025-847d-4a1f-bf1f-6212bc2981e8	2	2026-06-08 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-06-22 12:18:47.312853+00	2026-06-22 14:24:00.313966+00	VENTA	87cc40f2-9e57-414e-9ef6-b784691c2759	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
87a67e6f-ef47-482c-9b6d-bb6325c58dd3	2	2026-06-08 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	CLIENTE	\N	\N	2026-06-22 12:20:17.988002+00	2026-06-22 14:24:00.313966+00	VENTA	571ca198-ca4f-40c3-8254-e813922b76d9	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
e7c220ab-1903-4b2c-84e9-4010db3be2b8	2	2026-06-10 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-06-22 12:21:10.20233+00	2026-06-22 14:24:00.313966+00	VENTA	17f303ca-9003-4aec-a554-60e68579c17e	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
ea032237-ec7f-4561-92d1-9220ebe2250f	2	2026-06-10 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-22 12:21:52.374101+00	2026-06-22 14:24:00.313966+00	VENTA	b48fe808-7668-4d53-ba45-9efcac9ab9e6	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
bfdaa095-8845-4555-8511-461b43f16673	2	2026-06-10 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-06-22 12:23:24.963704+00	2026-06-22 14:24:00.313966+00	VENTA	8f108d53-a2fe-4205-87a9-2d3b39034110	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
93da5b67-7615-44a4-8976-4249f483ddb4	2	2026-06-12 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-06-22 12:24:43.332879+00	2026-06-22 14:24:00.313966+00	VENTA	dc5e9eac-3542-4690-b0ae-03f43c81252f	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
3a7b14fb-7a5e-4381-8ce1-d526bfac8c0a	2	2026-06-12 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-22 12:25:39.465747+00	2026-06-22 14:24:00.313966+00	VENTA	d5845dc2-f1d0-42bb-b87b-d6d09f044431	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
4d538fe2-bf28-4e52-b2af-cfb05b6f3537	2	2026-06-12 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	db735bfa-0343-4745-aa54-5dd0c15db45b	CLIENTE	\N	\N	2026-06-22 12:26:53.23068+00	2026-06-22 14:24:00.313966+00	VENTA	f70adcf3-d2d2-4b8d-804c-68610ed560a8	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
60a73379-23c0-4494-87d8-89e5e4a8021a	2	2026-06-12 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	7e992fe9-d375-47b4-acb9-bbf185071bda	CLIENTE	\N	\N	2026-06-22 12:29:02.877621+00	2026-06-22 14:24:00.313966+00	VENTA	36c8bd18-7284-42ca-889b-63d87b15a78f	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
e7501a63-ca24-4b49-9870-12ef349783d8	2	2026-06-10 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-06-22 12:31:25.167271+00	2026-06-22 14:24:00.313966+00	VENTA	10494094-7a23-4270-966e-9c1d02e62d65	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
c1d93875-771a-4c17-ac8f-626d0cfbcef5	2	2026-06-11 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3c6706bb-e519-439c-9ea4-36095cb6c678	CLIENTE	\N	\N	2026-06-22 12:32:54.63034+00	2026-06-22 14:24:00.313966+00	VENTA	ca2a904a-e22b-4709-a314-ceeeb8f3691d	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
87a6db66-ab2a-417b-bba3-34477f15b3de	2	2026-06-15 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-06-22 12:39:26.043965+00	2026-06-22 14:24:00.313966+00	VENTA	3bd0e3bc-c051-48ba-b3e3-c57736a5290c	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
ede82d5d-10c3-48a8-8268-e316f4c7c559	2	2026-06-15 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-06-22 12:40:34.294196+00	2026-06-22 14:24:00.313966+00	VENTA	6f5e9a40-d0c7-442e-9c11-037e36f21670	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
be17aaa5-689a-49d6-a601-4c39cde84b25	2	2026-06-15 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-22 12:41:34.798974+00	2026-06-22 14:24:00.313966+00	VENTA	58d6bfbd-c188-4362-bf46-8d0c4ff215b5	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
8c5bf80a-aeff-4671-a9f9-46d699c8a738	2	2026-06-16 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-06-22 12:42:30.909684+00	2026-06-22 14:24:00.313966+00	VENTA	697218c2-76c0-447e-a4fc-b8353ecde81b	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
d935f23e-51e9-4992-8363-e2ef0ccf2fce	2	2026-06-16 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-22 12:45:47.551971+00	2026-06-22 14:24:00.313966+00	VENTA	fe84c328-e264-4abc-9f2f-400f209afefa	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
f1da69a2-4f04-45c2-a1cd-f6f16f94ea5c	2	2026-07-06 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-07-19 17:20:01.883488+00	2026-07-19 17:20:01.883488+00	VENTA	00b2d302-308b-42ca-a711-89741e5cdcbe	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
886118c4-cad4-4835-8acb-cf749e70f463	2	2026-07-06 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	170cec38-63b0-4969-92a7-ec872bebc116	CLIENTE	\N	\N	2026-07-19 17:25:14.548548+00	2026-07-19 17:25:14.548548+00	VENTA	72fb6044-5610-43fe-90c8-2cc5ff69c86f	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
df33b3a5-a244-4dac-83cd-f61b48020fba	2	2026-06-17 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-06-22 12:48:15.680194+00	2026-06-22 14:24:00.313966+00	VENTA	fa937de3-7822-4d7b-8e23-ded1426a2085	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
00b5f933-2ed2-4504-92fa-89f29c171036	2	2026-06-17 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	575b9d5a-7152-43b5-af6d-7bd90bc6e780	CLIENTE	\N	\N	2026-06-22 12:50:57.21166+00	2026-06-22 14:24:00.313966+00	VENTA	b72244b1-977d-423e-b863-60fbe7d62bd7	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
da710c5f-5fa2-4fd2-9d4f-b0b90094dc03	2	2026-06-18 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3c6706bb-e519-439c-9ea4-36095cb6c678	CLIENTE	\N	\N	2026-06-22 12:54:13.012093+00	2026-06-22 14:24:00.313966+00	VENTA	f34fa3a5-b67c-422d-8d88-ab734ac2a312	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
ac346a5a-f79d-4bdf-9ab1-c33ae103cccd	2	2026-06-18 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	CLIENTE	\N	\N	2026-06-22 12:55:18.84808+00	2026-06-22 14:24:00.313966+00	VENTA	01742e1e-8dee-458b-b22c-6b140b5c0dea	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
61e318ad-6c54-44a5-a431-39396870caf7	2	2026-06-18 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	beca476c-87f4-48cf-adeb-90b904d48a10	CLIENTE	\N	\N	2026-06-22 12:56:12.750673+00	2026-06-22 14:24:00.313966+00	VENTA	44191426-9626-4ef9-afc9-72dc89f1a732	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
20abb5cd-117b-47a8-9ac5-96e37e981089	2	2026-06-19 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-22 12:57:24.175117+00	2026-06-22 14:24:00.313966+00	VENTA	f13dc362-e0bd-40ca-ac82-6859fb5220ec	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
e3e21f18-5724-4feb-aaa6-2d19bd3afb42	2	2026-06-19 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-06-22 12:58:14.378136+00	2026-06-22 14:24:00.313966+00	VENTA	bca315e2-dd3c-458e-9b67-82a444a3b6f1	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
3204ecbb-04f6-4173-987c-c0bea6936c0c	2	2026-06-18 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	CLIENTE	\N	\N	2026-06-22 12:59:19.494236+00	2026-06-22 14:24:00.313966+00	VENTA	c896909f-850a-455f-9ca4-773bfe5ea508	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
df4147bc-e554-4eaa-aa4c-368e1ac60d20	2	2026-06-22 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3249bfe8-6aeb-449c-a605-647b9cae453c	CLIENTE	\N	\N	2026-06-22 13:04:47.39348+00	2026-06-22 14:24:00.313966+00	VENTA	4a4eba49-618c-4e36-93f5-78117d2a956b	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
7a13aeec-e56e-43f3-be15-e4c6da50547c	2	2026-06-13 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	CLIENTE	\N	\N	2026-06-22 13:11:03.937117+00	2026-06-22 14:24:00.313966+00	VENTA	628bcc85-4d0d-48ae-b47b-74a373138839	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
304dfd30-c1eb-4766-bcee-5b8910a90ef4	3	2026-06-26 13:57:59.336724	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-06-26 13:57:59.336724+00	2026-06-26 13:57:59.336724+00	EGRESO	74abfe5c-a8d1-485b-ba12-74215dea3f7b	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
d6bc8b7b-aa8e-4430-8bec-b67f72d51cd7	2	2026-06-22 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-06-26 15:34:38.096916+00	2026-06-26 15:34:38.096916+00	VENTA	115e199b-2922-48a1-a4e6-0fd365c4709b	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
a481296e-480c-4ee6-827b-15d1de6107fb	2	2026-06-22 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-26 15:36:49.591976+00	2026-06-26 15:36:49.591976+00	VENTA	551c6689-b5e8-4ffa-9a02-b323f7cdeecc	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
009c942c-1e92-4876-82a3-63ef50a130cf	2	2026-06-22 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-06-26 15:39:08.235263+00	2026-06-26 15:39:08.235263+00	VENTA	5318c470-e889-460a-9eac-78c18942fa93	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
4c1450dc-e823-4079-a111-8a00aaf3e468	2	2026-06-22 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	575b9d5a-7152-43b5-af6d-7bd90bc6e780	CLIENTE	\N	\N	2026-06-26 15:40:21.78731+00	2026-06-26 15:40:21.78731+00	VENTA	527a3fa7-ba92-4930-bae1-8c198644e399	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
c0df15c1-fa8a-4c6a-aa6e-6349ed052001	3	2026-06-26 15:44:01.427853	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-06-26 15:44:01.427853+00	2026-06-26 15:44:01.427853+00	EGRESO	1c64dbe3-ea47-4cf3-9f40-5d80e40c5460	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
024b2bef-f569-4a67-b0c8-712d1609ec24	3	2026-06-26 15:47:04.965522	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-06-26 15:47:04.965522+00	2026-06-26 15:47:04.965522+00	EGRESO	8032d08d-83f1-4d71-a9d7-cc0875fb8493	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
f85c2063-02c8-4a9f-8f2a-2f27f942a564	3	2026-06-26 15:48:49.550982	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-06-26 15:48:49.550982+00	2026-06-26 15:48:49.550982+00	EGRESO	c21b486b-bcd1-4fff-8bc7-9d1993ce09d3	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
c6d398dc-3f6d-4a6b-945c-35653027ccf9	3	2026-06-26 15:53:10.652051	2a08da39-1889-4a3c-a67b-fe63deb762a8	CONFIRMADA	f2016a87-e798-4e74-a11b-43a2679dc5b6	\N	\N	\N	\N	\N	2026-06-26 15:53:10.652051+00	2026-06-26 15:53:10.652051+00	EGRESO	216376b6-b1e4-4052-b532-789d0cb58f39	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
08665cf2-337f-4b71-942d-3da529b1aac9	3	2026-06-26 15:54:13.211797	2a08da39-1889-4a3c-a67b-fe63deb762a8	CONFIRMADA	f2016a87-e798-4e74-a11b-43a2679dc5b6	\N	\N	\N	\N	\N	2026-06-26 15:54:13.211797+00	2026-06-26 15:54:13.211797+00	EGRESO	baa6c125-cb62-43b1-9fe8-1c6acd628d56	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
3f5430d0-b69f-429e-88fe-3309bb9e2969	3	2026-06-26 15:55:37.429575	2a08da39-1889-4a3c-a67b-fe63deb762a8	CONFIRMADA	f2016a87-e798-4e74-a11b-43a2679dc5b6	\N	\N	\N	\N	\N	2026-06-26 15:55:37.429575+00	2026-06-26 15:55:37.429575+00	EGRESO	0f16ad90-d250-4a13-beae-02918ccffb2d	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
ca7d010a-4f5d-46e0-ba4c-26439a0ddbdb	2	2026-07-31 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-07-31 03:27:57.546374+00	2026-07-31 03:27:57.546374+00	VENTA	196e9aa0-d105-448d-9b93-93e787c121ab	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
f41db1e1-ad96-409f-866e-277a7664ac5a	2	2026-06-29 21:30:17.441938	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	\N	88ce6836-bb6c-4380-863d-7a8c5957d906	469c1269-5dd0-453b-99ca-a00adf8ebf87	CLIENTE	\N	\N	2026-06-29 21:30:17.441938+00	2026-06-29 21:30:17.441938+00	VENTA	7d1084e5-b9db-475d-b230-61631e60324f	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
d0292698-af8b-4a6f-a033-dd754ad51de6	1	2026-06-29 21:33:35.364906	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	88ce6836-bb6c-4380-863d-7a8c5957d906	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	Rendición diaria repartidor	2026-06-29 21:33:35.364906+00	2026-06-29 21:33:35.364906+00	\N	\N	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
748bc60d-1bb9-49a3-bb9d-6aa9ac15643e	3	2026-06-30 12:26:45.829535	2a08da39-1889-4a3c-a67b-fe63deb762a8	CONFIRMADA	f2016a87-e798-4e74-a11b-43a2679dc5b6	\N	\N	\N	\N	\N	2026-06-30 12:26:45.829535+00	2026-06-30 12:26:45.829535+00	EGRESO	45b1af66-f64b-4ce2-b488-3201d72ae06d	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
42973042-52ad-4790-bddc-2a43fabf72f3	3	2026-06-30 12:43:25.474304	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-06-30 12:43:25.474304+00	2026-06-30 12:43:25.474304+00	EGRESO	1dcfa50b-3338-45f4-b3d7-88361c7c95f5	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
604b3faa-13a4-41ab-8d3d-4975cdb01d6c	3	2026-06-30 12:44:18.914982	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-06-30 12:44:18.914982+00	2026-06-30 12:44:18.914982+00	EGRESO	2e869684-2432-41a0-a8de-2250199bd0a4	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
fc8fb835-ef74-4b10-9864-6350baba9fc9	11	2026-06-30 12:49:13.162251	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	f2016a87-e798-4e74-a11b-43a2679dc5b6	\N	\N	\N	21/6/2026	2026-06-30 12:49:13.162251+00	2026-06-30 12:49:13.162251+00	\N	\N	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
6dfdbf95-e527-4888-8b0e-018222e0c257	2	2026-06-24 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	575b9d5a-7152-43b5-af6d-7bd90bc6e780	CLIENTE	\N	\N	2026-06-30 13:08:05.373579+00	2026-06-30 13:08:05.373579+00	VENTA	e9606946-3545-4180-8d96-2c74eeedb662	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
9528f35c-dfd3-4260-9abb-22b88313665d	2	2026-06-26 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3c6706bb-e519-439c-9ea4-36095cb6c678	CLIENTE	\N	\N	2026-06-30 13:11:45.932917+00	2026-06-30 13:11:45.932917+00	VENTA	88099e84-762a-47a7-90c0-bdce1a66b9f7	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
6e510b80-02bb-4ac6-8534-bf188d81cf63	2	2026-06-26 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	7e992fe9-d375-47b4-acb9-bbf185071bda	CLIENTE	\N	\N	2026-06-30 13:13:11.487218+00	2026-06-30 13:13:11.487218+00	VENTA	7b33a6b7-ab46-4d21-9684-4c3fe05a1a55	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
7097b34e-6a94-4335-a2b9-500c7afec1b6	2	2026-06-26 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-06-30 13:16:13.31843+00	2026-06-30 13:16:13.31843+00	VENTA	4e423182-706d-4218-bfa0-f4b7af3bb0b9	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
8fb54c2f-f50f-4042-9a01-d0199ea95b57	2	2026-06-26 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-06-30 13:17:17.975895+00	2026-06-30 13:17:17.975895+00	VENTA	7101d972-7b99-417b-8e7d-55dbaff920c9	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
a9382fd3-203f-40f7-9703-e9fcc555e01f	2	2026-06-23 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	CLIENTE	\N	\N	2026-06-30 13:19:35.252977+00	2026-06-30 13:19:35.252977+00	VENTA	7ce777ee-51e0-4863-a637-8ca5aa89d05c	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
5cbf6b16-73c0-4174-a520-9456336d02a7	2	2026-06-24 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-06-30 13:22:23.016304+00	2026-06-30 13:22:23.016304+00	VENTA	af3160eb-a205-4fde-b0cd-a4edc96c386a	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
0b3b7538-4102-4a93-9247-c093904bcec4	2	2026-06-26 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-30 13:26:44.362654+00	2026-06-30 13:26:44.362654+00	VENTA	8ea0dce0-24cc-4b24-a0c8-118b0db24736	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
55057975-723c-4ce4-9214-d497fab8448c	2	2026-06-30 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	CLIENTE	\N	\N	2026-06-30 14:02:42.949324+00	2026-06-30 14:02:42.949324+00	VENTA	2f62512f-ccc3-45ee-a0f3-227ac57c4a3a	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
a3ee3da1-39ee-4841-8f66-142c3053a3f8	2	2026-06-29 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3249bfe8-6aeb-449c-a605-647b9cae453c	CLIENTE	\N	\N	2026-06-30 14:07:28.751543+00	2026-06-30 14:07:28.751543+00	VENTA	c65f4643-4b84-43b9-8e2c-6870f06e29d7	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
f67b3db7-3ebc-45e6-ae32-0e2d401f161c	2	2026-06-29 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-30 14:09:52.622324+00	2026-06-30 14:09:52.622324+00	VENTA	a01e692c-973e-455b-ad10-7e5774ffa206	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
59f15734-8aed-437c-8947-f0b126d4871e	2	2026-06-29 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-06-30 14:11:44.67418+00	2026-06-30 14:11:44.67418+00	VENTA	9be7c326-9a4c-4521-8700-a23113923bb4	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
6cd21f5e-f050-4856-af8a-c1a9c881d79d	2	2026-06-29 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-06-30 14:13:11.44965+00	2026-06-30 14:13:11.44965+00	VENTA	72782f24-2f31-40ed-af31-ce5a739154db	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
c47ddd3b-8e51-44bb-8f19-7cd49dfc9646	2	2026-06-06 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	170cec38-63b0-4969-92a7-ec872bebc116	CLIENTE	\N	\N	2026-06-30 14:55:40.575433+00	2026-06-30 14:55:40.575433+00	VENTA	1689ef65-5132-4c7f-a938-0c98bfa683c0	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
16b6f122-7cd8-46e7-8ac3-952b88e5a55d	2	2026-06-30 15:23:41.095773	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	469c1269-5dd0-453b-99ca-a00adf8ebf87	CLIENTE	\N	\N	2026-06-30 15:23:41.095773+00	2026-06-30 15:23:41.095773+00	VENTA	38367469-d996-4215-90ab-4bb78dd8f923	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
cdba642d-81e4-447e-af8a-3dcbe6ea03e6	2	2026-07-31 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	CLIENTE	\N	\N	2026-07-31 03:30:24.504247+00	2026-07-31 03:30:24.504247+00	VENTA	7414e697-94c7-4f60-afcf-c951238cb5a3	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
d3685083-8ce8-4304-b7fe-201e1b1e65f9	3	2026-06-30 14:05:48.882156	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-01 14:05:48.882156+00	2026-07-02 16:03:49.852046+00	EGRESO	76e4e23e-207a-4e89-bef4-4d065954cadb	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
69621422-2681-4606-ab2f-ba6f96f8f64f	3	2026-06-30 14:12:41.868581	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-01 14:12:41.868581+00	2026-07-02 16:03:49.852046+00	EGRESO	17cd798f-5dfc-45db-8f56-7c1c61cdb1e0	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
52059cd5-f19a-4912-85d8-50762ab8ced9	3	2026-06-30 14:13:35.068271	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-01 14:13:35.068271+00	2026-07-02 16:03:49.852046+00	EGRESO	42501e2c-5f54-4b6e-b555-ed181ca0d5ed	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
ae3ddbe8-1a76-4bc3-9aca-f7a6f2316434	3	2026-06-30 14:14:27.713794	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-01 14:14:27.713794+00	2026-07-02 16:03:49.852046+00	EGRESO	172cd1ac-a530-42f8-ad7c-b62f9e65c0ee	\N	3cc69ffa-6f76-4970-bc03-4e5ee0153175	\N
5cc5b701-31c8-4221-9021-270ddab0312c	2	2026-07-01 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-07-09 12:30:59.263762+00	2026-07-09 12:30:59.263762+00	VENTA	97126300-4dbc-46a2-aa0b-4efa71d764b4	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
8ae13712-7e67-4dc7-8fac-eb02f8c6d86d	2	2026-07-02 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3c6706bb-e519-439c-9ea4-36095cb6c678	CLIENTE	\N	\N	2026-07-09 12:36:25.96423+00	2026-07-09 12:36:25.96423+00	VENTA	1cc32153-fd17-4e31-a7fb-8a3d622781c5	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
c5593964-c83e-48c8-ad30-ca48e7b86a3c	2	2026-07-03 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-07-09 12:39:14.952396+00	2026-07-09 12:39:14.952396+00	VENTA	2797cc16-57c2-4b55-81a0-f5a23bac2f28	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
ea62e998-c467-49b5-ad79-d169ee6cda41	8	2026-07-14 07:48:45.300016	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	2a08da39-1889-4a3c-a67b-fe63deb762a8	SOCIO	\N	\N	2026-07-14 07:48:45.300016+00	2026-07-14 07:48:45.300016+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	15
3b897f61-30c6-4775-9414-75c89109ea0d	3	2026-07-31 21:03:51.661423	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-31 21:03:51.661423+00	2026-07-31 21:03:51.661423+00	EGRESO	838bf1ba-135e-429a-a496-57ccbd897e57	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
56dae58f-ebb9-47b1-9182-ae4fb831d7d4	6	2026-07-31 23:59:59	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	\N	\N	\N	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
2d83904c-3869-4e1e-a675-e2880422f00d	2	2026-07-06 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3249bfe8-6aeb-449c-a605-647b9cae453c	CLIENTE	\N	\N	2026-07-19 17:21:57.88095+00	2026-07-19 17:21:57.88095+00	VENTA	883b349b-cc83-4bd3-9b03-9e9441dcc35d	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
8f09741b-eaa8-45e4-bd0c-06be6f7a410d	2	2026-07-08 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-07-19 17:25:53.385734+00	2026-07-19 17:25:53.385734+00	VENTA	3e36ab98-2292-47f2-9790-ff9c61179100	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
2b3b5739-7950-4d2e-a348-ab6a873d89c2	2	2026-07-09 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3c6706bb-e519-439c-9ea4-36095cb6c678	CLIENTE	\N	\N	2026-07-19 17:28:33.061417+00	2026-07-19 17:28:33.061417+00	VENTA	4f7ec5be-774e-4c2f-9247-56597747bd30	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
e5e8480a-cc59-4acd-83c5-34fb49e89daf	2	2026-07-09 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	7e992fe9-d375-47b4-acb9-bbf185071bda	CLIENTE	\N	\N	2026-07-19 17:31:09.207138+00	2026-07-19 17:31:09.207138+00	VENTA	03848e89-39a7-43cd-8b6a-c943171b2dbb	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
2db8fd70-d4ff-4cf8-a6d7-ad8e91f46127	2	2026-07-10 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	7e992fe9-d375-47b4-acb9-bbf185071bda	CLIENTE	\N	\N	2026-07-19 17:33:49.948156+00	2026-07-19 17:33:49.948156+00	VENTA	b849d43d-e4a6-4aed-862c-e35460fbdecb	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
ffbb11d4-e7ed-4773-b9fd-845becde810e	2	2026-07-10 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-07-19 17:35:37.410654+00	2026-07-19 17:35:37.410654+00	VENTA	d0e8ebd9-1e93-419b-91e2-481a6c2a6d92	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
52363d4f-f4cb-43b4-a838-0b70bc800e5c	2	2026-07-13 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-07-19 17:38:58.237263+00	2026-07-19 17:38:58.237263+00	VENTA	54347062-c438-4699-8b35-a297b7326ceb	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
af25c185-fd20-42ba-b14d-90bf4faf4005	2	2026-07-15 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	575b9d5a-7152-43b5-af6d-7bd90bc6e780	CLIENTE	\N	\N	2026-07-19 17:41:29.956024+00	2026-07-19 17:41:29.956024+00	VENTA	62438726-116a-4fa4-88a9-cb3171a0fb23	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
0fab4864-0955-4c3b-8574-0e5b6743dcfc	8	2026-07-21 18:56:12.760376	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	2a08da39-1889-4a3c-a67b-fe63deb762a8	SOCIO	\N	\N	2026-07-21 18:56:12.760376+00	2026-07-21 18:56:12.760376+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	16
2b9b43e1-e4a3-4c87-804f-7ddc949dbd90	2	2026-07-15 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	575b9d5a-7152-43b5-af6d-7bd90bc6e780	CLIENTE	\N	\N	2026-07-21 20:02:35.562145+00	2026-07-21 20:02:35.562145+00	VENTA	15f22141-23dd-44c5-8dd2-95ce74c34f09	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
6884eaeb-a9aa-48ac-8abd-dfd325effa99	2	2026-07-15 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-07-21 20:18:41.046646+00	2026-07-21 20:18:41.046646+00	VENTA	7dd8440e-3c68-4c65-a08e-51157b687af1	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
f63ce3e3-a152-4328-86c3-f36ba6a7679f	2	2026-07-16 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3249bfe8-6aeb-449c-a605-647b9cae453c	CLIENTE	\N	\N	2026-07-21 20:21:47.517095+00	2026-07-21 20:21:47.517095+00	VENTA	5ea2cc34-2e66-460e-873a-057ef872dceb	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
a0fb0f25-fbb7-4a56-abfc-23e5517939d2	2	2026-07-17 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-07-21 20:25:01.976113+00	2026-07-21 20:25:01.976113+00	VENTA	f463dc19-3f68-4ae7-937d-59ba11ff1255	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
d722132f-f34c-4542-928d-d195af81ff5f	2	2026-07-17 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-07-21 20:28:20.423596+00	2026-07-21 20:28:20.423596+00	VENTA	a152067d-0684-4ca6-be03-92e9e3c75184	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
8bcda406-9b0d-41f0-854b-51a4a91c394b	2	2026-07-20 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-07-21 20:30:11.139901+00	2026-07-21 20:30:11.139901+00	VENTA	d2875995-79bb-4cb8-841b-43a636539638	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
04750226-ea44-4006-806d-1520120af314	8	2026-07-25 01:18:51.93948	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	8855cdde-cd2a-4422-9220-041f5da8f61f	SOCIO	\N	\N	2026-07-25 01:18:51.93948+00	2026-07-25 01:18:51.93948+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	33
77087c85-c563-480d-9a98-d83f6b49634f	10	2026-07-27 00:06:12.514247	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	8855cdde-cd2a-4422-9220-041f5da8f61f	SOCIO	\N	\N	2026-07-27 00:06:12.514247+00	2026-07-27 00:06:12.514247+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	39
8276d3cb-a43a-4cde-8d79-1708e4225d91	2	2026-07-24 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	CLIENTE	\N	\N	2026-07-28 12:32:44.872623+00	2026-07-28 12:32:44.872623+00	VENTA	3581af9a-33aa-4c4c-b720-cb71d2ae4901	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
a8404959-0798-4ac2-bb91-2aada87c1010	2	2026-07-24 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-07-28 12:34:33.531739+00	2026-07-28 12:34:33.531739+00	VENTA	f6525a98-af76-4176-aef5-fd0fb627f797	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
a915f244-1041-4c7a-83ad-9c85653f0f4d	2	2026-07-23 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3249bfe8-6aeb-449c-a605-647b9cae453c	CLIENTE	\N	\N	2026-07-28 12:37:26.642761+00	2026-07-28 12:37:26.642761+00	VENTA	e30d341f-e131-4f15-a0e4-90dd63185938	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
606e7bf0-b52d-4ca6-9402-8de8ce6b9b54	2	2026-07-22 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-07-28 12:39:38.845234+00	2026-07-28 12:39:38.845234+00	VENTA	b05190ff-1ad6-4b03-9108-bd5f8e9e6148	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
e5349457-97cd-45b7-938d-2c9c25fc3844	2	2026-07-21 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-07-28 12:58:16.52675+00	2026-07-28 12:58:16.52675+00	VENTA	cbcaa551-5761-436d-ae52-2811789a83d4	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
84f2e240-e621-4b6d-bf8c-f2212e885c28	2	2026-07-27 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	10a150de-5f46-47af-a303-30e1bcd42f90	CLIENTE	\N	\N	2026-07-28 13:00:14.014612+00	2026-07-28 13:00:14.014612+00	VENTA	009ed6cd-13cd-4a95-9874-a2dea0c9f217	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
96c2d3ee-38d8-49f5-acd4-fcab1211c814	3	2026-07-28 13:11:39.986643	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-28 13:11:39.986643+00	2026-07-28 13:11:39.986643+00	EGRESO	65617666-1bce-41a8-9191-f1f9b8264d3d	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
b3f001f4-16ca-4c36-a8c1-bb14bef1818c	3	2026-07-28 13:15:59.974801	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-28 13:15:59.974801+00	2026-07-28 13:15:59.974801+00	EGRESO	63d6bca1-5b47-4a36-85f2-bae6c56a1016	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
df89d709-91cd-4cf0-8fd2-a194a55f0bf5	18	2026-07-28 15:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	f2016a87-e798-4e74-a11b-43a2679dc5b6	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	\N	\N	Fondear Caja Central	2026-07-28 13:20:19.13951+00	2026-07-28 13:20:19.13951+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	41
3c031f48-c661-4910-8afb-c020b26758d8	3	2026-07-28 19:56:49.632065	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-28 19:56:49.632065+00	2026-07-28 19:56:49.632065+00	EGRESO	ed9ac0f3-4053-43ef-a7c6-8e1fb4fa1406	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
417dc165-9fe9-4e35-bc15-4f1d22683354	3	2026-07-29 16:39:21.001716	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-29 16:39:21.001716+00	2026-07-29 16:39:21.001716+00	EGRESO	34150dd6-8189-437a-a6e1-80b08370ed8c	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
74dd49b4-4a02-4bec-84b3-1e72d400504c	2	2026-07-31 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	CLIENTE	\N	\N	2026-07-31 03:32:06.032538+00	2026-07-31 03:32:06.032538+00	VENTA	3e6e0750-9c79-4b9b-9045-5f053d49f22d	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
44b8fa4d-ed63-47f3-8c9e-2b342367fbd9	2	2026-07-29 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	6f5a2c3a-7240-4f3c-bc02-41accaad8a44	CLIENTE	\N	CORR-CAJA-2026-07-31: caja destino reapuntada de Caja Rodolfo Rolando a Caja Javier Benitez (el cobro fisico lo hizo Javier).	2026-07-30 15:55:32.587417+00	2026-07-31 13:30:41.74437+00	VENTA	add06fe4-df20-4f02-8802-eea46aeec65a	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
9321558b-41db-4340-bbaa-3e7af9bee03a	18	2026-07-01 15:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	\N	\N	Fondeo para adelanto Javier	2026-07-30 00:50:30.924103+00	2026-07-30 00:50:30.924103+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	45
eee91392-638f-4e63-ae95-07618b73233c	14	2026-07-31 23:59:59	2a08da39-1889-4a3c-a67b-fe63deb762a8	CONFIRMADA	f2016a87-e798-4e74-a11b-43a2679dc5b6	\N	2a08da39-1889-4a3c-a67b-fe63deb762a8	SOCIO	\N	\N	2026-08-01 13:07:51.19579+00	2026-08-01 14:56:35.887997+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	80
84ad83fb-589a-424b-a015-74e0aeeb3f40	10	2026-07-01 15:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	2a08da39-1889-4a3c-a67b-fe63deb762a8	SOCIO	\N	\N	2026-07-30 04:01:56.285608+00	2026-07-30 04:01:56.285608+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	70
b4678879-776d-4b1b-94d6-7c224dfb94e1	18	2026-07-23 15:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	\N	\N	Fondeo Caja Central, para otorgar ADELANTO a otro socio	2026-07-30 04:06:15.654521+00	2026-07-30 04:06:15.654521+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	71
258307dd-a0cf-4596-8669-c835d4fea220	10	2026-07-23 15:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	2a08da39-1889-4a3c-a67b-fe63deb762a8	SOCIO	\N	\N	2026-07-30 04:08:05.088588+00	2026-07-30 04:08:05.088588+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	72
0d27bc62-2cf0-4693-ae76-4008badab240	18	2026-07-29 15:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	\N	\N	Fondeo de CC para otorgar ADELANTO a otro Socio	2026-07-30 04:12:27.506811+00	2026-07-30 04:12:27.506811+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	73
64fa5586-7eb9-4d17-95c0-f8cdfad2a5e2	10	2026-07-29 15:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	2a08da39-1889-4a3c-a67b-fe63deb762a8	SOCIO	\N	\N	2026-07-30 04:13:04.535086+00	2026-07-30 04:13:04.535086+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	74
9a14921a-94aa-4458-aec8-efe4289110c6	2	2026-07-29 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	f2016a87-e798-4e74-a11b-43a2679dc5b6	819465e3-bd53-4571-897b-e4a9d4cae03d	CLIENTE	\N	\N	2026-07-30 15:53:09.315009+00	2026-07-30 15:53:09.315009+00	VENTA	b5562eec-d4d4-4351-a218-040d00f6f48e	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
44ee7f0c-5228-4094-aa9f-e746de1238ed	2	2026-07-29 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	575b9d5a-7152-43b5-af6d-7bd90bc6e780	CLIENTE	\N	\N	2026-07-30 15:53:57.892845+00	2026-07-30 15:53:57.892845+00	VENTA	28eee34d-d2e2-4338-9ec3-a275d4bc559c	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
7d63dd99-59ef-4c05-8db6-40ac6fcdee7f	2	2026-07-30 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3c6706bb-e519-439c-9ea4-36095cb6c678	CLIENTE	\N	\N	2026-07-30 15:57:21.995101+00	2026-07-30 15:57:21.995101+00	VENTA	b849a1fd-026a-4b16-b1e1-452eb66bce4f	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
6e64709e-0b4f-42b3-9380-1810211e460d	2	2026-07-30 03:00:00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	CONFIRMADA	\N	300b4667-734d-45e0-a92a-a78737f75eb8	3249bfe8-6aeb-449c-a605-647b9cae453c	CLIENTE	\N	\N	2026-07-30 15:59:42.072974+00	2026-07-30 15:59:42.072974+00	VENTA	43dc8a2a-4e24-4a44-b359-f833c1482583	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
0149ec9e-2db1-435e-b147-0d1670a0b002	3	2026-07-30 16:13:34.110178	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	\N	\N	\N	\N	\N	2026-07-30 16:13:34.110178+00	2026-07-30 16:13:34.110178+00	EGRESO	5f906378-457c-4d2d-8ce7-c272f6e19e63	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	\N
aa94aa1d-77a5-4045-8709-116e7925b9eb	18	2026-07-01 15:00:00	259e6361-632b-4584-b7c8-90a8c3b411a5	CONFIRMADA	300b4667-734d-45e0-a92a-a78737f75eb8	fc3431c5-7d76-43cf-a7c2-5a338bdc1380	\N	\N	\N	Fondeo de Caja Central para RETIRO de Patricia [CORRECCION 2026-07-30 14:30] importe 447.00 -> 446917.50. Importe cargado por error	2026-07-30 16:23:19.707725+00	2026-07-30 17:30:35.994058+00	\N	\N	\N	cc61b1c7-afaf-453e-9254-6b2d24809465	75
\.


--
-- Data for Name: mvp_periodo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_periodo (id, codigo, fecha_inicio, fecha_fin, estado, created_at, updated_at) FROM stdin;
3cc69ffa-6f76-4970-bc03-4e5ee0153175	2026-06	2026-06-01	2026-06-30	CERRADO	2026-06-12 21:36:37.670018+00	2026-07-02 18:48:46.701648+00
cc61b1c7-afaf-453e-9254-6b2d24809465	2026-07	2026-07-01	2026-07-31	CERRADO	2026-07-02 18:48:46.701648+00	2026-08-01 13:16:25.481153+00
7cfffcd1-5884-4b5b-b2e6-851dea123784	2026-08	2026-08-01	2026-08-31	ABIERTO	2026-08-01 13:16:25.481153+00	2026-08-01 13:16:25.481153+00
\.


--
-- Data for Name: mvp_productos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_productos (id, nombre, precio_lista, activo, created_at, updated_at, sigla) FROM stdin;
cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	francesa	2100.00	t	2026-06-07 17:22:10.065244+00	2026-06-07 18:54:39.555661+00	fra
ba1b6030-3855-49a1-ae3f-c0163e97a52a	rucula	1500.00	t	2026-06-07 17:22:10.065244+00	2026-06-07 18:54:39.555661+00	ruc
0c294dd6-af93-42de-aca5-f50ab942924a	asian mix	3500.00	t	2026-06-07 17:22:10.065244+00	2026-06-07 18:54:39.555661+00	asi
de5e2ae8-64b1-4f1a-a478-34d1db2bf034	albahaca	2000.00	t	2026-06-07 17:22:10.065244+00	2026-06-07 18:54:39.555661+00	alb
ac7a936f-2229-4748-8201-5aabbfdfd435	morada	2100.00	t	2026-06-07 17:22:10.065244+00	2026-06-07 18:54:39.555661+00	mor
c3e9630c-0382-4f35-8a82-33aa02fa590c	manteca	2100.00	t	2026-06-07 17:22:10.065244+00	2026-06-07 18:54:39.555661+00	man
32a40321-8506-4c3b-9928-0f32ecf3f3c3	acedera	2000.00	t	2026-06-07 17:22:10.065244+00	2026-06-07 18:54:39.555661+00	ace
60b7361b-c218-4e5a-8473-f4e3542cd339	cilantro	2500.00	t	2026-06-07 17:22:10.065244+00	2026-06-07 18:54:39.555661+00	cil
813681e7-9782-466c-bf6e-c345572179b2	eneldo	2500.00	t	2026-06-07 17:22:10.065244+00	2026-06-07 18:54:39.555661+00	ene
228aeec5-78b6-4bd2-90d2-ad39c8df33c5	mix lechugas	3000.00	t	2026-06-07 17:22:10.065244+00	2026-06-07 18:54:39.555661+00	mix
09bcd123-8c47-46d2-9ad2-d1d67500091d	mostaza	2500.00	t	2026-06-07 17:22:10.065244+00	2026-06-07 18:54:39.555661+00	mos
bdf0ebe0-0dfa-4a03-a1c4-9d3cd5ff98c2	radichio	2500.00	t	2026-06-07 17:22:10.065244+00	2026-06-07 18:54:39.555661+00	rad
7a907a3d-7134-4504-a022-a74c554b75c7	microgreen	3500.00	t	2026-06-07 19:47:29.133624+00	2026-06-07 20:04:34.07115+00	mic
ae42bca4-7d61-4416-8142-2f0a45401cee	brotes	3500.00	f	2026-06-07 17:22:10.065244+00	2026-06-07 20:05:01.56832+00	bro
e10d7f75-18d7-4da4-9fdb-158b3eb648f9	perejil	2000.00	f	2026-06-07 17:22:10.065244+00	2026-07-24 20:12:16.513607+00	per
\.


--
-- Data for Name: mvp_proveedores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_proveedores (id, nombre, cuit_cuil, created_at, updated_at, activo, creado_por) FROM stdin;
64fea813-ac79-48b4-92a2-a6b08d53b8a5	Andres	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
0be41609-eb7a-4570-8e3e-07273bd56e23	Acquatron	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
5df36cba-1894-4a93-aaf5-855d344c650e	AgroPlastic	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
c571bee6-c281-4df7-8492-ea6667ddafe5	Autopistas	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
6a829e8f-55f6-4517-a70f-e930ced13fdc	Casera	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
2730fa75-fe67-442c-a43a-5c4c645e9a72	DAV	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
e1e40efd-b972-4f73-9aab-b584fe86974d	El Campito	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
3a49799c-024b-41cb-9ea8-761d7e4209c0	Ezequiel	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
4c18dd67-24e9-488a-b895-188731bc1a9e	Federación	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
93fc5b70-77f7-445a-a196-2fb6be7d85b7	Floricultores	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
cdc71cb4-e03a-4145-9037-5207af197dba	La Rural	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
cd5b81ef-d03c-4756-93f8-1f8423da80ea	Papelera	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
6bc67b97-4f78-4286-ac43-1a15113dd5b8	Plantinera	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
f25672e6-85cd-4cb4-b949-86b7ba42b397	Plenta	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
bedb1926-6e2e-4af2-b90b-5ac0a1135319	Rodrigo Oña	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
1512a8be-8da7-43c1-83ad-149c37f59384	Sebastian	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
28319d48-e2f5-4126-aaaa-20b0d5d8aa05	Service	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
20986897-3e23-41c1-8405-1336e714fe31	SHELL	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
2621807f-8dc7-4a42-a2f9-6b4d36961bba	Thiago	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
df7f8ca8-dcbc-40cf-9f78-3804735ea37e	Tomás	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
eae1a10e-cd23-48e4-b886-abd58d18cd9d	Verde Agua	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
01c1e463-811d-4186-8d70-6b7a6e13fb0f	Verduleria	\N	2026-06-07 17:22:44.756386+00	2026-06-07 17:22:44.756386+00	t	\N
2d5e1cb7-772d-43df-96bf-9cce68d74439	Hernan Semilleria	\N	2026-06-26 15:46:22.605371+00	2026-06-26 15:46:22.605371+00	t	\N
0678cb6c-d381-49fc-b92f-1fd26353aa4e	OISLY	\N	2026-06-30 12:25:50.209325+00	2026-06-30 12:25:50.209325+00	t	2a08da39-1889-4a3c-a67b-fe63deb762a8
422a53ab-b2b0-48e6-adaf-151bf0890ab6	Quimica Drago	\N	2026-07-23 05:42:03.991768+00	2026-07-23 05:42:03.991768+00	t	2a08da39-1889-4a3c-a67b-fe63deb762a8
5c16fe64-103a-4416-a756-82d82600a0b8	Centro VTV Pilar	\N	2026-07-28 13:10:28.953355+00	2026-07-28 13:10:28.953355+00	t	259e6361-632b-4584-b7c8-90a8c3b411a5
65480fa1-acf4-498d-8085-b48fe1ba05fb	ALLI VAMOS	\N	2026-07-28 13:15:34.255345+00	2026-07-28 13:15:34.255345+00	t	259e6361-632b-4584-b7c8-90a8c3b411a5
4caee9dd-3901-4324-8415-feafc893b8f6	Edenor	\N	2026-07-28 13:16:30.754975+00	2026-07-28 13:16:30.754975+00	t	259e6361-632b-4584-b7c8-90a8c3b411a5
\.


--
-- Data for Name: mvp_reglas_negocio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_reglas_negocio (id, id_base, version, titulo, modulo, estado, sustituida_por, causa_sustitucion, definicion, descripcion_completa, tags, tablas_relacionadas, rpcs_relacionadas, pantallas_relacionadas, version_doc, fecha_actualizacion, created_at, updated_at, id_version_sistema, definicion_usuario) FROM stdin;
RN-V07	RN-014	0	Entrega y cobro al contado (camino A)	ventas	VIGENTE	\N	\N	Cuando un Repartidor llega con un pedido y el cliente paga en ese mismo momento, marca el pedido como entregado e ingresa el importe que recibió. El sistema verifica que el importe coincida exactamente con el total de la factura. Si coincide, la venta queda COBRADA y el dinero ingresa a la caja del Repartidor. Si difiere, la operación se rechaza. No se admiten cobros parciales por este camino.	Cuando un Repartidor llega con un pedido y el cliente paga en ese mismo momento, abre la pantalla de entregas, marca el pedido como entregado e ingresa el importe que recibió. El sistema verifica que el importe coincida exactamente con el total de la factura. Si coincide, la venta queda registrada como cobrada y el dinero ingresa a la caja del Repartidor. Si el importe difiere, el sistema rechaza la operación y muestra cuál era el monto correcto. No se admiten cobros parciales por este camino.	{ventas,cobros,entregas,repartidor}	{mvp_ventas,mvp_movimientos_caja,mvp_cajas}	{fn_registrar_entrega}	{SCR-Entregas}	v1.9	2026-07-03	2026-05-16 12:31:44.374583+00	2026-07-03 17:01:09.466381+00	1	{"motivo": "fusionada", "version": 1, "visible": false, "cubierta_por": "RN-V01.1"}
RN-T04	RN-021	0	Operaciones Exclusivas del Tesorero	tesoreria	VIGENTE	\N	\N	Tres operaciones quedan reservadas a la Tesorería: registrar aportes de capital de los Socios, registrar retiros que los Socios toman de Hidroplanta y otorgar adelantos a cuenta de la liquidación mensual. Las registra el Tesorero o el Administrador y siempre pasan por la Caja Central. Un Socio no puede registrarse un aporte o un retiro por su cuenta: tiene que pedírselo a la Tesorería.	Tres tipos de operaciones quedan reservadas a la función de Tesorería: registrar aportes de capital de los Socios, registrar retiros que toman los Socios de Hidroplanta, y otorgar adelantos a cuenta de la liquidación mensual. Estas operaciones las puede registrar el Tesorero o el Administrador —que puede operar toda la tesorería del sistema— y siempre pasan por la Caja Central. Un Socio no puede registrar por sí mismo un aporte propio ni un retiro: tiene que pedírselo a la Tesorería.	{tesoreria,caja_central,aportes,retiros,adelantos,tesorero}	{mvp_cajas,mvp_movimientos_caja}	{}	{}	v1.9	2026-07-06	2026-05-16 12:31:44.374583+00	2026-07-06 21:35:41.110826+00	1	{"texto": "Los aportes, retiros y adelantos de los Socios pertenecen al flujo personal: los registra el Tesorero o el Administrador y pasan siempre por la Caja Central; un Socio no puede registrárselos por su cuenta. Entre cajas delegadas no se mueve dinero directamente, salvo la transferencia entre ellas. La Caja Central se consulta desde su pantalla, que es solo de lectura; las operaciones se hacen en Movimientos Especiales.", "absorbe": ["RN-CC01", "RN-T08.1"], "version": 2, "visible": true}
RN-A03	RN-034	0	ABM de Proveedores	administracion	PROPUESTA	\N	\N	El Administrador mantiene el padrón general de Proveedores desde una pantalla dedicada del módulo de Administración: puede dar de alta, modificar o deshabilitar Proveedores. Los Socios no acceden a esta pantalla, pero pueden dar de alta un Proveedor nuevo cuando cargan una compra. Si se ingresa CUIT, no puede repetirse con el de otro Proveedor.	El Administrador mantiene el padrón general de Proveedores desde una pantalla dedicada del módulo de Administración. Puede agregar nuevos, modificar datos o deshabilitar los que ya no se usan. Los Socios no tienen acceso a esta pantalla, pero pueden dar de alta un Proveedor nuevo en el momento de cargar una compra. Cuando se carga el CUIT del proveedor, el sistema verifica que no exista otro proveedor con el mismo CUIT; si el CUIT no se ingresa (para proveedores informales), no hay verificación.	{administracion,proveedores,abm,admin}	{mvp_proveedores}	{}	{SCR-Proveedores}	v1.9	2026-05-16	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	2	{"motivo": "propuesta", "version": 1, "visible": false}
RN-A04	RN-035	0	Exportación a Excel	administracion	PROPUESTA	\N	\N	El Administrador a veces necesita sacar información del sistema en una planilla para revisar números fuera de la app, armar reportes para terceros o respaldar datos. Para eso hay una pantalla donde elige qué exportar (ventas, compras y gastos, o movimientos de una caja) y un rango de fechas. El archivo se arma en el navegador y se descarga. Es a demanda, sin reportes programados.	El Administrador necesita a veces sacar la información del sistema en una planilla de Excel, para revisar números fuera de la app, armar reportes para terceros o respaldar datos. Para eso, hay una pantalla específica donde elige qué quiere exportar (ventas, compras y gastos, o movimientos de una caja particular) y un rango de fechas. El archivo se arma directamente en el navegador y se descarga, sin necesidad de generar nada en el servidor. La exportación es a demanda: no hay reportes programados ni automáticos.	{administracion,estadisticas,admin}	{}	{}	{SCR-Exportacion}	v1.9	2026-05-16	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	2	{"motivo": "propuesta", "version": 1, "visible": false}
RN-U04.2	RN-004	2	El Operador representa a un Cliente	usuarios	VIGENTE	\N	\N	El Cliente es el comercio al que Hidroplanta le vende (un hotel, un restaurante). No es un usuario del sistema y no inicia sesión. Si necesita cargar sus propios pedidos, puede designar a un Operador para que actúe en su nombre. El sistema acepta un único Operador por Cliente activo.	El Cliente es una entidad comercial (hotel, restaurante, verdulería) a la que Hidroplanta le vende. Vive en mvp_clientes y no tiene credenciales: no es usuario del sistema y no inicia sesión.\n\nSi necesita cargar sus propios pedidos, puede designar un Operador: usuario con login propio (rol primario operador en mvp_users) y menú acotado, cuyo alcance se limita a registrar pedidos en nombre del cliente que representa, vinculado por mvp_users.cliente_id. Un cliente activo admite a lo sumo un Operador activo por vez; para reemplazarlo, primero se da de baja el actual y luego se da de alta el nuevo.\n\nLa designación es opcional para el flujo de venta: un Socio puede cargar pedidos para un cliente aunque este no tenga Operador asignado.\n\nEl rol operador está excluido de la capacidad Repartidor por trigger (trg_validar_operador_no_repartidor) y tampoco puede recibir la capacidad Tesorero, restringida a socios por CHECK.	{usuarios,operador,clientes,permisos}	{mvp_clientes,mvp_users}	{}	{SCR-Clientes}	v1.15	2026-07-10	2026-07-11 14:20:54.514224+00	2026-07-11 14:20:54.514224+00	1	{"texto": "El Cliente es el comercio al que Hidroplanta le vende (un hotel, un restaurante). No entra al sistema. Si necesita cargar sus propios pedidos, puede designar un Operador que ingresa en su nombre. Cada cliente activo tiene un único Operador.", "version": 1, "visible": true}
RN-U06.1	RN-006	1	Activación y baja del rol Repartidor	usuarios	VIGENTE	\N	\N	Solo el Administrador activa o desactiva la capacidad de Repartidor de un Socio. Para dar la baja, la caja usada por el Repartidor debe estar en cero y no deben quedarle entregas pendientes asignadas; si alguna condición falla, la baja será rechazada.	La capacidad Repartidor es ortogonal al rol primario y se materializa como fila en mvp_repartidores con activo = true. Solo el Administrador la activa o desactiva, vía fn_actualizar_usuario (parámetro p_es_repartidor). El Socio no puede asignársela ni quitársela por sí mismo.\n\nAl ACTIVAR: se crea o reactiva la fila en mvp_repartidores y se asigna su caja de tipo REPARTIDOR, necesaria para rendir lo cobrado en los repartos.\n\nAl DAR DE BAJA: la RPC valida dos condiciones. Primera, que la caja usada como Repartidor esté en cero (rindió todo lo cobrado). Segunda, que no queden pedidos pendientes de entregar (estados ASIGNADO o ENTREGADA sin rendir). Si alguna falla, la operación se rechaza con excepción y la baja no se produce. La baja es siempre lógica (activo = false), nunca física.\n\nEl rol operador está excluido por trigger. El Repartidor externo puro (persona ajena a la organización, sin rol primario socio) queda diferido a v2.	{usuarios,repartidor,permisos,admin}	{mvp_repartidores,mvp_cajas,mvp_ventas}	{fn_actualizar_usuario}	{SCR-Usuarios}	v1.15	2026-07-10	2026-07-11 14:20:54.514224+00	2026-07-11 14:20:54.514224+00	1	{"texto": "Solo el Administrador activa o desactiva la capacidad de Repartidor de un Socio. Para darla de baja, la caja que usó como Repartidor tiene que estar en cero y no pueden quedarle entregas pendientes; si algo de eso falla, la baja se rechaza.", "version": 1, "visible": true}
RN-U07.1	RN-007	1	Selección de rol al login para quienes tienen capacidad multi-rol	usuarios	VIGENTE	\N	\N	Si un Socio además tiene la capacidad de Repartidor, al iniciar sesión debe elegir cómo ingresar: por ejemplo, «Entrar como Socio» o «Entrar como Repartidor». La elección vale para toda la sesión; para cambiar el rol elegido, debe salir del sistema y volver a ingresar con otro rol.	Cuando un usuario tiene su rol primario y además la capacidad Repartidor activa, al ingresar se le presenta SCR-SeleccionRol para elegir el modo de sesión: por ejemplo «Entrar como Socio» o «Entrar como Repartidor». El modo elegido (rolActivo) determina el menú de toda la sesión y se persiste en sessionStorage; para cambiarlo hay que cerrar sesión y volver a entrar. Los usuarios con un solo rol no ven esta pantalla.\n\nLa capacidad Tesorero es deliberadamente asimétrica: NO agrega opción en SCR-SeleccionRol ni constituye un modo de sesión. El Socio-Tesorero, al ingresar como Socio, ve los ítems de Tesorería sumados a su menú (menú aditivo). Conjunto habilitado: Caja Central, Transferencias, Operaciones Especiales, Cierre mensual, Dashboard, Estadísticas y Consulta de cuenta corriente.\n\nConsecuencia: si un Socio-Tesorero además es Repartidor y elige entrar como Repartidor, NO ve Tesorería en esa sesión. La capacidad Tesorero solo se expresa en el menú cuando el modo activo es Socio.	{usuarios,autenticacion,repartidor,tesorero,permisos}	{mvp_users,mvp_repartidores}	{}	{SCR-SeleccionRol}	v1.15	2026-07-10	2026-07-11 14:20:54.514224+00	2026-07-11 14:20:54.514224+00	1	{"texto": "Si un Socio además es Repartidor, al iniciar sesión elige cómo entrar: por ejemplo «Entrar como Socio» o «Entrar como Repartidor». La elección vale para toda la sesión; para cambiar hay que salir y volver a entrar. La capacidad de Tesorero no aparece en esta pantalla: el Socio-Tesorero ve sus ítems de Tesorería sumados a su menú de Socio.", "version": 1, "visible": true}
RN-U09	RN-048	0	Activación y desactivación del rol Tesorero	usuarios	VIGENTE	\N	\N	Solo el Administrador activa o desactiva la capacidad de Tesorero de un Socio. El rol de Tesorero debe estar siempre cubierto, porque desarrolla operaciones propias como el Cierre Mensual y las Operaciones Especiales de la Caja Central. El sistema admite un único Tesorero a la vez.	La capacidad Tesorero es un segundo rol acumulable, ortogonal al rol primario. Solo el Administrador la activa o desactiva, y únicamente sobre un usuario con rol primario socio. Se materializa en mvp_users.rol_tesorero (booleano) y se opera desde SCR-Usuarios mediante fn_actualizar_usuario (parámetro p_rol_tesorero; NULL = no modificar).\n\nInvariantes garantizadas por la BD:\n- Único: índice único parcial uq_unico_tesorero (WHERE rol_tesorero = true). Un segundo socio es rechazado.\n- Socio: CHECK chk_tesorero_es_socio impide el flag sobre otro rol.\n- Autorización: la RPC valida que el ejecutor sea admin.\n\nAlcance: administra la Caja Central (singleton, tipo CENTRAL) y ejecuta el Cierre Mensual. Sus operaciones son aportes, retiros, adelantos, transferencias, ingresos y cierre. La autorización se resuelve con el helper es_tesorero() (SECURITY DEFINER), presente en diez policies de lectura y en las seis RPC de escritura de tesorería.\n\nCobertura: el sistema garantiza a lo sumo un Tesorero, pero no fuerza que exista al menos uno; mantenerlo cubierto es responsabilidad del Administrador, que además cubre la tesorería de forma inherente por su rol. La garantía de existencia mínima queda diferida a v2.\n\nBaja: el Tesorero no tiene caja propia, por lo que desactivarlo no requiere validaciones; consiste en apagar el flag.	{usuarios,tesorero,permisos,admin,caja_central}	{mvp_users,mvp_cajas}	{es_tesorero,fn_actualizar_usuario,fn_ejecutar_cierre,fn_registrar_aporte,fn_registrar_retiro,fn_registrar_adelanto}	{SCR-Usuarios}	v1.15	2026-07-10	2026-07-11 14:20:54.514224+00	2026-07-11 14:20:54.514224+00	1	{"texto": "Solo el Administrador activa o desactiva la capacidad de Tesorero de un Socio. El Tesorero se ocupa del Cierre Mensual y de las Operaciones Especiales de la Caja Central, así que el rol debe estar siempre cubierto. Hay un único Tesorero a la vez. Mientras ningún Socio la tenga asignada, el Administrador cubre la tesorería.", "version": 1, "visible": true}
RN-U02.4	RN-002	4	Jerarquía y Restricción de Roles	usuarios	VIGENTE	\N	\N	Hay cinco tipos de usuario: Administrador, Tesorero, Socio, Operador y Repartidor. Cada uno ve su propio menú y sus operaciones. Los tres primeros roles son cubiertos por personas de la organización. Los roles de Tesorero, Operador y Repartidor se explican en otras RN. Los roles de Tesorero y Repartidor pueden asignarse como «segundos roles» a un Socio. Un Socio puede además ser TESTER (RN-U10). El sistema reconoce un único Administrador, un único Tesorero y a lo sumo un TESTER.	El rol primario se almacena en el escalar mvp_users.rol (dominio: admin, tesorero, socio, operador, repartidor). El Administrador puede operar todo el sistema, incluida la tesorería. El Socio maneja su caja delegada, registra ventas y gastos y participa de la liquidación. El Operador solo registra pedidos por un cliente. El Repartidor entrega y rinde lo cobrado.\n\nSobre el rol primario se acumulan capacidades ortogonales, que NO viven en el escalar rol. Dos están materializadas en la BD:\n\n1) Repartidor: fila activa en mvp_repartidores (user_id = usuario AND activo = true). Alta y baja lógica (RN-U06.1). Excluida para operador por trigger. Habilita elegir modo de sesión al ingresar (RN-U07.1).\n\n2) Tesorero: columna booleana mvp_users.rol_tesorero. Solo asignable a rol socio (CHECK chk_tesorero_es_socio). Unicidad por índice único parcial uq_unico_tesorero. Autorización vía es_tesorero(). NO agrega opción en la selección de rol: el Socio-Tesorero ve Tesorería sumada a su menú (RN-U07.1, RN-U09).\n\nUna tercera es convencional y NO tiene soporte en el esquema:\n\n3) TESTER: Socio con participación 0/0 que carga datos ficticios conviviendo con los reales. Ninguna columna, CHECK ni policy lo distingue de un Socio. Su unicidad y sus tres límites son convención, no invariante (RN-U10). Materialización diferida a v2.\n\nEl valor tesorero queda en el dominio de rol como legacy; fn_crear_usuario ya no lo ofrece. Repartidor externo: diferido a v2.	{usuarios,permisos,admin,tesorero,socio,operador,repartidor,tester}	{mvp_users,mvp_socios,mvp_repartidores,mvp_clientes}	{es_tesorero,fn_crear_usuario,fn_actualizar_usuario}	{SCR-Usuarios}	v1.16	2026-07-13	2026-07-11 14:20:54.514224+00	2026-07-13 17:10:26.796001+00	1	{"texto": "Hay cinco tipos de usuario: Administrador, Tesorero, Socio, Operador y Repartidor. Cada uno ve su propio menú. Un Socio puede sumar dos segundos roles: Tesorero y Repartidor. Puede además ser TESTER, para hacer pruebas con datos ficticios. Hay un único Administrador, un único Tesorero y, a lo sumo, un TESTER.", "absorbe": ["RN-U05.1"], "version": 2, "visible": true}
RN-C01.1	RN-016	1	Unificación de Egresos	compras_gastos	VIGENTE	\N	\N	Hidroplanta maneja compras y gastos en un mismo lugar. Cada egreso es una línea simple, sin detalle de productos comprados. Al cargarlo hay que indicar si es una Compra (típicamente mercadería con factura de proveedor) o un Gasto (servicios, peajes, fletes). Se puede agregar una descripción breve. El egreso no puede superar el saldo de la caja delegada del Socio: si no alcanza, se rechaza.	Hidroplanta maneja compras y gastos en un mismo lugar. Cada egreso es una línea: no hay detalle de productos comprados, solo el total. Al cargar un egreso hay que indicar si es una Compra (típicamente mercadería con factura de proveedor) o un Gasto (servicios, peajes, fletes). Se puede agregar una descripción breve para identificar el egreso.\n\nEl egreso se paga desde la caja delegada del Socio y NO puede superar su saldo: la caja no puede quedar en negativo (RN-T01.2). Si el monto excede el saldo, la operación se rechaza. El Socio tiene dos caminos para poder pagarlo: cobrar ventas pendientes, o recibir una transferencia de otra caja delegada con saldo (RN-T14). Un adelanto del Tesorero NO sirve: pertenece al flujo personal, sale de la Caja Central y se asienta en la cuenta corriente del Socio, sin tocar su caja delegada.	{compras,tesoreria,caja_delegada,saldo}	{mvp_egresos,mvp_proveedores}	{fn_registrar_egreso,calcular_saldo_caja}	{SCR-IngresoComprasGastos,SCR-MisCompras}	v1.17	2026-07-13	2026-05-16 12:31:44.374583+00	2026-07-13 21:08:58.731202+00	1	{"texto": "Las compras y los gastos se cargan en un mismo lugar. Cada egreso es una línea simple, sin detalle de productos. Al cargarlo se indica si es una Compra (mercadería con factura de proveedor) o un Gasto (servicios, peajes, fletes) y puede agregarse una descripción breve. El Proveedor es obligatorio en ambos casos. No podés cargar un egreso mayor al saldo de tu caja: si no te alcanza, cobrá ventas pendientes o pedile una transferencia a otro Socio.", "version": 2, "visible": true}
RN-T06	RN-023	0	Cálculo de Saldo de Caja	tesoreria	VIGENTE	\N	\N	El sistema nunca guarda el saldo de las cajas en un dato fijo. Cada vez que alguien consulta el saldo, el sistema lo calcula al momento sumando todos los movimientos del período. Esto garantiza que el saldo siempre refleje con exactitud el estado actual, sin riesgo de desincronización entre el saldo registrado y los movimientos reales.	El sistema nunca guarda el saldo de las cajas en una columna fija. Cada vez que alguien quiere consultar el saldo de una caja, el sistema lo calcula sumando todos los movimientos del período. Esto evita errores de sincronización: el saldo siempre refleja con exactitud lo que está registrado. La aplicación, las pantallas y los reportes piden el saldo siempre al servidor, nunca lo calculan por su cuenta.	{tesoreria,cajas,auditoria}	{mvp_cajas,mvp_movimientos_caja}	{calcular_saldo_caja}	{}	v1.9	2026-05-16	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"motivo": "fusionada", "version": 1, "visible": false, "cubierta_por": "RN-T02"}
RN-T09	RN-026	0	Policies de Escritura	tesoreria	VIGENTE	\N	\N	Por seguridad y para garantizar la integridad de la contabilidad, las operaciones que tocan movimientos de dinero no pueden ejecutarse directamente desde la aplicación: siempre pasan por funciones controladas del servidor. Esto asegura que la partida doble nunca pueda saltearse desde la aplicación. Los catálogos generales del sistema, como productos o proveedores, sí pueden modificarse directamente.	Por seguridad y para garantizar la integridad de la contabilidad, las operaciones que tocan los movimientos de dinero del sistema no pueden ejecutarse directamente desde el frontend: siempre pasan por funciones controladas del servidor. Esto asegura que la partida doble nunca pueda saltearse desde la aplicación. Los catálogos generales del sistema, como productos o proveedores, sí pueden modificarse directamente porque las reglas que los protegen son más simples.	{tesoreria,permisos,auditoria,partida_doble}	{mvp_movimientos_caja,mvp_operacion_caja,mvp_cierres,mvp_cierre_detalle}	{}	{}	v1.9	2026-07-02	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"motivo": "tecnica", "version": 1, "visible": false}
RN-U10.1	RN-049	1	Capacidad TESTER del Socio	usuarios	VIGENTE	\N	\N	Puede haber un TESTER o ninguno, nunca más de uno. Es un Socio con participación 0% en ganancias y ventas, marcado con mvp_users.es_tester, habilitado para cargar datos ficticios que conviven con los reales. Opera con tres límites: (1) crea sus propios clientes y proveedores; (2) no se le asignan ventas reales, ni como repartidor ni como cobrador; (3) sus pruebas se confinan al período vigente y se borran antes del cierre con LIMPIADOR, verificado con POST-LIMPIADOR.	Capacidad convencional acumulable sobre el rol primario socio. Desde 2026-07-14 la columna booleana mvp_users.es_tester lo identifica. La usan los reportes del Dashboard para rotularlo; sus datos se siguen limpiando por procedimiento (LIMPIADOR), no por esquema.\n\nCardinalidad cero o uno, garantizada por el índice único parcial uq_unico_tester (WHERE es_tester = true) y validada por fn_actualizar_usuario. El CHECK chk_tester_es_socio impide la marca sobre otro rol. El Administrador habilita al Socio, le fija participación 0/0 (RN-U03) y activa es_tester, para que no reciba dividendos ni participe del reparto de ventas en el cierre.\n\nLÍMITE 1 - Catálogo propio. El TESTER crea sus clientes y proveedores; no opera sobre los reales. Quedan marcados por creado_por y se barren junto con sus datos.\n\nLÍMITE 2 - No intervención en el circuito real. Ningún Socio le asigna ventas reales como repartidor ni lo designa socio cobrador. Es la única vía por la que entra dinero REAL a su caja, y el LIMPIADOR no puede retirarlo: exige reconciliación manual.\n\nLÍMITE 3 - Confinamiento temporal. Las pruebas se limitan al período ABIERTO y terminan antes del cierre. Secuencia: LIMPIADOR, POST-LIMPIADOR con veredicto OK y, recién entonces, rendición de sus cajas en cero. Ninguna guarda del cierre lo excluye: C1_RENDICION recorre las cajas SOCIO y D-J las REPARTIDOR con saldo; si no rinde ambas, bloquea el cierre. Exclusión automática: diferida a v2 (PEN-028/RLS-DT03).	{usuarios,tester,socio,permisos,pruebas}	{mvp_users,mvp_socios,mvp_repartidores,mvp_cajas,mvp_clientes,mvp_proveedores}	{fn_ejecutar_cierre,fn_dashboard_cajas_repartidores,fn_dashboard_delegadas_header}	{SCR-Usuarios,SCR-Dashboard}	v1.19	2026-07-25	2026-07-13 17:13:21.622431+00	2026-07-26 21:10:56.130196+00	1	{"texto": "Puede haber un TESTER, o ninguno, pero nunca más de uno. Es un Socio que hace pruebas con datos ficticios: no cobra dividendos ni participa del reparto de ventas. Trabaja con clientes y proveedores propios, no recibe pedidos reales, y sus pruebas se borran antes del cierre del mes. El sistema lo marca con una etiqueta para no confundir sus datos de prueba con los reales.", "version": 2, "visible": true}
RN-C02.1	RN-017	1	Gestión de Proveedores (Alta, Baja y Reactivación)	compras_gastos	VIGENTE	\N	\N	El Socio puede dar de alta un Proveedor al momento de cargar una compra. El alta general también la hace el Administrador desde Administración. La baja es una baja lógica exclusiva del Administrador desde el ABM: el proveedor sale de los selectores de alta pero se conserva en los egresos históricos. Un proveedor dado de baja puede reactivarse. Los egresos con proveedor inactivo se muestran con el sufijo ' (baja)'.	Cuando un Socio carga una compra y el Proveedor no está en el sistema, puede darlo de alta en el momento desde la misma pantalla de ingreso de egresos, sin cortar el flujo ni pedir intervención del Administrador. El alta general de Proveedores también está disponible para el Administrador desde el módulo de Administración. La baja de Proveedores es una operación exclusiva del Administrador, realizada desde el ABM de Proveedores del módulo de Administración. Se trata de una baja lógica: el proveedor pasa a estado inactivo. Un proveedor inactivo deja de aparecer en los selectores de alta de nuevos egresos, pero se conserva intacto en todos los egresos históricos que lo referencian (mismo criterio de preservación de histórico que RN-V05 para productos). El Administrador puede reactivar un proveedor inactivo desde la misma pantalla del ABM. En las pantallas de consulta de egresos, cuando un egreso referencia a un proveedor inactivo, el nombre del proveedor se muestra seguido del sufijo ' (baja)' para señalar su estado sin ocultar el dato histórico.	{compras,socio,administrador,abm,baja_logica}	{mvp_proveedores,mvp_egresos}	{}	{SCR-MisCompras,SCR-ConsultaCompras}	v1.9	2026-07-02	2026-05-21 13:16:18.53175+00	2026-07-03 16:23:21.062276+00	1	{"texto": "El Socio puede dar de alta un Proveedor mientras carga una compra; el Administrador también lo hace desde Administración. La baja es exclusiva del Administrador: el proveedor deja de aparecer para nuevas cargas, pero se conserva en los egresos históricos con el sufijo «(baja)». Un proveedor dado de baja puede reactivarse.", "version": 1, "visible": true}
RN-T16.1	RN-042	1	Saldo Inicial de Caja en el Cierre	tesoreria	VIGENTE	\N	\N	El saldo inicial de una caja en un período es igual al saldo final del cierre del período anterior de esa misma caja; si no existe un cierre anterior, es cero. No es un movimiento de caja ni una transferencia: es un valor derivado que se registra en el cierre. Para las cajas delegadas de los Socios es siempre cero, porque el cierre las barre y nunca pueden quedar en negativo (RN-T01.2).	El saldo_inicial de una caja para un período N es el saldo_final del cierre del período N-1 de esa caja (mvp_cierre_detalle.saldo_final); 0 si no hay cierre previo. No se materializa como movimiento ni como operación de apertura: es un valor derivado en mvp_cierre_detalle.saldo_inicial. Como las cajas son persistentes y sus movimientos no se reinician, el saldo inicial ya está implícito en el acumulado; la columna solo lo rotula (un movimiento de apertura sería doble conteo).\n\nCajas SOCIO: el saldo_inicial es SIEMPRE cero. El cierre barre la caja (RN-T05.2) y la invariante de saldo no negativo (RN-T01.2) impide el arrastre deudor. El saldo_final de una caja SOCIO en el cierre es cero por construcción.\n\nEl arrastre deudor descrito en versiones anteriores queda INALCANZABLE. El código que lo implementa y el check C5_DEUDOR del precierre se conservan como defensa ante una manipulación manual de datos, pero no pueden dispararse por la operatoria normal. Su habilitación efectiva queda diferida a v2. Aplica a cajas CENTRAL y SOCIO; REPARTIDOR no participa del cierre mensual.	{tesoreria,cierre,saldo,periodo,caja_delegada}	{mvp_cierre_detalle,mvp_cierres,mvp_periodo,mvp_cajas}	{fn_preview_cierre,fn_ejecutar_cierre,calcular_saldo_caja,fn_saldo_neto_periodo}	{SCR-CierreMensual}	v1.17	2026-07-13	2026-06-15 15:21:19.659519+00	2026-07-13 21:10:16.113294+00	1	{"motivo": "fusionada", "version": 2, "visible": false, "cubierta_por": "RN-T05.2"}
RN-V01.1	RN-008	1	Ciclo de Vida de la Venta (Estados)	ventas	VIGENTE	\N	\N	Una venta arranca como PEDIDO cuando un Socio u Operador la carga. Cuando un Socio asigna un Repartidor, pasa a ASIGNADO. A partir de ahí hay dos caminos: si el cliente paga al contado al recibir, la venta pasa directo a COBRADO. Si paga en forma diferida, queda en ENTREGADA y un Socio cobra después en una operación separada.	Una venta comienza siempre como PEDIDO cuando un Socio o un Operador la carga. Cuando un Socio asigna un Repartidor para la entrega, la venta pasa a ASIGNADO. A partir de ahí hay dos caminos. Camino A: si el cliente paga al contado al recibir la mercadería, el Repartidor registra entrega y cobro en un solo paso, y la venta pasa directamente de ASIGNADO a COBRADO. Camino B: si el cliente recibe la mercadería pero pagará después, el Repartidor solo marca como entregada, la venta queda en estado ENTREGADA, y más tarde un Socio registra el cobro desde la pantalla de cobranzas pendientes, llevando la venta a COBRADO. Una venta cobrada no puede volver atrás; cualquier corrección requiere intervención del Administrador o del Socio responsable.	{ventas,pedidos,cobros,entregas}	{mvp_ventas}	{fn_carga_rapida_venta,fn_asignar_reparto,fn_registrar_entrega,fn_registrar_cobro_venta,fn_anular_venta}	{SCR-Reparto,SCR-Entregas,SCR-PendientesDeCobro}	v1.9	2026-07-02	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"texto": "Una venta nace como PEDIDO al cargarla y pasa a ASIGNADO cuando se le asigna Repartidor. Al entregar hay dos caminos: si el cliente paga al contado, el Repartidor cobra el importe exacto de la factura (sin pagos parciales), la venta queda COBRADA y el dinero entra a su caja. Si paga en forma diferida, queda ENTREGADA y más adelante un Socio confirma el cobro: el dinero entra a la caja de ese Socio. Un Socio puede cobrar varias ventas del mismo cliente en una sola operación.", "absorbe": ["RN-V03.1", "RN-V07", "RN-V08"], "version": 1, "visible": true}
RN-U08	RN-039	0	Teléfono de contacto del usuario	usuarios	VIGENTE	\N	\N	Cada usuario puede tener registrado un teléfono de contacto. Es opcional: puede quedar vacío. Sirve para comunicarse con la persona y como base para los informes y avisos que el sistema envíe en el futuro, por ejemplo por WhatsApp. No reemplaza al correo: el ingreso al sistema sigue siendo solo con email y contraseña. Puede cargarlo o editarlo el Administrador sobre cualquier usuario, el Socio sobre sus operadores, y cada usuario sobre su propio teléfono.	El sistema permite guardar un teléfono de contacto para cada usuario. Es un dato opcional. Se usa para comunicarse con la persona y está pensado como base para los informes y avisos que el sistema pueda enviar más adelante, especialmente a quienes trabajan en la calle, como los operadores de los clientes y los repartidores; el canal previsto para esos avisos es WhatsApp. El teléfono es un dato de contacto, no una credencial: el acceso al sistema se mantiene exclusivamente con correo y contraseña, sin ningún cambio. Sobre quién puede editarlo: el Administrador puede cargar o modificar el teléfono de cualquier usuario; el Socio puede hacerlo sobre los operadores que gestiona; y cada usuario puede ver y modificar su propio teléfono. En esta etapa el formato del número es libre; la normalización a un formato estándar queda para cuando se diseñe el envío de avisos. Pendiente para una versión futura (v2): extender el alcance del Socio para que también pueda gestionar el teléfono de los repartidores, y desarrollar el envío de avisos por WhatsApp.	{usuarios,contacto,informes}	{mvp_users}	{fn_crear_usuario,fn_actualizar_usuario,fn_actualizar_mi_telefono}	{}	v1.10	2026-06-03	2026-06-03 17:30:19.105472+00	2026-07-03 16:23:21.062276+00	1	{"motivo": "superficial", "version": 1, "visible": false}
RN-A05	RN-036	0	Backup	administracion	PROPUESTA	\N	\N	El Administrador puede generar respaldos completos de la base de datos del sistema. Esta funcionalidad no la implementa la propia app: se delega a la herramienta de respaldo que ofrece la plataforma de hosting. La app solo informa al Administrador cómo acceder a esa herramienta cuando hace falta.	El Administrador puede generar respaldos completos de la base de datos del sistema. Esta funcionalidad no la implementa la propia app: se delega al panel de administración de la plataforma de hosting de la base, que ya ofrece herramientas de backup y restauración. La app solo informa al Administrador cómo acceder a esa herramienta cuando hace falta.	{administracion,admin,auditoria}	{}	{}	{}	v1.9	2026-05-16	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	2	{"motivo": "propuesta", "version": 1, "visible": false}
RN-V06	RN-013	0	Asignación de reparto	ventas	VIGENTE	\N	\N	Cada mañana un Socio entra a la pantalla de reparto y ve los pedidos que se entregan ese día. Por cada uno elige qué Repartidor lo llevará y registra el número de factura emitida. Si después necesita cambiar de Repartidor o corregir el número, puede hacerlo mientras la venta no haya sido entregada. Una vez entregada, la asignación queda congelada. Cualquier Socio puede realizar la asignación.	Cada mañana un Socio entra a la pantalla de reparto y ve la lista de pedidos que se entregan ese día. Por cada pedido elige qué Repartidor lo va a llevar y registra el número de la factura que se le imprimió en el talonario. Si después necesita cambiar de Repartidor o corregir el número, puede hacerlo mientras la venta no haya sido entregada todavía. Una vez entregada, la asignación queda congelada. Cualquier Socio puede realizar la asignación, no hace falta que sea quien cargó originalmente el pedido.	{ventas,pedidos,repartidor,socio}	{mvp_ventas,mvp_repartidores}	{fn_asignar_reparto}	{SCR-Reparto}	v1.9	2026-07-03	2026-05-16 12:31:44.374583+00	2026-07-03 17:01:09.466381+00	1	{"texto": "Cada mañana un Socio entra a la pantalla de reparto, ve los pedidos del día y a cada uno le asigna un Repartidor y le registra el número de factura del talonario, que es obligatorio. Puede corregir ambos datos mientras la venta no esté entregada; después quedan congelados. La emisión automática de remitos en PDF queda para una versión futura.", "absorbe": ["RN-V10"], "version": 1, "visible": true}
RN-T22	RN-050	0	Rendición de la Caja Delegada	tesoreria	VIGENTE	\N	\N	Antes del cierre mensual, cada Socio rinde su caja delegada: declara cuánto efectivo tiene realmente. No puede declarar más que el saldo del libro. Si declara menos, la diferencia es un faltante que se le debita en su cuenta corriente y la caja queda en el efectivo declarado. Rendir no vacía la caja: eso lo hace el cierre. Se rinde una sola vez por período y no se puede revertir. Sin la rendición de todas las cajas delegadas, el Tesorero no puede cerrar el mes.	Operación del Socio sobre su caja delegada, previa al cierre mensual. Se ejecuta vía fn_rendir_caja_socio(p_efectivo) y registra una fila en mvp_rendiciones (una por caja y período).\n\nEl saldo de libro es el que calcula el sistema (calcular_saldo_caja). El Socio declara el efectivo que tiene en la mano. No se admite sobrante: declarar más que el saldo de libro se rechaza.\n\nFALTANTE. Si el efectivo declarado es menor que el saldo de libro, la diferencia genera una operación LIQUIDACION con número de comprobante, que produce: (a) un movimiento negativo por el faltante en la caja delegada, dejándola exactamente en el efectivo declarado, y (b) un asiento al DEBE de la cuenta corriente del Socio (tipo LIQUIDACION, RN-T19), que reduce su haber. NO es un adelanto: el adelanto es un anticipo voluntario que otorga el Tesorero desde la Caja Central; la liquidación es automática y representa efectivo que el Socio debe a Hidroplanta.\n\nLa rendición NO barre la caja: el barrido a Caja Central lo hace el cierre (RN-T05.2). La guarda C1_RENDICION de fn_precierre_estado y fn_ejecutar_cierre exige que TODAS las cajas SOCIO estén rendidas en el período; si falta una, el cierre se bloquea para toda la cooperativa. Una vez confirmada, la rendición no puede revertirse.	{tesoreria,rendicion,caja_delegada,socio,liquidacion,cierre_mensual}	{mvp_rendiciones,mvp_cajas,mvp_movimientos_caja,mvp_operacion_caja,mvp_ctacte,mvp_periodo}	{fn_rendir_caja_socio,calcular_saldo_caja,fn_precierre_estado,fn_ejecutar_cierre}	{SCR-MiCajaDelegada,SCR-CierreMensual}	v1.17	2026-07-13	2026-07-13 21:10:48.164067+00	2026-07-13 21:10:48.164067+00	1	{"texto": "Antes de que se cierre el mes, cada Socio rinde su caja delegada: declara cuánto efectivo tiene de verdad. No se puede declarar de más. Si declarás menos de lo que dice el sistema, esa diferencia queda como un faltante que se te debita en tu cuenta corriente, y la caja queda con el efectivo que declaraste. Rendir no vacía la caja: eso lo hace el cierre. Se rinde una sola vez por mes y no se puede deshacer. Si algún Socio no rinde, el Tesorero no puede cerrar el mes.", "version": 1, "visible": true}
RN-U01.1	RN-001	1	Autenticación, Recuperación y Cambio de Contraseña	usuarios	VIGENTE	\N	\N	Cada usuario entra al sistema con su correo electrónico y una contraseña personal. Si olvida la contraseña, puede restablecerla desde la propia pantalla de inicio de sesión. Con la sesión activa, puede cambiar su contraseña desde Mi Perfil sin necesidad de ingresar la contraseña actual. La dirección de correo no se puede cambiar después de creado el usuario.	Para usar el sistema cada usuario debe iniciar sesión con su dirección de correo electrónico y una contraseña. Si olvida su contraseña, puede recuperarla desde la propia pantalla de inicio de sesión apretando el botón 'Olvidé mi contraseña'. Adicionalmente, un usuario con la sesión activa puede actualizar su propia contraseña desde la pantalla Mi Perfil, sin necesidad de ingresar la contraseña actual. La dirección de correo, una vez asignada, no puede cambiarse. Si una persona necesita cambiar de email, hay que dar de baja al usuario y crear uno nuevo.	{usuarios,autenticacion,permisos}	{auth.users,mvp_users}	{}	{SCR-MiPerfil,SCR-Login}	v1.10	2026-06-04	2026-06-04 22:50:24.763792+00	2026-07-03 16:23:21.062276+00	1	{"texto": "Cada usuario ingresa con su correo electrónico y una contraseña personal. Si la olvida, puede restablecerla desde la pantalla de inicio de sesión. Con la sesión abierta, puede cambiarla desde Mi Perfil. El correo no se puede cambiar una vez creado el usuario.", "version": 1, "visible": true}
RN-T12	RN-029	0	Rendición administrativa de excepción	tesoreria	VIGENTE	\N	\N	Si un Socio con capacidad de Repartidor no puede rendir su Caja Repartidora (enfermedad, accidente, negativa u otro impedimento), el Administrador ejecuta la rendición por él. El sistema muestra los Repartidores con saldo pendiente y, con un click, el Administrador confirma: el dinero pasa de la Caja Repartidora a la Caja Delegada del propio Socio. Sin restricción de fecha: puede ejecutarse el mismo día. Solo aplica a Repartidores compartidos, no a Repartidores únicos contratados.	Si un Socio que también actúa como Repartidor no puede rendir el saldo de su Caja Repartidora (enfermedad, accidente, negativa u otro impedimento operativo), el Administrador ejecuta la rendición en su nombre.\r\n\r\nEl sistema muestra una pantalla con los Repartidores que tienen saldo pendiente y, con un solo click, el Administrador confirma la rendición: el dinero pasa de la Caja Repartidora a la Caja Delegada del propio Socio. El destino no se elige: se deriva automáticamente. La operación es atómica y no admite parciales: deja la Caja Repartidora en cero o falla. Queda registrado qué usuario la ejecutó.\r\n\r\nNo hay restricción temporal: el Administrador puede ejecutarla el mismo día. Solo funciona para Repartidores compartidos. Si se trata de un Repartidor único contratado externamente y no rinde, esa situación queda fuera del alcance del sistema y se resuelve manualmente.	{tesoreria,rendicion,admin,repartidor}	{mvp_cajas,mvp_movimientos_caja,mvp_operacion_caja,mvp_repartidores,mvp_users}	{fn_rendir_dia_administrativo,fn_listar_rendiciones_pendientes,calcular_saldo_caja}	{SCR-RendicionAdministrativa}	v1.18	2026-07-14	2026-05-16 12:31:44.374583+00	2026-07-14 22:25:25.625171+00	2	{"motivo": "implementada", "version": 0, "visible": true}
RN-T14	RN-040	0	Transferencia entre Cajas Delegadas	tesoreria	VIGENTE	\N	\N	Un Socio puede transferir dinero de su caja delegada a la de otro Socio que lo necesite. Es dinero comercial de la empresa, no personal, y no obliga a devolución. Solo se permite si al que transfiere le alcanza el saldo: su caja no puede quedar en negativo. La transferencia queda pendiente; el receptor puede reintegrarla si tiene saldo, y si al cierre mensual sigue pendiente, el propio cierre la da por saldada sin mover dinero.	Operación de tesorería de ámbito interno que mueve fondos directamente entre dos cajas tipo SOCIO, sin intervención de la Caja Central ni del Tesorero (excepción a RN-T08.1). El desembolso lo ejecuta el socio prestamista vía fn_registrar_prestamo_socio, que valida rol socio, pertenencia y tipo SOCIO de ambas cajas, cajas distintas, monto positivo y saldo suficiente en la caja prestamista. Crea una operación PRESTAMO_ENTRE_SOCIOS (cabecera CONFIRMADA) con dos movimientos atómicos: HABER en la caja prestamista y DEBE en la receptora, con tipo_referencia TRANSFERENCIA. El préstamo queda pendiente mientras no exista una cancelación vinculada por operacion_relacionada_id. La cancelación la ejecuta solo el socio receptor vía fn_cancelar_prestamo_socio, que valida el préstamo (existencia, tipo, estado CONFIRMADA, no cancelado), que el ejecutante sea titular de la caja receptora y que tenga saldo suficiente; genera la operación inversa CANCELACION_PRESTAMO_ENTRE_SOCIOS vinculada al original. Cualquier socio puede prestar a cualquier otro. Puente provisorio: la cancelación es manual; al construirse el cierre mensual (fn_ejecutar_cierre), la cancelación automática de préstamos pendientes deberá ejecutarse antes del barrido de saldos (RN-T05, Pasos 5 y 6).	{tesoreria,prestamo_entre_socios,cajas,socios,transferencia}	{mvp_cajas,mvp_movimientos_caja,mvp_operacion_caja,mvp_tipo_operaciones}	{fn_registrar_prestamo_socio,fn_cancelar_prestamo_socio,fn_listar_socios_para_prestamo,fn_listar_prestamos_socio}	{SCR-MiCajaDelegada}	v1.11	2026-07-03	2026-06-05 17:50:08.920444+00	2026-07-03 19:59:03.413468+00	1	{"texto": "Un Socio puede transferir dinero de su caja delegada a la de otro Socio que lo necesite. Es dinero comercial de la empresa, no personal: no hay obligación de devolverlo. Solo se permite si al que transfiere le alcanza el saldo: su caja no puede quedar en negativo. La transferencia queda registrada como pendiente; si el receptor decide reintegrarla, también debe tener saldo. Si al cierre mensual sigue pendiente, el propio cierre la da por saldada sin mover dinero.", "version": 1, "visible": true}
RN-T02	RN-019	0	Integridad Contable (Partida Doble)	tesoreria	VIGENTE	\N	\N	Todas las operaciones de dinero respetan el principio de partida doble. Cuando se cobra una venta o se paga un gasto, el sistema registra automáticamente el movimiento contable. Los ingresos quedan con monto positivo, los egresos con negativo. Cuando una operación involucra dos cajas (como una transferencia), los dos movimientos se hacen al mismo tiempo: si uno falla, ninguno se aplica.	Cuando se cobra una venta o se paga un gasto, el sistema registra automáticamente el movimiento contable correspondiente. Los ingresos quedan con monto positivo y los egresos con monto negativo. Cuando un movimiento involucra a dos cajas, como una transferencia, los dos movimientos se hacen al mismo tiempo: si uno falla, ninguno se aplica. Esto garantiza que la contabilidad nunca quede desbalanceada.	{tesoreria,partida_doble,auditoria}	{mvp_movimientos_caja,mvp_cajas}	{}	{}	v1.9	2026-07-02	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"texto": "Cada peso que se mueve queda registrado automáticamente y vinculado a la operación que lo originó (una venta, un gasto, una transferencia o un cierre): siempre puede reconstruirse la historia de un saldo. Los saldos no se guardan como un número fijo: se calculan cada vez sumando los movimientos reales, por eso siempre están al día. En esta versión solo se opera con efectivo.", "absorbe": ["RN-T03", "RN-T06", "RN-T07"], "version": 1, "visible": true}
RN-A02.1	RN-033	1	ABM de Productos	administracion	VIGENTE	\N	\N	El Administrador da de alta, edita (nombre, precio, sigla) y da de baja productos. El Socio puede dar de alta un producto nuevo al cargar un pedido (nombre y precio, sin sigla); queda activo y vendible de inmediato. El Admin completa la sigla luego: su ausencia marca al producto como pendiente de revisión. No se admiten nombres duplicados ni variantes por mayúsculas o acentos entre activos. La sigla es opcional y única entre activos. Cambiar el precio no afecta ventas ya cargadas.	El Administrador es quien mantiene el padrón de productos de Hidroplanta: da de alta nuevos productos, modifica nombre, precio de lista y sigla, y da de baja los que ya no se venden. La novedad de esta versión es que el Socio también puede dar de alta un producto nuevo, pero solo en el momento de cargar un pedido (alta inline en SCR-IngresoPedidos): indica nombre y precio, y el producto queda activo y disponible para venderse de inmediato, sin sigla. El alta es de dos etapas: el Socio crea (etapa 1) y el Administrador revisa y completa la sigla y, si hace falta, normaliza el nombre (etapa 2). La ausencia de sigla es la señal de que el producto es nuevo y está pendiente de revisión; no hay un estado almacenado, la cola de revisión se deriva de los productos sin sigla. El sistema no admite nombres duplicados ni cuasi-duplicados por mayúsculas o acentos entre productos activos (por ejemplo, no pueden coexistir 'rúcula' y 'rucula' activos). La sigla es un identificador abreviado opcional, pensado para listados compactos; cuando se carga, es única entre productos activos. La edición de nombre, precio y sigla y la baja lógica son exclusivas del Administrador. Cuando el Administrador modifica el precio de lista, las ventas ya cargadas no cambian: cada una conserva el precio que tenía al momento de cargarse (snapshot). Los nuevos pedidos sí toman el precio actualizado.	{administracion,ventas,productos,padron,abm,admin,socio}	{mvp_productos,mvp_ventas_detalle}	{}	{SCR-Productos,SCR-IngresoPedidos}	v1.12	2026-06-07	2026-06-07 18:52:06.435906+00	2026-07-03 16:23:21.062276+00	1	{"texto": "El Administrador da de alta, edita y da de baja productos. El Socio puede crear un producto nuevo mientras carga un pedido, y queda vendible de inmediato; el Administrador le completa la sigla después. No se admiten nombres duplicados. Cambiar un precio no afecta ventas ya cargadas. Los productos dados de baja desaparecen de las pantallas de carga, pero se conservan en el historial.", "absorbe": ["RN-V05"], "version": 1, "visible": true}
RN-T23	RN-051	0	Transferencias entre Caja Central y Cajas Delegadas	tesoreria	VIGENTE	\N	\N	Cuando a la Caja Central le falta efectivo o a un Socio no le alcanza para operar, el dinero comercial puede moverse entre la Central y una caja delegada, en los dos sentidos. No es dinero personal y no se reintegra: el cierre mensual lo acomoda solo. Las registra la Tesorería cuando el efectivo cambia de manos. Nunca se toca la cuenta corriente del Socio: eso es lo que las diferencia de un adelanto. Las cajas de Repartidor no participan, porque solo se mueven por rendición.	Segunda excepción a RN-T04 / RN-T08.1: el dinero pasa por la Central, así que la centralización no se viola, pero el caso no estaba contemplado. Dos códigos de mvp_tipo_operaciones, ámbito INTERNA, usa_ctacte=false: ASISTENCIA_CAJA_DELEGADA (Central -> Delegada) y RECAUDACION_ANTICIPADA (Delegada -> Central). Ambos los ejecuta fn_registrar_transferencia, que deriva el código del tipo de la caja de origen y emite una operación CONFIRMADA con dos movimientos atómicos de tipo_referencia TRANSFERENCIA y nro_comprobante asignado. Guardas: par de cajas restringido a un extremo CENTRAL y otro SOCIO (rechaza SOCIO-SOCIO derivando a RN-T14 y cualquier extremo REPARTIDOR derivando a la rendición); saldo suficiente en el origen; caja SOCIO no rendida en el período; fecha dentro del período vigente en hora local. Autorización asimétrica: la salida de la Central la registra tesorero/admin/es_tesorero(); la entrada, el titular de la caja de origen o el Administrador. La vía del Socio titular existe en backend pero sin pantalla (diferida a v3): en la práctica la registra el Administrador al recibir el efectivo. Neutral frente al cierre: los movimientos TRANSFERENCIA no computan en V ni en C (fn_ejecutar_cierre los calcula por tipo_referencia VENTA/EGRESO), así que no afecta dividendos; y el barrido la autocorrige, porque el remanente en la delegada vuelve a la Central. Lectura por fn_listar_transferencias_periodo(), que además incorpora el ADELANTO a la vista de SCR-Transferencias.	{tesoreria,caja_central,caja_delegada,transferencias,tesorero,socio}	{mvp_cajas,mvp_movimientos_caja,mvp_operacion_caja,mvp_tipo_operaciones,mvp_rendiciones}	{fn_registrar_transferencia,fn_listar_transferencias_periodo,calcular_saldo_caja}	{SCR-Transferencias,SCR-MiCajaDelegada,SCR-CajaCentral}	v1.19	2026-07-24	2026-07-24 18:17:06.092495+00	2026-07-24 18:17:06.092495+00	2	{"texto": "El dinero comercial puede pasar de la Caja Central a la caja delegada de un Socio, o al revés. Si la Central le provee fondos a un Socio para que pueda comprar o pagar, o si un Socio le entrega efectivo a la Central antes del cierre, la operación la registra la Tesorería en el momento. No hay que devolver nada: el cierre mensual barre los saldos igual. No lo confundas con un adelanto: el adelanto se descuenta de tu cuenta corriente, esto no.", "version": 0, "visible": true}
RN-T10.1	RN-027	1	Caja Repartidor: alcance, ciclo diario y exclusión del cierre mensual	tesoreria	VIGENTE	\N	\N	La Caja Repartidora funciona distinto de la Caja Delegada. Es transitoria y diaria: durante el día recibe el dinero de los cobros al contado, y al terminar la jornada el Repartidor rinde ese saldo transfiriéndolo a su Caja Delegada. Al cerrar el día la caja debe quedar en cero. Si queda con saldo, el Administrador puede rendirla mediante una rendición administrativa, sin restricción de fecha (RN-T12). Las Cajas Repartidoras no participan del cierre mensual: viven a ritmo diario, no mensual.	La Caja Repartidora funciona distinto de la Caja Delegada. Es transitoria y diaria: durante el día recibe el dinero de los cobros al contado, y al terminar la jornada el Repartidor rinde ese saldo transfiriéndolo a su Caja Delegada. Al cerrar el día la caja debe quedar en cero.\r\n\r\nSi por algún motivo queda con saldo positivo, el Administrador puede ejecutar la rendición en nombre del Repartidor (RN-T12). No hay restricción de fecha: puede hacerlo el mismo día.\r\n\r\nLas Cajas Repartidoras no participan del cierre mensual: viven a ritmo diario, no mensual. El motor de cierre opera únicamente sobre las Cajas Delegadas y la Caja Central.\r\n\r\nConsecuencia a tener presente: el cierre mensual no valida hoy el saldo de las Cajas Repartidoras. Si una queda con saldo al cerrar el período, ese dinero ya fue contado como venta en el resultado del mes pero no se barre a Caja Central, y su rendición posterior impacta en el período siguiente. Por eso todas las Cajas Repartidoras deben quedar en cero antes de ejecutar el cierre. El Dashboard informa los fondos en tránsito para detectarlo (RN-D01.1).	{tesoreria,cajas,repartidor,rendicion}	{mvp_cajas,mvp_movimientos_caja,mvp_operacion_caja,mvp_repartidores}	{fn_rendir_dia,fn_rendir_dia_administrativo,fn_listar_rendiciones_pendientes,calcular_saldo_caja,fn_ejecutar_cierre}	{SCR-Rendicion}	v1.18	2026-07-14	2026-05-16 12:31:44.374583+00	2026-07-14 22:25:25.625171+00	1	{"texto": "La caja del Repartidor es diaria y transitoria: durante el día recibe los cobros al contado y al terminar la jornada se rinde completa. Si el Repartidor es un Socio, el dinero pasa a su propia caja de Socio; si es un Repartidor único, se distribuye entre las cajas de los Socios involucrados. No hay rendiciones parciales: la caja queda en cero o la operación se rechaza. Estas cajas no participan del cierre mensual.", "absorbe": ["RN-T11"], "version": 1, "visible": true}
RN-T17	RN-043	0	Cálculo de Dividendos del Cierre Mensual	tesoreria	VIGENTE	\N	\N	Cada socio cobra un único tipo de dividendo: por ganancia (porcentaje sobre el Estado de Resultados) o por ventas (porcentaje sobre el total de ventas cobradas del período), nunca ambos. El tipo se determina por convención: el porcentaje cargado mayor a cero es el que aplica; el otro está en cero.	El cierre calcula el dividendo en orden NO invertible: (1) Dividendos por ventas = porc_venta × Total de Ventas Cobradas del período (V), por cada socio con porc_venta>0. (2) Estado de Resultados ER = V − Compras/Gastos Pagados (C) − Dividendos por Ventas. (3) Dividendos por ganancia = porc_ganancia × ER, por cada socio con porc_ganancia>0. Las ganancias se reparten totalmente: Σ porc_ganancia = 100% (guarda dura del motor; si no suma 100, el cierre falla). Las ventas no se reparten enteras: Σ porc_venta no necesariamente da 100%. El monto se registra en mvp_cierre_detalle.monto_dividendos sobre la fila de la caja SOCIO, con porc_aplicado y tipo_dividendo_aplicado (GANANCIA/VENTA). No genera movimiento: el efectivo queda en Central como haber del socio. El control de coherencia de los porcentajes no está en el MVP; lo administra el admin (mejora v2).	{tesoreria,cierre,dividendos,estado_resultados}	{mvp_socios,mvp_cierre_detalle,mvp_cierre_resumen,mvp_movimientos_caja}	{fn_ejecutar_cierre,fn_preview_cierre}	{SCR-CierreMensual}	v1.13	2026-07-02	2026-06-15 15:21:39.1448+00	2026-07-03 16:23:21.062276+00	1	{"texto": "Cada Socio cobra un solo tipo de dividendo: por ganancia (un porcentaje del resultado del mes) o por ventas (un porcentaje de las ventas cobradas del período), nunca los dos. Aplica el porcentaje que tenga cargado mayor a cero; el otro debe estar en cero.", "version": 1, "visible": true}
RN-V03.1	RN-010	1	Asignación y Confirmación de Cobro	ventas	VIGENTE	\N	\N	Cuando una venta se cobra, el sistema registra en qué caja entró el dinero. Si el cobro lo hizo el Repartidor al momento de entregar, el dinero entra a la caja del Repartidor. Si el cobro lo hizo un Socio en forma diferida, el dinero entra directamente a la caja de ese Socio y queda registrado quién lo cobró. Un Socio puede cobrar varias ventas del mismo cliente en una sola operación.	Cuando una venta se cobra, el sistema registra en qué caja entró el dinero. Si el cobro lo hizo el Repartidor al momento de entregar (camino A), el dinero entra a la caja del Repartidor, no a la de un Socio en particular, por eso no se registra Socio cobrador. Si el cobro lo hizo un Socio en forma diferida (camino B), el dinero entra directamente a la caja de ese Socio y queda registrado quién lo cobró. Desde la pantalla de cobranzas pendientes el sistema permite cobrar varias ventas del mismo cliente en una sola operación.	{ventas,cobros,auditoria}	{mvp_ventas}	{fn_registrar_cobro_venta}	{SCR-PendientesDeCobro}	v1.9	2026-07-02	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"motivo": "fusionada", "version": 1, "visible": false, "cubierta_por": "RN-V01.1"}
RN-V05	RN-012	0	Filtrado de Productos en Consultas	ventas	VIGENTE	\N	\N	Los productos del padrón pueden darse de baja sin eliminar el historial: se marcan como inactivos. Cualquier consulta de productos en pantallas de pedidos, ventas o compras muestra solo los productos activos. Los productos inactivos solo aparecen al consultar ventas históricas, pero no están disponibles para crear nuevas operaciones.	Los productos del padrón pueden darse de baja sin eliminar el historial: simplemente se marcan como inactivos. Cualquier consulta o selección de productos en pantallas de pedidos, ventas o compras debe mostrar solo los productos activos. Los productos inactivos solo aparecen al consultar ventas históricas, pero no están disponibles para crear nuevas ventas.	{ventas,padron}	{mvp_productos}	{}	{}	v1.9	2026-05-16	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"motivo": "fusionada", "version": 1, "visible": false, "cubierta_por": "RN-A02.1"}
RN-U05.1	RN-005	1	Padrón ampliado de roles primarios y capacidad ortogonal repartidor	usuarios	VIGENTE	\N	\N	Cada usuario tiene un rol principal que define el menú al que accede. Independientemente del rol principal, algunos usuarios pueden además trabajar como Repartidor en jornadas específicas. Esta capacidad se activa o desactiva por separado. Un Socio puede ser también Repartidor (caso muy común). Solo el Operador queda excluido de esta combinación porque representa al cliente.	Un usuario del sistema tiene un rol principal que define el menú al que accede. Pero independientemente del rol principal, algunos usuarios también pueden trabajar como Repartidores en jornadas específicas. Esta capacidad de repartidor es independiente del rol y se activa marcando un checkbox al dar de alta o modificar al usuario. Un Socio puede ser también Repartidor (caso muy común). Un Administrador o un Tesorero también pueden serlo si hace falta. Solo el Operador queda excluido: como representa al cliente, no tiene sentido que también haga entregas para Hidroplanta. Existe además el caso del Repartidor único, que es alguien contratado solo para hacer entregas, sin otro rol.	{usuarios,repartidor,permisos}	{mvp_users,mvp_repartidores}	{}	{}	v1.9	2026-05-16	2026-05-16 12:31:44.374583+00	2026-07-13 21:07:46.495995+00	1	{"motivo": "fusionada", "version": 1, "visible": false, "cubierta_por": "RN-U02.4"}
RN-V10	RN-041	0	Modalidad de emisión del remito en reparto	ventas	VIGENTE	\N	\N	Al asignar el reparto, el Socio elige la modalidad de emisión del remito: Manual o Automática. En Manual (única operativa en esta versión) el Socio transcribe el número de factura del talonario físico, que es obligatorio. La modalidad Automática, que genera un remito en PDF con numeración provista por el sistema e impresión en papel térmico, queda reservada para la Versión 2 y se muestra deshabilitada. La elección de modalidad no altera el contrato de fn_asignar_reparto.	La pantalla de reparto incorpora, dentro del dialog de asignación, un selector de modalidad de emisión del remito con dos ramas que conviven. Manual: comportamiento histórico (RN-V06); el Socio transcribe el número de la factura del talonario físico, obligatorio, validado en cliente solo por presencia, sin formato ni unicidad; única modalidad operativa en esta versión. Automática: reservada para la Versión 2; el sistema generará el remito en PDF (encabezado, fecha, numeración, cliente, una línea por producto con cantidad y precio, y totalizador) y lo enviará a una impresora bluetooth de papel térmico disparada por el Socio. Los datos ya existen en mvp_ventas, mvp_ventas_detalle y mvp_clientes; falta la fuente de numeración y el canal de salida. La numeración automática vuelve obligatoria la unicidad de nro_factura (hoy diferida, PEN-FUTURO-07) y el canal bluetooth/térmico es un riesgo técnico abierto a evaluar por separado del PDF. En esta versión la rama Automática se muestra deshabilitada con un distintivo Versión 2 y no afecta el flujo de guardado.	{ventas,reparto,remito,impresion}	{mvp_ventas,mvp_ventas_detalle,mvp_clientes}	{fn_asignar_reparto}	{SCR-Reparto}	v1.12	2026-06-11	2026-06-11 17:56:55.150075+00	2026-07-03 16:23:21.062276+00	1	{"motivo": "fusionada", "version": 1, "visible": false, "cubierta_por": "RN-V06"}
RN-V08	RN-015	0	Entrega sin cobro y cobro diferido (camino B)	ventas	VIGENTE	\N	\N	Algunos clientes pagan en forma diferida (semanal o mensual). En esos casos, cuando el Repartidor entrega, solo marca el pedido como entregado, sin importe. La venta queda en estado ENTREGADA, lista para que cualquier Socio la cobre más adelante. Cuando llega el pago, el Socio entra a la pantalla de cobranzas pendientes, selecciona la venta y confirma el cobro. El dinero ingresa a su caja.	Algunos clientes pagan en forma diferida, semanal o mensual. En esos casos, cuando el Repartidor entrega la mercadería, simplemente marca el pedido como entregado, sin ingresar importe. La venta queda en estado ENTREGADA, lista para que cualquier Socio la cobre más adelante. Cuando llega el momento del pago, el Socio entra a la pantalla de cobranzas pendientes, filtra por cliente o por fecha, selecciona las ventas que está cobrando, ingresa la fecha de cobro y confirma. El dinero ingresa entonces a la caja del Socio que registró el cobro. No se admite cobro parcial: si el cliente paga menos de lo que figura en la factura, el Socio debe gestionar la diferencia por fuera del sistema.	{ventas,cobros,entregas,socio}	{mvp_ventas,mvp_movimientos_caja}	{fn_registrar_entrega,fn_registrar_cobro_venta}	{SCR-Entregas,SCR-PendientesDeCobro}	v1.9	2026-07-03	2026-05-16 12:31:44.374583+00	2026-07-03 17:01:09.466381+00	1	{"motivo": "fusionada", "version": 1, "visible": false, "cubierta_por": "RN-V01.1"}
RN-E01	RN-038	0	Resúmenes Estadísticos	estadisticas	PROPUESTA	\N	\N	El Administrador y el Tesorero pueden acceder a una pantalla de estadísticas donde el sistema consolida información histórica de Hidroplanta: ventas totales por Socio, gastos totales por Socio, y cómo fueron evolucionando los saldos de cada caja mes a mes. Es una pantalla de solo consulta: no permite ejecutar operaciones ni modificar nada.	El Administrador y el Tesorero pueden acceder a una pantalla de estadísticas donde el sistema consolida información histórica de Hidroplanta: ventas totales por Socio, gastos totales por Socio, y cómo fueron evolucionando los saldos de cada caja mes a mes. Esta pantalla es solo de consulta: no permite ejecutar operaciones ni modificar nada. Sirve para tener una visión de cómo viene el negocio en perspectiva.	{estadisticas,tesoreria,admin,tesorero}	{}	{}	{SCR-Estadisticas}	v1.9	2026-05-16	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	2	{"motivo": "propuesta", "version": 1, "visible": false}
RN-S01	RN-037	0	Estado de Conectividad	sistema	PROPUESTA	\N	\N	El sistema tiene un indicador único que señala si está operativo o en mantenimiento. Cualquier usuario autenticado puede ver ese indicador en la pantalla de diagnóstico, donde un cartel muestra si la conexión a la base de datos responde. Solo el Administrador puede cambiar manualmente este estado, por ejemplo cuando hay que avisar a los demás que el sistema entra en mantenimiento.	El sistema tiene un indicador que señala si está operativo o en mantenimiento. Cualquier usuario que entra a la app puede ver ese indicador en la pantalla de diagnóstico, donde un cartel muestra si la conexión a la base de datos responde. Solo el Administrador puede cambiar manualmente este estado, por ejemplo cuando hay que avisar a los demás usuarios que el sistema entra en mantenimiento.	{sistema,admin,permisos}	{mvp_system_status}	{fn_toggle_online,fn_test_conexion}	{SCR-Diagnostico}	v1.9	2026-07-02	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"motivo": "propuesta", "version": 1, "visible": false}
RN-T18	RN-044	0	Retiro y Haber del Socio	tesoreria	VIGENTE	\N	\N	El haber de un socio es el dividendo acumulado a su favor en Caja Central, neto de adelantos y retiros: haber = Σ dividendos − Σ adelantos − Σ retiros. El retiro de dividendos y el adelanto salen de Caja Central (no de la caja del socio) y se atribuyen al socio. El dividendo no retirado queda disponible en Central.	Bajo el modelo de caja delegada, los movimientos personales del socio (dividendos, adelantos, retiros) se canalizan por Caja Central, no por su caja operativa. haber = Σ monto_dividendos (snapshot de cierres) − Σ adelantos − Σ retiros, computado en Central y expuesto por fn_cuenta_socio. El retiro (fn_registrar_retiro) y el adelanto (fn_registrar_adelanto) generan un egreso en Central atribuido al socio (tercero_id, tipo_tercero=SOCIO); no tocan la caja operativa del socio. El adelanto es un anticipo contra dividendos futuros y se descuenta del haber. El dividendo no retirado queda disponible en Central (retirable); la capitalización a aporte sería explícita y opcional (no automática), fuera del MVP. El retiro no puede dejar Central en negativo (RN-T13).	{tesoreria,dividendos,retiro,haber}	{mvp_cajas,mvp_movimientos_caja,mvp_operacion_caja,mvp_socios,mvp_ctacte}	{fn_cuenta_socio,fn_registrar_retiro,fn_registrar_adelanto}	{SCR-OperacionesEspeciales}	v1.13	2026-07-02	2026-06-15 15:21:49.02917+00	2026-07-03 16:23:21.062276+00	1	{"texto": "El haber de un Socio es el dividendo acumulado a su favor en la Caja Central, descontando adelantos y retiros. Estos movimientos pertenecen a su flujo personal: salen de la Caja Central (nunca de su caja delegada) y se asientan en su cuenta corriente. El dividendo que no se retira queda disponible en la Central, a la orden del Socio.", "version": 1, "visible": true}
RN-T03	RN-020	0	Naturaleza de los Movimientos	tesoreria	VIGENTE	\N	\N	En esta versión inicial, el sistema registra solo movimientos en efectivo. No hay todavía soporte para tarjetas de crédito, transferencias bancarias ni cheques. Cada movimiento de caja queda asociado a su origen: si proviene de una venta, queda vinculado al pedido cobrado; si proviene de un gasto, al egreso correspondiente. Esto permite auditar la historia completa de cualquier saldo.	El sistema, en esta versión inicial, registra solo movimientos en efectivo. No hay todavía soporte para tarjetas de crédito, transferencias bancarias ni cheques. Cada movimiento de caja queda asociado a su origen: si proviene de una venta, queda vinculado al pedido cobrado; si proviene de un gasto, al egreso correspondiente. Esto permite auditar la historia completa de cualquier saldo.	{tesoreria,auditoria}	{mvp_movimientos_caja,mvp_operacion_caja,mvp_tipo_operaciones}	{}	{}	v1.9	2026-05-16	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"motivo": "fusionada", "version": 1, "visible": false, "cubierta_por": "RN-T02"}
RN-T20	RN-046	0	Comprobante de movimiento de cuenta corriente	tesoreria	PROPUESTA	\N	\N	Cada operación especial que la Tesorería hace sobre la Caja Central y que toca la cuenta corriente de un socio genera un comprobante: un documento con número único, fecha y hora, el socio, el detalle de la operación y el importe movido. Ese comprobante respalda el movimiento del libro personal del socio; no es una transferencia ni un movimiento de caja en sí, es el registro que le da soporte.	El comprobante es la fila de mvp_operacion_caja vinculada al asiento de mvp_ctacte por operacion_id. Se identifica con nro_comprobante: entero secuencial con índice único global (uq_mvp_operacion_caja_nro_comprobante), asignado al confirmar la operación, siguiendo el patrón de uq_mvp_ventas_nro_factura. Registra fecha y hora (fecha), usuario que la genera (usuario_id = Tesorero), socio atribuido (tercero_id, tipo_tercero=SOCIO), tipo de operación (tipo_operacion_id) e importe (monto del movimiento asociado). El asiento de ctacte es un registro paralelo al movimiento de caja en Central, no una transferencia entre cajas. fn_movimientos_ctacte expone nro_comprobante en el detalle; el reporte ordenado del libro funciona como herramienta de auditoría.	{tesoreria,ctacte,comprobante,auditoria}	{mvp_operacion_caja,mvp_ctacte,mvp_movimientos_caja}	{fn_movimientos_ctacte,fn_registrar_ingreso,fn_registrar_retiro,fn_registrar_adelanto,fn_registrar_aporte}	{SCR-MiCuentaPersonal,SCR-ConsultaCte,SCR-OperacionesEspeciales}	v1.14	2026-07-02	2026-06-27 14:27:51.782022+00	2026-07-03 16:23:21.062276+00	1	{"motivo": "propuesta", "version": 1, "visible": false}
RN-T19	RN-045	0	Cuenta Corriente del Socio (subsistema)	tesoreria	VIGENTE	\N	\N	La cuenta corriente es el libro personal donde la Tesorería anota los movimientos de dinero de cada socio sobre la Caja Central: dividendos, adelantos, retiros, ingresos y aportes. No es una caja ni guarda dinero, no tiene cierre, no se comparte y no aparece en el Dashboard. El socio solo la consulta; los asientos los genera siempre la Tesorería. El saldo indica cuánto puede retirar el socio; los aportes son patrimoniales y no lo afectan.	Subsistema de tesorería materializado en mvp_ctacte: libro perpetuo, sin cierre, no compartido y ausente del Dashboard de Hidroplanta. Cada asiento referencia una operación de mvp_operacion_caja (operacion_id) que actúa como comprobante. tipo_mov_ctacte en {DIVIDENDOS, INGRESO, ADELANTO, LIQUIDACION, RETIRO, APORTE}. El saldo (haber) se calcula solo sobre filas con afecta_saldo=true: haber = + Sum dividendos + Sum ingresos - Sum adelantos - Sum retiros - Sum liquidaciones. Los movimientos patrimoniales (APORTE, afecta_saldo=false) se registran y se ven en el libro pero no integran el saldo. Escritura exclusiva por RPC SECURITY DEFINER del Tesorero (fn_registrar_adelanto, fn_registrar_retiro, fn_registrar_ingreso, fn_registrar_aporte, fn_rendir_caja_socio, fn_ejecutar_cierre); ningún rol tiene INSERT/UPDATE/DELETE directo. RLS ctacte_access: SELECT para admin y tesorero (todos los socios) y para el socio (solo socio_id=auth.uid()). Detalle del libro vía fn_movimientos_ctacte; resumen y haber vía fn_cuenta_socio; listado consolidado para Tesorería vía fn_ctacte_resumen_socios. Precisa la fórmula de haber de RN-T18 al incorporar ingresos y liquidaciones. El sobregiro se difiere a v2 (RN-T21).	{tesoreria,ctacte,cuenta_corriente,saldo,libro_mayor}	{mvp_ctacte,mvp_operacion_caja,mvp_socios,mvp_users}	{fn_cuenta_socio,fn_movimientos_ctacte,fn_ctacte_resumen_socios,fn_registrar_ingreso,fn_registrar_aporte}	{SCR-MiCuentaPersonal,SCR-ConsultaCte}	v1.14	2026-07-03	2026-06-27 14:27:51.782022+00	2026-07-03 16:23:21.062276+00	1	{"texto": "La cuenta corriente es el libro personal donde la Tesorería anota los movimientos de dinero de cada Socio sobre la Caja Central: dividendos, adelantos, retiros, ingresos y aportes. Pertenece al flujo personal del Socio: es independiente de su caja delegada y nunca se mezcla con ella. No es una caja: no guarda dinero ni tiene cierre. El Socio la consulta; los asientos los genera siempre la Tesorería. El saldo indica cuánto puede retirar; los aportes son patrimoniales y no lo afectan.", "version": 1, "visible": true}
RN-T05.2	RN-022	2	Proceso de Cierre Mensual	tesoreria	VIGENTE	\N	\N	Al cierre de cada mes el Tesorero ejecuta el cierre del período. Se calculan los dividendos (RN-T17) y se registran como haber del socio en Caja Central sin generar movimiento; se barre el saldo de cada caja SOCIO a Central, dejándola en cero. El saldo de una caja delegada nunca es negativo (RN-T01.2), así que no hay arrastre deudor. Las cajas Repartidor no participan.	El Tesorero ejecuta el cierre del período no cerrado. Paso 1 (consolidación): se consolidan las operaciones del período. Paso 2 (dividendos): se calculan según RN-T17 en orden no invertible (ventas → Estado de Resultados → ganancia) y se registran en mvp_cierre_detalle.monto_dividendos; NO generan movimiento de caja: el efectivo queda en Caja Central como haber del socio (RN-T18). Paso 3 (barrido): el saldo de cada caja SOCIO se transfiere a Caja Central (tipo_referencia CIERRE), dejándola en cero. Paso 4 (período): se cierra el período actual y se abre el siguiente.\n\nRequisito previo: todas las cajas SOCIO deben estar rendidas en el período (guarda C1_RENDICION, RN-T22). Las cajas Repartidor no participan.\n\nEl antiguo Paso de arrastre del saldo deudor al período siguiente queda SIN EFECTO: la caja delegada no puede quedar en saldo negativo (RN-T01.2, RN-C01.1). El código de arrastre y el check C5_DEUDOR del precierre se conservan como defensa, pero son inalcanzables; el saldo inicial de una caja SOCIO es siempre cero (RN-T16.1). Revisión 2026-06-15: los dividendos ya no se transfieren a la caja del socio; bajo el modelo de caja delegada permanecen en Central.	{tesoreria,cierre_mensual,dividendos,liquidacion,tesorero,rendicion}	{mvp_cajas,mvp_cierres,mvp_cierre_detalle,mvp_cierre_resumen,mvp_periodo,mvp_movimientos_caja,mvp_rendiciones,mvp_ctacte,mvp_socios}	{fn_preview_cierre,fn_precierre_estado,fn_ejecutar_cierre,fn_abrir_periodo}	{SCR-CierreMensual}	v1.17	2026-07-13	2026-05-16 12:31:44.374583+00	2026-07-13 21:09:38.080794+00	1	{"texto": "Al terminar el mes, el Tesorero ejecuta el cierre del período: se calculan los dividendos de cada Socio y se acreditan en su cuenta corriente, como haber en la Caja Central; el saldo de cada caja delegada se transfiere a la Central y queda en cero. Antes del cierre, cada Socio tiene que haber rendido su caja. Las cajas de Repartidor no participan.", "absorbe": ["RN-T16.1"], "version": 2, "visible": true}
RN-T21	RN-047	0	No sobregiro de la cuenta corriente (v1)	tesoreria	PROPUESTA	\N	\N	En esta versión el socio no puede sobregirar su cuenta corriente con un retiro: la Tesorería no puede registrar un retiro mayor al saldo disponible del socio. El adelanto es la excepción: como es un anticipo de dividendos futuros, sí puede dejar el saldo en negativo. El ingreso nunca sobregira porque suma saldo. Sobregirar con un límite definido en el perfil del socio queda para la v2.	Guard de v1 sobre el saldo de mvp_ctacte (haber expuesto por fn_cuenta_socio). RETIRO: fn_registrar_retiro rechaza la operación si (haber_actual - monto) < 0, además del guard preexistente de no dejar la Caja Central en negativo (RN-T13). ADELANTO: excluido del guard; por su naturaleza de anticipo contra dividendos futuros (RN-T18) puede dejar el haber en negativo. INGRESO: no aplica, incrementa el haber. El sobregiro con tope configurable por socio (campo de límite en el perfil) se difiere a v2, fuera del MVP. El error de saldo insuficiente se emite con ERRCODE P0001 y HINT diferenciable (SALDO_INSUFICIENTE_CTACTE) para mensaje legible en la UI.	{tesoreria,ctacte,sobregiro,retiro,adelanto}	{mvp_ctacte,mvp_cajas,mvp_movimientos_caja}	{fn_registrar_retiro,fn_registrar_adelanto,fn_cuenta_socio}	{SCR-OperacionesEspeciales,SCR-ConsultaCte}	v1.14	2026-07-02	2026-06-27 14:27:51.782022+00	2026-07-03 16:23:21.062276+00	1	{"motivo": "propuesta", "version": 1, "visible": false}
RN-U03	RN-003	0	Participación del Socio	usuarios	VIGENTE	\N	\N	Cuando se incorpora un Socio a Hidroplanta, se le asignan dos porcentajes: uno define su participación en las ganancias y otro su participación en las ventas. Ambos van entre 0 y 100. Se ingresan al darlo de alta y pueden modificarse después. El sistema los usa en el cierre mensual para calcular cuánto le corresponde a cada Socio.	Cuando se incorpora un Socio a Hidroplanta, se le asignan dos porcentajes que definen cómo se reparten las ganancias y las ventas entre los Socios. Ambos porcentajes se ingresan al dar de alta al Socio y pueden modificarse después. Al final de cada mes, durante el cierre mensual, el sistema usa estos porcentajes para calcular cuánto le corresponde a cada Socio. Los porcentajes admiten valores entre 0 y 100.	{usuarios,socio,dividendos,cierre_mensual}	{mvp_socios}	{}	{}	v1.9	2026-07-02	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"texto": "A cada Socio se le asignan dos porcentajes: uno de participación en las ganancias y otro en las ventas. Se cargan al darlo de alta y pueden modificarse después. El cierre mensual los usa para calcular el dividendo que le corresponde a cada uno.", "version": 1, "visible": true}
RN-T08.1	RN-025	1	Exclusividad de Movimientos Especiales sobre Caja Central	tesoreria	VIGENTE	\N	\N	Los aportes, retiros y adelantos de los Socios siempre pasan por la Caja Central y los registra el Tesorero o el Administrador; no se permite mover dinero directamente entre cajas sin pasar por la Central. Única excepción: un Socio puede transferir fondos comerciales desde su caja delegada a la de otro Socio sin pasar por la Central ni la Tesorería; es la única operación que mueve dinero directo entre cajas delegadas y se rige por RN-T14.	Cuando un Socio aporta capital a Hidroplanta, retira fondos personales, o recibe un adelanto a cuenta de su liquidación mensual, esa operación siempre pasa por la Caja Central. No se permite mover dinero directamente entre la caja personal de un Socio y otra caja sin pasar primero por la Central. Los usuarios habilitados para registrar estos movimientos especiales son el Tesorero y el Administrador. Los adelantos otorgados quedan registrados y se descuentan automáticamente del cálculo de dividendos al cierre del mes. Como única excepción a esta centralización, un socio puede transferir fondos desde su caja a la de otro socio en calidad de préstamo de corto plazo, sin pasar por la Caja Central y sin intervención de la Tesorería. Esta operación, la única que mueve dinero directamente entre cajas de socios, y sus condiciones están reguladas por RN-T14.	{tesoreria,caja_central,aportes,retiros,adelantos,tesorero,prestamo_entre_socios}	{mvp_cajas,mvp_movimientos_caja}	{}	{SCR-OperacionesEspeciales}	v1.11	2026-07-06	2026-06-05 17:50:08.920444+00	2026-07-06 21:35:56.714463+00	1	{"motivo": "fusionada", "version": 1, "visible": false, "cubierta_por": "RN-T04"}
RN-V02	RN-009	0	Gestión de Pedidos y Precios	ventas	VIGENTE	\N	\N	Cuando un Socio carga un pedido, indica la fecha de entrega, qué productos lleva el cliente y en qué cantidades. Por cada producto, el sistema guarda dos precios: el precio de lista vigente al momento del pedido y el precio que efectivamente se cobró, que puede ajustarse si corresponde un descuento. El total se calcula automáticamente sumando precio por cantidad.	Cuando un Socio recibe un pedido por teléfono u otro canal, lo carga manualmente indicando para qué fecha se entrega, qué productos lleva el cliente y en qué cantidades. Por cada producto, el sistema sugiere el precio de lista vigente y permite ajustarlo si corresponde (por ejemplo, un descuento puntual). Se guardan ambos valores: el precio de lista al momento del pedido y el precio real aplicado. El total se calcula automáticamente. El sistema también admite un campo opcional de notas para registrar comentarios sobre el pedido.	{ventas,pedidos,padron}	{mvp_ventas,mvp_ventas_detalle,mvp_productos}	{fn_carga_rapida_venta}	{SCR-IngresoPedidos}	v1.9	2026-07-02	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"texto": "Al cargar un pedido se indican la fecha de entrega, los productos y las cantidades. Por cada producto se guardan dos precios: el de lista vigente y el efectivamente cobrado, que puede ajustarse si corresponde un descuento. El total se calcula automáticamente.", "version": 1, "visible": true}
RN-V04	RN-011	0	Inventario	ventas	VIGENTE	\N	\N	Hidroplanta produce hortalizas en forma continua, por lo que no hay manejo de stock ni inventario en esta versión del sistema. Cuando se carga un pedido, no se descuenta nada del stock disponible. El control de la disponibilidad real lo hace el Socio fuera del sistema.	Hidroplanta produce hortalizas en forma continua, por lo que no hay manejo de stock ni inventario en esta versión del sistema. Cuando se carga un pedido, no se descuenta nada del stock disponible. El control de la disponibilidad real lo hace el Socio fuera del sistema.	{ventas,padron}	{}	{}	{}	v1.9	2026-05-16	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"texto": "Hidroplanta produce en forma continua, por eso el sistema no maneja stock: cargar un pedido no descuenta nada. La disponibilidad real la controla el Socio fuera del sistema.", "version": 1, "visible": true}
RN-T01.2	RN-018	2	Arquitectura de Cajas	tesoreria	VIGENTE	\N	\N	Hidroplanta organiza el manejo del dinero en tres tipos de cajas. La Caja Central, única en el sistema, la administra el Tesorero y concentra aportes, retiros y dividendos. Cada Socio tiene su caja mensual donde registra ventas cobradas, compras y gastos; nunca puede quedar en saldo negativo. Cada Repartidor activo tiene una caja transitoria diaria que recibe los cobros del día y se vacía al final de la jornada.	El sistema organiza el manejo del dinero en tres tipos de cajas. La Caja Central, única en todo el sistema, la administra exclusivamente el Tesorero y concentra los aportes, retiros y dividendos generales. Cada Socio tiene su propia caja mensual (delegada) donde se registran sus ventas cobradas, compras y gastos durante el mes. Y cada Repartidor tiene una caja transitoria donde van entrando los cobros del día, que al final de la jornada se rinden hacia las cajas de los Socios. Las cajas de Repartidor son diarias y no participan del cierre mensual.\n\nINVARIANTE DE LA CAJA DELEGADA: su saldo nunca es negativo. Es efectivo de Hidroplanta en custodia del Socio; no se puede entregar lo que no se tiene. Solo entra dinero por dos vías: el cobro de ventas y la transferencia recibida de otra caja delegada con saldo (RN-T14). El flujo personal del Socio (aportes, adelantos, retiros, dividendos) circula por la Caja Central y su cuenta corriente (RN-T19) y NO alimenta la caja delegada. En consecuencia, un egreso que exceda el saldo se rechaza (RN-C01.1) y el saldo deudor no puede existir.	{tesoreria,cajas,caja_central,repartidor,caja_delegada,saldo}	{mvp_cajas}	{calcular_saldo_caja}	{SCR-CajaCentral,SCR-Rendicion}	v1.17	2026-07-13	2026-05-16 12:31:44.374583+00	2026-07-13 21:08:33.450135+00	1	{"texto": "El dinero circula por dos flujos independientes que no se mezclan. El comercial usa las cajas delegadas: cada Socio administra una caja mensual con dinero de la empresa (por eso «delegada») donde registra ventas cobradas, compras y gastos; al cierre, su saldo pasa a la Caja Central. Esa caja nunca queda en negativo: no se puede pagar más de lo que hay en ella. El personal se asienta en la cuenta corriente del Socio, contra la Caja Central: dividendos, adelantos, retiros y aportes. La Central, única, la maneja el Tesorero. Cada Repartidor tiene una caja diaria transitoria.", "version": 2, "visible": true}
RN-T07	RN-024	0	Referencia Polimórfica en Movimientos	tesoreria	VIGENTE	\N	\N	Para que cualquier movimiento de caja pueda auditarse hasta su origen, el sistema guarda dos datos adicionales: una etiqueta que indica de qué tipo de documento proviene el movimiento (una venta, un egreso, una transferencia o un cierre) y el identificador del documento. Así, mirando un movimiento, siempre se puede reconstruir qué operación lo generó.	Para que cualquier movimiento de caja pueda auditarse hasta su origen, el sistema guarda dos datos adicionales: una etiqueta que indica de qué tipo de documento proviene el movimiento (una venta, un egreso, una transferencia o un cierre) y el identificador del documento. Así, mirando un movimiento, siempre se puede reconstruir qué operación lo generó.	{tesoreria,auditoria}	{mvp_movimientos_caja}	{}	{}	v1.9	2026-05-16	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"motivo": "fusionada", "version": 1, "visible": false, "cubierta_por": "RN-T02"}
RN-D01.1	RN-031	1	Cálculo y alcance del Dashboard	dashboard	VIGENTE	\N	\N	El Dashboard muestra una foto del período mensual en curso: resultado de Hidroplanta, Caja Central, cada Caja Delegada y las Cajas Repartidoras. Se calcula al momento de la consulta. Disponible para Administrador, Tesorero y Socio. El encabezado de Cajas Delegadas informa los totales consolidados (recaudación, gastos, resultado, saldo real y fondos en tránsito) y lo ven todos los Socios; el detalle por caja sigue restringido a la caja propia. Las Cajas Repartidoras se muestran en solo lectura.	El Dashboard muestra una foto consolidada del período mensual en curso. La información se calcula al consultarse, no se almacena, y siempre refleja el estado actual.\r\n\r\nEl bloque Cajas Delegadas tiene un encabezado con los totales de la cooperativa: Recaudación (ventas cobradas en la Caja Delegada más las rendiciones recibidas desde una Caja Repartidora), Compras y gastos, Estado de Resultados (Recaudación menos Compras y gastos), Saldo real total (suma física de los movimientos de todas las Cajas Delegadas) y Fondos en tránsito (dinero cobrado por Repartidores y aún no rendido). El encabezado lo ven todos los Socios; el detalle por caja sigue restringido a la caja propia de cada Socio.\r\n\r\nLos fondos en tránsito explican la única diferencia posible entre el Estado de Resultados de las Cajas Delegadas y el de la empresa que informa Caja Central: el dinero comercial entra por las Cajas Delegadas y las Cajas Repartidoras, y sale por las Cajas Delegadas. Rendidas todas las Cajas Repartidoras, ambos resultados coinciden.\r\n\r\nLas Cajas Repartidoras se muestran en un bloque de solo lectura, con un resumen por caja (cobrado, rendido, saldo pendiente y rendiciones administrativas) y el detalle de movimientos del período, ordenable y paginado. Un saldo pendiente distinto de cero indica un Repartidor que no rindió. Los usuarios tester se identifican con etiqueta y se excluyen de los totales.	{dashboard,estadisticas,tesoreria,socio}	{mvp_movimientos_caja,mvp_operacion_caja,mvp_ventas,mvp_ventas_detalle,mvp_egresos,mvp_socios,mvp_cajas,mvp_cierres,mvp_users,mvp_repartidores}	{fn_dashboard_periodo,fn_dashboard_cajas_repartidores,fn_dashboard_delegadas_header,calcular_saldo_caja}	{SCR-Dashboard}	v1.18	2026-07-14	2026-05-16 12:31:44.374583+00	2026-07-14 22:25:25.625171+00	1	{"texto": "El Dashboard muestra la foto del mes en curso: el resultado de Hidroplanta, la situación de la Caja Central y la de cada caja de Socio. Los números se calculan al momento de consultar, por eso siempre están al día. Lo ven el Administrador, el Tesorero y los Socios. Las cajas de Repartidor no aparecen porque son diarias, no mensuales.", "version": 1, "visible": true}
RN-CC01	RN-030	0	Pantalla SCR-CajaCentral solo lectura	caja_central	VIGENTE	\N	\N	El Administrador y el Tesorero pueden consultar en cualquier momento el estado de la Caja Central, viendo su saldo actualizado y el listado de movimientos del período. Esta pantalla es exclusivamente informativa: no permite operar. Para registrar aportes, retiros o adelantos hay que ir a la pantalla específica de Movimientos Especiales.	El Administrador y el Tesorero pueden consultar en cualquier momento el estado de la Caja Central, viendo su saldo actualizado y el listado de movimientos del período. Esta pantalla no permite operar: para registrar aportes, retiros o adelantos hay que ir a la pantalla específica de Movimientos Especiales.	{caja_central,tesoreria,permisos}	{mvp_cajas,mvp_movimientos_caja}	{calcular_saldo_caja}	{SCR-CajaCentral}	v1.9	2026-07-02	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"motivo": "fusionada", "version": 1, "visible": false, "cubierta_por": "RN-T04"}
RN-A01.1	RN-032	1	ABM de Usuarios	administracion	VIGENTE	\N	\N	El Administrador gestiona la mayoría de los usuarios del sistema: crea cuentas, modifica datos y deshabilita los que dejan de operar (las bajas son lógicas, no físicas). Los Socios tienen una capacidad delegada: solo pueden crear y modificar Operadores. Al crear un usuario, el sistema genera automáticamente la caja que le corresponde según su rol. El rol primario no se cambia: hay que dar de baja y crear uno nuevo.	El Administrador es quien gestiona la mayoría de los usuarios del sistema: crea cuentas para Socios, Tesorero, Operadores y Repartidores; modifica sus datos cuando hace falta; y los deshabilita cuando dejan de operar (no se eliminan físicamente). Los Socios tienen una capacidad delegada y acotada: pueden crear y modificar Operadores en nombre de los clientes que atienden. Al crear un usuario, el sistema le genera automáticamente la caja que le corresponda según su rol. Si se necesita cambiar el rol principal de un usuario existente (por ejemplo, convertir a un Socio en Tesorero), no se modifica directamente: se desactiva el usuario actual y se crea uno nuevo con el rol correcto.	{administracion,usuarios,abm,admin,socio}	{auth.users,mvp_users,mvp_socios,mvp_cajas,mvp_repartidores,mvp_clientes}	{fn_crear_usuario,fn_actualizar_usuario}	{SCR-Usuarios}	v1.9	2026-05-16	2026-05-16 12:31:44.374583+00	2026-07-03 16:23:21.062276+00	1	{"texto": "El Administrador crea los usuarios, modifica sus datos y los deshabilita cuando dejan de operar (nunca se borran). Los Socios solo pueden crear y modificar Operadores. Al crear un usuario, el sistema le genera automáticamente su caja según el rol. El rol principal no se cambia: se da de baja el usuario y se crea uno nuevo.", "version": 1, "visible": true}
RN-T11	RN-028	0	Rendición diaria del repartidor	tesoreria	VIGENTE	\N	\N	Al finalizar la jornada, el Repartidor entra a la pantalla de rendición y traspasa todo el dinero cobrado del día a las cajas correspondientes. Si es un Socio que actúa también como Repartidor, el destino es su propia caja Socio. Si es un Repartidor único, distribuye el total entre las cajas de los Socios involucrados. El sistema no admite rendiciones parciales: o la caja queda en cero o se rechaza la operación.	Cuando un Repartidor termina la jornada, entra a la pantalla de rendición y traspasa todo el dinero cobrado durante el día a las cajas correspondientes. Si es un Socio que también actúa como Repartidor (caso compartido), el destino es automáticamente su propia caja de Socio: solo tiene que confirmar. Si es un Repartidor único contratado externamente, el sistema le muestra un formulario donde tiene que distribuir el total entre las cajas de los Socios involucrados; la suma de la distribución tiene que coincidir exactamente con el saldo de la caja. El sistema no admite rendiciones parciales: o la caja queda en cero al rendir, o la rendición se rechaza. Una vez confirmada, la rendición no puede revertirse.	{tesoreria,rendicion,repartidor,transferencias}	{mvp_cajas,mvp_movimientos_caja,mvp_operacion_caja,mvp_tipo_operaciones,mvp_repartidores}	{fn_rendir_dia,calcular_saldo_caja}	{SCR-Rendicion}	v1.9	2026-07-03	2026-05-16 12:31:44.374583+00	2026-07-03 17:01:09.466381+00	1	{"motivo": "fusionada", "version": 1, "visible": false, "cubierta_por": "RN-T10"}
\.


--
-- Data for Name: mvp_rendiciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_rendiciones (id, caja_id, socio_id, periodo_id, saldo_libro, efectivo_declarado, faltante, operacion_liquidacion_id, usuario_id, fecha, created_at, updated_at) FROM stdin;
425b4221-e17b-4ef0-b97f-69e70c358d35	6638fa38-c9bd-4004-8a84-891005d8f0b9	8855cdde-cd2a-4422-9220-041f5da8f61f	3cc69ffa-6f76-4970-bc03-4e5ee0153175	0.00	0.00	0.00	\N	8855cdde-cd2a-4422-9220-041f5da8f61f	2026-06-30 02:28:19.450677	2026-06-30 02:28:19.450677+00	2026-06-30 02:28:19.450677+00
3236558b-5ea2-4d4e-9cfe-36b1c925a345	c2c653b5-bd3b-4e71-a5b4-bc8599183e33	f96a856d-9da8-4873-9256-62ec1e3a7c55	3cc69ffa-6f76-4970-bc03-4e5ee0153175	0.00	0.00	0.00	\N	f96a856d-9da8-4873-9256-62ec1e3a7c55	2026-07-01 20:39:23.05577	2026-07-01 20:39:23.05577+00	2026-07-01 20:39:23.05577+00
05081557-5bab-4595-8315-0dab5551fc6e	300b4667-734d-45e0-a92a-a78737f75eb8	259e6361-632b-4584-b7c8-90a8c3b411a5	3cc69ffa-6f76-4970-bc03-4e5ee0153175	2064494.00	2064494.00	0.00	\N	259e6361-632b-4584-b7c8-90a8c3b411a5	2026-07-02 16:09:36.081473	2026-07-02 16:09:36.081473+00	2026-07-02 16:09:36.081473+00
4f56b14a-19ef-41be-b7a2-28098cfb4c2c	f2016a87-e798-4e74-a11b-43a2679dc5b6	2a08da39-1889-4a3c-a67b-fe63deb762a8	3cc69ffa-6f76-4970-bc03-4e5ee0153175	958782.00	958782.00	0.00	\N	2a08da39-1889-4a3c-a67b-fe63deb762a8	2026-07-02 18:24:06.708407	2026-07-02 18:24:06.708407+00	2026-07-02 18:24:06.708407+00
fdf68e45-cc5e-42df-8d78-b8dfcab1fb3b	300b4667-734d-45e0-a92a-a78737f75eb8	259e6361-632b-4584-b7c8-90a8c3b411a5	cc61b1c7-afaf-453e-9254-6b2d24809465	1242887.00	1242887.00	0.00	\N	259e6361-632b-4584-b7c8-90a8c3b411a5	2026-08-01 13:04:53.393895	2026-08-01 13:04:53.393895+00	2026-08-01 13:04:53.393895+00
cf92c64b-0f74-431e-97a2-bbb783f843d9	c2c653b5-bd3b-4e71-a5b4-bc8599183e33	f96a856d-9da8-4873-9256-62ec1e3a7c55	cc61b1c7-afaf-453e-9254-6b2d24809465	0.00	0.00	0.00	\N	f96a856d-9da8-4873-9256-62ec1e3a7c55	2026-08-01 13:05:54.512157	2026-08-01 13:05:54.512157+00	2026-08-01 13:05:54.512157+00
618743e8-614b-4af9-bd8a-962b289be1e7	6638fa38-c9bd-4004-8a84-891005d8f0b9	8855cdde-cd2a-4422-9220-041f5da8f61f	cc61b1c7-afaf-453e-9254-6b2d24809465	0.00	0.00	0.00	\N	8855cdde-cd2a-4422-9220-041f5da8f61f	2026-08-01 13:06:46.702917	2026-08-01 13:06:46.702917+00	2026-08-01 13:06:46.702917+00
41e17ea3-d5bc-4a6a-b51a-95ee2177c77e	f2016a87-e798-4e74-a11b-43a2679dc5b6	2a08da39-1889-4a3c-a67b-fe63deb762a8	cc61b1c7-afaf-453e-9254-6b2d24809465	1004700.00	0.00	1004700.00	eee91392-638f-4e63-ae95-07618b73233c	2a08da39-1889-4a3c-a67b-fe63deb762a8	2026-08-01 13:07:51.19579	2026-08-01 13:07:51.19579+00	2026-08-01 13:07:51.19579+00
\.


--
-- Data for Name: mvp_repartidores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_repartidores (id, user_id, activo, created_at, updated_at) FROM stdin;
8f8fcbef-faf6-4b6f-9cf7-152545d8acde	2a08da39-1889-4a3c-a67b-fe63deb762a8	t	2026-06-08 22:46:45.725432+00	2026-06-08 22:46:45.725432+00
e66e4b43-873a-4ea9-b9ef-f632f2d1673a	8855cdde-cd2a-4422-9220-041f5da8f61f	t	2026-06-08 22:47:01.604851+00	2026-06-08 22:47:01.604851+00
b40c2109-704e-4303-a08f-a9556c3fe571	259e6361-632b-4584-b7c8-90a8c3b411a5	t	2026-06-08 22:47:10.64627+00	2026-06-08 22:47:10.64627+00
e3d2eb7f-9284-4183-9784-9180bd7deabd	f96a856d-9da8-4873-9256-62ec1e3a7c55	t	2026-06-28 00:11:39.90615+00	2026-07-04 19:36:06.166207+00
\.


--
-- Data for Name: mvp_socios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_socios (id, user_id, porc_ganancia, porc_venta, created_at, updated_at) FROM stdin;
36b55efb-e01d-49ee-9259-87c36318d581	2a08da39-1889-4a3c-a67b-fe63deb762a8	50.00	0.00	2026-04-26 17:05:22.304644+00	2026-06-08 22:46:45.725432+00
3ed6493c-0274-46a5-9f6c-13ad9a8f3971	8855cdde-cd2a-4422-9220-041f5da8f61f	0.00	10.00	2026-04-26 17:05:22.304644+00	2026-06-08 22:47:01.604851+00
56eb204d-9859-4fec-a799-7a38ee21626b	259e6361-632b-4584-b7c8-90a8c3b411a5	50.00	0.00	2026-04-26 17:05:22.304644+00	2026-07-14 15:21:43.381863+00
e9c40192-2f1d-4f25-890b-8f06d0deeace	f96a856d-9da8-4873-9256-62ec1e3a7c55	0.00	0.00	2026-06-20 21:44:40.830145+00	2026-07-29 19:09:06.245206+00
\.


--
-- Data for Name: mvp_system_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_system_status (id, on_line, updated_at) FROM stdin;
1	f	2026-05-17 17:29:26.782551+00
\.


--
-- Data for Name: mvp_tipo_operaciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_tipo_operaciones (id, codigo, nombre, descripcion, modulo, ambito, cantidad_mov, usa_caja_origen, usa_caja_destino, usa_tercero, tipo_tercero, requiere_documento, tipo_documento, rpc_handler, roles_permitidos, metadata, activa, orden, created_at, updated_at, usa_ctacte, ctacte_efecto, mov_es_multiplo) FROM stdin;
2	COBRO	Cobro	\N	VENTA	COMERCIAL	1	f	t	t	CLIENTE	f	\N	\N	{}	\N	t	2	2026-05-25 18:40:01.004838+00	2026-05-25 18:40:01.004838+00	f	\N	f
3	PAGO	Pago	\N	COMPRA	COMERCIAL	1	t	f	t	PROVEEDOR	f	\N	\N	{}	\N	t	3	2026-05-25 18:40:01.004838+00	2026-05-25 18:40:01.004838+00	f	\N	f
4	AJUSTE	Ajuste	\N	TESORERIA	ADMINISTRATIVA	1	f	t	f	\N	f	\N	\N	{}	\N	t	4	2026-05-25 18:40:01.004838+00	2026-05-25 18:40:01.004838+00	f	\N	f
5	APERTURA	Apertura de caja	\N	TESORERIA	ADMINISTRATIVA	1	f	t	f	\N	f	\N	\N	{}	\N	t	5	2026-05-25 18:40:01.004838+00	2026-05-25 18:40:01.004838+00	f	\N	f
16	CIERRE_PRESTAMO_DELEGADO	Cierre de transferencia entre cajas delegadas	Saldo por cierre de una transferencia entre cajas delegadas que quedó pendiente al cierre del período. La crea el motor de cierre antes del barrido, vinculada a la transferencia original; no mueve efectivo ni afecta la cuenta corriente del socio.	TESORERIA	INTERNA	0	t	t	f	\N	f	\N	fn_ejecutar_cierre	{}	\N	t	15	2026-06-28 22:51:07.034522+00	2026-07-03 18:40:46.214427+00	f	\N	f
11	PRESTAMO_ENTRE_SOCIOS	Transferencia entre cajas delegadas	Transferencia de dinero comercial desde la caja delegada de un Socio hacia la de otro que lo necesita. No es dinero personal y no obliga a devolución. Queda pendiente hasta que se reintegre o hasta que el cierre la salde.	TESORERIA	INTERNA	2	t	t	f	\N	f	\N	fn_registrar_prestamo_socio	{socio}	\N	t	10	2026-06-05 17:05:27.070317+00	2026-07-03 19:59:27.865597+00	f	\N	f
17	ASISTENCIA_CAJA_DELEGADA	Asistencia a caja delegada	La Caja Central provee fondos comerciales a la caja delegada de un Socio para que pueda operar. Es dinero de la empresa, no personal: no se reintegra ni afecta la cuenta corriente del Socio. El saldo remanente vuelve a Central en el barrido del cierre.	TESORERIA	INTERNA	2	t	t	f	\N	f	\N	fn_registrar_transferencia	{tesorero,admin}	\N	t	16	2026-07-24 15:52:23.591458+00	2026-07-24 15:52:23.591458+00	f	\N	f
18	RECAUDACION_ANTICIPADA	Recaudación anticipada a Caja Central	Un Socio entrega a la Caja Central, antes del cierre, parte del efectivo comercial de su caja delegada. Adelanta el barrido: no se reintegra ni afecta la cuenta corriente del Socio.	TESORERIA	INTERNA	2	t	t	f	\N	f	\N	fn_registrar_transferencia	{socio,admin}	\N	t	17	2026-07-24 15:52:23.591458+00	2026-07-24 16:29:12.40423+00	f	\N	f
6	CIERRE	Cierre de caja	\N	TESORERIA	ADMINISTRATIVA	2	t	f	f	\N	f	\N	\N	{}	\N	t	6	2026-05-25 18:40:01.004838+00	2026-07-26 21:41:31.91878+00	f	\N	f
1	TRANSFERENCIA	Transferencia	\N	TESORERIA	INTERNA	2	t	t	f	\N	f	\N	\N	{}	\N	t	1	2026-05-25 18:40:01.004838+00	2026-07-26 21:41:31.91878+00	f	\N	t
15	INGRESO	Ingreso a cuenta corriente	Deposito no patrimonial del socio en Caja Central para balancear su cuenta corriente; inverso del retiro, acredita la ctacte y afecta el saldo.	TESORERIA	ADMINISTRATIVA	1	f	t	t	SOCIO	f	\N	fn_registrar_ingreso	{}	\N	t	14	2026-06-27 14:55:37.259623+00	2026-06-27 16:33:56.481216+00	t	HABER	f
8	RETIRO_DIVIDENDOS	Retiro de dividendos	\N	TESORERIA	ADMINISTRATIVA	1	t	f	t	SOCIO	f	\N	\N	{}	\N	t	8	2026-05-25 18:40:01.004838+00	2026-06-27 16:34:08.830574+00	t	DEBE	f
10	ADELANTO	Adelanto	Adelanto de dividendos a un socio (Caja Central -> Caja Socio); se descuenta en el cierre mensual	TESORERIA	ADMINISTRATIVA	1	t	f	t	SOCIO	f	\N	\N	{}	\N	t	9	2026-05-28 16:31:04.304909+00	2026-06-27 16:34:08.830574+00	t	DEBE	f
13	DIVIDENDOS	Dividendos	Devengamiento de dividendos del cierre; acredita la cuenta corriente del socio sin mover efectivo.	TESORERIA	ADMINISTRATIVA	0	f	f	t	SOCIO	f	\N	fn_ejecutar_cierre	{}	\N	t	12	2026-06-17 01:48:58.696678+00	2026-06-27 16:34:08.830574+00	t	HABER	f
14	LIQUIDACION	Liquidación	Faltante de rendicion de la caja delegada: egreso que la cierra a cero y debita la cuenta corriente del socio.	TESORERIA	ADMINISTRATIVA	1	t	f	t	SOCIO	f	\N	fn_rendir_caja_socio	{socio}	\N	t	13	2026-06-17 01:48:58.696678+00	2026-06-27 16:34:08.830574+00	t	DEBE	f
7	APORTE	Aporte patrimonial	\N	TESORERIA	PATRIMONIAL	1	f	t	t	SOCIO	f	\N	\N	{}	\N	t	7	2026-05-25 18:40:01.004838+00	2026-06-27 16:34:18.366074+00	t	HABER	f
12	CANCELACION_PRESTAMO_ENTRE_SOCIOS	Devolución de transferencia entre cajas delegadas	Devolución de una transferencia entre cajas delegadas. La ejecuta el Socio receptor; revierte la transferencia original a la que queda vinculada.	TESORERIA	INTERNA	2	t	t	f	\N	f	\N	fn_cancelar_prestamo_socio	{socio}	\N	t	11	2026-06-05 17:05:27.070317+00	2026-07-03 18:40:46.214427+00	f	\N	f
\.


--
-- Data for Name: mvp_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_users (id, email, rol, cliente_id, nombre, activo, created_at, updated_at, telefono, rol_tesorero, es_tester) FROM stdin;
2a08da39-1889-4a3c-a67b-fe63deb762a8	jb486005@gmail.com	socio	\N	Javier Benítez	t	2026-04-26 17:05:22.304644+00	2026-07-02 17:51:26.458919+00	11-7777-7777	f	f
52145560-ffc2-4d29-b702-bd1893a62035	hectorjorgeaguirre@hotmail.com	tesorero	\N	Héctor Tesorero	f	2026-04-26 17:05:22.304644+00	2026-07-10 16:53:11.211595+00	\N	f	f
259e6361-632b-4584-b7c8-90a8c3b411a5	ferrando.rodolfo@gmail.com	socio	\N	Rodolfo	t	2026-04-26 17:05:22.304644+00	2026-07-14 15:21:43.381863+00	11-6666-6666	t	f
f96a856d-9da8-4873-9256-62ec1e3a7c55	lucaspeirano@gmail.com	socio	\N	Lucas Peirano	t	2026-06-20 21:44:40.752162+00	2026-07-29 19:09:06.245206+00	1121781490	f	t
20f0a578-b9b3-4e56-a634-aa3ff7970b77	hectorag@gmail.com	admin	\N	Héctor Admin	t	2026-04-26 17:05:22.304644+00	2026-06-03 19:24:05.727735+00	1134195543	f	f
8855cdde-cd2a-4422-9220-041f5da8f61f	patferrari56@gmail.com	socio	\N	Patricia	t	2026-04-26 17:05:22.304644+00	2026-06-08 22:47:01.604851+00	\N	f	f
\.


--
-- Data for Name: mvp_ventas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_ventas (id, cliente_id, socio_id, socio_cobrador_id, created_at, fecha_entrega, estado, total, notas, updated_at, repartidor_id, nro_factura, motivo_anulacion, fecha_asignacion, fecha_anulacion) FROM stdin;
88099e84-762a-47a7-90c0-bdce1a66b9f7	3c6706bb-e519-439c-9ea4-36095cb6c678	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-30 13:11:45.932917	2026-06-26	COBRADO	103500.00	\N	2026-06-30 13:42:19.964812+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41080	\N	\N	\N
4e423182-706d-4218-bfa0-f4b7af3bb0b9	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-30 13:16:13.31843	2026-06-26	COBRADO	29600.00	\N	2026-06-30 13:43:01.476955+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41083	\N	\N	\N
7ce777ee-51e0-4863-a637-8ca5aa89d05c	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-30 13:19:35.252977	2026-06-23	COBRADO	90500.00	\N	2026-06-30 13:43:45.562748+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41077	\N	\N	\N
8ea0dce0-24cc-4b24-a0c8-118b0db24736	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-30 13:26:44.362654	2026-06-26	COBRADO	57000.00	\N	2026-06-30 13:44:24.180832+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41085	\N	\N	\N
b48fe808-7668-4d53-ba45-9efcac9ab9e6	10a150de-5f46-47af-a303-30e1bcd42f90	36b55efb-e01d-49ee-9259-87c36318d581	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:21:52.374101	2026-06-10	COBRADO	17000.00	\N	2026-06-30 13:45:39.707176+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11100	\N	2026-06-10	\N
7d1084e5-b9db-475d-b230-61631e60324f	469c1269-5dd0-453b-99ca-a00adf8ebf87	56eb204d-9859-4fec-a799-7a38ee21626b	\N	2026-06-29 21:26:23.697031	2026-06-29	COBRADO	205325.00	\N	2026-06-30 13:49:32.622926+00	259e6361-632b-4584-b7c8-90a8c3b411a5	290626	\N	2026-06-29	\N
c65f4643-4b84-43b9-8e2c-6870f06e29d7	3249bfe8-6aeb-449c-a605-647b9cae453c	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-30 14:07:28.751543	2026-06-29	COBRADO	198000.00	\N	2026-06-30 14:07:28.751543+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41090	\N	\N	\N
9be7c326-9a4c-4521-8700-a23113923bb4	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-30 14:11:44.67418	2026-06-29	COBRADO	36000.00	\N	2026-06-30 14:11:44.67418+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41088	\N	\N	\N
1689ef65-5132-4c7f-a938-0c98bfa683c0	170cec38-63b0-4969-92a7-ec872bebc116	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-30 14:55:40.575433	2026-06-06	COBRADO	25200.00	\N	2026-06-30 14:55:40.575433+00	259e6361-632b-4584-b7c8-90a8c3b411a5	11094	\N	\N	\N
97126300-4dbc-46a2-aa0b-4efa71d764b4	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-09 12:30:59.263762	2026-07-01	COBRADO	17000.00	\N	2026-07-09 12:30:59.263762+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41093	\N	\N	\N
34256591-b222-410f-8b27-311efbc0ca97	575b9d5a-7152-43b5-af6d-7bd90bc6e780	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-09 12:33:42.438072	2026-07-01	COBRADO	76000.00	\N	2026-07-09 12:33:42.438072+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41095	\N	\N	\N
9d41438f-6faa-433b-8edf-cc25aef71047	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-09 12:37:30.674931	2026-07-03	COBRADO	56000.00	\N	2026-07-09 12:37:30.674931+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41097	\N	\N	\N
2797cc16-57c2-4b55-81a0-f5a23bac2f28	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-09 12:39:14.952396	2026-07-03	COBRADO	36500.00	\N	2026-07-09 12:39:14.952396+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41099	\N	\N	\N
bf23060f-263a-44fd-8d57-3b6680152b08	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-09 12:42:38.98681	2026-07-01	COBRADO	36500.00	\N	2026-07-09 12:42:38.98681+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41092	\N	\N	\N
00b2d302-308b-42ca-a711-89741e5cdcbe	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-19 17:20:01.883488	2026-07-06	COBRADO	23600.00	\N	2026-07-19 17:20:01.883488+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27802	\N	\N	\N
7d61e654-10c5-4bda-832f-6859d7fb1dd0	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-19 17:24:11.542056	2026-07-06	COBRADO	28000.00	\N	2026-07-19 17:24:11.542056+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27801	\N	\N	\N
3e36ab98-2292-47f2-9790-ff9c61179100	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-19 17:25:53.385734	2026-07-08	COBRADO	17000.00	\N	2026-07-19 17:25:53.385734+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27806	\N	\N	\N
4f7ec5be-774e-4c2f-9247-56597747bd30	3c6706bb-e519-439c-9ea4-36095cb6c678	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-19 17:28:33.061417	2026-07-09	COBRADO	180500.00	\N	2026-07-19 17:28:33.061417+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27808	\N	\N	\N
b849d43d-e4a6-4aed-862c-e35460fbdecb	7e992fe9-d375-47b4-acb9-bbf185071bda	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-19 17:33:49.948156	2026-07-10	COBRADO	44000.00	\N	2026-07-19 17:33:49.948156+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27814	\N	\N	\N
d0e8ebd9-1e93-419b-91e2-481a6c2a6d92	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-19 17:35:37.410654	2026-07-10	COBRADO	47500.00	\N	2026-07-19 17:35:37.410654+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27813	\N	\N	\N
54347062-c438-4699-8b35-a297b7326ceb	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-19 17:38:58.237263	2026-07-13	COBRADO	73100.00	\N	2026-07-19 17:38:58.237263+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27816	\N	\N	\N
62438726-116a-4fa4-88a9-cb3171a0fb23	575b9d5a-7152-43b5-af6d-7bd90bc6e780	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-19 17:41:29.956024	2026-07-15	COBRADO	91200.00	\N	2026-07-19 17:41:29.956024+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27817	\N	\N	\N
03848e89-39a7-43cd-8b6a-c943171b2dbb	7e992fe9-d375-47b4-acb9-bbf185071bda	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-19 17:31:09.207138	2026-07-09	COBRADO	38000.00	\N	2026-07-19 17:50:04.646224+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27810	\N	\N	\N
15f22141-23dd-44c5-8dd2-95ce74c34f09	575b9d5a-7152-43b5-af6d-7bd90bc6e780	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-21 20:02:35.562145	2026-07-15	COBRADO	19000.00	\N	2026-07-21 20:02:35.562145+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27818	\N	\N	\N
7dd8440e-3c68-4c65-a08e-51157b687af1	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-21 20:18:41.046646	2026-07-15	COBRADO	28000.00	\N	2026-07-21 20:18:41.046646+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27821	\N	\N	\N
5ea2cc34-2e66-460e-873a-057ef872dceb	3249bfe8-6aeb-449c-a605-647b9cae453c	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-21 20:21:47.517095	2026-07-16	COBRADO	166500.00	\N	2026-07-21 20:21:47.517095+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27823	\N	\N	\N
f463dc19-3f68-4ae7-937d-59ba11ff1255	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-21 20:25:01.976113	2026-07-17	COBRADO	33000.00	\N	2026-07-21 20:25:01.976113+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27825	\N	\N	\N
a152067d-0684-4ca6-be03-92e9e3c75184	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-21 20:28:20.423596	2026-07-17	COBRADO	50100.00	\N	2026-07-21 20:28:20.423596+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27827	\N	\N	\N
d2875995-79bb-4cb8-841b-43a636539638	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-21 20:30:11.139901	2026-07-20	COBRADO	47500.00	\N	2026-07-21 20:30:11.139901+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27829	\N	\N	\N
fb5a8110-a2be-4037-aa7f-c7289c8f83f1	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	\N	2026-06-18 21:52:14.989397	2026-06-01	COBRADO	100000.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11077	\N	2026-06-01	\N
f72ebf0e-a320-4e85-ab95-e363c4e9449b	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	\N	2026-06-18 22:16:45.14204	2026-06-01	COBRADO	29600.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11078	\N	2026-06-01	\N
195ae60e-73b7-41e5-ac13-6c11ae9b6c38	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	\N	2026-06-18 22:17:34.956784	2026-06-01	COBRADO	46500.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11079	\N	2026-06-01	\N
eac6103f-7117-460a-a092-1dd1434a0421	7e992fe9-d375-47b4-acb9-bbf185071bda	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-28 12:31:28.827781	2026-07-24	COBRADO	120500.00	\N	2026-07-28 12:31:28.827781+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27842	\N	\N	\N
6aac7d1f-2c7f-4685-af97-adfaeb6e9a83	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-28 12:33:45.474466	2026-07-24	COBRADO	83100.00	\N	2026-07-28 12:33:45.474466+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27840	\N	\N	\N
e7b9784f-b8e8-407c-b76b-4bb7f5764fc1	7e992fe9-d375-47b4-acb9-bbf185071bda	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-28 12:36:11.844468	2026-07-24	COBRADO	131500.00	\N	2026-07-28 12:36:11.844468+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27837	\N	\N	\N
2017702b-69d0-4729-80ff-d3af4ab8b100	3c6706bb-e519-439c-9ea4-36095cb6c678	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-28 12:38:41.10112	2026-07-23	COBRADO	166500.00	\N	2026-07-28 12:38:41.10112+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27835	\N	\N	\N
b735f45d-c9bc-4cc9-806c-1176524507d3	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-28 12:55:06.585645	2026-07-27	COBRADO	40000.00	\N	2026-07-28 12:55:06.585645+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27833	\N	\N	\N
0648fb30-e041-407b-9b08-4c414328d015	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-28 12:59:18.438289	2026-07-27	COBRADO	23600.00	\N	2026-07-28 12:59:18.438289+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27844	\N	\N	\N
e1138a39-b377-4e7d-9db1-88eedaab0011	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-28 13:01:06.822983	2026-07-20	COBRADO	25800.00	\N	2026-07-28 13:01:06.822983+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27831	\N	\N	\N
28eee34d-d2e2-4338-9ec3-a275d4bc559c	575b9d5a-7152-43b5-af6d-7bd90bc6e780	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-30 15:53:57.892845	2026-07-29	COBRADO	91200.00	\N	2026-07-30 15:53:57.892845+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27452	\N	\N	\N
b849a1fd-026a-4b16-b1e1-452eb66bce4f	3c6706bb-e519-439c-9ea4-36095cb6c678	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-30 15:57:21.995101	2026-07-30	COBRADO	166500.00	\N	2026-07-30 15:57:21.995101+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27454	\N	\N	\N
12ebaa3a-23a3-425a-afa2-fa6d97d19345	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-31 03:25:49.7328	2026-07-31	COBRADO	25800.00	\N	2026-07-31 03:25:49.7328+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27457	\N	\N	\N
7414e697-94c7-4f60-afcf-c951238cb5a3	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-31 03:30:24.504247	2026-07-31	COBRADO	159500.00	\N	2026-07-31 03:30:24.504247+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27458	\N	\N	\N
49d70853-4652-454b-9419-822b7caeede1	575b9d5a-7152-43b5-af6d-7bd90bc6e780	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-19 04:30:53.285777	2026-06-03	COBRADO	76000.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11080	\N	2026-06-03	\N
f804bca9-18b7-4105-8129-7b8f63e9ca9e	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-19 04:32:51.146645	2026-06-03	COBRADO	17000.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11081	\N	2026-06-03	\N
007b8f1d-a423-4ba5-8dd3-b5e724da3180	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-19 04:35:52.075925	2026-06-03	COBRADO	21200.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11082	\N	2026-06-03	\N
8b780d2c-5189-4172-803a-1632b72c2890	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-19 04:37:06.603739	2026-06-03	COBRADO	25500.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11083	\N	2026-06-03	\N
493b3c7e-029c-4fc1-a8a4-f690dcf0401c	3c6706bb-e519-439c-9ea4-36095cb6c678	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-19 04:40:42.01634	2026-06-04	COBRADO	165500.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	11084	\N	2026-06-04	\N
d185c422-7924-4918-9cac-f536a7d6783e	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 11:54:06.796917	2026-06-04	COBRADO	163600.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	11085	\N	2026-06-04	\N
dd4bacb2-b66e-4684-afce-ef3607a88f64	ae45363b-7cb9-47d6-befd-0f8d058ea3eb	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 11:57:11.861703	2026-06-04	COBRADO	98000.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	11086	\N	2026-06-04	\N
b2287a3d-ce8f-4d2f-bad4-bbe12e58de8c	db735bfa-0343-4745-aa54-5dd0c15db45b	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:00:02.169845	2026-06-05	COBRADO	50000.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	11087	\N	2026-06-05	\N
1c577f66-ef47-48b0-a8a6-50126d1183f5	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:02:31.448238	2026-06-05	COBRADO	49000.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11088	\N	2026-06-05	\N
a13ffb73-62e3-4499-8370-975121e99ba6	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:04:09.667167	2026-06-05	COBRADO	69000.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11089	\N	2026-06-05	\N
a2838726-29d8-4fe7-9497-cfa20da0892c	819465e3-bd53-4571-897b-e4a9d4cae03d	36b55efb-e01d-49ee-9259-87c36318d581	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:10:12.197307	2026-06-05	COBRADO	23300.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11090	\N	2026-06-05	\N
c41cc71e-5a93-473d-8017-968b9bc8323d	7e992fe9-d375-47b4-acb9-bbf185071bda	36b55efb-e01d-49ee-9259-87c36318d581	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:11:15.291194	2026-06-05	COBRADO	36500.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	11091	\N	2026-06-05	\N
317b6891-99dc-49a5-9baa-cc5f36ae0fa5	beca476c-87f4-48cf-adeb-90b904d48a10	36b55efb-e01d-49ee-9259-87c36318d581	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:12:53.106907	2026-06-05	COBRADO	20000.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11092	\N	2026-06-05	\N
63ffd0fa-c1c0-41e6-a588-1c160c756217	575b9d5a-7152-43b5-af6d-7bd90bc6e780	36b55efb-e01d-49ee-9259-87c36318d581	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:14:23.830753	2026-06-06	COBRADO	76000.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	11093	\N	2026-06-06	\N
4c4bc996-3a72-4f73-9918-5e261c79d0eb	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	36b55efb-e01d-49ee-9259-87c36318d581	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:17:08.469447	2026-06-08	COBRADO	68000.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11095	\N	2026-06-08	\N
84a3d414-e734-4364-89ea-02ff7a53bf90	10a150de-5f46-47af-a303-30e1bcd42f90	36b55efb-e01d-49ee-9259-87c36318d581	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:17:58.263968	2026-06-08	COBRADO	48500.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11096	\N	2026-06-08	\N
87cc40f2-9e57-414e-9ef6-b784691c2759	819465e3-bd53-4571-897b-e4a9d4cae03d	36b55efb-e01d-49ee-9259-87c36318d581	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:18:47.312853	2026-06-08	COBRADO	25400.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11097	\N	2026-06-08	\N
571ca198-ca4f-40c3-8254-e813922b76d9	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	36b55efb-e01d-49ee-9259-87c36318d581	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:20:17.988002	2026-06-08	COBRADO	112000.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	11098	\N	2026-06-08	\N
17f303ca-9003-4aec-a554-60e68579c17e	819465e3-bd53-4571-897b-e4a9d4cae03d	36b55efb-e01d-49ee-9259-87c36318d581	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:21:10.20233	2026-06-10	COBRADO	27500.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	11099	\N	2026-06-10	\N
8f108d53-a2fe-4205-87a9-2d3b39034110	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	36b55efb-e01d-49ee-9259-87c36318d581	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:23:24.963704	2026-06-10	COBRADO	70500.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41051	\N	2026-06-10	\N
dc5e9eac-3542-4690-b0ae-03f43c81252f	819465e3-bd53-4571-897b-e4a9d4cae03d	36b55efb-e01d-49ee-9259-87c36318d581	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:24:43.332879	2026-06-12	COBRADO	24100.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41052	\N	2026-06-12	\N
d5845dc2-f1d0-42bb-b87b-d6d09f044431	10a150de-5f46-47af-a303-30e1bcd42f90	36b55efb-e01d-49ee-9259-87c36318d581	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:25:39.465747	2026-06-12	COBRADO	73100.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41053	\N	2026-06-12	\N
f70adcf3-d2d2-4b8d-804c-68610ed560a8	db735bfa-0343-4745-aa54-5dd0c15db45b	36b55efb-e01d-49ee-9259-87c36318d581	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:26:53.23068	2026-06-12	COBRADO	82500.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41054	\N	2026-06-12	\N
36c8bd18-7284-42ca-889b-63d87b15a78f	7e992fe9-d375-47b4-acb9-bbf185071bda	36b55efb-e01d-49ee-9259-87c36318d581	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:29:02.877621	2026-06-12	COBRADO	78500.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41055	\N	2026-06-12	\N
10494094-7a23-4270-966e-9c1d02e62d65	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	36b55efb-e01d-49ee-9259-87c36318d581	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:31:25.167271	2026-06-10	COBRADO	65500.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41056	\N	2026-06-10	\N
ca2a904a-e22b-4709-a314-ceeeb8f3691d	3c6706bb-e519-439c-9ea4-36095cb6c678	36b55efb-e01d-49ee-9259-87c36318d581	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:32:54.63034	2026-06-11	COBRADO	183000.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41057	\N	2026-06-11	\N
3bd0e3bc-c051-48ba-b3e3-c57736a5290c	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:39:26.043965	2026-06-15	COBRADO	33800.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41059	\N	2026-06-15	\N
6f5e9a40-d0c7-442e-9c11-037e36f21670	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:40:34.294196	2026-06-15	COBRADO	40500.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41060	\N	2026-06-15	\N
58d6bfbd-c188-4362-bf46-8d0c4ff215b5	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:41:34.798974	2026-06-15	COBRADO	56100.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41061	\N	2026-06-15	\N
697218c2-76c0-447e-a4fc-b8353ecde81b	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:42:30.909684	2026-06-16	COBRADO	25500.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41062	\N	2026-06-16	\N
fe84c328-e264-4abc-9f2f-400f209afefa	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:45:47.551971	2026-06-16	COBRADO	27500.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41063	\N	2026-06-16	\N
fa937de3-7822-4d7b-8e23-ded1426a2085	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:48:15.680194	2026-06-17	COBRADO	17000.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41064	\N	2026-06-17	\N
b72244b1-977d-423e-b863-60fbe7d62bd7	575b9d5a-7152-43b5-af6d-7bd90bc6e780	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:50:57.21166	2026-06-17	COBRADO	76000.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41065	\N	2026-06-17	\N
f34fa3a5-b67c-422d-8d88-ab734ac2a312	3c6706bb-e519-439c-9ea4-36095cb6c678	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:54:13.012093	2026-06-18	COBRADO	177000.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41066	\N	2026-06-18	\N
01742e1e-8dee-458b-b22c-6b140b5c0dea	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:55:18.84808	2026-06-18	COBRADO	111300.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41067	\N	2026-06-18	\N
44191426-9626-4ef9-afc9-72dc89f1a732	beca476c-87f4-48cf-adeb-90b904d48a10	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:56:12.750673	2026-06-18	COBRADO	10000.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41068	\N	2026-06-18	\N
f13dc362-e0bd-40ca-ac82-6859fb5220ec	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:57:24.175117	2026-06-19	COBRADO	50300.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41069	\N	2026-06-19	\N
bca315e2-dd3c-458e-9b67-82a444a3b6f1	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-22 12:58:14.378136	2026-06-19	COBRADO	25400.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41070	\N	2026-06-19	\N
c896909f-850a-455f-9ca4-773bfe5ea508	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 12:59:19.494236	2026-06-18	COBRADO	68000.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41071	\N	2026-06-18	\N
4a4eba49-618c-4e36-93f5-78117d2a956b	3249bfe8-6aeb-449c-a605-647b9cae453c	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 13:04:47.39348	2026-06-22	COBRADO	198000.00	\N	2026-06-22 23:53:35.929213+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41072	\N	2026-06-22	\N
628bcc85-4d0d-48ae-b47b-74a373138839	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-22 13:11:03.937117	2026-06-13	COBRADO	134000.00	\N	2026-06-22 23:53:35.929213+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41058	\N	2026-06-13	\N
115e199b-2922-48a1-a4e6-0fd365c4709b	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-26 15:34:38.096916	2026-06-22	COBRADO	47500.00	\N	2026-06-26 15:34:38.096916+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41073	\N	\N	\N
551c6689-b5e8-4ffa-9a02-b323f7cdeecc	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-26 15:36:49.591976	2026-06-22	COBRADO	63600.00	\N	2026-06-26 15:36:49.591976+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41074	\N	\N	\N
5318c470-e889-460a-9eac-78c18942fa93	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-26 15:39:08.235263	2026-06-22	COBRADO	28000.00	\N	2026-06-26 15:39:08.235263+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41075	\N	\N	\N
527a3fa7-ba92-4930-bae1-8c198644e399	575b9d5a-7152-43b5-af6d-7bd90bc6e780	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-26 15:40:21.78731	2026-06-22	COBRADO	76000.00	\N	2026-06-26 15:40:21.78731+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41076	\N	\N	\N
e9606946-3545-4180-8d96-2c74eeedb662	575b9d5a-7152-43b5-af6d-7bd90bc6e780	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-30 13:08:05.373579	2026-06-24	COBRADO	76000.00	\N	2026-06-30 13:41:59.215686+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41079	\N	\N	\N
7b33a6b7-ab46-4d21-9684-4c3fe05a1a55	7e992fe9-d375-47b4-acb9-bbf185071bda	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-30 13:13:11.487218	2026-06-26	COBRADO	75500.00	\N	2026-06-30 13:42:41.67102+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41081	\N	\N	\N
7101d972-7b99-417b-8e7d-55dbaff920c9	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-30 13:17:17.975895	2026-06-26	COBRADO	10500.00	\N	2026-06-30 13:43:21.530178+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41084	\N	\N	\N
af3160eb-a205-4fde-b0cd-a4edc96c386a	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-30 13:22:23.016304	2026-06-24	COBRADO	46500.00	\N	2026-06-30 13:44:05.685805+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41078	\N	\N	\N
2f62512f-ccc3-45ee-a0f3-227ac57c4a3a	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-30 14:02:42.949324	2026-06-30	COBRADO	133500.00	\N	2026-06-30 14:02:42.949324+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41091	\N	\N	\N
a01e692c-973e-455b-ad10-7e5774ffa206	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-30 14:09:52.622324	2026-06-29	COBRADO	55000.00	\N	2026-06-30 14:09:52.622324+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41089	\N	\N	\N
72782f24-2f31-40ed-af31-ce5a739154db	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-06-30 14:13:11.44965	2026-06-29	COBRADO	27500.00	\N	2026-06-30 14:13:11.44965+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41087	\N	\N	\N
38367469-d996-4215-90ab-4bb78dd8f923	469c1269-5dd0-453b-99ca-a00adf8ebf87	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-06-30 13:36:56.652871	2026-06-30	COBRADO	91750.00	\N	2026-06-30 15:23:41.095773+00	259e6361-632b-4584-b7c8-90a8c3b411a5	300626	\N	2026-06-30	\N
cf500b07-7e2e-40ca-a145-d4daba247fd9	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-09 12:32:51.128143	2026-07-01	COBRADO	23600.00	\N	2026-07-09 12:32:51.128143+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41094	\N	\N	\N
1cc32153-fd17-4e31-a7fb-8a3d622781c5	3c6706bb-e519-439c-9ea4-36095cb6c678	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-09 12:36:25.96423	2026-07-02	COBRADO	156000.00	\N	2026-07-09 12:36:25.96423+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41096	\N	\N	\N
b246eca0-7241-4021-b5b7-4cd720e35bcd	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-09 12:38:20.384258	2026-07-03	COBRADO	23600.00	\N	2026-07-09 12:38:20.384258+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	41098	\N	\N	\N
7be3f424-d803-4b7e-b896-658e6587f835	7e992fe9-d375-47b4-acb9-bbf185071bda	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-09 12:41:10.526569	2026-07-03	COBRADO	39000.00	\N	2026-07-09 12:41:10.526569+00	259e6361-632b-4584-b7c8-90a8c3b411a5	41100	\N	\N	\N
c71f7468-f8c8-4cbc-bf4b-67916f9760e5	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-19 17:18:58.639425	2026-07-06	COBRADO	36500.00	\N	2026-07-19 17:18:58.639425+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27803	\N	\N	\N
883b349b-cc83-4bd3-9b03-9e9441dcc35d	3249bfe8-6aeb-449c-a605-647b9cae453c	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-19 17:21:57.88095	2026-07-06	COBRADO	81500.00	\N	2026-07-19 17:21:57.88095+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27804	\N	\N	\N
72fb6044-5610-43fe-90c8-2cc5ff69c86f	170cec38-63b0-4969-92a7-ec872bebc116	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-19 17:25:14.548548	2026-07-06	COBRADO	48000.00	\N	2026-07-19 17:25:14.548548+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27805	\N	\N	\N
74378a5e-1e3c-4c91-b488-b5051ecf8516	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-19 17:27:15.287088	2026-07-08	COBRADO	74600.00	\N	2026-07-19 17:27:15.287088+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27807	\N	\N	\N
84fe840f-c94b-4e45-9ed1-a5735aca0f7c	3249bfe8-6aeb-449c-a605-647b9cae453c	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-19 17:29:59.858871	2026-07-09	COBRADO	124500.00	\N	2026-07-19 17:29:59.858871+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27809	\N	\N	\N
16ac9237-cdfc-42d2-8428-e987b5d46911	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-19 17:32:01.746648	2026-07-10	COBRADO	25800.00	\N	2026-07-19 17:32:01.746648+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27811	\N	\N	\N
779708ab-5557-4792-8875-5a24dfa8cfc2	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-19 17:34:54.710093	2026-07-10	COBRADO	83100.00	\N	2026-07-19 17:34:54.710093+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27812	\N	\N	\N
0cc8cee0-3a1b-4fd4-910b-aceb1ee24267	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-19 17:36:24.698842	2026-07-13	COBRADO	47500.00	\N	2026-07-19 17:36:24.698842+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27815	\N	\N	\N
2af9b95c-9a92-4685-bdfe-2ccbcaaf92ed	db735bfa-0343-4745-aa54-5dd0c15db45b	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-19 17:42:31.365752	2026-07-15	COBRADO	104000.00	\N	2026-07-19 17:42:31.365752+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27819	\N	\N	\N
a96bff15-ad90-4acc-ac9f-d7b2d74c98e7	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-21 20:17:43.030846	2026-07-15	COBRADO	25500.00	\N	2026-07-21 20:17:43.030846+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27820	\N	\N	\N
00734614-d7ae-4b68-a0b4-7c1b860fd693	3c6706bb-e519-439c-9ea4-36095cb6c678	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-21 20:20:02.899636	2026-07-16	COBRADO	166500.00	\N	2026-07-21 20:20:02.899636+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27822	\N	\N	\N
4df3c0e8-f8aa-44d5-afde-9c0cb67b8561	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-21 20:23:06.949245	2026-07-16	COBRADO	114500.00	\N	2026-07-21 20:23:06.949245+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27824	\N	\N	\N
78be609e-d109-48e9-b670-a1e807eefd9b	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-21 20:27:09.517244	2026-07-17	COBRADO	30200.00	\N	2026-07-21 20:27:09.517244+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27826	\N	\N	\N
80989874-2ba5-4b86-8215-9d5d1c6bfb97	7e992fe9-d375-47b4-acb9-bbf185071bda	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-21 20:29:14.560255	2026-07-17	COBRADO	78500.00	\N	2026-07-21 20:29:14.560255+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27828	\N	\N	\N
cbb77c2e-c120-44c1-b782-007ab766e417	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-21 20:31:02.249434	2026-07-20	COBRADO	112000.00	\N	2026-07-21 20:31:02.249434+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27830	\N	\N	\N
3581af9a-33aa-4c4c-b720-cb71d2ae4901	f72561fb-b0a1-4d09-acba-a4abe0bb4beb	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-28 12:32:44.872623	2026-07-24	COBRADO	173000.00	\N	2026-07-28 12:32:44.872623+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27841	\N	\N	\N
f6525a98-af76-4176-aef5-fd0fb627f797	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-28 12:34:33.531739	2026-07-24	COBRADO	47500.00	\N	2026-07-28 12:34:33.531739+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27838	\N	\N	\N
e30d341f-e131-4f15-a0e4-90dd63185938	3249bfe8-6aeb-449c-a605-647b9cae453c	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-28 12:37:26.642761	2026-07-23	COBRADO	103500.00	\N	2026-07-28 12:37:26.642761+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27836	\N	\N	\N
b05190ff-1ad6-4b03-9108-bd5f8e9e6148	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-28 12:39:38.845234	2026-07-22	COBRADO	23600.00	\N	2026-07-28 12:39:38.845234+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27834	\N	\N	\N
cbcaa551-5761-436d-ae52-2811789a83d4	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-28 12:58:16.52675	2026-07-21	COBRADO	78000.00	\N	2026-07-28 12:58:16.52675+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27832	\N	\N	\N
009ed6cd-13cd-4a95-9874-a2dea0c9f217	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-28 13:00:14.014612	2026-07-27	COBRADO	72100.00	\N	2026-07-28 13:00:14.014612+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27843	\N	\N	\N
b5562eec-d4d4-4351-a218-040d00f6f48e	819465e3-bd53-4571-897b-e4a9d4cae03d	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-30 15:53:09.315009	2026-07-29	COBRADO	28000.00	\N	2026-07-30 15:53:09.315009+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27451	\N	\N	\N
43dc8a2a-4e24-4a44-b359-f833c1482583	3249bfe8-6aeb-449c-a605-647b9cae453c	56eb204d-9859-4fec-a799-7a38ee21626b	56eb204d-9859-4fec-a799-7a38ee21626b	2026-07-30 15:59:42.072974	2026-07-30	COBRADO	145500.00	\N	2026-07-30 15:59:42.072974+00	259e6361-632b-4584-b7c8-90a8c3b411a5	27455	\N	\N	\N
196e9aa0-d105-448d-9b93-93e787c121ab	10a150de-5f46-47af-a303-30e1bcd42f90	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-31 03:27:57.546374	2026-07-31	COBRADO	64500.00	\N	2026-07-31 03:27:57.546374+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27456	\N	\N	\N
3e6e0750-9c79-4b9b-9045-5f053d49f22d	40dda90c-b9ca-4699-ade8-7e3bb1fd33e5	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-31 03:32:06.032538	2026-07-31	COBRADO	47500.00	\N	2026-07-31 03:32:06.032538+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27459	\N	\N	\N
add06fe4-df20-4f02-8802-eea46aeec65a	6f5a2c3a-7240-4f3c-bc02-41accaad8a44	56eb204d-9859-4fec-a799-7a38ee21626b	36b55efb-e01d-49ee-9259-87c36318d581	2026-07-30 15:55:32.587417	2026-07-29	COBRADO	19000.00	\N	2026-07-31 13:30:41.74437+00	2a08da39-1889-4a3c-a67b-fe63deb762a8	27453	\N	\N	\N
\.


--
-- Data for Name: mvp_ventas_bajas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_ventas_bajas (id, venta_id, periodo_id, fecha_baja, usuario_baja_id, estado_previo, nro_factura, fecha_entrega, cliente_id, cliente_razon_social, socio_id, socio_nombre, repartidor_nombre, total, caja_afectada_id, caja_afectada_nombre, motivo, snapshot, created_at, updated_at) FROM stdin;
37aab9dc-17e3-443d-b211-93072ebf6a66	25b1d806-4097-4554-b0e1-c7d4095a8438	cc61b1c7-afaf-453e-9254-6b2d24809465	2026-07-21 19:25:17.455617+00	20f0a578-b9b3-4e56-a634-aa3ff7970b77	COBRADO	27818	2026-07-15	575b9d5a-7152-43b5-af6d-7bd90bc6e780	Ulises	56eb204d-9859-4fec-a799-7a38ee21626b	Rodolfo	Rodolfo	19000.00	300b4667-734d-45e0-a92a-a78737f75eb8	Caja Rodolfo Rolando	prueba de baja - venta test Ulises 15/07	{"venta": {"id": "25b1d806-4097-4554-b0e1-c7d4095a8438", "notas": null, "total": 19000.00, "estado": "COBRADO", "socio_id": "56eb204d-9859-4fec-a799-7a38ee21626b", "cliente_id": "575b9d5a-7152-43b5-af6d-7bd90bc6e780", "created_at": "2026-07-19T17:40:07.598822", "updated_at": "2026-07-19T17:40:07.598822+00:00", "nro_factura": "27818", "fecha_entrega": "2026-07-15", "repartidor_id": "259e6361-632b-4584-b7c8-90a8c3b411a5", "fecha_anulacion": null, "fecha_asignacion": null, "motivo_anulacion": null, "socio_cobrador_id": "56eb204d-9859-4fec-a799-7a38ee21626b"}, "detalle": [{"id": "8b8547a6-e301-4412-8e32-6f2d5fbea10d", "cantidad": 10.00, "venta_id": "25b1d806-4097-4554-b0e1-c7d4095a8438", "created_at": "2026-07-19T17:40:07.598822+00:00", "updated_at": "2026-07-19T17:40:07.598822+00:00", "precio_real": 1900.00, "producto_id": "228aeec5-78b6-4bd2-90d2-ad39c8df33c5", "precio_lista": 3000.00}], "operacion": {"id": "22d4b112-b5e6-499c-a3da-8736b0bc46a9", "fecha": "2026-07-15T03:00:00", "estado": "CONFIRMADA", "created_at": "2026-07-19T17:40:07.598822+00:00", "periodo_id": "cc61b1c7-afaf-453e-9254-6b2d24809465", "tercero_id": "575b9d5a-7152-43b5-af6d-7bd90bc6e780", "updated_at": "2026-07-19T17:40:07.598822+00:00", "usuario_id": "20f0a578-b9b3-4e56-a634-aa3ff7970b77", "documento_id": "25b1d806-4097-4554-b0e1-c7d4095a8438", "tipo_tercero": "CLIENTE", "observaciones": null, "caja_origen_id": null, "documento_tipo": "VENTA", "caja_destino_id": "300b4667-734d-45e0-a92a-a78737f75eb8", "nro_comprobante": null, "tipo_operacion_id": 2, "referencia_externa": null, "operacion_relacionada_id": null}, "movimientos": [{"id": "e4c1f6b5-68e9-4b77-bb32-d2cd16be2700", "fecha": "2026-07-15T03:00:00", "monto": 19000.00, "caja_id": "300b4667-734d-45e0-a92a-a78737f75eb8", "created_at": "2026-07-19T17:40:07.598822+00:00", "updated_at": "2026-07-19T17:40:07.598822+00:00", "operacion_id": "22d4b112-b5e6-499c-a3da-8736b0bc46a9", "referencia_id": "25b1d806-4097-4554-b0e1-c7d4095a8438", "tipo_referencia": "VENTA"}]}	2026-07-21 19:25:17.455617+00	2026-07-21 19:25:17.455617+00
\.


--
-- Data for Name: mvp_ventas_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mvp_ventas_detalle (id, venta_id, producto_id, cantidad, precio_lista, precio_real, created_at, updated_at) FROM stdin;
706b45b6-7960-415d-9d87-469db06973c4	fb5a8110-a2be-4037-aa7f-c7289c8f83f1	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2100.00	2100.00	2026-06-18 21:52:15.186889+00	2026-06-18 21:52:15.186889+00
69034b6b-d838-4786-8bec-7fae55f4b2d9	fb5a8110-a2be-4037-aa7f-c7289c8f83f1	ac7a936f-2229-4748-8201-5aabbfdfd435	10.00	2100.00	2100.00	2026-06-18 21:52:15.186889+00	2026-06-18 21:52:15.186889+00
b3ebf809-d718-478f-b526-05b0d3b433bd	fb5a8110-a2be-4037-aa7f-c7289c8f83f1	ba1b6030-3855-49a1-ae3f-c0163e97a52a	25.00	1500.00	1700.00	2026-06-18 21:52:15.186889+00	2026-06-18 21:52:15.186889+00
54fc863d-540b-4296-a30b-e046c5e91551	fb5a8110-a2be-4037-aa7f-c7289c8f83f1	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	2.00	2000.00	2500.00	2026-06-18 21:52:15.186889+00	2026-06-18 21:52:15.186889+00
18d88a53-1c64-4b76-9cae-8625a8232b04	f72ebf0e-a320-4e85-ab95-e363c4e9449b	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	6.00	2100.00	2100.00	2026-06-18 22:16:45.370344+00	2026-06-18 22:16:45.370344+00
0e41e244-af1f-4ffd-b5f9-e81df1c942b0	f72ebf0e-a320-4e85-ab95-e363c4e9449b	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1500.00	1700.00	2026-06-18 22:16:45.370344+00	2026-06-18 22:16:45.370344+00
4bd433bb-baec-47ad-a454-3a9ca0f46195	195ae60e-73b7-41e5-ac13-6c11ae9b6c38	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2100.00	2100.00	2026-06-18 22:17:35.069627+00	2026-06-18 22:17:35.069627+00
e7eb0873-14b1-4d94-9ed3-0eb25e9337b3	195ae60e-73b7-41e5-ac13-6c11ae9b6c38	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1500.00	1700.00	2026-06-18 22:17:35.069627+00	2026-06-18 22:17:35.069627+00
ca760314-8329-428d-bbb2-6e676542c082	49d70853-4652-454b-9419-822b7caeede1	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	40.00	3000.00	1900.00	2026-06-19 04:30:53.285777+00	2026-06-19 04:30:53.285777+00
7f6de68b-ba8d-4fe7-bad1-1db1fc47daa2	f804bca9-18b7-4105-8129-7b8f63e9ca9e	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1500.00	1700.00	2026-06-19 04:32:51.146645+00	2026-06-19 04:32:51.146645+00
5bd78a35-9a04-4730-a0e4-918f5056e384	007b8f1d-a423-4ba5-8dd3-b5e724da3180	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1500.00	1700.00	2026-06-19 04:35:52.075925+00	2026-06-19 04:35:52.075925+00
d25648f7-e64d-48ca-a5dc-e74b7e2e7d7b	007b8f1d-a423-4ba5-8dd3-b5e724da3180	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	2.00	2100.00	2100.00	2026-06-19 04:35:52.075925+00	2026-06-19 04:35:52.075925+00
fb1b57ac-0c48-4bfd-bc61-d9eca95d3977	8b780d2c-5189-4172-803a-1632b72c2890	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1700.00	2026-06-19 04:37:06.603739+00	2026-06-19 04:37:06.603739+00
e282ccdd-ea27-46cb-bba2-556fda7556f4	493b3c7e-029c-4fc1-a8a4-f690dcf0401c	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	30.00	3000.00	2100.00	2026-06-19 04:40:42.01634+00	2026-06-19 04:40:42.01634+00
347ad1bc-cb04-41bb-924a-65d77aa71ae1	493b3c7e-029c-4fc1-a8a4-f690dcf0401c	ba1b6030-3855-49a1-ae3f-c0163e97a52a	5.00	1700.00	1600.00	2026-06-19 04:40:42.01634+00	2026-06-19 04:40:42.01634+00
0793a695-9142-4eeb-a3e6-453afa2a3cd3	493b3c7e-029c-4fc1-a8a4-f690dcf0401c	7a907a3d-7134-4504-a022-a74c554b75c7	27.00	3500.00	3500.00	2026-06-19 04:40:42.01634+00	2026-06-19 04:40:42.01634+00
722ddfaa-a6aa-4f01-8983-c77040bcc139	d185c422-7924-4918-9cac-f536a7d6783e	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	40.00	2100.00	2200.00	2026-06-22 11:54:06.796917+00	2026-06-22 11:54:06.796917+00
5b39f113-78a0-412a-b973-bb6bed4f86c6	d185c422-7924-4918-9cac-f536a7d6783e	ba1b6030-3855-49a1-ae3f-c0163e97a52a	40.00	1600.00	1700.00	2026-06-22 11:54:06.796917+00	2026-06-22 11:54:06.796917+00
f97b9ebe-f62b-4277-8780-92190feefb47	d185c422-7924-4918-9cac-f536a7d6783e	0c294dd6-af93-42de-aca5-f50ab942924a	2.00	3500.00	3800.00	2026-06-22 11:54:06.796917+00	2026-06-22 11:54:06.796917+00
dd43f53e-e639-4102-86ba-3f8efa985dec	dd4bacb2-b66e-4684-afce-ef3607a88f64	c3e9630c-0382-4f35-8a82-33aa02fa590c	10.00	2100.00	2200.00	2026-06-22 11:57:11.861703+00	2026-06-22 11:57:11.861703+00
0d62f3df-9a74-4c97-8374-569f78b52e9a	dd4bacb2-b66e-4684-afce-ef3607a88f64	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3800.00	3800.00	2026-06-22 11:57:11.861703+00	2026-06-22 11:57:11.861703+00
de1c0f36-9588-48b6-a64f-bdb0f557530c	dd4bacb2-b66e-4684-afce-ef3607a88f64	7a907a3d-7134-4504-a022-a74c554b75c7	10.00	3500.00	3800.00	2026-06-22 11:57:11.861703+00	2026-06-22 11:57:11.861703+00
ad83582f-240b-43eb-95b0-31ede456f38f	b2287a3d-ce8f-4d2f-bad4-bbe12e58de8c	0c294dd6-af93-42de-aca5-f50ab942924a	20.00	3800.00	2500.00	2026-06-22 12:00:02.169845+00	2026-06-22 12:00:02.169845+00
b76c9cf1-215b-4cfa-87f0-a735210c3e7e	1c577f66-ef47-48b0-a8a6-50126d1183f5	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2100.00	2026-06-22 12:02:31.448238+00	2026-06-22 12:02:31.448238+00
09a8dd3b-1a5b-4288-8d0d-297fe987b98e	1c577f66-ef47-48b0-a8a6-50126d1183f5	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1700.00	2026-06-22 12:02:31.448238+00	2026-06-22 12:02:31.448238+00
1f5441ff-e81a-4896-a769-9b5b79d96fee	1c577f66-ef47-48b0-a8a6-50126d1183f5	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	1.00	2000.00	2500.00	2026-06-22 12:02:31.448238+00	2026-06-22 12:02:31.448238+00
5d45c747-b353-4236-bc4d-4a0234898859	a13ffb73-62e3-4499-8370-975121e99ba6	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2200.00	2100.00	2026-06-22 12:04:09.667167+00	2026-06-22 12:04:09.667167+00
9dae68cc-2a5a-48c1-b7f8-0ec65fab49b5	a13ffb73-62e3-4499-8370-975121e99ba6	7a907a3d-7134-4504-a022-a74c554b75c7	1.00	3800.00	3500.00	2026-06-22 12:04:09.667167+00	2026-06-22 12:04:09.667167+00
f62d2e2c-05cd-42e1-b8a3-7adaaa8a4e8e	a13ffb73-62e3-4499-8370-975121e99ba6	ba1b6030-3855-49a1-ae3f-c0163e97a52a	20.00	1700.00	1700.00	2026-06-22 12:04:09.667167+00	2026-06-22 12:04:09.667167+00
cd46885a-7b67-4543-a6db-98a686d9a98d	a2838726-29d8-4fe7-9497-cfa20da0892c	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	3.00	2100.00	2100.00	2026-06-22 12:10:12.197307+00	2026-06-22 12:10:12.197307+00
445d62f0-0b88-48f0-acdb-0dc75fe68340	a2838726-29d8-4fe7-9497-cfa20da0892c	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1500.00	1700.00	2026-06-22 12:10:12.197307+00	2026-06-22 12:10:12.197307+00
350d488b-85fa-4857-959b-28e809067648	c41cc71e-5a93-473d-8017-968b9bc8323d	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2100.00	2100.00	2026-06-22 12:11:15.291194+00	2026-06-22 12:11:15.291194+00
b72e52d7-e743-4249-a25f-9ac2cc976384	c41cc71e-5a93-473d-8017-968b9bc8323d	ac7a936f-2229-4748-8201-5aabbfdfd435	5.00	2100.00	2100.00	2026-06-22 12:11:15.291194+00	2026-06-22 12:11:15.291194+00
dbed85ac-7b1b-420c-a881-38275d27d153	c41cc71e-5a93-473d-8017-968b9bc8323d	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	2.00	2000.00	2500.00	2026-06-22 12:11:15.291194+00	2026-06-22 12:11:15.291194+00
e2aff113-78ab-4b30-be00-97937a4e7919	317b6891-99dc-49a5-9baa-cc5f36ae0fa5	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	2000.00	2026-06-22 12:12:53.106907+00	2026-06-22 12:12:53.106907+00
eba06ed2-4b5c-4a0b-b2c7-9a9bf6f3436c	63ffd0fa-c1c0-41e6-a588-1c160c756217	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	40.00	3000.00	1900.00	2026-06-22 12:14:23.830753+00	2026-06-22 12:14:23.830753+00
378c11cb-4fa6-4a64-a277-22814af1f0ec	4c4bc996-3a72-4f73-9918-5e261c79d0eb	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2100.00	2100.00	2026-06-22 12:17:08.469447+00	2026-06-22 12:17:08.469447+00
85ff3291-af13-42be-902d-a8f09b90398e	4c4bc996-3a72-4f73-9918-5e261c79d0eb	ba1b6030-3855-49a1-ae3f-c0163e97a52a	20.00	1700.00	1700.00	2026-06-22 12:17:08.469447+00	2026-06-22 12:17:08.469447+00
c4c21207-b0b0-4763-a540-e7b434613ca8	4c4bc996-3a72-4f73-9918-5e261c79d0eb	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	1.00	2500.00	2500.00	2026-06-22 12:17:08.469447+00	2026-06-22 12:17:08.469447+00
603bd127-c878-43a4-85cb-eb3e2b71c9e2	84a3d414-e734-4364-89ea-02ff7a53bf90	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2100.00	2100.00	2026-06-22 12:17:58.263968+00	2026-06-22 12:17:58.263968+00
e45c8530-2bb4-4d49-a863-887025f07405	84a3d414-e734-4364-89ea-02ff7a53bf90	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-06-22 12:17:58.263968+00	2026-06-22 12:17:58.263968+00
751d18b7-2d5b-44c8-b66e-fa09d34e6abe	87cc40f2-9e57-414e-9ef6-b784691c2759	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	4.00	2100.00	2100.00	2026-06-22 12:18:47.312853+00	2026-06-22 12:18:47.312853+00
ee4b31ec-4c4c-46f4-95ea-300e02e2bc41	87cc40f2-9e57-414e-9ef6-b784691c2759	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-06-22 12:18:47.312853+00	2026-06-22 12:18:47.312853+00
076a9af1-f162-435c-a34e-f4569ffe09f7	571ca198-ca4f-40c3-8254-e813922b76d9	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	20.00	2100.00	2200.00	2026-06-22 12:20:17.988002+00	2026-06-22 12:20:17.988002+00
e21459cb-0722-4a14-a25b-e87bd07acc20	571ca198-ca4f-40c3-8254-e813922b76d9	ba1b6030-3855-49a1-ae3f-c0163e97a52a	40.00	1700.00	1700.00	2026-06-22 12:20:17.988002+00	2026-06-22 12:20:17.988002+00
ead94f8d-cd61-43f8-a252-65c8494d68c0	17f303ca-9003-4aec-a554-60e68579c17e	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2200.00	2100.00	2026-06-22 12:21:10.20233+00	2026-06-22 12:21:10.20233+00
42418f60-c626-4ade-bd41-89ec539fccd7	17f303ca-9003-4aec-a554-60e68579c17e	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-06-22 12:21:10.20233+00	2026-06-22 12:21:10.20233+00
226bea88-62be-498e-a550-925d421d9324	b48fe808-7668-4d53-ba45-9efcac9ab9e6	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-06-22 12:21:52.374101+00	2026-06-22 12:21:52.374101+00
a63e11a0-2330-47fc-9c74-2624c055b79d	8f108d53-a2fe-4205-87a9-2d3b39034110	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2200.00	2100.00	2026-06-22 12:23:24.963704+00	2026-06-22 12:23:24.963704+00
f924e9f5-e1c3-475f-88ed-70fbe443c472	8f108d53-a2fe-4205-87a9-2d3b39034110	ba1b6030-3855-49a1-ae3f-c0163e97a52a	20.00	1700.00	1700.00	2026-06-22 12:23:24.963704+00	2026-06-22 12:23:24.963704+00
4bd60bfb-2a51-4214-bdc4-f6580ef0719b	8f108d53-a2fe-4205-87a9-2d3b39034110	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	2.00	2500.00	2500.00	2026-06-22 12:23:24.963704+00	2026-06-22 12:23:24.963704+00
e8bd52fe-8aba-415d-bd01-04c0e3f7a02a	dc5e9eac-3542-4690-b0ae-03f43c81252f	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2200.00	2100.00	2026-06-22 12:24:43.332879+00	2026-06-22 12:24:43.332879+00
dfac1756-3109-43dc-8736-3b2c3f313fd0	dc5e9eac-3542-4690-b0ae-03f43c81252f	ba1b6030-3855-49a1-ae3f-c0163e97a52a	8.00	1700.00	1700.00	2026-06-22 12:24:43.332879+00	2026-06-22 12:24:43.332879+00
9a6a7d64-0df6-47f8-a9f1-cb6b0855afb3	d5845dc2-f1d0-42bb-b87b-d6d09f044431	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2200.00	2100.00	2026-06-22 12:25:39.465747+00	2026-06-22 12:25:39.465747+00
4bece4b9-12ae-4e81-9a14-b81de506d7b7	d5845dc2-f1d0-42bb-b87b-d6d09f044431	7a907a3d-7134-4504-a022-a74c554b75c7	2.00	3500.00	3800.00	2026-06-22 12:25:39.465747+00	2026-06-22 12:25:39.465747+00
b463bc39-32c2-4c9a-90e3-3540c464240f	d5845dc2-f1d0-42bb-b87b-d6d09f044431	ba1b6030-3855-49a1-ae3f-c0163e97a52a	20.00	1700.00	1700.00	2026-06-22 12:25:39.465747+00	2026-06-22 12:25:39.465747+00
f09e4d36-4fe9-441d-9562-04c4e05c30dc	f70adcf3-d2d2-4b8d-804c-68610ed560a8	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	25.00	3000.00	2500.00	2026-06-22 12:26:53.23068+00	2026-06-22 12:26:53.23068+00
63901d18-472f-4e1f-861e-86ce5b5abae7	f70adcf3-d2d2-4b8d-804c-68610ed560a8	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2000.00	2026-06-22 12:26:53.23068+00	2026-06-22 12:26:53.23068+00
2906c8e1-cc88-46ab-8a97-00cf5184dbeb	36c8bd18-7284-42ca-889b-63d87b15a78f	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	20.00	2200.00	2200.00	2026-06-22 12:29:02.877621+00	2026-06-22 12:29:02.877621+00
ab60a2a2-7b1a-471b-b68c-c4ab5ac31080	36c8bd18-7284-42ca-889b-63d87b15a78f	ac7a936f-2229-4748-8201-5aabbfdfd435	10.00	2100.00	2200.00	2026-06-22 12:29:02.877621+00	2026-06-22 12:29:02.877621+00
bba4be17-2be5-4720-958d-35ea07f13032	36c8bd18-7284-42ca-889b-63d87b15a78f	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	5.00	2500.00	2500.00	2026-06-22 12:29:02.877621+00	2026-06-22 12:29:02.877621+00
c2d6f35d-37ce-453e-83ce-76a19b515647	10494094-7a23-4270-966e-9c1d02e62d65	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2200.00	2100.00	2026-06-22 12:31:25.167271+00	2026-06-22 12:31:25.167271+00
2f5dcdbf-a4ef-4c55-94d3-e0837419ea6d	10494094-7a23-4270-966e-9c1d02e62d65	ba1b6030-3855-49a1-ae3f-c0163e97a52a	20.00	1700.00	1700.00	2026-06-22 12:31:25.167271+00	2026-06-22 12:31:25.167271+00
4cbbf24d-bd71-4f3b-9029-439eb98d9f1d	ca2a904a-e22b-4709-a314-ceeeb8f3691d	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	30.00	3000.00	2100.00	2026-06-22 12:32:54.63034+00	2026-06-22 12:32:54.63034+00
ff9811a8-52a3-4b07-895f-a44a0bbfaa1f	ca2a904a-e22b-4709-a314-ceeeb8f3691d	ba1b6030-3855-49a1-ae3f-c0163e97a52a	5.00	1700.00	1600.00	2026-06-22 12:32:54.63034+00	2026-06-22 12:32:54.63034+00
90606528-8634-41d4-839e-3313d757897d	ca2a904a-e22b-4709-a314-ceeeb8f3691d	7a907a3d-7134-4504-a022-a74c554b75c7	27.00	3800.00	3500.00	2026-06-22 12:32:54.63034+00	2026-06-22 12:32:54.63034+00
bdbe83ba-27f4-4f61-9371-9723085bf645	ca2a904a-e22b-4709-a314-ceeeb8f3691d	0c294dd6-af93-42de-aca5-f50ab942924a	5.00	3500.00	3500.00	2026-06-22 12:32:54.63034+00	2026-06-22 12:32:54.63034+00
a3240c44-8b5b-4240-9110-1709eb564fc7	3bd0e3bc-c051-48ba-b3e3-c57736a5290c	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-06-22 12:39:26.043965+00	2026-06-22 12:39:26.043965+00
68cd5013-7ae3-4bab-84e1-76b8cb94e719	3bd0e3bc-c051-48ba-b3e3-c57736a5290c	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	8.00	2200.00	2100.00	2026-06-22 12:39:26.043965+00	2026-06-22 12:39:26.043965+00
d267a69f-d6f3-46d6-a725-183bea88d415	6f5e9a40-d0c7-442e-9c11-037e36f21670	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2100.00	2026-06-22 12:40:34.294196+00	2026-06-22 12:40:34.294196+00
ac98a19b-9d69-402d-832c-0edab6bb066e	6f5e9a40-d0c7-442e-9c11-037e36f21670	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-06-22 12:40:34.294196+00	2026-06-22 12:40:34.294196+00
d9d69ee6-4642-411d-bd2c-9e618a6f85dc	6f5e9a40-d0c7-442e-9c11-037e36f21670	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	1.00	2500.00	2500.00	2026-06-22 12:40:34.294196+00	2026-06-22 12:40:34.294196+00
c8b4ae0b-472e-4671-8db7-184cc499dd25	58d6bfbd-c188-4362-bf46-8d0c4ff215b5	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2200.00	2100.00	2026-06-22 12:41:34.798974+00	2026-06-22 12:41:34.798974+00
d3299423-369b-41cc-bcab-7701152e575a	58d6bfbd-c188-4362-bf46-8d0c4ff215b5	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-06-22 12:41:34.798974+00	2026-06-22 12:41:34.798974+00
52d5b607-f863-481e-9469-adc8d8eae9f4	58d6bfbd-c188-4362-bf46-8d0c4ff215b5	7a907a3d-7134-4504-a022-a74c554b75c7	2.00	3800.00	3800.00	2026-06-22 12:41:34.798974+00	2026-06-22 12:41:34.798974+00
f6ad6ae7-76cc-44eb-bb30-d00483c5fef8	697218c2-76c0-447e-a4fc-b8353ecde81b	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1700.00	2026-06-22 12:42:30.909684+00	2026-06-22 12:42:30.909684+00
43f975b8-b39a-42b9-8f07-2dbb2b8e6c28	fe84c328-e264-4abc-9f2f-400f209afefa	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2200.00	2100.00	2026-06-22 12:45:47.551971+00	2026-06-22 12:45:47.551971+00
9e10be7f-b4da-41e7-9b36-bae5dadea53e	fe84c328-e264-4abc-9f2f-400f209afefa	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-06-22 12:45:47.551971+00	2026-06-22 12:45:47.551971+00
92029c93-b72e-4de5-9939-6e4eebb91839	fa937de3-7822-4d7b-8e23-ded1426a2085	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-06-22 12:48:15.680194+00	2026-06-22 12:48:15.680194+00
142ce970-f398-42d2-940a-650aad62ef07	b72244b1-977d-423e-b863-60fbe7d62bd7	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	40.00	3000.00	1900.00	2026-06-22 12:50:57.21166+00	2026-06-22 12:50:57.21166+00
6cacd0fd-a359-473e-a44a-1e3e03fbf40d	f34fa3a5-b67c-422d-8d88-ab734ac2a312	7a907a3d-7134-4504-a022-a74c554b75c7	18.00	3800.00	3500.00	2026-06-22 12:54:13.012093+00	2026-06-22 12:54:13.012093+00
b1e0c877-d457-42b1-90ec-eb11c35b1c06	f34fa3a5-b67c-422d-8d88-ab734ac2a312	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	30.00	2200.00	2100.00	2026-06-22 12:54:13.012093+00	2026-06-22 12:54:13.012093+00
059c85a9-f4ce-4f36-91b8-3b8e9db0827d	f34fa3a5-b67c-422d-8d88-ab734ac2a312	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	3500.00	2026-06-22 12:54:13.012093+00	2026-06-22 12:54:13.012093+00
bd65f881-470a-48d7-bd48-28e601f77e18	f34fa3a5-b67c-422d-8d88-ab734ac2a312	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1600.00	2026-06-22 12:54:13.012093+00	2026-06-22 12:54:13.012093+00
3f75e696-a27b-4dec-9e12-773b6cb512f5	01742e1e-8dee-458b-b22c-6b140b5c0dea	ba1b6030-3855-49a1-ae3f-c0163e97a52a	12.00	1700.00	1700.00	2026-06-22 12:55:18.84808+00	2026-06-22 12:55:18.84808+00
1ad843e9-195d-4964-b051-efa4413a7fcd	01742e1e-8dee-458b-b22c-6b140b5c0dea	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	1.00	2500.00	2900.00	2026-06-22 12:55:18.84808+00	2026-06-22 12:55:18.84808+00
3c7be71c-89e3-49ac-93ac-f748ee4c186e	01742e1e-8dee-458b-b22c-6b140b5c0dea	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	40.00	2200.00	2200.00	2026-06-22 12:55:18.84808+00	2026-06-22 12:55:18.84808+00
2a81936b-aec5-4b06-9d73-997540872d34	44191426-9626-4ef9-afc9-72dc89f1a732	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	1000.00	2026-06-22 12:56:12.750673+00	2026-06-22 12:56:12.750673+00
7522496a-9d54-4a17-8981-c6a7d9242a6f	f13dc362-e0bd-40ca-ac82-6859fb5220ec	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2100.00	2026-06-22 12:57:24.175117+00	2026-06-22 12:57:24.175117+00
60a68977-a2d1-49b3-a049-b8779847301d	f13dc362-e0bd-40ca-ac82-6859fb5220ec	7a907a3d-7134-4504-a022-a74c554b75c7	1.00	3800.00	3800.00	2026-06-22 12:57:24.175117+00	2026-06-22 12:57:24.175117+00
24340fd1-4473-416d-a426-68ca76acb0c3	f13dc362-e0bd-40ca-ac82-6859fb5220ec	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1700.00	2026-06-22 12:57:24.175117+00	2026-06-22 12:57:24.175117+00
e9fbf5d0-945f-428d-827a-11a6b74fbbd9	bca315e2-dd3c-458e-9b67-82a444a3b6f1	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	4.00	2200.00	2100.00	2026-06-22 12:58:14.378136+00	2026-06-22 12:58:14.378136+00
693d4e8f-5dc2-4a51-ba41-299d0e4143c8	bca315e2-dd3c-458e-9b67-82a444a3b6f1	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-06-22 12:58:14.378136+00	2026-06-22 12:58:14.378136+00
14df9b5f-f50b-4a5e-9b65-9451a2fa77e9	c896909f-850a-455f-9ca4-773bfe5ea508	ba1b6030-3855-49a1-ae3f-c0163e97a52a	40.00	1700.00	1700.00	2026-06-22 12:59:19.494236+00	2026-06-22 12:59:19.494236+00
e87455c8-8196-4575-b350-f1e2a5b05bdc	4a4eba49-618c-4e36-93f5-78117d2a956b	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	40.00	3000.00	2100.00	2026-06-22 13:04:47.39348+00	2026-06-22 13:04:47.39348+00
693a7e69-e9d2-40bc-bebc-f6e20050f3fa	4a4eba49-618c-4e36-93f5-78117d2a956b	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	3500.00	2026-06-22 13:04:47.39348+00	2026-06-22 13:04:47.39348+00
ac0bf51d-fcef-42f2-bb7b-218910845ecc	4a4eba49-618c-4e36-93f5-78117d2a956b	7a907a3d-7134-4504-a022-a74c554b75c7	18.00	3800.00	3500.00	2026-06-22 13:04:47.39348+00	2026-06-22 13:04:47.39348+00
ac7962f3-c249-4d25-85d4-45559aa18b5e	4a4eba49-618c-4e36-93f5-78117d2a956b	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1600.00	2026-06-22 13:04:47.39348+00	2026-06-22 13:04:47.39348+00
5ebc53cc-ea40-40c3-92d8-3f9f9b408eed	628bcc85-4d0d-48ae-b47b-74a373138839	ba1b6030-3855-49a1-ae3f-c0163e97a52a	40.00	1700.00	1700.00	2026-06-22 13:11:03.937117+00	2026-06-22 13:11:03.937117+00
2f909582-3d7a-48aa-a75b-391a413735d8	628bcc85-4d0d-48ae-b47b-74a373138839	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	30.00	2200.00	2200.00	2026-06-22 13:11:03.937117+00	2026-06-22 13:11:03.937117+00
ac96d784-f4d5-4d9d-a384-fce9e4261aa3	115e199b-2922-48a1-a4e6-0fd365c4709b	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2100.00	2200.00	2026-06-26 15:34:38.096916+00	2026-06-26 15:34:38.096916+00
28a40b9b-7363-447b-834f-094984fa27e8	115e199b-2922-48a1-a4e6-0fd365c4709b	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1500.00	1700.00	2026-06-26 15:34:38.096916+00	2026-06-26 15:34:38.096916+00
60e9510f-748a-4bcb-945e-ba87960687a5	551c6689-b5e8-4ffa-9a02-b323f7cdeecc	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2200.00	2026-06-26 15:36:49.591976+00	2026-06-26 15:36:49.591976+00
70bd842f-0018-4f0f-aacc-15288092f704	551c6689-b5e8-4ffa-9a02-b323f7cdeecc	7a907a3d-7134-4504-a022-a74c554b75c7	2.00	3500.00	3800.00	2026-06-26 15:36:49.591976+00	2026-06-26 15:36:49.591976+00
488dce1e-b3c7-42ae-8aac-95aed04c7b99	551c6689-b5e8-4ffa-9a02-b323f7cdeecc	ba1b6030-3855-49a1-ae3f-c0163e97a52a	20.00	1700.00	1700.00	2026-06-26 15:36:49.591976+00	2026-06-26 15:36:49.591976+00
a714c9d8-5637-4821-8dc1-be281064fe9d	5318c470-e889-460a-9eac-78c18942fa93	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-06-26 15:39:08.235263+00	2026-06-26 15:39:08.235263+00
7960edb8-03a8-4f8d-9bad-ae121020ec77	5318c470-e889-460a-9eac-78c18942fa93	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2200.00	2200.00	2026-06-26 15:39:08.235263+00	2026-06-26 15:39:08.235263+00
7ad64aaf-a618-4c03-801a-4bd8a3aab8e4	527a3fa7-ba92-4930-bae1-8c198644e399	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	40.00	3000.00	1900.00	2026-06-26 15:40:21.78731+00	2026-06-26 15:40:21.78731+00
3ed9b162-c3dc-4fa9-b62f-f17c7e587d49	7d1084e5-b9db-475d-b230-61631e60324f	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	155.00	2100.00	1075.00	2026-06-29 21:26:23.843197+00	2026-06-29 21:26:23.843197+00
b9dfd595-8e8b-47ff-868e-8b0d7691084c	7d1084e5-b9db-475d-b230-61631e60324f	ac7a936f-2229-4748-8201-5aabbfdfd435	36.00	2100.00	1075.00	2026-06-29 21:26:23.843197+00	2026-06-29 21:26:23.843197+00
db0bdd0c-c6e8-4c66-b9ad-701223e06af3	e9606946-3545-4180-8d96-2c74eeedb662	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	40.00	3000.00	1900.00	2026-06-30 13:08:05.373579+00	2026-06-30 13:08:05.373579+00
6bcacff9-ee2b-461c-b46a-382f37f1687d	88099e84-762a-47a7-90c0-bdce1a66b9f7	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	10.00	3000.00	2100.00	2026-06-30 13:11:45.932917+00	2026-06-30 13:11:45.932917+00
cf5f403a-a3a3-4a43-9c5c-6e0483f53bc8	88099e84-762a-47a7-90c0-bdce1a66b9f7	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1500.00	1600.00	2026-06-30 13:11:45.932917+00	2026-06-30 13:11:45.932917+00
33d6f40a-26fd-4975-9d9b-631e2399f87b	88099e84-762a-47a7-90c0-bdce1a66b9f7	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	3500.00	2026-06-30 13:11:45.932917+00	2026-06-30 13:11:45.932917+00
97fef76d-7326-4002-80c9-246fe3e7fa29	88099e84-762a-47a7-90c0-bdce1a66b9f7	7a907a3d-7134-4504-a022-a74c554b75c7	9.00	3500.00	3500.00	2026-06-30 13:11:45.932917+00	2026-06-30 13:11:45.932917+00
ec4e93bc-b178-4083-8059-0eeac9d5d8f8	7b33a6b7-ab46-4d21-9684-4c3fe05a1a55	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	20.00	2100.00	2100.00	2026-06-30 13:13:11.487218+00	2026-06-30 13:13:11.487218+00
7066c8f2-e54f-4ad8-8ecb-7a33c04786e3	7b33a6b7-ab46-4d21-9684-4c3fe05a1a55	ac7a936f-2229-4748-8201-5aabbfdfd435	10.00	2100.00	2100.00	2026-06-30 13:13:11.487218+00	2026-06-30 13:13:11.487218+00
6ab9cbf7-15b6-4331-a68f-28442840399e	7b33a6b7-ab46-4d21-9684-4c3fe05a1a55	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	5.00	2000.00	2500.00	2026-06-30 13:13:11.487218+00	2026-06-30 13:13:11.487218+00
982a9a50-b913-4dbe-a0ba-63e3c80cf656	4e423182-706d-4218-bfa0-f4b7af3bb0b9	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	6.00	2100.00	2100.00	2026-06-30 13:16:13.31843+00	2026-06-30 13:16:13.31843+00
b71db11c-b347-4582-92c3-0f770afe80ce	4e423182-706d-4218-bfa0-f4b7af3bb0b9	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1600.00	1700.00	2026-06-30 13:16:13.31843+00	2026-06-30 13:16:13.31843+00
ca106644-aa5d-4893-a51a-0c5f9904755b	7101d972-7b99-417b-8e7d-55dbaff920c9	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2100.00	2100.00	2026-06-30 13:17:17.975895+00	2026-06-30 13:17:17.975895+00
155440f6-6dd9-431c-ab31-a068d28d254f	7ce777ee-51e0-4863-a637-8ca5aa89d05c	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	40.00	2100.00	2200.00	2026-06-30 13:19:35.252977+00	2026-06-30 13:19:35.252977+00
4464da1d-b3cf-4845-b223-27854d0c03a8	7ce777ee-51e0-4863-a637-8ca5aa89d05c	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	1.00	2500.00	2500.00	2026-06-30 13:19:35.252977+00	2026-06-30 13:19:35.252977+00
2a5a93ad-3309-40b7-bff3-48bc53bb52fd	af3160eb-a205-4fde-b0cd-a4edc96c386a	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2100.00	2026-06-30 13:22:23.016304+00	2026-06-30 13:22:23.016304+00
d94076a2-3a7c-46c2-8a64-a7943925f6f6	af3160eb-a205-4fde-b0cd-a4edc96c386a	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1700.00	2026-06-30 13:22:23.016304+00	2026-06-30 13:22:23.016304+00
67870011-0f8b-4e93-842e-4bdb3e42f330	8ea0dce0-24cc-4b24-a0c8-118b0db24736	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2200.00	2100.00	2026-06-30 13:26:44.362654+00	2026-06-30 13:26:44.362654+00
8a7e5ec6-8e52-4d0a-a2e0-7644669d9354	8ea0dce0-24cc-4b24-a0c8-118b0db24736	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1700.00	2026-06-30 13:26:44.362654+00	2026-06-30 13:26:44.362654+00
154abcc5-8797-4a8c-b89b-a053b5bab0db	38367469-d996-4215-90ab-4bb78dd8f923	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	23.00	2100.00	1075.00	2026-06-30 13:36:56.759952+00	2026-06-30 13:36:56.759952+00
e943a6ef-9dbd-4caf-b180-f376d115b53e	38367469-d996-4215-90ab-4bb78dd8f923	ba1b6030-3855-49a1-ae3f-c0163e97a52a	58.00	1500.00	1100.00	2026-06-30 13:36:56.759952+00	2026-06-30 13:36:56.759952+00
be0c8528-28c2-4cf8-8694-2ebad90c437f	38367469-d996-4215-90ab-4bb78dd8f923	ac7a936f-2229-4748-8201-5aabbfdfd435	3.00	2100.00	1075.00	2026-06-30 13:36:56.759952+00	2026-06-30 13:36:56.759952+00
68b4a98e-5216-437b-bd04-399f92bfb1d8	2f62512f-ccc3-45ee-a0f3-227ac57c4a3a	ba1b6030-3855-49a1-ae3f-c0163e97a52a	40.00	1500.00	1700.00	2026-06-30 14:02:42.949324+00	2026-06-30 14:02:42.949324+00
9f920395-7c53-4c0f-bc32-78e4c2647669	2f62512f-ccc3-45ee-a0f3-227ac57c4a3a	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	30.00	2100.00	2100.00	2026-06-30 14:02:42.949324+00	2026-06-30 14:02:42.949324+00
0b2f6d93-b589-476f-87e8-969fbf8743d6	2f62512f-ccc3-45ee-a0f3-227ac57c4a3a	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	1.00	2000.00	2500.00	2026-06-30 14:02:42.949324+00	2026-06-30 14:02:42.949324+00
fe31e517-5697-4b3e-af33-b8b223507582	c65f4643-4b84-43b9-8e2c-6870f06e29d7	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	40.00	2100.00	2100.00	2026-06-30 14:07:28.751543+00	2026-06-30 14:07:28.751543+00
522da640-1fb4-4e01-b720-9b7bcef38a1a	c65f4643-4b84-43b9-8e2c-6870f06e29d7	7a907a3d-7134-4504-a022-a74c554b75c7	18.00	3500.00	3500.00	2026-06-30 14:07:28.751543+00	2026-06-30 14:07:28.751543+00
63c081ce-42e1-48dc-aaa8-3a4176d33479	c65f4643-4b84-43b9-8e2c-6870f06e29d7	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1600.00	2026-06-30 14:07:28.751543+00	2026-06-30 14:07:28.751543+00
9408be5c-3939-4d21-9a55-d20d2b0b96ee	c65f4643-4b84-43b9-8e2c-6870f06e29d7	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	3500.00	2026-06-30 14:07:28.751543+00	2026-06-30 14:07:28.751543+00
7f316e4d-faff-4497-9347-af4a15c9faa2	a01e692c-973e-455b-ad10-7e5774ffa206	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2100.00	2100.00	2026-06-30 14:09:52.622324+00	2026-06-30 14:09:52.622324+00
48abb437-59a1-4502-96d9-07db05e7c4d5	a01e692c-973e-455b-ad10-7e5774ffa206	ba1b6030-3855-49a1-ae3f-c0163e97a52a	20.00	1700.00	1700.00	2026-06-30 14:09:52.622324+00	2026-06-30 14:09:52.622324+00
39749387-4a12-41d9-aa1b-b4776b0623dd	9be7c326-9a4c-4521-8700-a23113923bb4	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2100.00	2100.00	2026-06-30 14:11:44.67418+00	2026-06-30 14:11:44.67418+00
079d79ba-a887-42ce-acb8-2d7c0bcb3746	9be7c326-9a4c-4521-8700-a23113923bb4	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1700.00	2026-06-30 14:11:44.67418+00	2026-06-30 14:11:44.67418+00
8b119e84-58b2-467b-a451-32226758b23f	72782f24-2f31-40ed-af31-ce5a739154db	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2100.00	2100.00	2026-06-30 14:13:11.44965+00	2026-06-30 14:13:11.44965+00
55b591d5-3c08-4f4f-9e9a-0ac3e9f463ed	72782f24-2f31-40ed-af31-ce5a739154db	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-06-30 14:13:11.44965+00	2026-06-30 14:13:11.44965+00
1f1596ce-7d45-44b5-bab6-399a57b8a14e	1689ef65-5132-4c7f-a938-0c98bfa683c0	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	21.00	2100.00	1200.00	2026-06-30 14:55:40.575433+00	2026-06-30 14:55:40.575433+00
bafaf29e-35a8-4cd9-9e99-856b4a8e7f36	97126300-4dbc-46a2-aa0b-4efa71d764b4	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1500.00	1700.00	2026-07-09 12:30:59.263762+00	2026-07-09 12:30:59.263762+00
75722bef-2341-43b6-9751-993e0459bd97	cf500b07-7e2e-40ca-a145-d4daba247fd9	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	3.00	2100.00	2200.00	2026-07-09 12:32:51.128143+00	2026-07-09 12:32:51.128143+00
5dc9506e-aa46-4d76-86f8-773694805b42	cf500b07-7e2e-40ca-a145-d4daba247fd9	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-07-09 12:32:51.128143+00	2026-07-09 12:32:51.128143+00
82aa296b-9f5f-4aad-acfb-cdc048be1370	34256591-b222-410f-8b27-311efbc0ca97	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	40.00	3000.00	1900.00	2026-07-09 12:33:42.438072+00	2026-07-09 12:33:42.438072+00
81c370e9-dafd-46af-8df9-0eead3ab89bb	1cc32153-fd17-4e31-a7fb-8a3d622781c5	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	20.00	2200.00	2100.00	2026-07-09 12:36:25.96423+00	2026-07-09 12:36:25.96423+00
f0a91e33-3aa7-4512-9541-b30ab56064f6	1cc32153-fd17-4e31-a7fb-8a3d622781c5	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	3500.00	2026-07-09 12:36:25.96423+00	2026-07-09 12:36:25.96423+00
ea68220a-5fe7-4ded-bfb1-5d2262d749db	1cc32153-fd17-4e31-a7fb-8a3d622781c5	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1600.00	2026-07-09 12:36:25.96423+00	2026-07-09 12:36:25.96423+00
2f883544-8951-4471-aca4-1809763c1cc9	1cc32153-fd17-4e31-a7fb-8a3d622781c5	7a907a3d-7134-4504-a022-a74c554b75c7	18.00	3500.00	3500.00	2026-07-09 12:36:25.96423+00	2026-07-09 12:36:25.96423+00
c3edf525-4182-4091-bb8e-8ed305c19b19	9d41438f-6faa-433b-8edf-cc25aef71047	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2200.00	2026-07-09 12:37:30.674931+00	2026-07-09 12:37:30.674931+00
47d0a87c-139e-47e0-8c1a-40234e9a280c	9d41438f-6faa-433b-8edf-cc25aef71047	ba1b6030-3855-49a1-ae3f-c0163e97a52a	20.00	1700.00	1700.00	2026-07-09 12:37:30.674931+00	2026-07-09 12:37:30.674931+00
cf68db7e-a817-494d-96cd-768b87260dc2	b246eca0-7241-4021-b5b7-4cd720e35bcd	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	3.00	2200.00	2200.00	2026-07-09 12:38:20.384258+00	2026-07-09 12:38:20.384258+00
ad14f103-6084-4372-a59e-0e1d2a1bc735	b246eca0-7241-4021-b5b7-4cd720e35bcd	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-07-09 12:38:20.384258+00	2026-07-09 12:38:20.384258+00
4247c1b2-4f10-49ce-9da1-1499e0e7ba37	2797cc16-57c2-4b55-81a0-f5a23bac2f28	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2200.00	2200.00	2026-07-09 12:39:14.952396+00	2026-07-09 12:39:14.952396+00
f76af93c-f558-423b-b759-ce8865c4abda	2797cc16-57c2-4b55-81a0-f5a23bac2f28	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1700.00	2026-07-09 12:39:14.952396+00	2026-07-09 12:39:14.952396+00
d3468d0d-8a84-4dc0-af4a-f6085ef8dd85	7be3f424-d803-4b7e-b896-658e6587f835	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2100.00	2026-07-09 12:41:10.526569+00	2026-07-09 12:41:10.526569+00
411dba95-a9ac-40d3-a699-224b78cded06	7be3f424-d803-4b7e-b896-658e6587f835	ac7a936f-2229-4748-8201-5aabbfdfd435	5.00	2100.00	2100.00	2026-07-09 12:41:10.526569+00	2026-07-09 12:41:10.526569+00
bf6b8b1e-db3d-4209-b4e4-e65db018ad32	7be3f424-d803-4b7e-b896-658e6587f835	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	3.00	2000.00	2500.00	2026-07-09 12:41:10.526569+00	2026-07-09 12:41:10.526569+00
40844ac3-1ae1-4f70-ab99-de1f5fb87a52	bf23060f-263a-44fd-8d57-3b6680152b08	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2100.00	2200.00	2026-07-09 12:42:38.98681+00	2026-07-09 12:42:38.98681+00
e302c20d-3f4e-49eb-b6ce-b640d2e0d3f3	bf23060f-263a-44fd-8d57-3b6680152b08	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1500.00	1700.00	2026-07-09 12:42:38.98681+00	2026-07-09 12:42:38.98681+00
73c8a857-7608-4654-acd2-04f2fd19453e	c71f7468-f8c8-4cbc-bf4b-67916f9760e5	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2100.00	2200.00	2026-07-19 17:18:58.639425+00	2026-07-19 17:18:58.639425+00
9db4b58d-e36c-41fe-a3b7-a2cf5791cc1a	c71f7468-f8c8-4cbc-bf4b-67916f9760e5	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1500.00	1700.00	2026-07-19 17:18:58.639425+00	2026-07-19 17:18:58.639425+00
637e5378-ed57-477d-a9f2-207ae98562be	00b2d302-308b-42ca-a711-89741e5cdcbe	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-07-19 17:20:01.883488+00	2026-07-19 17:20:01.883488+00
e3e650ac-473b-4695-bf3a-2abff4726150	00b2d302-308b-42ca-a711-89741e5cdcbe	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	3.00	2200.00	2200.00	2026-07-19 17:20:01.883488+00	2026-07-19 17:20:01.883488+00
05e786d7-ca3d-4e47-9a4a-6866566a7a8d	883b349b-cc83-4bd3-9b03-9e9441dcc35d	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2200.00	2100.00	2026-07-19 17:21:57.88095+00	2026-07-19 17:21:57.88095+00
f1abb53e-292b-4695-91c2-b0d243016433	883b349b-cc83-4bd3-9b03-9e9441dcc35d	7a907a3d-7134-4504-a022-a74c554b75c7	9.00	3500.00	3500.00	2026-07-19 17:21:57.88095+00	2026-07-19 17:21:57.88095+00
b29524e7-0356-4be2-ad40-cfb5af5838ec	883b349b-cc83-4bd3-9b03-9e9441dcc35d	0c294dd6-af93-42de-aca5-f50ab942924a	3.00	3500.00	3500.00	2026-07-19 17:21:57.88095+00	2026-07-19 17:21:57.88095+00
7c9f209e-8f4a-4520-b65b-9a7ec988997e	883b349b-cc83-4bd3-9b03-9e9441dcc35d	ba1b6030-3855-49a1-ae3f-c0163e97a52a	5.00	1700.00	1600.00	2026-07-19 17:21:57.88095+00	2026-07-19 17:21:57.88095+00
391f111b-2532-446e-876f-02a10205dd2f	7d61e654-10c5-4bda-832f-6859d7fb1dd0	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2200.00	2200.00	2026-07-19 17:24:11.542056+00	2026-07-19 17:24:11.542056+00
0aa12677-c613-467c-bdf9-20ae74799edb	7d61e654-10c5-4bda-832f-6859d7fb1dd0	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-07-19 17:24:11.542056+00	2026-07-19 17:24:11.542056+00
0681f92c-af38-448b-b201-073fa20dd451	72fb6044-5610-43fe-90c8-2cc5ff69c86f	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	30.00	3000.00	1600.00	2026-07-19 17:25:14.548548+00	2026-07-19 17:25:14.548548+00
505bde10-7dbd-476f-ad1c-7bb4f7de88a0	3e36ab98-2292-47f2-9790-ff9c61179100	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-07-19 17:25:53.385734+00	2026-07-19 17:25:53.385734+00
2abc76e2-235d-4549-933c-97841e512f55	74378a5e-1e3c-4c91-b488-b5051ecf8516	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2200.00	2200.00	2026-07-19 17:27:15.287088+00	2026-07-19 17:27:15.287088+00
fd2d1c37-bf21-4651-a308-21e790657077	74378a5e-1e3c-4c91-b488-b5051ecf8516	7a907a3d-7134-4504-a022-a74c554b75c7	2.00	3500.00	3800.00	2026-07-19 17:27:15.287088+00	2026-07-19 17:27:15.287088+00
975e81f6-37fe-40b4-bb47-e90556cab65f	74378a5e-1e3c-4c91-b488-b5051ecf8516	ba1b6030-3855-49a1-ae3f-c0163e97a52a	20.00	1700.00	1700.00	2026-07-19 17:27:15.287088+00	2026-07-19 17:27:15.287088+00
58ab2d1d-6b32-4e02-ab2b-f128dc48c10c	4f7ec5be-774e-4c2f-9247-56597747bd30	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1600.00	2026-07-19 17:28:33.061417+00	2026-07-19 17:28:33.061417+00
be7312e5-1962-488b-b882-7fd1fab82f80	4f7ec5be-774e-4c2f-9247-56597747bd30	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	3500.00	2026-07-19 17:28:33.061417+00	2026-07-19 17:28:33.061417+00
33be4a67-e4d7-4cf8-9eb5-656d09bb6249	4f7ec5be-774e-4c2f-9247-56597747bd30	7a907a3d-7134-4504-a022-a74c554b75c7	22.00	3800.00	3500.00	2026-07-19 17:28:33.061417+00	2026-07-19 17:28:33.061417+00
320548df-45a9-440f-bb83-750996377ac7	4f7ec5be-774e-4c2f-9247-56597747bd30	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	25.00	2200.00	2100.00	2026-07-19 17:28:33.061417+00	2026-07-19 17:28:33.061417+00
f764b141-e438-413a-b8c1-3b7b09fca1a9	84fe840f-c94b-4e45-9ed1-a5735aca0f7c	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	25.00	3000.00	2100.00	2026-07-19 17:29:59.858871+00	2026-07-19 17:29:59.858871+00
337f2e85-f3b5-4bb7-95a1-5091a1c09a67	84fe840f-c94b-4e45-9ed1-a5735aca0f7c	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1600.00	2026-07-19 17:29:59.858871+00	2026-07-19 17:29:59.858871+00
4bce9468-c26c-41e8-a300-df2db1ba78e9	84fe840f-c94b-4e45-9ed1-a5735aca0f7c	7a907a3d-7134-4504-a022-a74c554b75c7	9.00	3800.00	3500.00	2026-07-19 17:29:59.858871+00	2026-07-19 17:29:59.858871+00
f61bc763-9039-4fab-aaea-8ef7b414f94f	84fe840f-c94b-4e45-9ed1-a5735aca0f7c	0c294dd6-af93-42de-aca5-f50ab942924a	7.00	3500.00	3500.00	2026-07-19 17:29:59.858871+00	2026-07-19 17:29:59.858871+00
1a49647d-537f-4e6c-804d-2789e620d07a	03848e89-39a7-43cd-8b6a-c943171b2dbb	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2200.00	2026-07-19 17:31:09.207138+00	2026-07-19 17:31:09.207138+00
6e6c8f6c-5d71-4f50-a12d-7ed8b4e0f45f	03848e89-39a7-43cd-8b6a-c943171b2dbb	ac7a936f-2229-4748-8201-5aabbfdfd435	5.00	2100.00	2200.00	2026-07-19 17:31:09.207138+00	2026-07-19 17:31:09.207138+00
60a4f8aa-6283-41a4-9bac-8ebe7cdbbdbd	03848e89-39a7-43cd-8b6a-c943171b2dbb	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	2.00	2000.00	2500.00	2026-07-19 17:31:09.207138+00	2026-07-19 17:31:09.207138+00
9edaad01-84b7-4eca-ae28-a3d50fa80166	16ac9237-cdfc-42d2-8428-e987b5d46911	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-07-19 17:32:01.746648+00	2026-07-19 17:32:01.746648+00
a8e51d2d-82ed-4f89-b50a-d7441bbc3485	16ac9237-cdfc-42d2-8428-e987b5d46911	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	4.00	2200.00	2200.00	2026-07-19 17:32:01.746648+00	2026-07-19 17:32:01.746648+00
75324f5e-83de-4991-9c4d-120731123a17	b849d43d-e4a6-4aed-862c-e35460fbdecb	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2200.00	2200.00	2026-07-19 17:33:49.948156+00	2026-07-19 17:33:49.948156+00
e545adbb-3040-49d8-9e8d-997eafd80ae4	b849d43d-e4a6-4aed-862c-e35460fbdecb	ac7a936f-2229-4748-8201-5aabbfdfd435	5.00	2200.00	2200.00	2026-07-19 17:33:49.948156+00	2026-07-19 17:33:49.948156+00
2b56261c-e715-41b1-8fd2-0a5da651b5cc	779708ab-5557-4792-8875-5a24dfa8cfc2	ba1b6030-3855-49a1-ae3f-c0163e97a52a	25.00	1700.00	1700.00	2026-07-19 17:34:54.710093+00	2026-07-19 17:34:54.710093+00
898cd2e9-660f-4158-a0ec-b41651d6b481	779708ab-5557-4792-8875-5a24dfa8cfc2	7a907a3d-7134-4504-a022-a74c554b75c7	2.00	3800.00	3800.00	2026-07-19 17:34:54.710093+00	2026-07-19 17:34:54.710093+00
e4fddc84-4839-4069-b5c5-7b38cf39bccc	779708ab-5557-4792-8875-5a24dfa8cfc2	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2200.00	2200.00	2026-07-19 17:34:54.710093+00	2026-07-19 17:34:54.710093+00
c4c991d6-c23a-4a26-8d6c-9956082ddfb8	d0e8ebd9-1e93-419b-91e2-481a6c2a6d92	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2200.00	2026-07-19 17:35:37.410654+00	2026-07-19 17:35:37.410654+00
5358e41e-8e09-440c-b083-d4d408691330	d0e8ebd9-1e93-419b-91e2-481a6c2a6d92	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1700.00	2026-07-19 17:35:37.410654+00	2026-07-19 17:35:37.410654+00
ec2867ba-33e9-46b7-b66c-be7f974808f9	0cc8cee0-3a1b-4fd4-910b-aceb1ee24267	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2200.00	2026-07-19 17:36:24.698842+00	2026-07-19 17:36:24.698842+00
6a78a0a1-d69c-4724-9d94-610bf975e39c	0cc8cee0-3a1b-4fd4-910b-aceb1ee24267	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1700.00	2026-07-19 17:36:24.698842+00	2026-07-19 17:36:24.698842+00
ab79cfae-f29e-45e3-8a28-a365f93d01bd	54347062-c438-4699-8b35-a297b7326ceb	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2200.00	2100.00	2026-07-19 17:38:58.237263+00	2026-07-19 17:38:58.237263+00
102fd2d2-3a43-4fe9-bcc5-e04653488974	54347062-c438-4699-8b35-a297b7326ceb	ba1b6030-3855-49a1-ae3f-c0163e97a52a	20.00	1700.00	1700.00	2026-07-19 17:38:58.237263+00	2026-07-19 17:38:58.237263+00
679b37e9-62b8-41df-979d-a34635d22cdc	54347062-c438-4699-8b35-a297b7326ceb	7a907a3d-7134-4504-a022-a74c554b75c7	2.00	3800.00	3800.00	2026-07-19 17:38:58.237263+00	2026-07-19 17:38:58.237263+00
adbc3124-fd8e-49b4-b97f-dcad8e706bf6	62438726-116a-4fa4-88a9-cb3171a0fb23	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	48.00	3000.00	1900.00	2026-07-19 17:41:29.956024+00	2026-07-19 17:41:29.956024+00
dfc038fd-6f27-4574-9162-a45cb756abe4	2af9b95c-9a92-4685-bdfe-2ccbcaaf92ed	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	20.00	3000.00	2500.00	2026-07-19 17:42:31.365752+00	2026-07-19 17:42:31.365752+00
4e8776c5-54c8-4385-8ce5-3f9cd354baf5	2af9b95c-9a92-4685-bdfe-2ccbcaaf92ed	c3e9630c-0382-4f35-8a82-33aa02fa590c	15.00	2100.00	2000.00	2026-07-19 17:42:31.365752+00	2026-07-19 17:42:31.365752+00
a67979d2-ff82-46f8-b26a-820a2bc12a4b	2af9b95c-9a92-4685-bdfe-2ccbcaaf92ed	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1600.00	2026-07-19 17:42:31.365752+00	2026-07-19 17:42:31.365752+00
907b8979-40d9-487c-8ffa-78fcd0d88146	15f22141-23dd-44c5-8dd2-95ce74c34f09	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	10.00	3000.00	1900.00	2026-07-21 20:02:35.562145+00	2026-07-21 20:02:35.562145+00
2b7a16c2-b0b3-41ba-8aeb-5f895b0cca63	a96bff15-ad90-4acc-ac9f-d7b2d74c98e7	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1500.00	1700.00	2026-07-21 20:17:43.030846+00	2026-07-21 20:17:43.030846+00
10164706-31c4-4407-9ca3-4dfa4527d9ba	7dd8440e-3c68-4c65-a08e-51157b687af1	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2100.00	2200.00	2026-07-21 20:18:41.046646+00	2026-07-21 20:18:41.046646+00
03b287f8-bf63-4096-a133-a40ca38d576b	7dd8440e-3c68-4c65-a08e-51157b687af1	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-07-21 20:18:41.046646+00	2026-07-21 20:18:41.046646+00
22ee5dc3-bf0d-4094-a3d3-476ab6f32514	00734614-d7ae-4b68-a0b4-7c1b860fd693	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	25.00	2200.00	2100.00	2026-07-21 20:20:02.899636+00	2026-07-21 20:20:02.899636+00
10af70dd-b0f0-4d6c-9a63-7449a274aa8d	00734614-d7ae-4b68-a0b4-7c1b860fd693	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1600.00	2026-07-21 20:20:02.899636+00	2026-07-21 20:20:02.899636+00
3b394d2a-bf72-4e98-9852-4d0b4f7f7715	00734614-d7ae-4b68-a0b4-7c1b860fd693	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	3500.00	2026-07-21 20:20:02.899636+00	2026-07-21 20:20:02.899636+00
199c61a3-4c9a-4c3e-b05c-90585656ebcd	00734614-d7ae-4b68-a0b4-7c1b860fd693	7a907a3d-7134-4504-a022-a74c554b75c7	18.00	3500.00	3500.00	2026-07-21 20:20:02.899636+00	2026-07-21 20:20:02.899636+00
f8667484-6739-400c-b78e-824edd46594a	5ea2cc34-2e66-460e-873a-057ef872dceb	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	25.00	3000.00	2100.00	2026-07-21 20:21:47.517095+00	2026-07-21 20:21:47.517095+00
a98718e2-6885-41a8-95b6-180f0673577b	5ea2cc34-2e66-460e-873a-057ef872dceb	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1600.00	2026-07-21 20:21:47.517095+00	2026-07-21 20:21:47.517095+00
c948ff6d-1d69-4915-87d1-27ad4359c0d1	5ea2cc34-2e66-460e-873a-057ef872dceb	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	3500.00	2026-07-21 20:21:47.517095+00	2026-07-21 20:21:47.517095+00
9695036f-171a-43e3-9469-67748cdeaa52	5ea2cc34-2e66-460e-873a-057ef872dceb	7a907a3d-7134-4504-a022-a74c554b75c7	18.00	3500.00	3500.00	2026-07-21 20:21:47.517095+00	2026-07-21 20:21:47.517095+00
4ebe11b6-f764-4db5-b245-4245d48ac508	4df3c0e8-f8aa-44d5-afde-9c0cb67b8561	ba1b6030-3855-49a1-ae3f-c0163e97a52a	40.00	1700.00	1700.00	2026-07-21 20:23:06.949245+00	2026-07-21 20:23:06.949245+00
524ca419-e442-4cd7-b27c-2e10484c718f	4df3c0e8-f8aa-44d5-afde-9c0cb67b8561	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	20.00	2200.00	2200.00	2026-07-21 20:23:06.949245+00	2026-07-21 20:23:06.949245+00
1fba6b28-b21b-40d7-ac7d-a31c47a99d3e	4df3c0e8-f8aa-44d5-afde-9c0cb67b8561	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	1.00	2000.00	2500.00	2026-07-21 20:23:06.949245+00	2026-07-21 20:23:06.949245+00
52bf506f-2c0d-4e9f-9d55-600a7e25fe4f	f463dc19-3f68-4ae7-937d-59ba11ff1255	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	2200.00	2026-07-21 20:25:01.976113+00	2026-07-21 20:25:01.976113+00
ff2462b9-5652-4bc7-aaef-7a82c8f621dd	78be609e-d109-48e9-b670-a1e807eefd9b	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	2200.00	1700.00	2026-07-21 20:27:09.517244+00	2026-07-21 20:27:09.517244+00
8ef2723b-b050-428a-b4a0-c171ca7c5710	78be609e-d109-48e9-b670-a1e807eefd9b	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	6.00	2200.00	2200.00	2026-07-21 20:27:09.517244+00	2026-07-21 20:27:09.517244+00
2a715864-0045-4a15-a333-afe81a244f0b	a152067d-0684-4ca6-be03-92e9e3c75184	7a907a3d-7134-4504-a022-a74c554b75c7	2.00	3500.00	3800.00	2026-07-21 20:28:20.423596+00	2026-07-21 20:28:20.423596+00
390e242d-218c-4be4-99aa-0ef1a3a1f3fb	a152067d-0684-4ca6-be03-92e9e3c75184	ba1b6030-3855-49a1-ae3f-c0163e97a52a	25.00	2200.00	1700.00	2026-07-21 20:28:20.423596+00	2026-07-21 20:28:20.423596+00
45f6c6ad-8e21-4ad5-a6ee-6fb8db3470a7	80989874-2ba5-4b86-8215-9d5d1c6bfb97	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	20.00	2200.00	2200.00	2026-07-21 20:29:14.560255+00	2026-07-21 20:29:14.560255+00
3a8d3249-5ec6-4839-96d6-fc67a1bddc37	80989874-2ba5-4b86-8215-9d5d1c6bfb97	ac7a936f-2229-4748-8201-5aabbfdfd435	10.00	2100.00	2200.00	2026-07-21 20:29:14.560255+00	2026-07-21 20:29:14.560255+00
8dd2091f-1e31-4531-9438-cf76d8cf4b58	80989874-2ba5-4b86-8215-9d5d1c6bfb97	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	5.00	2500.00	2500.00	2026-07-21 20:29:14.560255+00	2026-07-21 20:29:14.560255+00
8851ec8f-ea3f-4280-a8a9-87254ab9d94f	d2875995-79bb-4cb8-841b-43a636539638	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2200.00	2026-07-21 20:30:11.139901+00	2026-07-21 20:30:11.139901+00
4862569d-6e29-408e-8389-064c03ad5b8a	d2875995-79bb-4cb8-841b-43a636539638	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	2200.00	1700.00	2026-07-21 20:30:11.139901+00	2026-07-21 20:30:11.139901+00
a61f1e80-2236-498c-8fcd-d65246189d93	cbb77c2e-c120-44c1-b782-007ab766e417	ba1b6030-3855-49a1-ae3f-c0163e97a52a	40.00	2200.00	1700.00	2026-07-21 20:31:02.249434+00	2026-07-21 20:31:02.249434+00
74304aac-f8ad-4c55-9d24-c05572d8bb98	cbb77c2e-c120-44c1-b782-007ab766e417	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	20.00	2200.00	2200.00	2026-07-21 20:31:02.249434+00	2026-07-21 20:31:02.249434+00
b3d4b742-d5a8-4f8d-943e-f9c70c7e7c8b	eac6103f-7117-460a-a092-1dd1434a0421	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2100.00	2200.00	2026-07-28 12:31:28.827781+00	2026-07-28 12:31:28.827781+00
31d8d427-71b8-4b90-bda8-b1b7d42a5dc1	eac6103f-7117-460a-a092-1dd1434a0421	ac7a936f-2229-4748-8201-5aabbfdfd435	5.00	2100.00	2200.00	2026-07-28 12:31:28.827781+00	2026-07-28 12:31:28.827781+00
9f8e471c-ff2b-47e5-8428-3e2b533816a3	eac6103f-7117-460a-a092-1dd1434a0421	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	3.00	2000.00	2500.00	2026-07-28 12:31:28.827781+00	2026-07-28 12:31:28.827781+00
481cf28f-b599-4e06-a40d-00e0bb4b4b2f	eac6103f-7117-460a-a092-1dd1434a0421	ba1b6030-3855-49a1-ae3f-c0163e97a52a	50.00	1500.00	1600.00	2026-07-28 12:31:28.827781+00	2026-07-28 12:31:28.827781+00
117204bd-f5c5-4361-9bda-2aa5ddca4948	3581af9a-33aa-4c4c-b720-cb71d2ae4901	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	40.00	2200.00	2200.00	2026-07-28 12:32:44.872623+00	2026-07-28 12:32:44.872623+00
9e592cf6-7747-408d-9041-29ab6fccba90	3581af9a-33aa-4c4c-b720-cb71d2ae4901	ba1b6030-3855-49a1-ae3f-c0163e97a52a	50.00	1600.00	1700.00	2026-07-28 12:32:44.872623+00	2026-07-28 12:32:44.872623+00
868e61a7-7234-4d1f-8533-dae8fe6e4f84	6aac7d1f-2c7f-4685-af97-adfaeb6e9a83	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	15.00	2200.00	2200.00	2026-07-28 12:33:45.474466+00	2026-07-28 12:33:45.474466+00
6a006548-b105-4827-a45a-855d8798fe74	6aac7d1f-2c7f-4685-af97-adfaeb6e9a83	ba1b6030-3855-49a1-ae3f-c0163e97a52a	25.00	1700.00	1700.00	2026-07-28 12:33:45.474466+00	2026-07-28 12:33:45.474466+00
a67b2fff-fc0b-4c97-ace3-242e525d4a72	6aac7d1f-2c7f-4685-af97-adfaeb6e9a83	7a907a3d-7134-4504-a022-a74c554b75c7	2.00	3500.00	3800.00	2026-07-28 12:33:45.474466+00	2026-07-28 12:33:45.474466+00
75b76525-28d9-4938-9714-8196f72fa374	f6525a98-af76-4176-aef5-fd0fb627f797	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2200.00	2026-07-28 12:34:33.531739+00	2026-07-28 12:34:33.531739+00
0395d938-c2ff-4c1e-981c-3d7bcfea45b6	f6525a98-af76-4176-aef5-fd0fb627f797	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1700.00	2026-07-28 12:34:33.531739+00	2026-07-28 12:34:33.531739+00
4450689c-c328-4c79-84cf-ca548e31aa54	e7b9784f-b8e8-407c-b76b-4bb7f5764fc1	ba1b6030-3855-49a1-ae3f-c0163e97a52a	50.00	1700.00	1600.00	2026-07-28 12:36:11.844468+00	2026-07-28 12:36:11.844468+00
eb06395c-e728-4500-8bbe-8f8ad451464d	e7b9784f-b8e8-407c-b76b-4bb7f5764fc1	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2200.00	2026-07-28 12:36:11.844468+00	2026-07-28 12:36:11.844468+00
95773526-b581-4d6f-914a-5b8efdf3e718	e7b9784f-b8e8-407c-b76b-4bb7f5764fc1	ac7a936f-2229-4748-8201-5aabbfdfd435	10.00	2200.00	2200.00	2026-07-28 12:36:11.844468+00	2026-07-28 12:36:11.844468+00
dcc64360-57a1-43b3-b2a4-1b7d80a5dcd5	e7b9784f-b8e8-407c-b76b-4bb7f5764fc1	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	3.00	2500.00	2500.00	2026-07-28 12:36:11.844468+00	2026-07-28 12:36:11.844468+00
7513545a-50b1-4038-85c1-6db2d3d604f7	e30d341f-e131-4f15-a0e4-90dd63185938	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	25.00	2200.00	2100.00	2026-07-28 12:37:26.642761+00	2026-07-28 12:37:26.642761+00
93201e83-3b68-4195-afdb-fa5d92f9dceb	e30d341f-e131-4f15-a0e4-90dd63185938	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	3500.00	2026-07-28 12:37:26.642761+00	2026-07-28 12:37:26.642761+00
aee5e2ee-b843-476f-9896-8b3149a50cbe	e30d341f-e131-4f15-a0e4-90dd63185938	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1600.00	2026-07-28 12:37:26.642761+00	2026-07-28 12:37:26.642761+00
b0581185-faa5-4da7-b6fc-06af43aae208	2017702b-69d0-4729-80ff-d3af4ab8b100	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	25.00	2200.00	2100.00	2026-07-28 12:38:41.10112+00	2026-07-28 12:38:41.10112+00
85d23d83-63c7-4ee3-9c66-01e54a4ac2e5	2017702b-69d0-4729-80ff-d3af4ab8b100	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1600.00	2026-07-28 12:38:41.10112+00	2026-07-28 12:38:41.10112+00
23c4f166-11e6-4490-b9f6-b238b67a0cf0	2017702b-69d0-4729-80ff-d3af4ab8b100	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	3500.00	2026-07-28 12:38:41.10112+00	2026-07-28 12:38:41.10112+00
51c1c5b5-c43b-4a4a-b158-174c42b4b151	2017702b-69d0-4729-80ff-d3af4ab8b100	7a907a3d-7134-4504-a022-a74c554b75c7	18.00	3800.00	3500.00	2026-07-28 12:38:41.10112+00	2026-07-28 12:38:41.10112+00
e8c1ebb3-c260-46a5-8444-2bb9a78533e9	b05190ff-1ad6-4b03-9108-bd5f8e9e6148	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-07-28 12:39:38.845234+00	2026-07-28 12:39:38.845234+00
36125aa6-bef1-4ffa-b47f-9da26ef566a5	b05190ff-1ad6-4b03-9108-bd5f8e9e6148	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	3.00	2200.00	2200.00	2026-07-28 12:39:38.845234+00	2026-07-28 12:39:38.845234+00
f5e09500-6632-4e3f-a60a-34729148c71f	b735f45d-c9bc-4cc9-806c-1176524507d3	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2100.00	1900.00	2026-07-28 12:55:06.585645+00	2026-07-28 12:55:06.585645+00
554acfbe-4715-4a13-8cf2-a778568a6a35	b735f45d-c9bc-4cc9-806c-1176524507d3	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1500.00	1400.00	2026-07-28 12:55:06.585645+00	2026-07-28 12:55:06.585645+00
b690f163-66d0-4535-92e7-97a8eb8c27ce	cbcaa551-5761-436d-ae52-2811789a83d4	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	20.00	2100.00	2200.00	2026-07-28 12:58:16.52675+00	2026-07-28 12:58:16.52675+00
2de2a18c-f73f-4a5d-b637-944e8014f9d6	cbcaa551-5761-436d-ae52-2811789a83d4	ba1b6030-3855-49a1-ae3f-c0163e97a52a	20.00	1500.00	1700.00	2026-07-28 12:58:16.52675+00	2026-07-28 12:58:16.52675+00
ff5327d5-f078-4334-b074-8389a5073bc3	0648fb30-e041-407b-9b08-4c414328d015	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-07-28 12:59:18.438289+00	2026-07-28 12:59:18.438289+00
24b8c9a7-1f41-47e7-89ef-3ab493c87f20	0648fb30-e041-407b-9b08-4c414328d015	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	3.00	2200.00	2200.00	2026-07-28 12:59:18.438289+00	2026-07-28 12:59:18.438289+00
3c650cc7-0417-4443-90e3-fe5405f9f6e1	009ed6cd-13cd-4a95-9874-a2dea0c9f217	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2200.00	2026-07-28 13:00:14.014612+00	2026-07-28 13:00:14.014612+00
b2c6fefe-a9f5-485e-b580-708387182bc1	009ed6cd-13cd-4a95-9874-a2dea0c9f217	ba1b6030-3855-49a1-ae3f-c0163e97a52a	25.00	1700.00	1700.00	2026-07-28 13:00:14.014612+00	2026-07-28 13:00:14.014612+00
1410e8aa-fa96-4ba5-8c12-3fe299372cdc	009ed6cd-13cd-4a95-9874-a2dea0c9f217	7a907a3d-7134-4504-a022-a74c554b75c7	2.00	3500.00	3800.00	2026-07-28 13:00:14.014612+00	2026-07-28 13:00:14.014612+00
3ccc40f4-33e6-4a41-ae9a-446680da6229	e1138a39-b377-4e7d-9db1-88eedaab0011	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	4.00	2200.00	2200.00	2026-07-28 13:01:06.822983+00	2026-07-28 13:01:06.822983+00
f8af3f21-300a-440e-94a2-73bd6f0c5620	e1138a39-b377-4e7d-9db1-88eedaab0011	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1700.00	1700.00	2026-07-28 13:01:06.822983+00	2026-07-28 13:01:06.822983+00
4b7fe263-5dc1-4a4e-bf85-a9ac94085099	b5562eec-d4d4-4351-a218-040d00f6f48e	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1500.00	1700.00	2026-07-30 15:53:09.315009+00	2026-07-30 15:53:09.315009+00
46b1b9fa-6b4e-4473-ae0c-41bf3a8cc1cb	b5562eec-d4d4-4351-a218-040d00f6f48e	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	5.00	2100.00	2200.00	2026-07-30 15:53:09.315009+00	2026-07-30 15:53:09.315009+00
402074f7-4d45-416b-8fb1-68d2ac2edb02	28eee34d-d2e2-4338-9ec3-a275d4bc559c	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	48.00	3000.00	1900.00	2026-07-30 15:53:57.892845+00	2026-07-30 15:53:57.892845+00
27698739-c02b-4886-a1b5-db840e7c1a0b	add06fe4-df20-4f02-8802-eea46aeec65a	228aeec5-78b6-4bd2-90d2-ad39c8df33c5	10.00	3000.00	1900.00	2026-07-30 15:55:32.587417+00	2026-07-30 15:55:32.587417+00
9ab69ce7-694f-418c-b91b-09e175529743	b849a1fd-026a-4b16-b1e1-452eb66bce4f	7a907a3d-7134-4504-a022-a74c554b75c7	18.00	3500.00	3500.00	2026-07-30 15:57:21.995101+00	2026-07-30 15:57:21.995101+00
48f8d001-01d4-415d-abc0-c15796cc7142	b849a1fd-026a-4b16-b1e1-452eb66bce4f	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	3500.00	2026-07-30 15:57:21.995101+00	2026-07-30 15:57:21.995101+00
a004b2d9-6029-4c4e-8e25-c2751b4820d3	b849a1fd-026a-4b16-b1e1-452eb66bce4f	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1500.00	1600.00	2026-07-30 15:57:21.995101+00	2026-07-30 15:57:21.995101+00
ccad6686-0399-41cb-b6a2-d2884506ecdc	b849a1fd-026a-4b16-b1e1-452eb66bce4f	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	25.00	2100.00	2100.00	2026-07-30 15:57:21.995101+00	2026-07-30 15:57:21.995101+00
f7881536-4787-4507-a453-8071f46c9da1	43dc8a2a-4e24-4a44-b359-f833c1482583	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	30.00	2100.00	2100.00	2026-07-30 15:59:42.072974+00	2026-07-30 15:59:42.072974+00
5e4e2f75-f751-49d5-b929-8bc32d0b3811	43dc8a2a-4e24-4a44-b359-f833c1482583	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1600.00	1600.00	2026-07-30 15:59:42.072974+00	2026-07-30 15:59:42.072974+00
8dc833bf-01db-4cf4-9941-266e9619dff7	43dc8a2a-4e24-4a44-b359-f833c1482583	0c294dd6-af93-42de-aca5-f50ab942924a	10.00	3500.00	3500.00	2026-07-30 15:59:42.072974+00	2026-07-30 15:59:42.072974+00
ea2c39f1-08d7-44b7-8e8e-b055fc237dca	43dc8a2a-4e24-4a44-b359-f833c1482583	7a907a3d-7134-4504-a022-a74c554b75c7	9.00	3500.00	3500.00	2026-07-30 15:59:42.072974+00	2026-07-30 15:59:42.072974+00
9f225d75-cbc6-40e6-a6a6-7127a6a182a3	12ebaa3a-23a3-425a-afa2-fa6d97d19345	ba1b6030-3855-49a1-ae3f-c0163e97a52a	10.00	1500.00	1700.00	2026-07-31 03:25:49.7328+00	2026-07-31 03:25:49.7328+00
02f2e290-0aea-4f5f-a6fe-09167861f1e3	12ebaa3a-23a3-425a-afa2-fa6d97d19345	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	4.00	2100.00	2200.00	2026-07-31 03:25:49.7328+00	2026-07-31 03:25:49.7328+00
622e0e17-45bb-4e53-a149-0939b8aa708f	196e9aa0-d105-448d-9b93-93e787c121ab	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2200.00	2026-07-31 03:27:57.546374+00	2026-07-31 03:27:57.546374+00
523f1b40-6081-4380-98bf-a50587e98683	196e9aa0-d105-448d-9b93-93e787c121ab	ba1b6030-3855-49a1-ae3f-c0163e97a52a	25.00	1700.00	1700.00	2026-07-31 03:27:57.546374+00	2026-07-31 03:27:57.546374+00
6a90c124-a1b9-44fe-826d-9dec7ec2116a	7414e697-94c7-4f60-afcf-c951238cb5a3	ba1b6030-3855-49a1-ae3f-c0163e97a52a	60.00	1700.00	1700.00	2026-07-31 03:30:24.504247+00	2026-07-31 03:30:24.504247+00
4ea8f188-a0f4-4380-8d37-75d219751651	7414e697-94c7-4f60-afcf-c951238cb5a3	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	25.00	2200.00	2200.00	2026-07-31 03:30:24.504247+00	2026-07-31 03:30:24.504247+00
7251cc2e-4b96-4ad1-95c7-b3ad12f45849	7414e697-94c7-4f60-afcf-c951238cb5a3	de5e2ae8-64b1-4f1a-a478-34d1db2bf034	1.00	2000.00	2500.00	2026-07-31 03:30:24.504247+00	2026-07-31 03:30:24.504247+00
b9ae267e-3dba-4e69-a183-f24a46a4fa1e	3e6e0750-9c79-4b9b-9045-5f053d49f22d	cd326cdf-e280-4ec9-a8cc-e1ca3e9c89c8	10.00	2200.00	2200.00	2026-07-31 03:32:06.032538+00	2026-07-31 03:32:06.032538+00
e1ca7fb5-3d99-4e86-bf27-75d7a6db1b72	3e6e0750-9c79-4b9b-9045-5f053d49f22d	ba1b6030-3855-49a1-ae3f-c0163e97a52a	15.00	1700.00	1700.00	2026-07-31 03:32:06.032538+00	2026-07-31 03:32:06.032538+00
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-04-14 13:17:45
20211116045059	2026-04-14 13:17:46
20211116050929	2026-04-14 13:17:48
20211116051442	2026-04-14 13:17:49
20211116212300	2026-04-14 13:17:50
20211116213355	2026-04-14 13:17:51
20211116213934	2026-04-14 13:17:52
20211116214523	2026-04-14 13:17:54
20211122062447	2026-04-14 13:17:55
20211124070109	2026-04-14 13:17:57
20211202204204	2026-04-14 13:17:58
20211202204605	2026-04-14 13:17:59
20211210212804	2026-04-14 13:18:02
20211228014915	2026-04-14 13:18:04
20220107221237	2026-04-14 13:18:05
20220228202821	2026-04-14 13:18:06
20220312004840	2026-04-14 13:18:07
20220603231003	2026-04-14 13:18:09
20220603232444	2026-04-14 13:18:10
20220615214548	2026-04-14 13:18:11
20220712093339	2026-04-14 13:18:13
20220908172859	2026-04-14 13:18:14
20220916233421	2026-04-14 13:18:15
20230119133233	2026-04-14 13:18:16
20230128025114	2026-04-14 13:18:18
20230128025212	2026-04-14 13:18:19
20230227211149	2026-04-14 13:18:20
20230228184745	2026-04-14 13:18:21
20230308225145	2026-04-14 13:18:22
20230328144023	2026-04-14 13:18:24
20231018144023	2026-04-14 13:18:25
20231204144023	2026-04-14 13:18:27
20231204144024	2026-04-14 13:18:28
20231204144025	2026-04-14 13:18:29
20240108234812	2026-04-14 13:18:30
20240109165339	2026-04-14 13:18:31
20240227174441	2026-04-14 13:18:33
20240311171622	2026-04-14 13:18:35
20240321100241	2026-04-14 13:18:37
20240401105812	2026-04-14 13:18:41
20240418121054	2026-04-14 13:18:42
20240523004032	2026-04-14 13:18:46
20240618124746	2026-04-14 13:18:48
20240801235015	2026-04-14 13:18:49
20240805133720	2026-04-14 13:18:50
20240827160934	2026-04-14 13:18:51
20240919163303	2026-04-14 13:18:53
20240919163305	2026-04-14 13:18:54
20241019105805	2026-04-14 13:18:55
20241030150047	2026-04-14 13:18:59
20241108114728	2026-04-14 13:19:01
20241121104152	2026-04-14 13:19:02
20241130184212	2026-04-14 13:19:03
20241220035512	2026-04-14 13:19:04
20241220123912	2026-04-14 13:19:06
20241224161212	2026-04-14 13:19:07
20250107150512	2026-04-14 13:19:08
20250110162412	2026-04-14 13:19:09
20250123174212	2026-04-14 13:19:10
20250128220012	2026-04-14 13:19:11
20250506224012	2026-04-14 13:19:12
20250523164012	2026-04-14 13:19:13
20250714121412	2026-04-14 13:19:14
20250905041441	2026-04-14 13:19:16
20251103001201	2026-04-14 13:19:17
20251120212548	2026-04-14 13:19:18
20251120215549	2026-04-14 13:19:19
20260218120000	2026-04-14 13:19:21
20260326120000	2026-04-14 13:19:22
20260514120000	2026-06-03 16:52:55
20260527120000	2026-06-03 16:52:58
20260528120000	2026-06-03 16:53:00
20260603120000	2026-06-04 22:36:02
20260605120000	2026-06-16 21:23:45
20260606110000	2026-06-16 21:23:46
20260616120000	2026-06-25 20:44:09
20260624120000	2026-06-25 20:44:12
20260626120000	2026-07-02 15:52:33
20260706120000	2026-07-09 17:17:25
20260707120000	2026-07-15 20:32:42
20260709120000	2026-07-15 20:32:43
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter, selected_columns) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-04-14 13:17:46.520203
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-04-14 13:17:46.528675
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-04-14 13:17:46.530895
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-04-14 13:17:46.550199
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-04-14 13:17:46.563007
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-04-14 13:17:46.565218
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-04-14 13:17:46.567917
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-04-14 13:17:46.570843
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-04-14 13:17:46.572904
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-04-14 13:17:46.575293
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-04-14 13:17:46.579166
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-04-14 13:17:46.58248
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-04-14 13:17:46.585115
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-04-14 13:17:46.587423
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-04-14 13:17:46.589728
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-04-14 13:17:46.616193
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-04-14 13:17:46.618405
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-04-14 13:17:46.620433
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-04-14 13:17:46.622438
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-04-14 13:17:46.625758
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-04-14 13:17:46.627805
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-04-14 13:17:46.632375
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-04-14 13:17:46.642893
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-04-14 13:17:46.65031
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-04-14 13:17:46.653674
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-04-14 13:17:46.656121
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-04-14 13:17:46.658486
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-04-14 13:17:46.660152
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-04-14 13:17:46.661872
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-04-14 13:17:46.66445
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-04-14 13:17:46.666998
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-04-14 13:17:46.669057
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-04-14 13:17:46.670757
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-04-14 13:17:46.672428
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-04-14 13:17:46.674317
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-04-14 13:17:46.675989
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-04-14 13:17:46.677624
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-04-14 13:17:46.679302
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-04-14 13:17:46.681903
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-04-14 13:17:46.689134
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-04-14 13:17:46.690914
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-04-14 13:17:46.692646
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-04-14 13:17:46.694501
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-04-14 13:17:46.69623
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-04-14 13:17:46.698007
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-04-14 13:17:46.701681
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-04-14 13:17:46.70903
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-04-14 13:17:46.711896
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-04-14 13:17:46.714823
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-04-14 13:17:46.728365
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-04-14 13:17:46.731175
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-04-14 13:17:47.280261
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-04-14 13:17:47.28162
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-04-14 13:17:47.288332
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-04-14 13:17:47.289858
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-04-14 13:17:47.291101
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-04-14 13:17:47.297834
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-04-14 13:17:47.30061
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-04-14 13:17:47.294599
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-05-05 21:50:20.57028
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-05-05 21:50:20.580873
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: supabase_migrations; Owner: postgres
--

COPY supabase_migrations.schema_migrations (version, statements, name, created_by, idempotency_key, rollback) FROM stdin;
20260505213657	{"COMMENT ON TABLE public.mvp_repartidores IS 'Capacidad ortogonal repartidor (RN-U05.1). user_id UNIQUE FK a mvp_users. Trigger trg_validar_operador_no_repartidor bloquea operadores.';"}		hectorag@gmail.com	\N	\N
20260506142026	{"COMMENT ON FUNCTION public.fn_actualizar_usuario(uuid, text, uuid, numeric, numeric, boolean, boolean) IS 'ABM Usuarios — actualización (RN-A01.1 v1.5). Multiparámetros NULL-able: NULL = no cambiar campo. Valida permisos por rol del ejecutor (admin todo, socio solo operadores). Valida RN-U06 al desactivar capacidad repartidor (caja en cero + sin entregas pendientes). Valida unicidad 1:1 cliente-operador en cambio de cliente_id. Decisión 6: bug consciente — desactivar usuario + capacidad simultáneamente requiere 2 llamadas.';"}		hectorag@gmail.com	\N	\N
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1042, true);


--
-- Name: mvp_operacion_caja_nro_comprobante_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mvp_operacion_caja_nro_comprobante_seq', 80, true);


--
-- Name: mvp_tipo_operaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mvp_tipo_operaciones_id_seq', 18, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_realtime_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: mvp_cajas mvp_cajas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_cajas
    ADD CONSTRAINT mvp_cajas_pkey PRIMARY KEY (id);


--
-- Name: mvp_cierre_detalle mvp_cierre_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_cierre_detalle
    ADD CONSTRAINT mvp_cierre_detalle_pkey PRIMARY KEY (id);


--
-- Name: mvp_cierre_resumen mvp_cierre_resumen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_cierre_resumen
    ADD CONSTRAINT mvp_cierre_resumen_pkey PRIMARY KEY (id);


--
-- Name: mvp_cierres mvp_cierres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_cierres
    ADD CONSTRAINT mvp_cierres_pkey PRIMARY KEY (id);


--
-- Name: mvp_clientes mvp_clientes_cuit_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_clientes
    ADD CONSTRAINT mvp_clientes_cuit_key UNIQUE (cuit);


--
-- Name: mvp_clientes mvp_clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_clientes
    ADD CONSTRAINT mvp_clientes_pkey PRIMARY KEY (id);


--
-- Name: mvp_config_seguridad mvp_config_seguridad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_config_seguridad
    ADD CONSTRAINT mvp_config_seguridad_pkey PRIMARY KEY (id);


--
-- Name: mvp_ctacte mvp_ctacte_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ctacte
    ADD CONSTRAINT mvp_ctacte_pkey PRIMARY KEY (id);


--
-- Name: mvp_egresos mvp_egresos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_egresos
    ADD CONSTRAINT mvp_egresos_pkey PRIMARY KEY (id);


--
-- Name: mvp_movimientos_caja mvp_movimientos_caja_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_movimientos_caja
    ADD CONSTRAINT mvp_movimientos_caja_pkey PRIMARY KEY (id);


--
-- Name: mvp_operacion_caja mvp_operacion_caja_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_operacion_caja
    ADD CONSTRAINT mvp_operacion_caja_pkey PRIMARY KEY (id);


--
-- Name: mvp_periodo mvp_periodo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_periodo
    ADD CONSTRAINT mvp_periodo_pkey PRIMARY KEY (id);


--
-- Name: mvp_productos mvp_productos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_productos
    ADD CONSTRAINT mvp_productos_pkey PRIMARY KEY (id);


--
-- Name: mvp_proveedores mvp_proveedores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_proveedores
    ADD CONSTRAINT mvp_proveedores_pkey PRIMARY KEY (id);


--
-- Name: mvp_reglas_negocio mvp_reglas_negocio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_reglas_negocio
    ADD CONSTRAINT mvp_reglas_negocio_pkey PRIMARY KEY (id);


--
-- Name: mvp_rendiciones mvp_rendiciones_caja_periodo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_rendiciones
    ADD CONSTRAINT mvp_rendiciones_caja_periodo_key UNIQUE (caja_id, periodo_id);


--
-- Name: mvp_rendiciones mvp_rendiciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_rendiciones
    ADD CONSTRAINT mvp_rendiciones_pkey PRIMARY KEY (id);


--
-- Name: mvp_repartidores mvp_repartidores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_repartidores
    ADD CONSTRAINT mvp_repartidores_pkey PRIMARY KEY (id);


--
-- Name: mvp_repartidores mvp_repartidores_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_repartidores
    ADD CONSTRAINT mvp_repartidores_user_id_key UNIQUE (user_id);


--
-- Name: mvp_socios mvp_socios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_socios
    ADD CONSTRAINT mvp_socios_pkey PRIMARY KEY (id);


--
-- Name: mvp_socios mvp_socios_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_socios
    ADD CONSTRAINT mvp_socios_user_id_key UNIQUE (user_id);


--
-- Name: mvp_system_status mvp_system_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_system_status
    ADD CONSTRAINT mvp_system_status_pkey PRIMARY KEY (id);


--
-- Name: mvp_tipo_operaciones mvp_tipo_operaciones_codigo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_tipo_operaciones
    ADD CONSTRAINT mvp_tipo_operaciones_codigo_key UNIQUE (codigo);


--
-- Name: mvp_tipo_operaciones mvp_tipo_operaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_tipo_operaciones
    ADD CONSTRAINT mvp_tipo_operaciones_pkey PRIMARY KEY (id);


--
-- Name: mvp_users mvp_users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_users
    ADD CONSTRAINT mvp_users_email_key UNIQUE (email);


--
-- Name: mvp_users mvp_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_users
    ADD CONSTRAINT mvp_users_pkey PRIMARY KEY (id);


--
-- Name: mvp_ventas_bajas mvp_ventas_bajas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ventas_bajas
    ADD CONSTRAINT mvp_ventas_bajas_pkey PRIMARY KEY (id);


--
-- Name: mvp_ventas_detalle mvp_ventas_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ventas_detalle
    ADD CONSTRAINT mvp_ventas_detalle_pkey PRIMARY KEY (id);


--
-- Name: mvp_ventas mvp_ventas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ventas
    ADD CONSTRAINT mvp_ventas_pkey PRIMARY KEY (id);


--
-- Name: mvp_cajas uq_caja_user_tipo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_cajas
    ADD CONSTRAINT uq_caja_user_tipo UNIQUE (user_id, tipo);


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages
    ADD CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL))) NOT VALID;


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_idempotency_key_key; Type: CONSTRAINT; Schema: supabase_migrations; Owner: postgres
--

ALTER TABLE ONLY supabase_migrations.schema_migrations
    ADD CONSTRAINT schema_migrations_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: supabase_migrations; Owner: postgres
--

ALTER TABLE ONLY supabase_migrations.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: idx_cajas_tipo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cajas_tipo ON public.mvp_cajas USING btree (tipo);


--
-- Name: idx_cierre_detalle_caja; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cierre_detalle_caja ON public.mvp_cierre_detalle USING btree (caja_id);


--
-- Name: idx_cierre_detalle_cierre; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cierre_detalle_cierre ON public.mvp_cierre_detalle USING btree (cierre_id);


--
-- Name: idx_movimientos_caja; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimientos_caja ON public.mvp_movimientos_caja USING btree (caja_id);


--
-- Name: idx_movimientos_caja_operacion; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movimientos_caja_operacion ON public.mvp_movimientos_caja USING btree (operacion_id);


--
-- Name: idx_mvp_clientes_socio_captador; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mvp_clientes_socio_captador ON public.mvp_clientes USING btree (socio_captador_id);


--
-- Name: idx_mvp_ctacte_fecha; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mvp_ctacte_fecha ON public.mvp_ctacte USING btree (fecha);


--
-- Name: idx_mvp_ctacte_operacion_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mvp_ctacte_operacion_id ON public.mvp_ctacte USING btree (operacion_id);


--
-- Name: idx_mvp_ctacte_socio_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mvp_ctacte_socio_id ON public.mvp_ctacte USING btree (socio_id);


--
-- Name: idx_mvp_proveedores_activo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mvp_proveedores_activo ON public.mvp_proveedores USING btree (activo);


--
-- Name: idx_mvp_proveedores_cuit_cuil_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_mvp_proveedores_cuit_cuil_unique ON public.mvp_proveedores USING btree (cuit_cuil) WHERE (cuit_cuil IS NOT NULL);


--
-- Name: idx_mvp_rendiciones_caja_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mvp_rendiciones_caja_id ON public.mvp_rendiciones USING btree (caja_id);


--
-- Name: idx_mvp_rendiciones_periodo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mvp_rendiciones_periodo_id ON public.mvp_rendiciones USING btree (periodo_id);


--
-- Name: idx_mvp_rendiciones_socio_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mvp_rendiciones_socio_id ON public.mvp_rendiciones USING btree (socio_id);


--
-- Name: idx_operacion_caja_destino; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_operacion_caja_destino ON public.mvp_operacion_caja USING btree (caja_destino_id);


--
-- Name: idx_operacion_caja_documento; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_operacion_caja_documento ON public.mvp_operacion_caja USING btree (documento_id);


--
-- Name: idx_operacion_caja_estado; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_operacion_caja_estado ON public.mvp_operacion_caja USING btree (estado);


--
-- Name: idx_operacion_caja_origen; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_operacion_caja_origen ON public.mvp_operacion_caja USING btree (caja_origen_id);


--
-- Name: idx_operacion_caja_periodo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_operacion_caja_periodo ON public.mvp_operacion_caja USING btree (periodo_id);


--
-- Name: idx_operacion_caja_relacionada; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_operacion_caja_relacionada ON public.mvp_operacion_caja USING btree (operacion_relacionada_id);


--
-- Name: idx_operacion_caja_tipo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_operacion_caja_tipo ON public.mvp_operacion_caja USING btree (tipo_operacion_id);


--
-- Name: idx_operacion_caja_usuario; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_operacion_caja_usuario ON public.mvp_operacion_caja USING btree (usuario_id);


--
-- Name: idx_reglas_negocio_estado; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reglas_negocio_estado ON public.mvp_reglas_negocio USING btree (estado);


--
-- Name: idx_reglas_negocio_id_base; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reglas_negocio_id_base ON public.mvp_reglas_negocio USING btree (id_base);


--
-- Name: idx_reglas_negocio_modulo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reglas_negocio_modulo ON public.mvp_reglas_negocio USING btree (modulo);


--
-- Name: idx_reglas_negocio_tags; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reglas_negocio_tags ON public.mvp_reglas_negocio USING gin (tags);


--
-- Name: idx_repartidores_activo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_repartidores_activo ON public.mvp_repartidores USING btree (activo) WHERE (activo = true);


--
-- Name: idx_repartidores_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_repartidores_user_id ON public.mvp_repartidores USING btree (user_id);


--
-- Name: idx_ventas_bajas_factura; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ventas_bajas_factura ON public.mvp_ventas_bajas USING btree (nro_factura);


--
-- Name: idx_ventas_bajas_periodo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ventas_bajas_periodo ON public.mvp_ventas_bajas USING btree (periodo_id, fecha_baja DESC);


--
-- Name: idx_ventas_bajas_venta; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ventas_bajas_venta ON public.mvp_ventas_bajas USING btree (venta_id);


--
-- Name: idx_ventas_cliente; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ventas_cliente ON public.mvp_ventas USING btree (cliente_id);


--
-- Name: idx_ventas_estado; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ventas_estado ON public.mvp_ventas USING btree (estado);


--
-- Name: idx_ventas_repartidor_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ventas_repartidor_id ON public.mvp_ventas USING btree (repartidor_id) WHERE (repartidor_id IS NOT NULL);


--
-- Name: idx_ventas_socio; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ventas_socio ON public.mvp_ventas USING btree (socio_id);


--
-- Name: mvp_productos_nombre_norm_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX mvp_productos_nombre_norm_uniq ON public.mvp_productos USING btree (translate(lower(btrim((nombre)::text)), 'áàäâãéèëêíìïîóòöôõúùüûñ'::text, 'aaaaaeeeeiiiiooooouuuun'::text)) WHERE (activo = true);


--
-- Name: mvp_productos_sigla_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX mvp_productos_sigla_uniq ON public.mvp_productos USING btree (lower(btrim((sigla)::text))) WHERE ((activo = true) AND (sigla IS NOT NULL));


--
-- Name: mvp_users_operador_cliente_unico; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX mvp_users_operador_cliente_unico ON public.mvp_users USING btree (cliente_id) WHERE (((rol)::text = 'operador'::text) AND (activo = true));


--
-- Name: uq_cierre_resumen_cierre; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_cierre_resumen_cierre ON public.mvp_cierre_resumen USING btree (cierre_id);


--
-- Name: uq_cierres_periodo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_cierres_periodo ON public.mvp_cierres USING btree (periodo_id);


--
-- Name: uq_mvp_operacion_caja_nro_comprobante; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_mvp_operacion_caja_nro_comprobante ON public.mvp_operacion_caja USING btree (nro_comprobante);


--
-- Name: uq_mvp_ventas_nro_factura; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_mvp_ventas_nro_factura ON public.mvp_ventas USING btree (nro_factura);


--
-- Name: uq_periodo_activo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_periodo_activo ON public.mvp_periodo USING btree ((true)) WHERE ((estado)::text <> 'CERRADO'::text);


--
-- Name: uq_periodo_codigo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_periodo_codigo ON public.mvp_periodo USING btree (codigo);


--
-- Name: uq_unico_tesorero; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_unico_tesorero ON public.mvp_users USING btree (rol_tesorero) WHERE (rol_tesorero = true);


--
-- Name: uq_unico_tester; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_unico_tester ON public.mvp_users USING btree (es_tester) WHERE (es_tester = true);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_selec ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter, COALESCE(selected_columns, '{}'::text[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: users on_auth_user_created; Type: TRIGGER; Schema: auth; Owner: supabase_auth_admin
--

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


--
-- Name: mvp_cierre_resumen set_updated_at_mvp_cierre_resumen; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_mvp_cierre_resumen BEFORE UPDATE ON public.mvp_cierre_resumen FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_ctacte set_updated_at_mvp_ctacte; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_mvp_ctacte BEFORE UPDATE ON public.mvp_ctacte FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_operacion_caja set_updated_at_mvp_operacion_caja; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_mvp_operacion_caja BEFORE UPDATE ON public.mvp_operacion_caja FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_periodo set_updated_at_mvp_periodo; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_mvp_periodo BEFORE UPDATE ON public.mvp_periodo FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_rendiciones set_updated_at_mvp_rendiciones; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_mvp_rendiciones BEFORE UPDATE ON public.mvp_rendiciones FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_tipo_operaciones set_updated_at_mvp_tipo_operaciones; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_updated_at_mvp_tipo_operaciones BEFORE UPDATE ON public.mvp_tipo_operaciones FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_users trg_block_email_update_on_mvp_users; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_block_email_update_on_mvp_users BEFORE UPDATE ON public.mvp_users FOR EACH ROW EXECUTE FUNCTION public.block_email_update_on_mvp_users();


--
-- Name: mvp_operacion_caja trg_guard_periodo_operacion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_guard_periodo_operacion BEFORE INSERT ON public.mvp_operacion_caja FOR EACH ROW EXECUTE FUNCTION public.fn_guard_periodo_operacion();


--
-- Name: mvp_cajas trg_mvp_cajas_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_cajas_updated_at BEFORE UPDATE ON public.mvp_cajas FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_cierre_detalle trg_mvp_cierre_detalle_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_cierre_detalle_updated_at BEFORE UPDATE ON public.mvp_cierre_detalle FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_cierres trg_mvp_cierres_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_cierres_updated_at BEFORE UPDATE ON public.mvp_cierres FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_clientes trg_mvp_clientes_creado_por_inmutable; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_clientes_creado_por_inmutable BEFORE UPDATE ON public.mvp_clientes FOR EACH ROW EXECUTE FUNCTION public.fn_mvp_clientes_creado_por_inmutable();


--
-- Name: mvp_clientes trg_mvp_clientes_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_clientes_updated_at BEFORE UPDATE ON public.mvp_clientes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_egresos trg_mvp_egresos_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_egresos_updated_at BEFORE UPDATE ON public.mvp_egresos FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_movimientos_caja trg_mvp_movimientos_caja_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_movimientos_caja_updated_at BEFORE UPDATE ON public.mvp_movimientos_caja FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_productos trg_mvp_productos_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_productos_updated_at BEFORE UPDATE ON public.mvp_productos FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_proveedores trg_mvp_proveedores_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_proveedores_updated_at BEFORE UPDATE ON public.mvp_proveedores FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_socios trg_mvp_socios_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_socios_updated_at BEFORE UPDATE ON public.mvp_socios FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_system_status trg_mvp_system_status_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_system_status_updated_at BEFORE UPDATE ON public.mvp_system_status FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_users trg_mvp_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_users_updated_at BEFORE UPDATE ON public.mvp_users FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_ventas_bajas trg_mvp_ventas_bajas_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_ventas_bajas_updated_at BEFORE UPDATE ON public.mvp_ventas_bajas FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_ventas_detalle trg_mvp_ventas_detalle_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_ventas_detalle_updated_at BEFORE UPDATE ON public.mvp_ventas_detalle FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_ventas trg_mvp_ventas_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_mvp_ventas_updated_at BEFORE UPDATE ON public.mvp_ventas FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_reglas_negocio trg_reglas_negocio_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_reglas_negocio_updated_at BEFORE UPDATE ON public.mvp_reglas_negocio FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();


--
-- Name: mvp_repartidores trg_set_updated_at_repartidores; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_set_updated_at_repartidores BEFORE UPDATE ON public.mvp_repartidores FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: mvp_repartidores trg_validar_operador_no_repartidor; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_validar_operador_no_repartidor BEFORE INSERT OR UPDATE ON public.mvp_repartidores FOR EACH ROW EXECUTE FUNCTION public.fn_validar_operador_no_repartidor();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mvp_cajas mvp_cajas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_cajas
    ADD CONSTRAINT mvp_cajas_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.mvp_users(id);


--
-- Name: mvp_cierre_detalle mvp_cierre_detalle_caja_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_cierre_detalle
    ADD CONSTRAINT mvp_cierre_detalle_caja_id_fkey FOREIGN KEY (caja_id) REFERENCES public.mvp_cajas(id);


--
-- Name: mvp_cierre_detalle mvp_cierre_detalle_cierre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_cierre_detalle
    ADD CONSTRAINT mvp_cierre_detalle_cierre_id_fkey FOREIGN KEY (cierre_id) REFERENCES public.mvp_cierres(id);


--
-- Name: mvp_cierre_resumen mvp_cierre_resumen_cierre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_cierre_resumen
    ADD CONSTRAINT mvp_cierre_resumen_cierre_id_fkey FOREIGN KEY (cierre_id) REFERENCES public.mvp_cierres(id);


--
-- Name: mvp_cierres mvp_cierres_periodo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_cierres
    ADD CONSTRAINT mvp_cierres_periodo_id_fkey FOREIGN KEY (periodo_id) REFERENCES public.mvp_periodo(id);


--
-- Name: mvp_cierres mvp_cierres_usuario_cierre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_cierres
    ADD CONSTRAINT mvp_cierres_usuario_cierre_fkey FOREIGN KEY (usuario_cierre) REFERENCES public.mvp_users(id);


--
-- Name: mvp_clientes mvp_clientes_creado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_clientes
    ADD CONSTRAINT mvp_clientes_creado_por_fkey FOREIGN KEY (creado_por) REFERENCES public.mvp_users(id) ON DELETE SET NULL;


--
-- Name: mvp_clientes mvp_clientes_socio_captador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_clientes
    ADD CONSTRAINT mvp_clientes_socio_captador_id_fkey FOREIGN KEY (socio_captador_id) REFERENCES public.mvp_socios(id) ON DELETE SET NULL;


--
-- Name: mvp_ctacte mvp_ctacte_operacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ctacte
    ADD CONSTRAINT mvp_ctacte_operacion_id_fkey FOREIGN KEY (operacion_id) REFERENCES public.mvp_operacion_caja(id);


--
-- Name: mvp_ctacte mvp_ctacte_socio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ctacte
    ADD CONSTRAINT mvp_ctacte_socio_id_fkey FOREIGN KEY (socio_id) REFERENCES public.mvp_users(id);


--
-- Name: mvp_egresos mvp_egresos_proveedor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_egresos
    ADD CONSTRAINT mvp_egresos_proveedor_id_fkey FOREIGN KEY (proveedor_id) REFERENCES public.mvp_proveedores(id);


--
-- Name: mvp_egresos mvp_egresos_socio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_egresos
    ADD CONSTRAINT mvp_egresos_socio_id_fkey FOREIGN KEY (socio_id) REFERENCES public.mvp_socios(id);


--
-- Name: mvp_movimientos_caja mvp_movimientos_caja_caja_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_movimientos_caja
    ADD CONSTRAINT mvp_movimientos_caja_caja_id_fkey FOREIGN KEY (caja_id) REFERENCES public.mvp_cajas(id);


--
-- Name: mvp_movimientos_caja mvp_movimientos_caja_operacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_movimientos_caja
    ADD CONSTRAINT mvp_movimientos_caja_operacion_id_fkey FOREIGN KEY (operacion_id) REFERENCES public.mvp_operacion_caja(id);


--
-- Name: mvp_operacion_caja mvp_operacion_caja_caja_destino_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_operacion_caja
    ADD CONSTRAINT mvp_operacion_caja_caja_destino_id_fkey FOREIGN KEY (caja_destino_id) REFERENCES public.mvp_cajas(id);


--
-- Name: mvp_operacion_caja mvp_operacion_caja_caja_origen_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_operacion_caja
    ADD CONSTRAINT mvp_operacion_caja_caja_origen_id_fkey FOREIGN KEY (caja_origen_id) REFERENCES public.mvp_cajas(id);


--
-- Name: mvp_operacion_caja mvp_operacion_caja_operacion_relacionada_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_operacion_caja
    ADD CONSTRAINT mvp_operacion_caja_operacion_relacionada_id_fkey FOREIGN KEY (operacion_relacionada_id) REFERENCES public.mvp_operacion_caja(id);


--
-- Name: mvp_operacion_caja mvp_operacion_caja_periodo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_operacion_caja
    ADD CONSTRAINT mvp_operacion_caja_periodo_id_fkey FOREIGN KEY (periodo_id) REFERENCES public.mvp_periodo(id);


--
-- Name: mvp_operacion_caja mvp_operacion_caja_tipo_operacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_operacion_caja
    ADD CONSTRAINT mvp_operacion_caja_tipo_operacion_id_fkey FOREIGN KEY (tipo_operacion_id) REFERENCES public.mvp_tipo_operaciones(id);


--
-- Name: mvp_operacion_caja mvp_operacion_caja_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_operacion_caja
    ADD CONSTRAINT mvp_operacion_caja_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.mvp_users(id);


--
-- Name: mvp_proveedores mvp_proveedores_creado_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_proveedores
    ADD CONSTRAINT mvp_proveedores_creado_por_fkey FOREIGN KEY (creado_por) REFERENCES public.mvp_users(id) ON DELETE SET NULL;


--
-- Name: mvp_rendiciones mvp_rendiciones_caja_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_rendiciones
    ADD CONSTRAINT mvp_rendiciones_caja_id_fkey FOREIGN KEY (caja_id) REFERENCES public.mvp_cajas(id);


--
-- Name: mvp_rendiciones mvp_rendiciones_operacion_liq_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_rendiciones
    ADD CONSTRAINT mvp_rendiciones_operacion_liq_fkey FOREIGN KEY (operacion_liquidacion_id) REFERENCES public.mvp_operacion_caja(id);


--
-- Name: mvp_rendiciones mvp_rendiciones_periodo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_rendiciones
    ADD CONSTRAINT mvp_rendiciones_periodo_id_fkey FOREIGN KEY (periodo_id) REFERENCES public.mvp_periodo(id);


--
-- Name: mvp_rendiciones mvp_rendiciones_socio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_rendiciones
    ADD CONSTRAINT mvp_rendiciones_socio_id_fkey FOREIGN KEY (socio_id) REFERENCES public.mvp_users(id);


--
-- Name: mvp_repartidores mvp_repartidores_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_repartidores
    ADD CONSTRAINT mvp_repartidores_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.mvp_users(id) ON DELETE RESTRICT;


--
-- Name: mvp_socios mvp_socios_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_socios
    ADD CONSTRAINT mvp_socios_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.mvp_users(id);


--
-- Name: mvp_users mvp_users_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_users
    ADD CONSTRAINT mvp_users_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.mvp_clientes(id);


--
-- Name: mvp_users mvp_users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_users
    ADD CONSTRAINT mvp_users_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mvp_ventas_bajas mvp_ventas_bajas_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ventas_bajas
    ADD CONSTRAINT mvp_ventas_bajas_periodo_fkey FOREIGN KEY (periodo_id) REFERENCES public.mvp_periodo(id);


--
-- Name: mvp_ventas_bajas mvp_ventas_bajas_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ventas_bajas
    ADD CONSTRAINT mvp_ventas_bajas_usuario_fkey FOREIGN KEY (usuario_baja_id) REFERENCES public.mvp_users(id);


--
-- Name: mvp_ventas mvp_ventas_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ventas
    ADD CONSTRAINT mvp_ventas_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.mvp_clientes(id);


--
-- Name: mvp_ventas_detalle mvp_ventas_detalle_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ventas_detalle
    ADD CONSTRAINT mvp_ventas_detalle_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.mvp_productos(id);


--
-- Name: mvp_ventas_detalle mvp_ventas_detalle_venta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ventas_detalle
    ADD CONSTRAINT mvp_ventas_detalle_venta_id_fkey FOREIGN KEY (venta_id) REFERENCES public.mvp_ventas(id) ON DELETE CASCADE;


--
-- Name: mvp_ventas mvp_ventas_repartidor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ventas
    ADD CONSTRAINT mvp_ventas_repartidor_id_fkey FOREIGN KEY (repartidor_id) REFERENCES public.mvp_users(id);


--
-- Name: mvp_ventas mvp_ventas_socio_cobrador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ventas
    ADD CONSTRAINT mvp_ventas_socio_cobrador_id_fkey FOREIGN KEY (socio_cobrador_id) REFERENCES public.mvp_socios(id);


--
-- Name: mvp_ventas mvp_ventas_socio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mvp_ventas
    ADD CONSTRAINT mvp_ventas_socio_id_fkey FOREIGN KEY (socio_id) REFERENCES public.mvp_socios(id);


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_cajas cajas_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY cajas_access ON public.mvp_cajas FOR SELECT USING ((((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text])) OR public.es_tesorero() OR (((public.get_user_rol())::text = 'socio'::text) AND (user_id = auth.uid()))));


--
-- Name: mvp_cajas cajas_access_repartidor; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY cajas_access_repartidor ON public.mvp_cajas FOR SELECT USING ((((tipo)::text = 'REPARTIDOR'::text) AND (user_id = auth.uid()) AND (EXISTS ( SELECT 1
   FROM public.mvp_repartidores
  WHERE ((mvp_repartidores.user_id = auth.uid()) AND (mvp_repartidores.activo = true))))));


--
-- Name: mvp_cajas cajas_socio_ver_socios; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY cajas_socio_ver_socios ON public.mvp_cajas FOR SELECT TO authenticated USING ((((public.get_user_rol())::text = 'socio'::text) AND ((tipo)::text = 'SOCIO'::text)));


--
-- Name: mvp_cierre_detalle cierre_detalle_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY cierre_detalle_access ON public.mvp_cierre_detalle FOR SELECT USING ((((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text])) OR public.es_tesorero() OR (((public.get_user_rol())::text = 'socio'::text) AND (caja_id IN ( SELECT mvp_cajas.id
   FROM public.mvp_cajas
  WHERE (mvp_cajas.user_id = auth.uid()))))));


--
-- Name: mvp_cierre_resumen cierre_resumen_select; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY cierre_resumen_select ON public.mvp_cierre_resumen FOR SELECT USING (((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text, 'socio'::text])));


--
-- Name: mvp_cierres cierres_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY cierres_access ON public.mvp_cierres FOR SELECT USING (((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text, 'socio'::text])));


--
-- Name: mvp_clientes clientes_insert; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY clientes_insert ON public.mvp_clientes FOR INSERT TO authenticated WITH CHECK (((creado_por = auth.uid()) AND (EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = ANY (ARRAY[('admin'::character varying)::text, ('socio'::character varying)::text])) AND (u.activo = true))))));


--
-- Name: mvp_clientes clientes_select; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY clientes_select ON public.mvp_clientes FOR SELECT TO authenticated USING (true);


--
-- Name: mvp_clientes clientes_update; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY clientes_update ON public.mvp_clientes FOR UPDATE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = ANY ((ARRAY['admin'::character varying, 'socio'::character varying])::text[])) AND (u.activo = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = ANY ((ARRAY['admin'::character varying, 'socio'::character varying])::text[])) AND (u.activo = true)))));


--
-- Name: mvp_ctacte ctacte_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY ctacte_access ON public.mvp_ctacte FOR SELECT USING ((((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text])) OR public.es_tesorero() OR (((public.get_user_rol())::text = 'socio'::text) AND (socio_id = auth.uid()))));


--
-- Name: mvp_egresos egresos_access_admin_tesorero; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY egresos_access_admin_tesorero ON public.mvp_egresos FOR SELECT USING ((((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text])) OR public.es_tesorero()));


--
-- Name: mvp_egresos egresos_access_socio; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY egresos_access_socio ON public.mvp_egresos FOR SELECT USING ((((public.get_user_rol())::text = 'socio'::text) AND (socio_id = ( SELECT mvp_socios.id
   FROM public.mvp_socios
  WHERE (mvp_socios.user_id = auth.uid())))));


--
-- Name: mvp_egresos egresos_delete_socio_si_huerfano; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY egresos_delete_socio_si_huerfano ON public.mvp_egresos FOR DELETE TO authenticated USING ((((public.get_user_rol())::text = 'socio'::text) AND (socio_id IN ( SELECT mvp_socios.id
   FROM public.mvp_socios
  WHERE (mvp_socios.user_id = auth.uid()))) AND (NOT (EXISTS ( SELECT 1
   FROM public.mvp_movimientos_caja
  WHERE (((mvp_movimientos_caja.tipo_referencia)::text = 'EGRESO'::text) AND ((mvp_movimientos_caja.referencia_id)::text = (mvp_egresos.id)::text)))))));


--
-- Name: mvp_egresos egresos_insert_socio; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY egresos_insert_socio ON public.mvp_egresos FOR INSERT TO authenticated WITH CHECK ((((public.get_user_rol())::text = 'socio'::text) AND (socio_id IN ( SELECT mvp_socios.id
   FROM public.mvp_socios
  WHERE (mvp_socios.user_id = auth.uid())))));


--
-- Name: mvp_egresos egresos_no_update; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY egresos_no_update ON public.mvp_egresos FOR UPDATE TO authenticated USING (false);


--
-- Name: mvp_movimientos_caja movimientos_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY movimientos_access ON public.mvp_movimientos_caja FOR SELECT USING ((((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text])) OR public.es_tesorero() OR (((public.get_user_rol())::text = 'socio'::text) AND (caja_id IN ( SELECT mvp_cajas.id
   FROM public.mvp_cajas
  WHERE (mvp_cajas.user_id = auth.uid()))))));


--
-- Name: mvp_cajas; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_cajas ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_cierre_detalle; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_cierre_detalle ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_cierre_resumen; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_cierre_resumen ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_cierres; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_cierres ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_clientes; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_clientes ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_config_seguridad; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_config_seguridad ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_ctacte; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_ctacte ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_egresos; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_egresos ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_movimientos_caja; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_movimientos_caja ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_operacion_caja; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_operacion_caja ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_periodo; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_periodo ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_productos; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_productos ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_proveedores; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_proveedores ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_reglas_negocio; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_reglas_negocio ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_rendiciones; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_rendiciones ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_repartidores; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_repartidores ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_socios; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_socios ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_system_status; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_system_status ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_tipo_operaciones; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_tipo_operaciones ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_tipo_operaciones mvp_tipo_operaciones_select_authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY mvp_tipo_operaciones_select_authenticated ON public.mvp_tipo_operaciones FOR SELECT TO authenticated USING (true);


--
-- Name: mvp_users; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_users ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_ventas; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_ventas ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_ventas_bajas; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_ventas_bajas ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_ventas_detalle; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mvp_ventas_detalle ENABLE ROW LEVEL SECURITY;

--
-- Name: mvp_operacion_caja operacion_caja_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY operacion_caja_access ON public.mvp_operacion_caja FOR SELECT TO authenticated USING ((((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text])) OR public.es_tesorero() OR (((public.get_user_rol())::text = 'socio'::text) AND ((caja_origen_id IN ( SELECT mvp_cajas.id
   FROM public.mvp_cajas
  WHERE (mvp_cajas.user_id = auth.uid()))) OR (caja_destino_id IN ( SELECT mvp_cajas.id
   FROM public.mvp_cajas
  WHERE (mvp_cajas.user_id = auth.uid())))))));


--
-- Name: mvp_periodo periodo_select_authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY periodo_select_authenticated ON public.mvp_periodo FOR SELECT USING ((auth.uid() IS NOT NULL));


--
-- Name: mvp_productos productos_insert; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY productos_insert ON public.mvp_productos FOR INSERT TO authenticated WITH CHECK (((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = 'admin'::text) AND (u.activo = true)))) OR ((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = 'socio'::text) AND (u.activo = true)))) AND (sigla IS NULL))));


--
-- Name: mvp_productos productos_select; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY productos_select ON public.mvp_productos FOR SELECT TO authenticated USING (true);


--
-- Name: mvp_productos productos_update_admin; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY productos_update_admin ON public.mvp_productos FOR UPDATE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = 'admin'::text) AND (u.activo = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = 'admin'::text) AND (u.activo = true)))));


--
-- Name: mvp_proveedores proveedores_insert; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY proveedores_insert ON public.mvp_proveedores FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = ANY ((ARRAY['admin'::character varying, 'socio'::character varying])::text[])) AND (u.activo = true)))));


--
-- Name: mvp_proveedores proveedores_select; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY proveedores_select ON public.mvp_proveedores FOR SELECT TO authenticated USING (true);


--
-- Name: mvp_proveedores proveedores_update; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY proveedores_update ON public.mvp_proveedores FOR UPDATE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = 'admin'::text) AND (u.activo = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = 'admin'::text) AND (u.activo = true)))));


--
-- Name: mvp_reglas_negocio reglas_negocio_delete_negado; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY reglas_negocio_delete_negado ON public.mvp_reglas_negocio FOR DELETE TO authenticated USING (false);


--
-- Name: mvp_reglas_negocio reglas_negocio_insert_negado; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY reglas_negocio_insert_negado ON public.mvp_reglas_negocio FOR INSERT TO authenticated WITH CHECK (false);


--
-- Name: mvp_reglas_negocio reglas_negocio_select_admin_tesorero_socio; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY reglas_negocio_select_admin_tesorero_socio ON public.mvp_reglas_negocio FOR SELECT TO authenticated USING (((public.get_user_rol())::text = ANY ((ARRAY['admin'::character varying, 'tesorero'::character varying, 'socio'::character varying])::text[])));


--
-- Name: mvp_reglas_negocio reglas_negocio_update_negado; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY reglas_negocio_update_negado ON public.mvp_reglas_negocio FOR UPDATE TO authenticated USING (false);


--
-- Name: mvp_rendiciones rendiciones_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY rendiciones_access ON public.mvp_rendiciones FOR SELECT USING ((((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text])) OR public.es_tesorero() OR (((public.get_user_rol())::text = 'socio'::text) AND (socio_id = auth.uid()))));


--
-- Name: mvp_repartidores repartidores_select_admin_tesorero; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY repartidores_select_admin_tesorero ON public.mvp_repartidores FOR SELECT USING ((((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text])) OR public.es_tesorero()));


--
-- Name: mvp_repartidores repartidores_select_self; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY repartidores_select_self ON public.mvp_repartidores FOR SELECT USING ((user_id = auth.uid()));


--
-- Name: mvp_repartidores repartidores_select_socio_activos; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY repartidores_select_socio_activos ON public.mvp_repartidores FOR SELECT USING ((((public.get_user_rol())::text = 'socio'::text) AND (activo = true)));


--
-- Name: mvp_socios socios_admin_tesorero; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY socios_admin_tesorero ON public.mvp_socios FOR SELECT USING ((((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text])) OR public.es_tesorero()));


--
-- Name: mvp_socios socios_admin_update; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY socios_admin_update ON public.mvp_socios FOR UPDATE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = 'admin'::text) AND (u.activo = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = 'admin'::text) AND (u.activo = true)))));


--
-- Name: mvp_socios socios_self; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY socios_self ON public.mvp_socios FOR SELECT USING ((((public.get_user_rol())::text = 'socio'::text) AND (user_id = auth.uid())));


--
-- Name: mvp_system_status system_status_block_delete; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY system_status_block_delete ON public.mvp_system_status FOR DELETE TO authenticated USING (false);


--
-- Name: mvp_system_status system_status_block_insert; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY system_status_block_insert ON public.mvp_system_status FOR INSERT TO authenticated WITH CHECK (false);


--
-- Name: mvp_system_status system_status_block_update; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY system_status_block_update ON public.mvp_system_status FOR UPDATE TO authenticated USING (false);


--
-- Name: mvp_system_status system_status_read; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY system_status_read ON public.mvp_system_status FOR SELECT TO authenticated USING (true);


--
-- Name: mvp_tipo_operaciones tipo_operaciones_no_delete; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tipo_operaciones_no_delete ON public.mvp_tipo_operaciones FOR DELETE TO authenticated USING (false);


--
-- Name: mvp_tipo_operaciones tipo_operaciones_no_insert; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tipo_operaciones_no_insert ON public.mvp_tipo_operaciones FOR INSERT TO authenticated WITH CHECK (false);


--
-- Name: mvp_tipo_operaciones tipo_operaciones_no_update; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tipo_operaciones_no_update ON public.mvp_tipo_operaciones FOR UPDATE TO authenticated USING (false);


--
-- Name: mvp_users users_admin_only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY users_admin_only ON public.mvp_users USING (((public.get_user_rol())::text = 'admin'::text));


--
-- Name: mvp_users users_privileged_read; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY users_privileged_read ON public.mvp_users FOR SELECT TO authenticated USING (((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text, 'socio'::text])));


--
-- Name: mvp_users users_self_select; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY users_self_select ON public.mvp_users FOR SELECT USING ((auth.uid() = id));


--
-- Name: mvp_users users_socio_update_operador; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY users_socio_update_operador ON public.mvp_users FOR UPDATE TO authenticated USING (((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = 'socio'::text) AND (u.activo = true)))) AND ((rol)::text = 'operador'::text) AND (EXISTS ( SELECT 1
   FROM public.mvp_clientes c
  WHERE ((c.id = mvp_users.cliente_id) AND (c.activo = true)))))) WITH CHECK (((EXISTS ( SELECT 1
   FROM public.mvp_users u
  WHERE ((u.id = auth.uid()) AND ((u.rol)::text = 'socio'::text) AND (u.activo = true)))) AND ((rol)::text = 'operador'::text) AND (EXISTS ( SELECT 1
   FROM public.mvp_clientes c
  WHERE ((c.id = mvp_users.cliente_id) AND (c.activo = true))))));


--
-- Name: mvp_ventas ventas_access_admin_tesorero; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY ventas_access_admin_tesorero ON public.mvp_ventas FOR SELECT USING ((((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text])) OR public.es_tesorero()));


--
-- Name: mvp_ventas ventas_access_repartidor; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY ventas_access_repartidor ON public.mvp_ventas FOR SELECT USING (((repartidor_id = auth.uid()) AND (EXISTS ( SELECT 1
   FROM public.mvp_repartidores
  WHERE ((mvp_repartidores.user_id = auth.uid()) AND (mvp_repartidores.activo = true))))));


--
-- Name: mvp_ventas ventas_access_socio_todas; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY ventas_access_socio_todas ON public.mvp_ventas FOR SELECT USING (((public.get_user_rol())::text = 'socio'::text));


--
-- Name: mvp_ventas_bajas ventas_bajas_select_admin; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY ventas_bajas_select_admin ON public.mvp_ventas_bajas FOR SELECT TO authenticated USING (((public.get_user_rol())::text = 'admin'::text));


--
-- Name: mvp_ventas_detalle ventas_detalle_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY ventas_detalle_access ON public.mvp_ventas_detalle FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.mvp_ventas v
  WHERE ((v.id = mvp_ventas_detalle.venta_id) AND (((public.get_user_rol())::text = ANY (ARRAY['admin'::text, 'tesorero'::text, 'socio'::text])) OR ((v.repartidor_id = auth.uid()) AND (EXISTS ( SELECT 1
           FROM public.mvp_repartidores r
          WHERE ((r.user_id = auth.uid()) AND (r.activo = true))))))))));


--
-- Name: mvp_ventas_detalle ventas_detalle_insert; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY ventas_detalle_insert ON public.mvp_ventas_detalle FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.mvp_ventas v
  WHERE ((v.id = mvp_ventas_detalle.venta_id) AND (((public.get_user_rol())::text = 'admin'::text) OR (((public.get_user_rol())::text = 'socio'::text) AND (v.socio_id = ( SELECT mvp_socios.id
           FROM public.mvp_socios
          WHERE (mvp_socios.user_id = auth.uid())))))))));


--
-- Name: mvp_ventas ventas_insert_admin; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY ventas_insert_admin ON public.mvp_ventas FOR INSERT WITH CHECK (((public.get_user_rol())::text = 'admin'::text));


--
-- Name: mvp_ventas ventas_insert_socio; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY ventas_insert_socio ON public.mvp_ventas FOR INSERT WITH CHECK ((((public.get_user_rol())::text = 'socio'::text) AND (socio_id = ( SELECT mvp_socios.id
   FROM public.mvp_socios
  WHERE (mvp_socios.user_id = auth.uid())))));


--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT USAGE ON SCHEMA auth TO postgres;


--
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO authenticated;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;


--
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA storage TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- Name: SCHEMA vault; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA vault TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA vault TO service_role;


--
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea, text[], text[]) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.crypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.dearmor(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_bytes(integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_uuid() FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text, integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO dashboard_user;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_key_id(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1mc() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v4() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_nil() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_dns() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_oid() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_url() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_x500() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;


--
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- Name: FUNCTION pg_reload_conf(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION pg_catalog.pg_reload_conf() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;


--
-- Name: FUNCTION block_email_update_on_mvp_users(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.block_email_update_on_mvp_users() TO anon;
GRANT ALL ON FUNCTION public.block_email_update_on_mvp_users() TO authenticated;
GRANT ALL ON FUNCTION public.block_email_update_on_mvp_users() TO service_role;


--
-- Name: FUNCTION calcular_saldo_caja(p_caja_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.calcular_saldo_caja(p_caja_id uuid) TO anon;
GRANT ALL ON FUNCTION public.calcular_saldo_caja(p_caja_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.calcular_saldo_caja(p_caja_id uuid) TO service_role;


--
-- Name: FUNCTION es_tesorero(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.es_tesorero() TO anon;
GRANT ALL ON FUNCTION public.es_tesorero() TO authenticated;
GRANT ALL ON FUNCTION public.es_tesorero() TO service_role;


--
-- Name: TABLE mvp_periodo; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_periodo TO anon;
GRANT ALL ON TABLE public.mvp_periodo TO authenticated;
GRANT ALL ON TABLE public.mvp_periodo TO service_role;


--
-- Name: FUNCTION fn_abrir_periodo(p_codigo character varying); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_abrir_periodo(p_codigo character varying) TO anon;
GRANT ALL ON FUNCTION public.fn_abrir_periodo(p_codigo character varying) TO authenticated;
GRANT ALL ON FUNCTION public.fn_abrir_periodo(p_codigo character varying) TO service_role;


--
-- Name: FUNCTION fn_actualizar_mi_telefono(p_telefono text); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.fn_actualizar_mi_telefono(p_telefono text) FROM PUBLIC;
GRANT ALL ON FUNCTION public.fn_actualizar_mi_telefono(p_telefono text) TO anon;
GRANT ALL ON FUNCTION public.fn_actualizar_mi_telefono(p_telefono text) TO authenticated;
GRANT ALL ON FUNCTION public.fn_actualizar_mi_telefono(p_telefono text) TO service_role;


--
-- Name: FUNCTION fn_actualizar_usuario(p_user_id uuid, p_nombre text, p_cliente_id uuid, p_porc_ganancia numeric, p_porc_venta numeric, p_activo boolean, p_es_repartidor boolean, p_telefono text, p_rol_tesorero boolean, p_es_tester boolean); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_actualizar_usuario(p_user_id uuid, p_nombre text, p_cliente_id uuid, p_porc_ganancia numeric, p_porc_venta numeric, p_activo boolean, p_es_repartidor boolean, p_telefono text, p_rol_tesorero boolean, p_es_tester boolean) TO anon;
GRANT ALL ON FUNCTION public.fn_actualizar_usuario(p_user_id uuid, p_nombre text, p_cliente_id uuid, p_porc_ganancia numeric, p_porc_venta numeric, p_activo boolean, p_es_repartidor boolean, p_telefono text, p_rol_tesorero boolean, p_es_tester boolean) TO authenticated;
GRANT ALL ON FUNCTION public.fn_actualizar_usuario(p_user_id uuid, p_nombre text, p_cliente_id uuid, p_porc_ganancia numeric, p_porc_venta numeric, p_activo boolean, p_es_repartidor boolean, p_telefono text, p_rol_tesorero boolean, p_es_tester boolean) TO service_role;


--
-- Name: FUNCTION fn_anular_venta(p_venta_id uuid, p_motivo character varying); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_anular_venta(p_venta_id uuid, p_motivo character varying) TO anon;
GRANT ALL ON FUNCTION public.fn_anular_venta(p_venta_id uuid, p_motivo character varying) TO authenticated;
GRANT ALL ON FUNCTION public.fn_anular_venta(p_venta_id uuid, p_motivo character varying) TO service_role;


--
-- Name: FUNCTION fn_asignar_reparto(p_venta_id uuid, p_repartidor_id uuid, p_nro_factura character varying); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_asignar_reparto(p_venta_id uuid, p_repartidor_id uuid, p_nro_factura character varying) TO anon;
GRANT ALL ON FUNCTION public.fn_asignar_reparto(p_venta_id uuid, p_repartidor_id uuid, p_nro_factura character varying) TO authenticated;
GRANT ALL ON FUNCTION public.fn_asignar_reparto(p_venta_id uuid, p_repartidor_id uuid, p_nro_factura character varying) TO service_role;


--
-- Name: FUNCTION fn_baja_venta(p_venta_id uuid, p_clave text, p_motivo text); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.fn_baja_venta(p_venta_id uuid, p_clave text, p_motivo text) FROM PUBLIC;
GRANT ALL ON FUNCTION public.fn_baja_venta(p_venta_id uuid, p_clave text, p_motivo text) TO authenticated;
GRANT ALL ON FUNCTION public.fn_baja_venta(p_venta_id uuid, p_clave text, p_motivo text) TO service_role;


--
-- Name: FUNCTION fn_caja_real_cobro(p_venta_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_caja_real_cobro(p_venta_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_caja_real_cobro(p_venta_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_caja_real_cobro(p_venta_id uuid) TO service_role;


--
-- Name: FUNCTION fn_cancelar_prestamo_socio(p_operacion_prestamo_id uuid, p_observaciones text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_cancelar_prestamo_socio(p_operacion_prestamo_id uuid, p_observaciones text) TO anon;
GRANT ALL ON FUNCTION public.fn_cancelar_prestamo_socio(p_operacion_prestamo_id uuid, p_observaciones text) TO authenticated;
GRANT ALL ON FUNCTION public.fn_cancelar_prestamo_socio(p_operacion_prestamo_id uuid, p_observaciones text) TO service_role;


--
-- Name: FUNCTION fn_carga_rapida_venta(p_socio_id uuid, p_fecha date, p_cliente_id uuid, p_items jsonb, p_repartidor_id uuid, p_nro_factura character varying, p_cobrada boolean, p_socio_receptor_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_carga_rapida_venta(p_socio_id uuid, p_fecha date, p_cliente_id uuid, p_items jsonb, p_repartidor_id uuid, p_nro_factura character varying, p_cobrada boolean, p_socio_receptor_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_carga_rapida_venta(p_socio_id uuid, p_fecha date, p_cliente_id uuid, p_items jsonb, p_repartidor_id uuid, p_nro_factura character varying, p_cobrada boolean, p_socio_receptor_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_carga_rapida_venta(p_socio_id uuid, p_fecha date, p_cliente_id uuid, p_items jsonb, p_repartidor_id uuid, p_nro_factura character varying, p_cobrada boolean, p_socio_receptor_id uuid) TO service_role;


--
-- Name: FUNCTION fn_crear_usuario(p_user_id uuid, p_rol text, p_nombre text, p_cliente_id uuid, p_porc_ganancia numeric, p_porc_venta numeric, p_caja_nombre text, p_es_repartidor boolean, p_telefono text, p_rol_tesorero boolean); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_crear_usuario(p_user_id uuid, p_rol text, p_nombre text, p_cliente_id uuid, p_porc_ganancia numeric, p_porc_venta numeric, p_caja_nombre text, p_es_repartidor boolean, p_telefono text, p_rol_tesorero boolean) TO anon;
GRANT ALL ON FUNCTION public.fn_crear_usuario(p_user_id uuid, p_rol text, p_nombre text, p_cliente_id uuid, p_porc_ganancia numeric, p_porc_venta numeric, p_caja_nombre text, p_es_repartidor boolean, p_telefono text, p_rol_tesorero boolean) TO authenticated;
GRANT ALL ON FUNCTION public.fn_crear_usuario(p_user_id uuid, p_rol text, p_nombre text, p_cliente_id uuid, p_porc_ganancia numeric, p_porc_venta numeric, p_caja_nombre text, p_es_repartidor boolean, p_telefono text, p_rol_tesorero boolean) TO service_role;


--
-- Name: FUNCTION fn_ctacte_resumen_socios(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_ctacte_resumen_socios() TO anon;
GRANT ALL ON FUNCTION public.fn_ctacte_resumen_socios() TO authenticated;
GRANT ALL ON FUNCTION public.fn_ctacte_resumen_socios() TO service_role;


--
-- Name: FUNCTION fn_cuenta_socio(p_socio_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_cuenta_socio(p_socio_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_cuenta_socio(p_socio_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_cuenta_socio(p_socio_id uuid) TO service_role;


--
-- Name: FUNCTION fn_dashboard_cajas_repartidores(p_limite integer, p_orden text, p_dir text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_dashboard_cajas_repartidores(p_limite integer, p_orden text, p_dir text) TO anon;
GRANT ALL ON FUNCTION public.fn_dashboard_cajas_repartidores(p_limite integer, p_orden text, p_dir text) TO authenticated;
GRANT ALL ON FUNCTION public.fn_dashboard_cajas_repartidores(p_limite integer, p_orden text, p_dir text) TO service_role;


--
-- Name: FUNCTION fn_dashboard_delegadas_header(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_dashboard_delegadas_header() TO anon;
GRANT ALL ON FUNCTION public.fn_dashboard_delegadas_header() TO authenticated;
GRANT ALL ON FUNCTION public.fn_dashboard_delegadas_header() TO service_role;


--
-- Name: FUNCTION fn_dashboard_periodo(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_dashboard_periodo() TO authenticated;
GRANT ALL ON FUNCTION public.fn_dashboard_periodo() TO service_role;


--
-- Name: FUNCTION fn_ejecutar_cierre(p_periodo_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_ejecutar_cierre(p_periodo_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_ejecutar_cierre(p_periodo_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_ejecutar_cierre(p_periodo_id uuid) TO service_role;


--
-- Name: FUNCTION fn_fecha_cobro(p_venta_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_fecha_cobro(p_venta_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_fecha_cobro(p_venta_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_fecha_cobro(p_venta_id uuid) TO service_role;


--
-- Name: FUNCTION fn_fecha_local(p_ts timestamp without time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_fecha_local(p_ts timestamp without time zone) TO anon;
GRANT ALL ON FUNCTION public.fn_fecha_local(p_ts timestamp without time zone) TO authenticated;
GRANT ALL ON FUNCTION public.fn_fecha_local(p_ts timestamp without time zone) TO service_role;


--
-- Name: FUNCTION fn_fecha_local_desde_ts(p_ts timestamp without time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_fecha_local_desde_ts(p_ts timestamp without time zone) TO anon;
GRANT ALL ON FUNCTION public.fn_fecha_local_desde_ts(p_ts timestamp without time zone) TO authenticated;
GRANT ALL ON FUNCTION public.fn_fecha_local_desde_ts(p_ts timestamp without time zone) TO service_role;


--
-- Name: FUNCTION fn_guard_periodo_operacion(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_guard_periodo_operacion() TO anon;
GRANT ALL ON FUNCTION public.fn_guard_periodo_operacion() TO authenticated;
GRANT ALL ON FUNCTION public.fn_guard_periodo_operacion() TO service_role;


--
-- Name: FUNCTION fn_haber_ctacte_a_fecha(p_socio_id uuid, p_fecha date); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.fn_haber_ctacte_a_fecha(p_socio_id uuid, p_fecha date) FROM PUBLIC;
GRANT ALL ON FUNCTION public.fn_haber_ctacte_a_fecha(p_socio_id uuid, p_fecha date) TO service_role;


--
-- Name: FUNCTION fn_informe_cierre(p_periodo_id uuid); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.fn_informe_cierre(p_periodo_id uuid) FROM PUBLIC;
GRANT ALL ON FUNCTION public.fn_informe_cierre(p_periodo_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_informe_cierre(p_periodo_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_informe_cierre(p_periodo_id uuid) TO service_role;


--
-- Name: FUNCTION fn_listar_movimientos_mi_caja(p_caja_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_listar_movimientos_mi_caja(p_caja_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_listar_movimientos_mi_caja(p_caja_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_listar_movimientos_mi_caja(p_caja_id uuid) TO service_role;


--
-- Name: FUNCTION fn_listar_prestamos_socio(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_listar_prestamos_socio() TO anon;
GRANT ALL ON FUNCTION public.fn_listar_prestamos_socio() TO authenticated;
GRANT ALL ON FUNCTION public.fn_listar_prestamos_socio() TO service_role;


--
-- Name: FUNCTION fn_listar_rendiciones_pendientes(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_listar_rendiciones_pendientes() TO anon;
GRANT ALL ON FUNCTION public.fn_listar_rendiciones_pendientes() TO authenticated;
GRANT ALL ON FUNCTION public.fn_listar_rendiciones_pendientes() TO service_role;


--
-- Name: FUNCTION fn_listar_socios(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_listar_socios() TO anon;
GRANT ALL ON FUNCTION public.fn_listar_socios() TO authenticated;
GRANT ALL ON FUNCTION public.fn_listar_socios() TO service_role;


--
-- Name: FUNCTION fn_listar_socios_para_prestamo(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_listar_socios_para_prestamo() TO anon;
GRANT ALL ON FUNCTION public.fn_listar_socios_para_prestamo() TO authenticated;
GRANT ALL ON FUNCTION public.fn_listar_socios_para_prestamo() TO service_role;


--
-- Name: FUNCTION fn_listar_transferencias_periodo(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_listar_transferencias_periodo() TO anon;
GRANT ALL ON FUNCTION public.fn_listar_transferencias_periodo() TO authenticated;
GRANT ALL ON FUNCTION public.fn_listar_transferencias_periodo() TO service_role;


--
-- Name: FUNCTION fn_listar_ventas_pendientes_caja(p_caja_id uuid); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.fn_listar_ventas_pendientes_caja(p_caja_id uuid) FROM PUBLIC;
GRANT ALL ON FUNCTION public.fn_listar_ventas_pendientes_caja(p_caja_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_listar_ventas_pendientes_caja(p_caja_id uuid) TO service_role;


--
-- Name: FUNCTION fn_movimientos_ctacte(p_socio_id uuid, p_desde date, p_hasta date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_movimientos_ctacte(p_socio_id uuid, p_desde date, p_hasta date) TO anon;
GRANT ALL ON FUNCTION public.fn_movimientos_ctacte(p_socio_id uuid, p_desde date, p_hasta date) TO authenticated;
GRANT ALL ON FUNCTION public.fn_movimientos_ctacte(p_socio_id uuid, p_desde date, p_hasta date) TO service_role;


--
-- Name: FUNCTION fn_movimientos_ctacte_todos(p_periodo_id uuid, p_socio_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_movimientos_ctacte_todos(p_periodo_id uuid, p_socio_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_movimientos_ctacte_todos(p_periodo_id uuid, p_socio_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_movimientos_ctacte_todos(p_periodo_id uuid, p_socio_id uuid) TO service_role;


--
-- Name: FUNCTION fn_mvp_clientes_creado_por_inmutable(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_mvp_clientes_creado_por_inmutable() TO anon;
GRANT ALL ON FUNCTION public.fn_mvp_clientes_creado_por_inmutable() TO authenticated;
GRANT ALL ON FUNCTION public.fn_mvp_clientes_creado_por_inmutable() TO service_role;


--
-- Name: FUNCTION fn_nombre_socio(p_socio_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_nombre_socio(p_socio_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_nombre_socio(p_socio_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_nombre_socio(p_socio_id uuid) TO service_role;


--
-- Name: FUNCTION fn_periodo_vigente(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_periodo_vigente() TO anon;
GRANT ALL ON FUNCTION public.fn_periodo_vigente() TO authenticated;
GRANT ALL ON FUNCTION public.fn_periodo_vigente() TO service_role;


--
-- Name: FUNCTION fn_periodo_vigente_id(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_periodo_vigente_id() TO anon;
GRANT ALL ON FUNCTION public.fn_periodo_vigente_id() TO authenticated;
GRANT ALL ON FUNCTION public.fn_periodo_vigente_id() TO service_role;


--
-- Name: FUNCTION fn_precierre_estado(p_periodo_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_precierre_estado(p_periodo_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_precierre_estado(p_periodo_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_precierre_estado(p_periodo_id uuid) TO service_role;


--
-- Name: FUNCTION fn_preview_cierre(p_periodo_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_preview_cierre(p_periodo_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_preview_cierre(p_periodo_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_preview_cierre(p_periodo_id uuid) TO service_role;


--
-- Name: FUNCTION fn_rango_fecha_operacion(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.fn_rango_fecha_operacion() FROM PUBLIC;
GRANT ALL ON FUNCTION public.fn_rango_fecha_operacion() TO authenticated;
GRANT ALL ON FUNCTION public.fn_rango_fecha_operacion() TO service_role;


--
-- Name: FUNCTION fn_registrar_adelanto(p_caja_central uuid, p_socio_id uuid, p_monto numeric, p_fecha date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_registrar_adelanto(p_caja_central uuid, p_socio_id uuid, p_monto numeric, p_fecha date) TO anon;
GRANT ALL ON FUNCTION public.fn_registrar_adelanto(p_caja_central uuid, p_socio_id uuid, p_monto numeric, p_fecha date) TO authenticated;
GRANT ALL ON FUNCTION public.fn_registrar_adelanto(p_caja_central uuid, p_socio_id uuid, p_monto numeric, p_fecha date) TO service_role;


--
-- Name: FUNCTION fn_registrar_aporte(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_registrar_aporte(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date) TO anon;
GRANT ALL ON FUNCTION public.fn_registrar_aporte(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date) TO authenticated;
GRANT ALL ON FUNCTION public.fn_registrar_aporte(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date) TO service_role;


--
-- Name: FUNCTION fn_registrar_cobro_venta(p_venta_id uuid, p_socio_cobrador_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_registrar_cobro_venta(p_venta_id uuid, p_socio_cobrador_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_registrar_cobro_venta(p_venta_id uuid, p_socio_cobrador_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_registrar_cobro_venta(p_venta_id uuid, p_socio_cobrador_id uuid) TO service_role;


--
-- Name: FUNCTION fn_registrar_egreso(p_egreso_id uuid, p_caja_id uuid, p_monto numeric); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_registrar_egreso(p_egreso_id uuid, p_caja_id uuid, p_monto numeric) TO anon;
GRANT ALL ON FUNCTION public.fn_registrar_egreso(p_egreso_id uuid, p_caja_id uuid, p_monto numeric) TO authenticated;
GRANT ALL ON FUNCTION public.fn_registrar_egreso(p_egreso_id uuid, p_caja_id uuid, p_monto numeric) TO service_role;


--
-- Name: FUNCTION fn_registrar_entrega(p_venta_id uuid, p_monto numeric); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_registrar_entrega(p_venta_id uuid, p_monto numeric) TO anon;
GRANT ALL ON FUNCTION public.fn_registrar_entrega(p_venta_id uuid, p_monto numeric) TO authenticated;
GRANT ALL ON FUNCTION public.fn_registrar_entrega(p_venta_id uuid, p_monto numeric) TO service_role;


--
-- Name: FUNCTION fn_registrar_ingreso(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_registrar_ingreso(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date) TO anon;
GRANT ALL ON FUNCTION public.fn_registrar_ingreso(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date) TO authenticated;
GRANT ALL ON FUNCTION public.fn_registrar_ingreso(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date) TO service_role;


--
-- Name: FUNCTION fn_registrar_prestamo_socio(p_caja_origen_id uuid, p_caja_destino_id uuid, p_monto numeric, p_observaciones text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_registrar_prestamo_socio(p_caja_origen_id uuid, p_caja_destino_id uuid, p_monto numeric, p_observaciones text) TO anon;
GRANT ALL ON FUNCTION public.fn_registrar_prestamo_socio(p_caja_origen_id uuid, p_caja_destino_id uuid, p_monto numeric, p_observaciones text) TO authenticated;
GRANT ALL ON FUNCTION public.fn_registrar_prestamo_socio(p_caja_origen_id uuid, p_caja_destino_id uuid, p_monto numeric, p_observaciones text) TO service_role;


--
-- Name: FUNCTION fn_registrar_retiro(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_registrar_retiro(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date) TO anon;
GRANT ALL ON FUNCTION public.fn_registrar_retiro(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date) TO authenticated;
GRANT ALL ON FUNCTION public.fn_registrar_retiro(p_caja_id uuid, p_monto numeric, p_socio_id uuid, p_fecha date) TO service_role;


--
-- Name: FUNCTION fn_registrar_transferencia(p_caja_origen_id uuid, p_caja_destino_id uuid, p_monto numeric, p_fecha timestamp with time zone, p_notas text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_registrar_transferencia(p_caja_origen_id uuid, p_caja_destino_id uuid, p_monto numeric, p_fecha timestamp with time zone, p_notas text) TO authenticated;
GRANT ALL ON FUNCTION public.fn_registrar_transferencia(p_caja_origen_id uuid, p_caja_destino_id uuid, p_monto numeric, p_fecha timestamp with time zone, p_notas text) TO service_role;


--
-- Name: FUNCTION fn_rendir_caja_socio(p_efectivo numeric); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_rendir_caja_socio(p_efectivo numeric) TO anon;
GRANT ALL ON FUNCTION public.fn_rendir_caja_socio(p_efectivo numeric) TO authenticated;
GRANT ALL ON FUNCTION public.fn_rendir_caja_socio(p_efectivo numeric) TO service_role;


--
-- Name: FUNCTION fn_rendir_dia(p_venta_ids uuid[]); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.fn_rendir_dia(p_venta_ids uuid[]) FROM PUBLIC;
GRANT ALL ON FUNCTION public.fn_rendir_dia(p_venta_ids uuid[]) TO authenticated;
GRANT ALL ON FUNCTION public.fn_rendir_dia(p_venta_ids uuid[]) TO service_role;


--
-- Name: FUNCTION fn_rendir_dia_administrativo(p_repartidor_id uuid, p_venta_ids uuid[]); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.fn_rendir_dia_administrativo(p_repartidor_id uuid, p_venta_ids uuid[]) FROM PUBLIC;
GRANT ALL ON FUNCTION public.fn_rendir_dia_administrativo(p_repartidor_id uuid, p_venta_ids uuid[]) TO authenticated;
GRANT ALL ON FUNCTION public.fn_rendir_dia_administrativo(p_repartidor_id uuid, p_venta_ids uuid[]) TO service_role;


--
-- Name: FUNCTION fn_saldo_caja_a_fecha(p_caja_id uuid, p_fecha date); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.fn_saldo_caja_a_fecha(p_caja_id uuid, p_fecha date) FROM PUBLIC;
GRANT ALL ON FUNCTION public.fn_saldo_caja_a_fecha(p_caja_id uuid, p_fecha date) TO service_role;


--
-- Name: FUNCTION fn_saldo_neto_periodo(p_caja_id uuid, p_periodo_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_saldo_neto_periodo(p_caja_id uuid, p_periodo_id uuid) TO anon;
GRANT ALL ON FUNCTION public.fn_saldo_neto_periodo(p_caja_id uuid, p_periodo_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.fn_saldo_neto_periodo(p_caja_id uuid, p_periodo_id uuid) TO service_role;


--
-- Name: FUNCTION fn_socio_actual(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_socio_actual() TO anon;
GRANT ALL ON FUNCTION public.fn_socio_actual() TO authenticated;
GRANT ALL ON FUNCTION public.fn_socio_actual() TO service_role;


--
-- Name: FUNCTION fn_test_conexion(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_test_conexion() TO anon;
GRANT ALL ON FUNCTION public.fn_test_conexion() TO authenticated;
GRANT ALL ON FUNCTION public.fn_test_conexion() TO service_role;


--
-- Name: FUNCTION fn_toggle_online(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_toggle_online() TO anon;
GRANT ALL ON FUNCTION public.fn_toggle_online() TO authenticated;
GRANT ALL ON FUNCTION public.fn_toggle_online() TO service_role;


--
-- Name: FUNCTION fn_ts_desde_fecha_local(p_fecha date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_ts_desde_fecha_local(p_fecha date) TO anon;
GRANT ALL ON FUNCTION public.fn_ts_desde_fecha_local(p_fecha date) TO authenticated;
GRANT ALL ON FUNCTION public.fn_ts_desde_fecha_local(p_fecha date) TO service_role;


--
-- Name: FUNCTION fn_validar_operador_no_repartidor(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.fn_validar_operador_no_repartidor() TO anon;
GRANT ALL ON FUNCTION public.fn_validar_operador_no_repartidor() TO authenticated;
GRANT ALL ON FUNCTION public.fn_validar_operador_no_repartidor() TO service_role;


--
-- Name: FUNCTION get_user_rol(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_rol() TO anon;
GRANT ALL ON FUNCTION public.get_user_rol() TO authenticated;
GRANT ALL ON FUNCTION public.get_user_rol() TO service_role;


--
-- Name: FUNCTION handle_new_user(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.handle_new_user() TO anon;
GRANT ALL ON FUNCTION public.handle_new_user() TO authenticated;
GRANT ALL ON FUNCTION public.handle_new_user() TO service_role;


--
-- Name: FUNCTION handle_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.handle_updated_at() TO anon;
GRANT ALL ON FUNCTION public.handle_updated_at() TO authenticated;
GRANT ALL ON FUNCTION public.handle_updated_at() TO service_role;


--
-- Name: FUNCTION rls_auto_enable(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.rls_auto_enable() TO anon;
GRANT ALL ON FUNCTION public.rls_auto_enable() TO authenticated;
GRANT ALL ON FUNCTION public.rls_auto_enable() TO service_role;


--
-- Name: FUNCTION set_updated_at(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_updated_at() TO anon;
GRANT ALL ON FUNCTION public.set_updated_at() TO authenticated;
GRANT ALL ON FUNCTION public.set_updated_at() TO service_role;


--
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;


--
-- Name: FUNCTION broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO postgres;
GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO dashboard_user;


--
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;


--
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) TO service_role;


--
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;


--
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;


--
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;


--
-- Name: FUNCTION send(payload jsonb, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION send_binary(payload bytea, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;


--
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;


--
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO postgres;
GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;


--
-- Name: FUNCTION wal2json_escape_identifier(name text); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.wal2json_escape_identifier(name text) TO postgres;
GRANT ALL ON FUNCTION realtime.wal2json_escape_identifier(name text) TO dashboard_user;


--
-- Name: FUNCTION _crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO service_role;


--
-- Name: FUNCTION create_secret(new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: FUNCTION update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- Name: TABLE custom_oauth_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.custom_oauth_providers TO postgres;
GRANT ALL ON TABLE auth.custom_oauth_providers TO dashboard_user;


--
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- Name: TABLE oauth_authorizations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_authorizations TO postgres;
GRANT ALL ON TABLE auth.oauth_authorizations TO dashboard_user;


--
-- Name: TABLE oauth_client_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_client_states TO postgres;
GRANT ALL ON TABLE auth.oauth_client_states TO dashboard_user;


--
-- Name: TABLE oauth_clients; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_clients TO postgres;
GRANT ALL ON TABLE auth.oauth_clients TO dashboard_user;


--
-- Name: TABLE oauth_consents; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_consents TO postgres;
GRANT ALL ON TABLE auth.oauth_consents TO dashboard_user;


--
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- Name: TABLE webauthn_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.webauthn_challenges TO postgres;
GRANT ALL ON TABLE auth.webauthn_challenges TO dashboard_user;


--
-- Name: TABLE webauthn_credentials; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.webauthn_credentials TO postgres;
GRANT ALL ON TABLE auth.webauthn_credentials TO dashboard_user;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements TO dashboard_user;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements_info FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO dashboard_user;


--
-- Name: TABLE mvp_cajas; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_cajas TO anon;
GRANT ALL ON TABLE public.mvp_cajas TO authenticated;
GRANT ALL ON TABLE public.mvp_cajas TO service_role;


--
-- Name: TABLE mvp_cierre_detalle; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_cierre_detalle TO anon;
GRANT ALL ON TABLE public.mvp_cierre_detalle TO authenticated;
GRANT ALL ON TABLE public.mvp_cierre_detalle TO service_role;


--
-- Name: TABLE mvp_cierre_resumen; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_cierre_resumen TO anon;
GRANT ALL ON TABLE public.mvp_cierre_resumen TO authenticated;
GRANT ALL ON TABLE public.mvp_cierre_resumen TO service_role;


--
-- Name: TABLE mvp_cierres; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_cierres TO anon;
GRANT ALL ON TABLE public.mvp_cierres TO authenticated;
GRANT ALL ON TABLE public.mvp_cierres TO service_role;


--
-- Name: TABLE mvp_clientes; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_clientes TO anon;
GRANT ALL ON TABLE public.mvp_clientes TO authenticated;
GRANT ALL ON TABLE public.mvp_clientes TO service_role;


--
-- Name: TABLE mvp_config_seguridad; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_config_seguridad TO service_role;


--
-- Name: TABLE mvp_ctacte; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_ctacte TO anon;
GRANT ALL ON TABLE public.mvp_ctacte TO authenticated;
GRANT ALL ON TABLE public.mvp_ctacte TO service_role;


--
-- Name: TABLE mvp_egresos; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_egresos TO anon;
GRANT ALL ON TABLE public.mvp_egresos TO authenticated;
GRANT ALL ON TABLE public.mvp_egresos TO service_role;


--
-- Name: TABLE mvp_movimientos_caja; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_movimientos_caja TO anon;
GRANT ALL ON TABLE public.mvp_movimientos_caja TO authenticated;
GRANT ALL ON TABLE public.mvp_movimientos_caja TO service_role;


--
-- Name: TABLE mvp_operacion_caja; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_operacion_caja TO anon;
GRANT ALL ON TABLE public.mvp_operacion_caja TO authenticated;
GRANT ALL ON TABLE public.mvp_operacion_caja TO service_role;


--
-- Name: SEQUENCE mvp_operacion_caja_nro_comprobante_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.mvp_operacion_caja_nro_comprobante_seq TO anon;
GRANT ALL ON SEQUENCE public.mvp_operacion_caja_nro_comprobante_seq TO authenticated;
GRANT ALL ON SEQUENCE public.mvp_operacion_caja_nro_comprobante_seq TO service_role;


--
-- Name: TABLE mvp_productos; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_productos TO anon;
GRANT ALL ON TABLE public.mvp_productos TO authenticated;
GRANT ALL ON TABLE public.mvp_productos TO service_role;


--
-- Name: TABLE mvp_proveedores; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_proveedores TO anon;
GRANT ALL ON TABLE public.mvp_proveedores TO authenticated;
GRANT ALL ON TABLE public.mvp_proveedores TO service_role;


--
-- Name: TABLE mvp_reglas_negocio; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_reglas_negocio TO anon;
GRANT ALL ON TABLE public.mvp_reglas_negocio TO authenticated;
GRANT ALL ON TABLE public.mvp_reglas_negocio TO service_role;


--
-- Name: TABLE mvp_rendiciones; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_rendiciones TO anon;
GRANT ALL ON TABLE public.mvp_rendiciones TO authenticated;
GRANT ALL ON TABLE public.mvp_rendiciones TO service_role;


--
-- Name: TABLE mvp_repartidores; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_repartidores TO anon;
GRANT ALL ON TABLE public.mvp_repartidores TO authenticated;
GRANT ALL ON TABLE public.mvp_repartidores TO service_role;


--
-- Name: TABLE mvp_socios; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_socios TO anon;
GRANT ALL ON TABLE public.mvp_socios TO authenticated;
GRANT ALL ON TABLE public.mvp_socios TO service_role;


--
-- Name: TABLE mvp_system_status; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_system_status TO anon;
GRANT ALL ON TABLE public.mvp_system_status TO authenticated;
GRANT ALL ON TABLE public.mvp_system_status TO service_role;


--
-- Name: TABLE mvp_tipo_operaciones; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_tipo_operaciones TO anon;
GRANT ALL ON TABLE public.mvp_tipo_operaciones TO authenticated;
GRANT ALL ON TABLE public.mvp_tipo_operaciones TO service_role;


--
-- Name: SEQUENCE mvp_tipo_operaciones_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.mvp_tipo_operaciones_id_seq TO anon;
GRANT ALL ON SEQUENCE public.mvp_tipo_operaciones_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.mvp_tipo_operaciones_id_seq TO service_role;


--
-- Name: TABLE mvp_users; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_users TO anon;
GRANT ALL ON TABLE public.mvp_users TO authenticated;
GRANT ALL ON TABLE public.mvp_users TO service_role;


--
-- Name: TABLE mvp_ventas; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_ventas TO anon;
GRANT ALL ON TABLE public.mvp_ventas TO authenticated;
GRANT ALL ON TABLE public.mvp_ventas TO service_role;


--
-- Name: TABLE mvp_ventas_bajas; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_ventas_bajas TO anon;
GRANT ALL ON TABLE public.mvp_ventas_bajas TO authenticated;
GRANT ALL ON TABLE public.mvp_ventas_bajas TO service_role;


--
-- Name: TABLE mvp_ventas_detalle; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.mvp_ventas_detalle TO anon;
GRANT ALL ON TABLE public.mvp_ventas_detalle TO authenticated;
GRANT ALL ON TABLE public.mvp_ventas_detalle TO service_role;


--
-- Name: TABLE v_ventas_consulta; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_ventas_consulta TO anon;
GRANT ALL ON TABLE public.v_ventas_consulta TO authenticated;
GRANT ALL ON TABLE public.v_ventas_consulta TO service_role;


--
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.messages TO postgres;
GRANT ALL ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;


--
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.subscription TO postgres;
GRANT ALL ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;


--
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;


--
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE storage.buckets FROM supabase_storage_admin;
GRANT ALL ON TABLE storage.buckets TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO postgres WITH GRANT OPTION;


--
-- Name: TABLE buckets_analytics; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets_analytics TO service_role;
GRANT ALL ON TABLE storage.buckets_analytics TO authenticated;
GRANT ALL ON TABLE storage.buckets_analytics TO anon;


--
-- Name: TABLE buckets_vectors; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE storage.buckets_vectors TO service_role;
GRANT SELECT ON TABLE storage.buckets_vectors TO authenticated;
GRANT SELECT ON TABLE storage.buckets_vectors TO anon;


--
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE storage.objects FROM supabase_storage_admin;
GRANT ALL ON TABLE storage.objects TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO postgres WITH GRANT OPTION;


--
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;


--
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;


--
-- Name: TABLE vector_indexes; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE storage.vector_indexes TO service_role;
GRANT SELECT ON TABLE storage.vector_indexes TO authenticated;
GRANT SELECT ON TABLE storage.vector_indexes TO anon;


--
-- Name: TABLE secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.secrets TO service_role;


--
-- Name: TABLE decrypted_secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.decrypted_secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.decrypted_secrets TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO service_role;


--
-- Name: ensure_rls; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER ensure_rls ON ddl_command_end
         WHEN TAG IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
   EXECUTE FUNCTION public.rls_auto_enable();


ALTER EVENT TRIGGER ensure_rls OWNER TO postgres;

--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO supabase_admin;

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

--
-- PostgreSQL database dump complete
--

\unrestrict VZhSrn4I2mReAABgHbsvLfw7glc2P1q9umfRYo2cuMqDeGIvndlVp7lphbDnaNu

